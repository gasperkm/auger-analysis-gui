#include "AugerUpTime.h"
#include <iostream>
#include <cstdlib>
using namespace std;

int main(int argc, char **argv) {

  if ( argc < 3 ) {
    cout << " usage: dumpUpTimes <uptimeFileName> <gpsTimes> " << endl;
    return 1;
  }

  AugerUpTime upTime(argv[1],NULL);

  int i=2;
  while ( i<argc ) {

    unsigned int gpsTime = atoi(argv[i]);
    cout << "\n gps = " << gpsTime << "\n" << endl;
    upTime.Print(gpsTime);
    cout << endl;
    i++;
  }
}

