#include <ACColumn.h>

using namespace std;

using namespace ADST;
using namespace ADST::AC;

/**********************************************************************/
ACColumn::ACColumn()
  : fName(""), fUnit("-"), fDescription(""), fWidth(0)
{
}

/**********************************************************************/
ACColumn::ACColumn(const std::string& name, const std::string& unit,
                   const std::string& descr, const unsigned int width)
  : fName(name), fUnit(unit), fDescription(descr), fWidth(width)
{
}
/**********************************************************************/
ACColumn::~ACColumn()
{
}

