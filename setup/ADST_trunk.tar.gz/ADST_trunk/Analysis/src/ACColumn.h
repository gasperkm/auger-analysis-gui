#ifndef __ACColumn_h
#define __ACColumn_h

#include <string>
#include <TObject.h>

class RecEvent;

namespace ADST {
  namespace AC {
    class ACColumn {
    public:
      ACColumn();
      ACColumn(const std::string& name, const std::string& unit,
               const std::string& descr, const unsigned int width);
      virtual ~ACColumn();

      const std::string& GetName() const { return fName; }
      const std::string& GetUnit() const { return fUnit; }
      const std::string& GetDescription() const { return fDescription; }
      unsigned int GetWidth() const { return fWidth; }

    private:
      std::string fName;
      std::string fUnit;
      std::string fDescription;
      unsigned int fWidth;
    };
  } // end namespace ADST::AC
} // end namespace ADST

#endif
