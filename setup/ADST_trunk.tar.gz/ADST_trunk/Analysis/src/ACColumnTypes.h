#ifndef _ADST_AC_ACColumnTypes_h_
#define _ADST_AC_ACColumnTypes_h_
// WARNING: This file was auto-generated. DO NOT EDIT!
//          Edit the AsciiConverter.yml file instead!

#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <iomanip>
#include <RecEventFile.h>
#include <RecEvent.h>
#include <FDEvent.h>
#include <SDEvent.h>
#include <DetectorGeometry.h>
#include <ACColumn.h>
#include <ACGlobalColumn.h>
#include <ACFDColumn.h>
#include <TBits.h>
#include <TVector3.h>


namespace ADST {
  namespace AC {

    // Unit conversion section
    const double kDeg2Rad = (3.14159265358979323846/180.0);
    const double kRad2Deg = 1./kDeg2Rad;

    // Column 'SdId'
    class ACColumnSdId : public ACGlobalColumn {
    public:
      ACColumnSdId()
       : ACGlobalColumn("SdId", "-", "SD event id", 11) {}
      virtual ~ACColumnSdId() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        outs << sdevent.GetEventId();
      }
    };

    // Column 'AugerId'
    class ACColumnAugerId : public ACGlobalColumn {
    public:
      ACColumnAugerId()
       : ACGlobalColumn("AugerId", "-", "event Auger id", 15) {}
      virtual ~ACColumnAugerId() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << event.GetAugerId();
      }
    };

    // Column 'GPSSec'
    class ACColumnSdGPSSecond : public ACGlobalColumn {
    public:
      ACColumnSdGPSSecond()
       : ACGlobalColumn("GPSSec", "s", "SD event GPS second", 11) {}
      virtual ~ACColumnSdGPSSecond() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        outs << sdevent.GetGPSSecond();
      }
    };

    // Column 'GPSNSec'
    class ACColumnSdGPSNanoSecond : public ACGlobalColumn {
    public:
      ACColumnSdGPSNanoSecond()
       : ACGlobalColumn("GPSNSec", "ns", "SD event GPS nanosecond", 11) {}
      virtual ~ACColumnSdGPSNanoSecond() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        outs << sdevent.GetGPSNanoSecond();
      }
    };

    // Column 'BadPeriod'
    class ACColumnBadPeriod : public ACGlobalColumn {
    public:
      ACColumnBadPeriod()
       : ACGlobalColumn("BadPeriod", "-", "SD Bad period id", 11) {}
      virtual ~ACColumnBadPeriod() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        outs << sdevent.GetBadPeriodId();
      }
    };

    // Column 'YYMMDD'
    class ACColumnSdYYMMDD : public ACGlobalColumn {
    public:
      ACColumnSdYYMMDD()
       : ACGlobalColumn("YYMMDD", "-", "event date", 11) {}
      virtual ~ACColumnSdYYMMDD() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        outs << setw(6) << setfill('0');
        outs << sdevent.GetYYMMDD();
      }
    };

    // Column 'HHMMSS'
    class ACColumnSdHHMMSS : public ACGlobalColumn {
    public:
      ACColumnSdHHMMSS()
       : ACGlobalColumn("HHMMSS", "-", "event time", 11) {}
      virtual ~ACColumnSdHHMMSS() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        outs << setw(6) << setfill('0');
        outs << sdevent.GetHHMMSS();
      }
    };

    // Column 'MJD'
    class ACColumnMJD : public ACGlobalColumn {
    public:
      ACColumnMJD()
       : ACGlobalColumn("MJD", "-", "Modified Julian Day", 11) {}
      virtual ~ACColumnMJD() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << event.GetMJD();
      }
    };

    // Column 'T4'
    class ACColumnSdT4 : public ACGlobalColumn {
    public:
      ACColumnSdT4()
       : ACGlobalColumn("T4", "-", "T4 flag", 11) {}
      virtual ~ACColumnSdT4() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        outs << sdevent.GetT4Trigger();
      }
    };

    // Column 'T5'
    class ACColumnSdT5 : public ACGlobalColumn {
    public:
      ACColumnSdT5()
       : ACGlobalColumn("T5", "-", "T5 flag (lightning = 10)", 11) {}
      virtual ~ACColumnSdT5() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        if (sdevent.IsLightning())
          outs << 10;
        else
          outs << sdevent.GetT5Trigger();
      }
    };

    // Column 'LDFStat'
    class ACColumnLDFStatus : public ACGlobalColumn {
    public:
      ACColumnLDFStatus()
       : ACGlobalColumn("LDFStat", "-", "LDF Status", 11) {}
      virtual ~ACColumnLDFStatus() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(1);
        outs << sdrec.GetLDF().GetLDFStatus();
      }
    };

    // Column 'Energy'
    class ACColumnSdEnergy : public ACGlobalColumn {
    public:
      ACColumnSdEnergy()
       : ACGlobalColumn("Energy", "EeV", "SD energy", 11) {}
      virtual ~ACColumnSdEnergy() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetEnergy()/1.e18;
      }
    };

    // Column 'EnergyErr'
    class ACColumnSdEnergyUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdEnergyUncertainty()
       : ACGlobalColumn("EnergyErr", "EeV", "SD energy uncertainty", 11) {}
      virtual ~ACColumnSdEnergyUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetEnergyError()/1.e18;
      }
    };

    // Column 'S1000'
    class ACColumnS1000 : public ACGlobalColumn {
    public:
      ACColumnS1000()
       : ACGlobalColumn("S1000", "VEM", "S1000", 11) {}
      virtual ~ACColumnS1000() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetLDF().GetS1000();
      }
    };

    // Column 'S1000Err'
    class ACColumnS1000Uncertainty : public ACGlobalColumn {
    public:
      ACColumnS1000Uncertainty()
       : ACGlobalColumn("S1000Err", "VEM", "S1000 uncertainty", 11) {}
      virtual ~ACColumnS1000Uncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetLDF().GetS1000Error();
      }
    };

    // Column 'S1000Sys'
    class ACColumnS1000BetaSystematics : public ACGlobalColumn {
    public:
      ACColumnS1000BetaSystematics()
       : ACGlobalColumn("S1000Sys", "VEM", "S(1000) systematics due to beta assumption", 11) {}
      virtual ~ACColumnS1000BetaSystematics() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetLDF().GetS1000BetaSys();
      }
    };

    // Column 'Theta'
    class ACColumnSdThetaCoreCS : public ACGlobalColumn {
    public:
      ACColumnSdThetaCoreCS()
       : ACGlobalColumn("Theta", "degree", "SD theta in core coordinate system", 11) {}
      virtual ~ACColumnSdThetaCoreCS() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetAxisCoreCS().Theta()*kRad2Deg;
      }
    };

    // Column 'ThetaErr'
    class ACColumnSdThetaCoreCSUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdThetaCoreCSUncertainty()
       : ACGlobalColumn("ThetaErr", "degree", "Uncertainty on SD theta in core coordinate system", 11) {}
      virtual ~ACColumnSdThetaCoreCSUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetZenithError()*kRad2Deg;
      }
    };

    // Column 'Phi'
    class ACColumnSdPhiCoreCS : public ACGlobalColumn {
    public:
      ACColumnSdPhiCoreCS()
       : ACGlobalColumn("Phi", "degree", "SD phi in core coordinate system", 11) {}
      virtual ~ACColumnSdPhiCoreCS() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetAxisCoreCS().Phi()*kRad2Deg;
      }
    };

    // Column 'PhiErr'
    class ACColumnSdPhiCoreCSUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdPhiCoreCSUncertainty()
       : ACGlobalColumn("PhiErr", "degree", "Uncertainty on SD phi in core coordinate system", 11) {}
      virtual ~ACColumnSdPhiCoreCSUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetAzimuthError()*kRad2Deg;
      }
    };

    // Column 'ThetaSite'
    class ACColumnSdThetaSiteCS : public ACGlobalColumn {
    public:
      ACColumnSdThetaSiteCS()
       : ACGlobalColumn("ThetaSite", "degree", "SD theta in site coordinate system", 11) {}
      virtual ~ACColumnSdThetaSiteCS() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetAxisSiteCS().Theta()*kRad2Deg;
      }
    };

    // Column 'PhiSite'
    class ACColumnSdPhiSiteCS : public ACGlobalColumn {
    public:
      ACColumnSdPhiSiteCS()
       : ACGlobalColumn("PhiSite", "degree", "SD phi in site coordinate system", 11) {}
      virtual ~ACColumnSdPhiSiteCS() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetAxisSiteCS().Phi()*kRad2Deg;
      }
    };

    // Column 'NCand'
    class ACColumnCandidateStations : public ACGlobalColumn {
    public:
      ACColumnCandidateStations()
       : ACGlobalColumn("NCand", "-", "No. of stations used in the reconstruction", 11) {}
      virtual ~ACColumnCandidateStations() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        outs << sdevent.GetNumberOfCandidates();
      }
    };

    // Column 'NAct'
    class ACColumnActiveStations : public ACGlobalColumn {
    public:
      ACColumnActiveStations()
       : ACGlobalColumn("NAct", "-", "No. of active stations", 11) {}
      virtual ~ACColumnActiveStations() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        outs << sdevent.GetNumberOfCandidates(true)+sdevent.GetNoOfAccidentalStations();
      }
    };

    // Column 'NWork'
    class ACColumnStationsInDAQ : public ACGlobalColumn {
    public:
      ACColumnStationsInDAQ()
       : ACGlobalColumn("NWork", "-", "No. of stations in DAQ", 11) {}
      virtual ~ACColumnStationsInDAQ() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << 0.;
      }
    };

    // Column 'Xcore'
    class ACColumnSdCoreSiteCSX : public ACGlobalColumn {
    public:
      ACColumnSdCoreSiteCSX()
       : ACGlobalColumn("Xcore", "m", "Core X in site coordinate system", 11) {}
      virtual ~ACColumnSdCoreSiteCSX() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(1);
        outs << sdrec.GetCoreSiteCS().X();
      }
    };

    // Column 'Ycore'
    class ACColumnSdCoreSiteCSY : public ACGlobalColumn {
    public:
      ACColumnSdCoreSiteCSY()
       : ACGlobalColumn("Ycore", "m", "Core Y in site coordinate system", 11) {}
      virtual ~ACColumnSdCoreSiteCSY() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(1);
        outs << sdrec.GetCoreSiteCS().Y();
      }
    };

    // Column 'Zcore'
    class ACColumnSdCoreSiteCSZ : public ACGlobalColumn {
    public:
      ACColumnSdCoreSiteCSZ()
       : ACGlobalColumn("Zcore", "m", "Core altitude in site coordinate system", 11) {}
      virtual ~ACColumnSdCoreSiteCSZ() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(1);
        outs << sdrec.GetCoreSiteCS().Z();
      }
    };

    // Column 'XcoreErr'
    class ACColumnSdCoreSiteCSXUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdCoreSiteCSXUncertainty()
       : ACGlobalColumn("XcoreErr", "m", "Core X uncertainty in site coordinate system", 11) {}
      virtual ~ACColumnSdCoreSiteCSXUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetCoreEastingError();
      }
    };

    // Column 'YcoreErr'
    class ACColumnSdCoreSiteCSYUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdCoreSiteCSYUncertainty()
       : ACGlobalColumn("YcoreErr", "m", "Core Y uncertainty in site coordinate system", 11) {}
      virtual ~ACColumnSdCoreSiteCSYUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetCoreNorthingError();
      }
    };

    // Column 'ZcoreErr'
    class ACColumnSdCoreSiteCSZUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdCoreSiteCSZUncertainty()
       : ACGlobalColumn("ZcoreErr", "m", "Core Z uncertainty in site coordinate system (altitude)", 11) {}
      virtual ~ACColumnSdCoreSiteCSZUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << 0.;
      }
    };

    // Column 'Easting'
    class ACColumnSdCoreUTMCSX : public ACGlobalColumn {
    public:
      ACColumnSdCoreUTMCSX()
       : ACGlobalColumn("Easting", "m", "Core X (easting) in UTM coordinate system", 11) {}
      virtual ~ACColumnSdCoreUTMCSX() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(1);
        outs << sdrec.GetCoreUTMCS().X();
      }
    };

    // Column 'Northing'
    class ACColumnSdCoreUTMCSY : public ACGlobalColumn {
    public:
      ACColumnSdCoreUTMCSY()
       : ACGlobalColumn("Northing", "m", "Core Y (northing) in UTM coordinate system", 11) {}
      virtual ~ACColumnSdCoreUTMCSY() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(1);
        outs << sdrec.GetCoreUTMCS().Y();
      }
    };

    // Column 'RA'
    class ACColumnSdRA : public ACGlobalColumn {
    public:
      ACColumnSdRA()
       : ACGlobalColumn("RA", "degree", "SD right ascension", 11) {}
      virtual ~ACColumnSdRA() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetRightAscension()*kRad2Deg;
      }
    };

    // Column 'Dec'
    class ACColumnSdDec : public ACGlobalColumn {
    public:
      ACColumnSdDec()
       : ACGlobalColumn("Dec", "degree", "SD declination", 11) {}
      virtual ~ACColumnSdDec() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetDeclination()*kRad2Deg;
      }
    };

    // Column 'RAErr'
    class ACColumnSdRAUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdRAUncertainty()
       : ACGlobalColumn("RAErr", "degree", "SD right ascension uncertainty", 11) {}
      virtual ~ACColumnSdRAUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetRightAscensionError()*kRad2Deg;
      }
    };

    // Column 'DecErr'
    class ACColumnSdDecUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdDecUncertainty()
       : ACGlobalColumn("DecErr", "degree", "SD declination uncertainty", 11) {}
      virtual ~ACColumnSdDecUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetDeclinationError()*kRad2Deg;
      }
    };

    // Column 'GalLat'
    class ACColumnSdGalacticLatitude : public ACGlobalColumn {
    public:
      ACColumnSdGalacticLatitude()
       : ACGlobalColumn("GalLat", "degree", "SD galactic latitude (J2000)", 11) {}
      virtual ~ACColumnSdGalacticLatitude() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetGalacticLatitude()*kRad2Deg;
      }
    };

    // Column 'GalLong'
    class ACColumnSdGalacticLongitude : public ACGlobalColumn {
    public:
      ACColumnSdGalacticLongitude()
       : ACGlobalColumn("GalLong", "degree", "SD galactic longitude (J2000)", 11) {}
      virtual ~ACColumnSdGalacticLongitude() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetGalacticLongitude()*kRad2Deg;
      }
    };

    // Column 'GalLatErr'
    class ACColumnSdGalacticLatitudeUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdGalacticLatitudeUncertainty()
       : ACGlobalColumn("GalLatErr", "degree", "SD galactic latitude (J2000) uncertainty", 11) {}
      virtual ~ACColumnSdGalacticLatitudeUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetGalacticLatitudeError()*kRad2Deg;
      }
    };

    // Column 'GalLongErr'
    class ACColumnSdGalacticLongitudeUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdGalacticLongitudeUncertainty()
       : ACGlobalColumn("GalLongErr", "degree", "SD galactic longitude (J2000) uncertainty", 11) {}
      virtual ~ACColumnSdGalacticLongitudeUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetGalacticLongitudeError()*kRad2Deg;
      }
    };

    // Column 'PlaneChi2'
    class ACColumnSdPlaneChi2 : public ACGlobalColumn {
    public:
      ACColumnSdPlaneChi2()
       : ACGlobalColumn("PlaneChi2", "-", "$\\chi^2$ from the SD plane fit", 11) {}
      virtual ~ACColumnSdPlaneChi2() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetAngleChi2();
      }
    };

    // Column 'PlaneNdf'
    class ACColumnSdPlaneNDoF : public ACGlobalColumn {
    public:
      ACColumnSdPlaneNDoF()
       : ACGlobalColumn("PlaneNdf", "-", "Number of degrees of freedom in the SD plane fit", 11) {}
      virtual ~ACColumnSdPlaneNDoF() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(0);
        outs << sdrec.GetAngleNDoF();
      }
    };

    // Column 'Beta'
    class ACColumnSdBeta : public ACGlobalColumn {
    public:
      ACColumnSdBeta()
       : ACGlobalColumn("Beta", "-", "SD LDF beta parameter (slope)", 11) {}
      virtual ~ACColumnSdBeta() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetLDF().GetBeta();
      }
    };

    // Column 'BetaErr'
    class ACColumnSdBetaUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdBetaUncertainty()
       : ACGlobalColumn("BetaErr", "-", "SD LDF beta parameter (slope) uncertainty", 11) {}
      virtual ~ACColumnSdBetaUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetLDF().GetBetaError();
      }
    };

    // Column 'Gamma'
    class ACColumnSdGamma : public ACGlobalColumn {
    public:
      ACColumnSdGamma()
       : ACGlobalColumn("Gamma", "-", "SD LDF gamma parameter", 11) {}
      virtual ~ACColumnSdGamma() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetLDF().GetGamma();
      }
    };

    // Column 'GammaErr'
    class ACColumnSdGammaUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdGammaUncertainty()
       : ACGlobalColumn("GammaErr", "-", "SD LDF gamma parameter uncertainty", 11) {}
      virtual ~ACColumnSdGammaUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetLDF().GetGammaError();
      }
    };

    // Column 'LDFchi2'
    class ACColumnSdLDFChi2 : public ACGlobalColumn {
    public:
      ACColumnSdLDFChi2()
       : ACGlobalColumn("LDFchi2", "-", "$\\chi^2$ from the SD LDF fit", 11) {}
      virtual ~ACColumnSdLDFChi2() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetLDF().GetLDFChi2();
      }
    };

    // Column 'LDFNdf'
    class ACColumnSdLDFNDoF : public ACGlobalColumn {
    public:
      ACColumnSdLDFNDoF()
       : ACGlobalColumn("LDFNdf", "-", "Number of degrees of freedom in the SD LDF fit", 11) {}
      virtual ~ACColumnSdLDFNDoF() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(0);
        outs << sdrec.GetLDF().GetLDFNdof();
      }
    };

    // Column 'RCurv'
    class ACColumnSdRadiusOfCurvature : public ACGlobalColumn {
    public:
      ACColumnSdRadiusOfCurvature()
       : ACGlobalColumn("RCurv", "km", "SD radius of curvature", 11) {}
      virtual ~ACColumnSdRadiusOfCurvature() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << (sdrec.GetCurvature() ? 1./sdrec.GetCurvature()/1000. : 0.);
      }
    };

    // Column 'RCurvErr'
    class ACColumnSdRadiusOfCurvatureUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdRadiusOfCurvatureUncertainty()
       : ACGlobalColumn("RCurvErr", "km", "Uncertainty on the SD radius of curvature", 11) {}
      virtual ~ACColumnSdRadiusOfCurvatureUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << (sdrec.GetCurvatureError() ? (sdrec.GetCurvatureError() / pow(sdrec.GetCurvature(), 2.)) / 1000. : 0.);
      }
    };

    // Column 'RiseTime'
    class ACColumnSdRiseTime : public ACGlobalColumn {
    public:
      ACColumnSdRiseTime()
       : ACGlobalColumn("RiseTime", "ns", "SD rise time", 11) {}
      virtual ~ACColumnSdRiseTime() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetRiseTimeResults().GetRiseTime1000();
      }
    };

    // Column 'RiseTimeErr'
    class ACColumnSdRiseTimeUncertainty : public ACGlobalColumn {
    public:
      ACColumnSdRiseTimeUncertainty()
       : ACGlobalColumn("RiseTimeErr", "ns", "SD rise time uncertainty", 11) {}
      virtual ~ACColumnSdRiseTimeUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetRiseTimeResults().GetRiseTime1000Error();
      }
    };

    // Column 'TResMean'
    class ACColumnSdTimeResidualMean : public ACGlobalColumn {
    public:
      ACColumnSdTimeResidualMean()
       : ACGlobalColumn("TResMean", "s", "SD time residual mean", 11) {}
      virtual ~ACColumnSdTimeResidualMean() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetTimeResidualMean();
      }
    };

    // Column 'TResSpread'
    class ACColumnSdTimeResidualSpread : public ACGlobalColumn {
    public:
      ACColumnSdTimeResidualSpread()
       : ACGlobalColumn("TResSpread", "s", "SD time residual spread", 11) {}
      virtual ~ACColumnSdTimeResidualSpread() {}

      void Convert(std::ostream& outs, const RecEvent& event)
        const
      {
        using namespace std;
        using namespace ADST;
        const SDEvent& sdevent = event.GetSDEvent();
        const SdRecShower& sdrec = sdevent.GetSdRecShower();
        outs << sdrec.GetTimeResidualSpread();
      }
    };

    // Column 'Eye'
    class ACColumnEyeId : public ACFDColumn {
    public:
      ACColumnEyeId()
       : ACFDColumn("Eye", "-", "FD eye Id", 11) {}
      virtual ~ACColumnEyeId() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << fdevent.GetEyeId();
      }
    };

    // Column 'Run'
    class ACColumnFdRunId : public ACFDColumn {
    public:
      ACColumnFdRunId()
       : ACFDColumn("Run", "-", "FD run Id", 11) {}
      virtual ~ACColumnFdRunId() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << fdevent.GetRunId();
      }
    };

    // Column 'Event'
    class ACColumnFdEventId : public ACFDColumn {
    public:
      ACColumnFdEventId()
       : ACFDColumn("Event", "-", "FD event Id", 11) {}
      virtual ~ACColumnFdEventId() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << fdevent.GetEventId();
      }
    };

    // Column 'GPSSec'
    class ACColumnFdGPSSecond : public ACFDColumn {
    public:
      ACColumnFdGPSSecond()
       : ACFDColumn("GPSSec", "s", "FD GPS second", 11) {}
      virtual ~ACColumnFdGPSSecond() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << fdevent.GetGPSSecond();
      }
    };

    // Column 'GPSNSec'
    class ACColumnFdGPSNanoSecond : public ACFDColumn {
    public:
      ACColumnFdGPSNanoSecond()
       : ACFDColumn("GPSNSec", "ns", "FD GPS nano second", 11) {}
      virtual ~ACColumnFdGPSNanoSecond() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs <<  setw(9) << setfill('0');
        outs << fdevent.GetGPSNanoSecond();
      }
    };

    // Column 'YYMMDD'
    class ACColumnFdYYMMDD : public ACFDColumn {
    public:
      ACColumnFdYYMMDD()
       : ACFDColumn("YYMMDD", "-", "event date", 11) {}
      virtual ~ACColumnFdYYMMDD() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << setw(6) << setfill('0');
        outs << fdevent.GetYYMMDD();
      }
    };

    // Column 'HHMMSS'
    class ACColumnFdHHMMSS : public ACFDColumn {
    public:
      ACColumnFdHHMMSS()
       : ACFDColumn("HHMMSS", "-", "event time", 11) {}
      virtual ~ACColumnFdHHMMSS() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << setw(6) << setfill('0');
        outs << fdevent.GetHHMMSS();
      }
    };

    // Column 'TelEvtBits'
    class ACColumnFdTelescopesInEvent : public ACFDColumn {
    public:
      ACColumnFdTelescopesInEvent()
       : ACFDColumn("TelEvtBits", "-", "FD telescopes in event", 11) {}
      virtual ~ACColumnFdTelescopesInEvent() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << setw(6) << setfill('0');
        outs << AsciiConverter::TBitsToInt(fdevent.GetMirrorsInEvent());
      }
    };

    // Column 'TelDAQBits'
    class ACColumnFdTelescopesInDAQ : public ACFDColumn {
    public:
      ACColumnFdTelescopesInDAQ()
       : ACFDColumn("TelDAQBits", "-", "FD telescopes in DAQ", 11) {}
      virtual ~ACColumnFdTelescopesInDAQ() {}

      void Convert(std::ostream& outs, const RecEvent& event, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << setw(6) << setfill('0');
        outs << AsciiConverter::TBitsToInt(event.GetDetector().GetMirrorsInDAQ(fdevent.GetEyeId()));
      }
    };

    // Column 'MoonCycle'
    class ACColumnMoonCycle : public ACFDColumn {
    public:
      ACColumnMoonCycle()
       : ACFDColumn("MoonCycle", "-", "Moon cycle since 2004-01-01", 11) {}
      virtual ~ACColumnMoonCycle() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << fdevent.GetMoonCycle();
      }
    };

    // Column 'RecLevel'
    class ACColumnFdRecLevel : public ACFDColumn {
    public:
      ACColumnFdRecLevel()
       : ACFDColumn("RecLevel", "-", "FD reconstruction level", 11) {}
      virtual ~ACColumnFdRecLevel() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << fdevent.GetRecLevel();
      }
    };

    // Column 'NPix'
    class ACColumnFdNumberOfPulsedPixels : public ACFDColumn {
    public:
      ACColumnFdNumberOfPulsedPixels()
       : ACFDColumn("NPix", "-", "Number of pixels with a pulse after FdPulseFinder module", 11) {}
      virtual ~ACColumnFdNumberOfPulsedPixels() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecPixel& fdpix = fdevent.GetFdRecPixel();
        outs << fdpix.GetNumberOfPulsedPixels();
      }
    };

    // Column 'SDPTheta'
    class ACColumnFdSDPTheta : public ACFDColumn {
    public:
      ACColumnFdSDPTheta()
       : ACFDColumn("SDPTheta", "degree", "Zenith angle of SDP normal vector", 11) {}
      virtual ~ACColumnFdSDPTheta() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetSDPTheta()*kRad2Deg;
      }
    };

    // Column 'SDPThetaErr'
    class ACColumnFdSDPThetaUncertainty : public ACFDColumn {
    public:
      ACColumnFdSDPThetaUncertainty()
       : ACFDColumn("SDPThetaErr", "degree", "Uncertainty on zenith angle of SDP normal vector", 11) {}
      virtual ~ACColumnFdSDPThetaUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetSDPThetaError()*kRad2Deg;
      }
    };

    // Column 'SDPPhi'
    class ACColumnFdSDPPhi : public ACFDColumn {
    public:
      ACColumnFdSDPPhi()
       : ACFDColumn("SDPPhi", "degree", "Azimuth angle of SDP normal vector", 11) {}
      virtual ~ACColumnFdSDPPhi() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetSDPPhi()*kRad2Deg;
      }
    };

    // Column 'SDPPhiErr'
    class ACColumnFdSDPPhiUncertainty : public ACFDColumn {
    public:
      ACColumnFdSDPPhiUncertainty()
       : ACFDColumn("SDPPhiErr", "degree", "Uncertainty on azimuth angle of SDP normal vector", 11) {}
      virtual ~ACColumnFdSDPPhiUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetSDPPhiError()*kRad2Deg;
      }
    };

    // Column 'SDPChi2'
    class ACColumnFdSDPChi2 : public ACFDColumn {
    public:
      ACColumnFdSDPChi2()
       : ACFDColumn("SDPChi2", "-", "$\\chi^2$ of SDP fit", 11) {}
      virtual ~ACColumnFdSDPChi2() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetSDPChi2();
      }
    };

    // Column 'SDPNdf'
    class ACColumnFdSDPNDoF : public ACFDColumn {
    public:
      ACColumnFdSDPNDoF()
       : ACFDColumn("SDPNdf", "-", "Number of degrees of freedom in SDP fit", 11) {}
      virtual ~ACColumnFdSDPNDoF() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetSDPNdF();
      }
    };

    // Column 'Rp'
    class ACColumnFdRp : public ACFDColumn {
    public:
      ACColumnFdRp()
       : ACFDColumn("Rp", "m", "Shower impact parameter ($R_p$)", 11) {}
      virtual ~ACColumnFdRp() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetRp();
      }
    };

    // Column 'RpErr'
    class ACColumnFdRpUncertainty : public ACFDColumn {
    public:
      ACColumnFdRpUncertainty()
       : ACFDColumn("RpErr", "m", "Uncertainty on shower impact parameter ($R_p$)", 11) {}
      virtual ~ACColumnFdRpUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetRpError();
      }
    };

    // Column 'Chi0'
    class ACColumnFdChi0 : public ACFDColumn {
    public:
      ACColumnFdChi0()
       : ACFDColumn("Chi0", "degree", "Angle of shower in the SDP ($\\chi_0$)", 11) {}
      virtual ~ACColumnFdChi0() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetChi0()*kRad2Deg;
      }
    };

    // Column 'Chi0Err'
    class ACColumnFdChi0Uncertainty : public ACFDColumn {
    public:
      ACColumnFdChi0Uncertainty()
       : ACFDColumn("Chi0Err", "degree", "Uncertainty on angle of shower in the SDP", 11) {}
      virtual ~ACColumnFdChi0Uncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetChi0Error()*kRad2Deg;
      }
    };

    // Column 'T0'
    class ACColumnFdT0 : public ACFDColumn {
    public:
      ACColumnFdT0()
       : ACFDColumn("T0", "ns", "FD time fit $T_0$", 11) {}
      virtual ~ACColumnFdT0() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetT0();
      }
    };

    // Column 'T0Err'
    class ACColumnFdT0Uncertainty : public ACFDColumn {
    public:
      ACColumnFdT0Uncertainty()
       : ACFDColumn("T0Err", "ns", "Uncertainty on FD time git $T_0$", 11) {}
      virtual ~ACColumnFdT0Uncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetT0Error();
      }
    };

    // Column 'TimeChi2'
    class ACColumnFdTimeFitChi2 : public ACFDColumn {
    public:
      ACColumnFdTimeFitChi2()
       : ACFDColumn("TimeChi2", "-", "Full $\\chi^2$ of FD axis fit", 11) {}
      virtual ~ACColumnFdTimeFitChi2() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetTimeFitChi2();
      }
    };

    // Column 'TimeChi2FD'
    class ACColumnFdTimeFitFdOnlyChi2 : public ACFDColumn {
    public:
      ACColumnFdTimeFitFdOnlyChi2()
       : ACFDColumn("TimeChi2FD", "-", "$\\chi^2$ of FD axis fit (FD only)", 11) {}
      virtual ~ACColumnFdTimeFitFdOnlyChi2() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetTimeFitFDChi2();
      }
    };

    // Column 'TimeNdf'
    class ACColumnFdTimeFitNDoF : public ACFDColumn {
    public:
      ACColumnFdTimeFitNDoF()
       : ACFDColumn("TimeNdf", "-", "Number of degrees of freedom in FD axis fit", 11) {}
      virtual ~ACColumnFdTimeFitNDoF() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetTimeFitNdof();
      }
    };

    // Column 'Easting'
    class ACColumnFdCoreUTMCSX : public ACFDColumn {
    public:
      ACColumnFdCoreUTMCSX()
       : ACFDColumn("Easting", "m", "FD core X (easting) in UTM coordinate system", 11) {}
      virtual ~ACColumnFdCoreUTMCSX() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(1);
        outs << fdrec.GetCoreUTMCS().X();
      }
    };

    // Column 'Northing'
    class ACColumnFdCoreUTMCSY : public ACFDColumn {
    public:
      ACColumnFdCoreUTMCSY()
       : ACFDColumn("Northing", "m", "FD core Y (northing) in UTM coordinate system", 11) {}
      virtual ~ACColumnFdCoreUTMCSY() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << resetiosflags(std::ios::scientific) << setiosflags(std::ios::fixed) << setprecision(1);
        outs << fdrec.GetCoreUTMCS().Y();
      }
    };

    // Column 'Altitude'
    class ACColumnFdCoreAltitude : public ACFDColumn {
    public:
      ACColumnFdCoreAltitude()
       : ACFDColumn("Altitude", "m", "FD Core altitude (UTM)", 11) {}
      virtual ~ACColumnFdCoreAltitude() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetCoreUTMCS().Z();
      }
    };

    // Column 'NorthingErr'
    class ACColumnFdCoreUTMCSYUncertainty : public ACFDColumn {
    public:
      ACColumnFdCoreUTMCSYUncertainty()
       : ACFDColumn("NorthingErr", "m", "Uncertainty on FD core Y (northing) in UTM coordinate system", 11) {}
      virtual ~ACColumnFdCoreUTMCSYUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetCoreNorthingError();
      }
    };

    // Column 'EastingErr'
    class ACColumnFdCoreUTMCSXUncertainty : public ACFDColumn {
    public:
      ACColumnFdCoreUTMCSXUncertainty()
       : ACFDColumn("EastingErr", "m", "Uncertainty on FD core X (easting) in UTM coordinate system", 11) {}
      virtual ~ACColumnFdCoreUTMCSXUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetCoreEastingError();
      }
    };

    // Column 'RhoNE'
    class ACColumnFdCoreUTMCSNECorrelation : public ACFDColumn {
    public:
      ACColumnFdCoreUTMCSNECorrelation()
       : ACFDColumn("RhoNE", "m", "Correlation of the FD Core northing/easting uncertainties", 11) {}
      virtual ~ACColumnFdCoreUTMCSNECorrelation() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetCoreNorthingEastingCorrelation();
      }
    };

    // Column 'Theta'
    class ACColumnFdThetaCoreCS : public ACFDColumn {
    public:
      ACColumnFdThetaCoreCS()
       : ACFDColumn("Theta", "degree", "FD shower zenith angle in core coordinate system", 11) {}
      virtual ~ACColumnFdThetaCoreCS() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetAxisCoreCS().Theta()*kRad2Deg;
      }
    };

    // Column 'ThetaErr'
    class ACColumnFdThetaCoreCSUncertainty : public ACFDColumn {
    public:
      ACColumnFdThetaCoreCSUncertainty()
       : ACFDColumn("ThetaErr", "degree", "Uncertainty on FD shower zenith angle in core coordinate system", 11) {}
      virtual ~ACColumnFdThetaCoreCSUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetZenithError()*kRad2Deg;
      }
    };

    // Column 'Phi'
    class ACColumnFdPhiCoreCS : public ACFDColumn {
    public:
      ACColumnFdPhiCoreCS()
       : ACFDColumn("Phi", "degree", "FD shower azimuth angle in core coordinate system", 11) {}
      virtual ~ACColumnFdPhiCoreCS() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetAxisCoreCS().Phi()*kRad2Deg;
      }
    };

    // Column 'PhiErr'
    class ACColumnFdPhiCoreCSUncertainty : public ACFDColumn {
    public:
      ACColumnFdPhiCoreCSUncertainty()
       : ACFDColumn("PhiErr", "degree", "Uncertainty on FD shower azimuth angle in core coordinate system", 11) {}
      virtual ~ACColumnFdPhiCoreCSUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetAzimuthError()*kRad2Deg;
      }
    };

    // Column 'RhoPT'
    class ACColumnFdThetaPhiCoreCSCorrelation : public ACFDColumn {
    public:
      ACColumnFdThetaPhiCoreCSCorrelation()
       : ACFDColumn("RhoPT", "-", "Correlation of FD zenith and azimuth", 11) {}
      virtual ~ACColumnFdThetaPhiCoreCSCorrelation() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetZenithAzimuthCorrelation();
      }
    };

    // Column 'RA'
    class ACColumnFdRA : public ACFDColumn {
    public:
      ACColumnFdRA()
       : ACFDColumn("RA", "degree", "FD right ascension", 11) {}
      virtual ~ACColumnFdRA() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetRightAscension()*kRad2Deg;
      }
    };

    // Column 'Dec'
    class ACColumnFdDec : public ACFDColumn {
    public:
      ACColumnFdDec()
       : ACFDColumn("Dec", "degree", "FD declination", 11) {}
      virtual ~ACColumnFdDec() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetDeclination()*kRad2Deg;
      }
    };

    // Column 'RAErr'
    class ACColumnFdRAUncertainty : public ACFDColumn {
    public:
      ACColumnFdRAUncertainty()
       : ACFDColumn("RAErr", "degree", "FD right ascension uncertainty", 11) {}
      virtual ~ACColumnFdRAUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetRightAscensionError()*kRad2Deg;
      }
    };

    // Column 'DecErr'
    class ACColumnFdDecUncertainty : public ACFDColumn {
    public:
      ACColumnFdDecUncertainty()
       : ACFDColumn("DecErr", "degree", "FD declination uncertainty", 11) {}
      virtual ~ACColumnFdDecUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetDeclinationError()*kRad2Deg;
      }
    };

    // Column 'RhoRD'
    class ACColumnFdRADecCorrelation : public ACFDColumn {
    public:
      ACColumnFdRADecCorrelation()
       : ACFDColumn("RhoRD", "-", "Correlation of FD right ascension and declination", 11) {}
      virtual ~ACColumnFdRADecCorrelation() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetRDCorrelation();
      }
    };

    // Column 'GalLong'
    class ACColumnFdGalacticLongitude : public ACFDColumn {
    public:
      ACColumnFdGalacticLongitude()
       : ACFDColumn("GalLong", "degree", "FD galactic longitude (J2000)", 11) {}
      virtual ~ACColumnFdGalacticLongitude() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetGalacticLongitude()*kRad2Deg;
      }
    };

    // Column 'GalLat'
    class ACColumnFdGalacticLatitude : public ACFDColumn {
    public:
      ACColumnFdGalacticLatitude()
       : ACFDColumn("GalLat", "degree", "FD galactic latitude (J2000)", 11) {}
      virtual ~ACColumnFdGalacticLatitude() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetGalacticLatitude()*kRad2Deg;
      }
    };

    // Column 'GalLongErr'
    class ACColumnFdGalacticLongitudeUncertainty : public ACFDColumn {
    public:
      ACColumnFdGalacticLongitudeUncertainty()
       : ACFDColumn("GalLongErr", "degree", "FD galactic longitude (J2000) uncertainty", 11) {}
      virtual ~ACColumnFdGalacticLongitudeUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetGalacticLongitudeError()*kRad2Deg;
      }
    };

    // Column 'GalLatErr'
    class ACColumnFdGalacticLatitudeUncertainty : public ACFDColumn {
    public:
      ACColumnFdGalacticLatitudeUncertainty()
       : ACFDColumn("GalLatErr", "degree", "FD galactic latitude (J2000) uncertainty", 11) {}
      virtual ~ACColumnFdGalacticLatitudeUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetGalacticLatitudeError()*kRad2Deg;
      }
    };

    // Column 'RhoLL'
    class ACColumnFdGalacticLongLatCorrelation : public ACFDColumn {
    public:
      ACColumnFdGalacticLongLatCorrelation()
       : ACFDColumn("RhoLL", "-", "Correlation of FD galactic longitude and latitude", 11) {}
      virtual ~ACColumnFdGalacticLongLatCorrelation() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetLongLatCorrelation();
      }
    };

    // Column 'dEdXmax'
    class ACColumnFddEdXmax : public ACFDColumn {
    public:
      ACColumnFddEdXmax()
       : ACFDColumn("dEdXmax", "GeV/(g/cm$^2$)", "Energy deposit at shower maximum", 11) {}
      virtual ~ACColumnFddEdXmax() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetdEdXmax();
      }
    };

    // Column 'dEdXmaxErr'
    class ACColumnFddEdXmaxUncertainty : public ACFDColumn {
    public:
      ACColumnFddEdXmaxUncertainty()
       : ACFDColumn("dEdXmaxErr", "GeV/(g/cm$^2$)", "Uncertainty on energy deposit at shower maximum", 11) {}
      virtual ~ACColumnFddEdXmaxUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetdEdXmaxError();
      }
    };

    // Column 'Xmax'
    class ACColumnFdXmax : public ACFDColumn {
    public:
      ACColumnFdXmax()
       : ACFDColumn("Xmax", "g/cm$^2$", "Atmospheric slant depth of shower maximum", 11) {}
      virtual ~ACColumnFdXmax() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetXmax();
      }
    };

    // Column 'XmaxErr'
    class ACColumnFdXmaxUncertainty : public ACFDColumn {
    public:
      ACColumnFdXmaxUncertainty()
       : ACFDColumn("XmaxErr", "g/cm$^2$", "Uncertainty on atmospheric slant depth of shower maximum", 11) {}
      virtual ~ACColumnFdXmaxUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetXmaxError();
      }
    };

    // Column 'X0'
    class ACColumnFdX0 : public ACFDColumn {
    public:
      ACColumnFdX0()
       : ACFDColumn("X0", "g/cm$^2$", "Gaisser-Hillas fit X0 parameter", 11) {}
      virtual ~ACColumnFdX0() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetX0();
      }
    };

    // Column 'X0Err'
    class ACColumnFdX0Uncertainty : public ACFDColumn {
    public:
      ACColumnFdX0Uncertainty()
       : ACFDColumn("X0Err", "g/cm$^2$", "Uncertainty on Gaisser-Hillas fit $X_0$ parameter", 11) {}
      virtual ~ACColumnFdX0Uncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetX0Error();
      }
    };

    // Column 'Lambda'
    class ACColumnFdLambda : public ACFDColumn {
    public:
      ACColumnFdLambda()
       : ACFDColumn("Lambda", "g/cm$^2$", "Gaisser-Hillas fit $\\lambda$ parameter", 11) {}
      virtual ~ACColumnFdLambda() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetLambda();
      }
    };

    // Column 'LambdaErr'
    class ACColumnFdLambdaUncertainty : public ACFDColumn {
    public:
      ACColumnFdLambdaUncertainty()
       : ACFDColumn("LambdaErr", "g/cm$^2$", "Uncertainty on Gaisser-Hillas fit $\\lambda$ parameter", 11) {}
      virtual ~ACColumnFdLambdaUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetLambdaError();
      }
    };

    // Column 'GHChi2'
    class ACColumnFdGHChi2 : public ACFDColumn {
    public:
      ACColumnFdGHChi2()
       : ACFDColumn("GHChi2", "-", "Gaisser-Hillas fit $\\chi^2$", 11) {}
      virtual ~ACColumnFdGHChi2() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetGHChi2();
      }
    };

    // Column 'GHNdf'
    class ACColumnFdGHNDoF : public ACFDColumn {
    public:
      ACColumnFdGHNDoF()
       : ACFDColumn("GHNdf", "-", "Number of degrees of freedom in Gaisser-Hillas fit", 11) {}
      virtual ~ACColumnFdGHNDoF() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetGHNdf();
      }
    };

    // Column 'DblGHXmax1'
    class ACColumnFdDGHXmax1 : public ACFDColumn {
    public:
      ACColumnFdDGHXmax1()
       : ACFDColumn("DblGHXmax1", "-", "Xmax of first peak in a double Gaisser-Hillas fit", 11) {}
      virtual ~ACColumnFdDGHXmax1() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetDGHXmax1();
      }
    };

    // Column 'DblGHXmax2'
    class ACColumnFdDGHXmax2 : public ACFDColumn {
    public:
      ACColumnFdDGHXmax2()
       : ACFDColumn("DblGHXmax2", "-", "Xmax of second peak in a double Gaisser-Hillas fit", 11) {}
      virtual ~ACColumnFdDGHXmax2() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetDGHXmax2();
      }
    };

    // Column 'DblGHChi2Improv'
    class ACColumnFdDGHChi2Improv : public ACFDColumn {
    public:
      ACColumnFdDGHChi2Improv()
       : ACFDColumn("DblGHChi2Improv", "-", "Improvement in chi2 of double Gaisser-Hillas fit over single fit", 11) {}
      virtual ~ACColumnFdDGHChi2Improv() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetDGHChi2Improvement();
      }
    };

    // Column 'LineFitChi2'
    class ACColumnFdLineFitChi2 : public ACFDColumn {
    public:
      ACColumnFdLineFitChi2()
       : ACFDColumn("LineFitChi2", "-", "$\\chi^2$ of linear fit to profile", 11) {}
      virtual ~ACColumnFdLineFitChi2() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetLinearProfileFitChi2();
      }
    };

    // Column 'EmEnergy'
    class ACColumnFdCalorimetricEnergy : public ACFDColumn {
    public:
      ACColumnFdCalorimetricEnergy()
       : ACFDColumn("EmEnergy", "EeV", "Calorimetric energy from GH fit", 11) {}
      virtual ~ACColumnFdCalorimetricEnergy() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetEcal() / 1.e18;
      }
    };

    // Column 'EmEnergyErr'
    class ACColumnFdCalorimetricEnergyUncertainty : public ACFDColumn {
    public:
      ACColumnFdCalorimetricEnergyUncertainty()
       : ACFDColumn("EmEnergyErr", "EeV", "Uncertainty on calorimetric energy from GH fit", 11) {}
      virtual ~ACColumnFdCalorimetricEnergyUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetEcalError() / 1.e18;
      }
    };

    // Column 'Energy'
    class ACColumnFdTotalEnergy : public ACFDColumn {
    public:
      ACColumnFdTotalEnergy()
       : ACFDColumn("Energy", "EeV", "Total energy from GH fit", 11) {}
      virtual ~ACColumnFdTotalEnergy() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetEnergy() / 1.e18;
      }
    };

    // Column 'EnergyErr'
    class ACColumnFdTotalEnergyUncertainty : public ACFDColumn {
    public:
      ACColumnFdTotalEnergyUncertainty()
       : ACFDColumn("EnergyErr", "EeV", "Uncertainty on total energy from GH fit", 11) {}
      virtual ~ACColumnFdTotalEnergyUncertainty() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetEnergyError() / 1.e18;
      }
    };

    // Column 'MinAngle'
    class ACColumnFdMinimumViewingAngle : public ACFDColumn {
    public:
      ACColumnFdMinimumViewingAngle()
       : ACFDColumn("MinAngle", "degree", "Minimum viewing angle", 11) {}
      virtual ~ACColumnFdMinimumViewingAngle() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetMinAngle()*kRad2Deg;
      }
    };

    // Column 'MaxAngle'
    class ACColumnFdMaximumViewingAngle : public ACFDColumn {
    public:
      ACColumnFdMaximumViewingAngle()
       : ACFDColumn("MaxAngle", "degree", "Maximum viewing angle", 11) {}
      virtual ~ACColumnFdMaximumViewingAngle() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetMaxAngle()*kRad2Deg;
      }
    };

    // Column 'MeanAngle'
    class ACColumnFdMeanViewingAngle : public ACFDColumn {
    public:
      ACColumnFdMeanViewingAngle()
       : ACFDColumn("MeanAngle", "degree", "Mean viewing angle", 11) {}
      virtual ~ACColumnFdMeanViewingAngle() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetMeanAngle()*kRad2Deg;
      }
    };

    // Column 'ChkovFrac'
    class ACColumnFdCherenkovFraction : public ACFDColumn {
    public:
      ACColumnFdCherenkovFraction()
       : ACFDColumn("ChkovFrac", "%", "Cherenkov light fraction", 11) {}
      virtual ~ACColumnFdCherenkovFraction() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetCherenkovFraction();
      }
    };

    // Column 'NTank'
    class ACColumnFdNumberOfHybridStations : public ACFDColumn {
    public:
      ACColumnFdNumberOfHybridStations()
       : ACFDColumn("NTank", "-", "Number of stations in hybrid fit", 11) {}
      virtual ~ACColumnFdNumberOfHybridStations() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetNHybridStations();
      }
    };

    // Column 'HottestTank'
    class ACColumnFdHottestHybridStation : public ACFDColumn {
    public:
      ACColumnFdHottestHybridStation()
       : ACFDColumn("HottestTank", "-", "Id of the station used in the hybrid fit", 11) {}
      virtual ~ACColumnFdHottestHybridStation() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetHottestStation();
      }
    };

    // Column 'AxisDist'
    class ACColumnFdAxisStationDistance : public ACFDColumn {
    public:
      ACColumnFdAxisStationDistance()
       : ACFDColumn("AxisDist", "m", "Distance between the shower axis and the hottest station", 11) {}
      virtual ~ACColumnFdAxisStationDistance() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetStationAxisDistance();
      }
    };

    // Column 'SDPDist'
    class ACColumnFdSDPStationDistance : public ACFDColumn {
    public:
      ACColumnFdSDPStationDistance()
       : ACFDColumn("SDPDist", "m", "Distance between the SDP and the hottest station", 11) {}
      virtual ~ACColumnFdSDPStationDistance() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetStationSDPDistance();
      }
    };

    // Column 'SDFDdT'
    class ACColumnSdFdTimeOffset : public ACFDColumn {
    public:
      ACColumnSdFdTimeOffset()
       : ACFDColumn("SDFDdT", "ns", "SD/FD time offset after minimization", 11) {}
      virtual ~ACColumnSdFdTimeOffset() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecGeometry& fdgeo = fdevent.GetFdRecGeometry();
        outs << fdgeo.GetSDFDTimeOffset();
      }
    };

    // Column 'XmaxEyeDist'
    class ACColumnFdXmaxDistanceToEye : public ACFDColumn {
    public:
      ACColumnFdXmaxDistanceToEye()
       : ACFDColumn("XmaxEyeDist", "m", "Distance between eye and shower maximum", 11) {}
      virtual ~ACColumnFdXmaxDistanceToEye() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetDistXmax();
      }
    };

    // Column 'EyeXmaxAtt'
    class ACColumnFdXmaxEyeAttenuation : public ACFDColumn {
    public:
      ACColumnFdXmaxEyeAttenuation()
       : ACFDColumn("EyeXmaxAtt", "-", "Mie and Rayleigh attenuation from $X_\\mathrm{max}$ to the eye at the reference wavelength", 11) {}
      virtual ~ACColumnFdXmaxEyeAttenuation() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetAttXmax();
      }
    };

    // Column 'XTrackMin'
    class ACColumnFdXTrackMin : public ACFDColumn {
    public:
      ACColumnFdXTrackMin()
       : ACFDColumn("XTrackMin", "g/cm$^2$", "First slant depth of track", 11) {}
      virtual ~ACColumnFdXTrackMin() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetXTrackMin();
      }
    };

    // Column 'XTrackMax'
    class ACColumnFdXTrackMax : public ACFDColumn {
    public:
      ACColumnFdXTrackMax()
       : ACFDColumn("XTrackMax", "g/cm$^2$", "Last slant depth of track", 11) {}
      virtual ~ACColumnFdXTrackMax() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetXTrackMax();
      }
    };

    // Column 'XFOVMin'
    class ACColumnFdXFOVMin : public ACFDColumn {
    public:
      ACColumnFdXFOVMin()
       : ACFDColumn("XFOVMin", "g/cm$^2$", "First slant depth inside field of view", 11) {}
      virtual ~ACColumnFdXFOVMin() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetXFOVMin();
      }
    };

    // Column 'XFOVMax'
    class ACColumnFdXFOVMax : public ACFDColumn {
    public:
      ACColumnFdXFOVMax()
       : ACFDColumn("XFOVMax", "g/cm$^2$", "Last slant depth inside field of view", 11) {}
      virtual ~ACColumnFdXFOVMax() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetXFOVMax();
      }
    };

    // Column 'XTrackObs'
    class ACColumnFdXObservedTrack : public ACFDColumn {
    public:
      ACColumnFdXObservedTrack()
       : ACFDColumn("XTrackObs", "g/cm$^2$", "Length (in atm. depth) of observed track", 11) {}
      virtual ~ACColumnFdXObservedTrack() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetXTrackMax()-fdrec.GetXTrackMin();
      }
    };

    // Column 'DegTrackObs'
    class ACColumnFdDegreesObservedTrack : public ACFDColumn {
    public:
      ACColumnFdDegreesObservedTrack()
       : ACFDColumn("DegTrackObs", "degree", "Angular length (in degrees) of observed track", 11) {}
      virtual ~ACColumnFdDegreesObservedTrack() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetAngTrackObs()*kRad2Deg;
      }
    };

    // Column 'TTrackObs'
    class ACColumnFdTimeObservedTrack : public ACFDColumn {
    public:
      ACColumnFdTimeObservedTrack()
       : ACFDColumn("TTrackObs", "100 ns", "Length (in time) of observed track", 11) {}
      virtual ~ACColumnFdTimeObservedTrack() {}

      void Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        outs << fdrec.GetTimTrackObs();
      }
    };

    // Column 'MieDatabase'
    class ACColumnFdHasMieDatabase : public ACFDColumn {
    public:
      ACColumnFdHasMieDatabase()
       : ACFDColumn("MieDatabase", "-", "Event has Mie-database information", 11) {}
      virtual ~ACColumnFdHasMieDatabase() {}

      void Convert(std::ostream& outs, const RecEvent& event, const FDEvent& /*fdevent*/)
        const
      {
        using namespace std;
        using namespace ADST;
        outs << event.GetDetector().HasMieDatabase();
      }
    };

  } // end namespace ADST::AC
} // end namespace ADST

#endif
