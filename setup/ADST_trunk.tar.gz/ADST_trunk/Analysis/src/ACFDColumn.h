#ifndef __ACFDColumn_h
#define __ACFDColumn_h

#include <string>
#include <iosfwd>
#include <ACColumn.h>

class RecEvent;
class FDEvent;

namespace ADST {
  namespace AC {
    class ACFDColumn : public ACColumn {
    public:
      ACFDColumn();
      ACFDColumn(const std::string& name, const std::string& unit,
                     const std::string& descr, const unsigned int width);
      virtual ~ACFDColumn();

      virtual void Convert(std::ostream& outs, const RecEvent& event,
                           const FDEvent& fdevent) const = 0;

    private:
    };
  } // end namespace ADST::AC
} // end namespace ADST

#endif
