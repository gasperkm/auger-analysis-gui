#include <ACGlobalColumn.h>

#include <iostream>
#include <RecEvent.h>

using namespace std;

using namespace ADST;
using namespace ADST::AC;

/**********************************************************************/
ACGlobalColumn::ACGlobalColumn()
{
}

/**********************************************************************/
ACGlobalColumn::ACGlobalColumn(const std::string& name, const std::string& unit,
                               const std::string& descr, const unsigned int width)
  : ACColumn(name, unit, descr, width)
{
}

/**********************************************************************/
ACGlobalColumn::~ACGlobalColumn()
{
}

