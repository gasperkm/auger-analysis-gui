#include <AsciiConverter.h>

#include <cmath>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <RecEvent.h>

#include <ACColumn.h>
#include <ACColumnTypes.h>

#include <TBits.h>
#include <TPRegexp.h>

using namespace std;

using namespace ADST;
using namespace ADST::AC;


std::vector<ADST::AC::ACColumn*> AsciiConverter::fgColumnTypes;


/**********************************************************************/
AsciiConverter::AsciiConverter() :
  fDoOwnOutStream(false),
  fOut(&std::cout),
  fColumnSeparator(" ")
{ }


/**********************************************************************/
AsciiConverter::AsciiConverter(const std::string& outfile) :
  fDoOwnOutStream(true),
  fOut(new std::ofstream(outfile.c_str())),
  fColumnSeparator(" ")
{ }


/**********************************************************************/
AsciiConverter::AsciiConverter(std::ostream& outstream) :
  fDoOwnOutStream(false),
  fOut(&outstream),
  fColumnSeparator(" ")
{ }


/**********************************************************************/
AsciiConverter::~AsciiConverter()
{
  if (fDoOwnOutStream)
    delete fOut;

  for (unsigned int iCol = 0; iCol < fColumns.size(); ++iCol)
    delete fColumns[iCol];
  fColumns.clear();
}


/**********************************************************************/
std::ostream&
AsciiConverter::GetOutputStream()
{
  return *fOut;
}


/**********************************************************************/
void
AsciiConverter::WriteColumnHeader()
{
  const std::vector<ADST::AC::ACColumn*>& cols = GetColumns();
  const std::string& colSep = GetColumnSeparator();
  std::ostream& outs = GetOutputStream();

  outs << '#';
  for (vector<ACColumn*>::const_iterator colIt = cols.begin(); colIt != cols.end(); ++colIt) {
    if (colIt != cols.begin())
      outs << colSep;

    const ACColumn* const col = *colIt;
    if (col->GetWidth())
      outs << setw(col->GetWidth() - (colIt == cols.begin() ? 1 : 0));
    outs << col->GetName();
  }
  outs << '\n';
}


/**********************************************************************/
unsigned int
AsciiConverter::TBitsToInt(const TBits& bits)
{
  unsigned int result = 0;
  unsigned int maxBit = bits.GetNbits();
  if (maxBit > 9) // 32bit long can't handle more than nine decimal places of 0/1
    maxBit = 9;

  for (unsigned int iBit = 1; iBit <= maxBit; ++iBit) {
    if (bits.TestBitNumber(iBit))
      result += (unsigned int)(pow(10., int(iBit-1)));
  }
  return result;
}


/**********************************************************************/
void
AsciiConverter::WriteColumnTextDescription(std::ostream& target)
{
  const vector<ACColumn*>& cols = GetColumns();
  unsigned int nameWidth  = GetMaxColumnNameWidth();
  if (nameWidth < 4)
    nameWidth = 4;
  unsigned int descWidth  = GetMaxColumnDescriptionWidth();
  if (descWidth < 11)
    descWidth = 11;
  unsigned int unitWidth  = GetMaxColumnUnitWidth();
  if (unitWidth < 4)
    unitWidth = 4;
  unsigned int colNoWidth = GetMaxColumnNumberWidth();
  if (colNoWidth < 2)
    colNoWidth = 2;

  target << GetOutputDescription() << "\n"
            "I. Maris, S. Müller, F. Schüssler, R. Ulrich and M. Unger\n"
            " --- HEADER DESCRIPTION ---\n\n"
         << setw(colNoWidth) << "ID" << " "
         << setw(nameWidth) << "NAME" << " "
         << setw(unitWidth) << "UNIT" << " "
         << setw(descWidth) << "DESCRIPTION"
         << "\n\n";

  for (unsigned int i = 0; i < cols.size(); ++i) {
    ACColumn c;
    target << setw(colNoWidth) << i << " "
           << setw(nameWidth) << cols[i]->GetName() << " "
           << setw(unitWidth) << cols[i]->GetUnit() << " "
           << setw(descWidth) << cols[i]->GetDescription()
           << '\n';
  }
  target << endl;
}


/**********************************************************************/
void
AsciiConverter::WriteColumnLaTeXDescription(std::ostream& target)
{
  const vector<ACColumn*>& cols = GetColumns();
  unsigned int nameWidth  = GetMaxColumnNameWidth();
  if (nameWidth < 4)
    nameWidth = 4;
  unsigned int descWidth  = GetMaxColumnDescriptionWidth();
  if (descWidth < 11)
    descWidth = 11;
  unsigned int unitWidth  = GetMaxColumnUnitWidth();
  if (unitWidth < 4)
    unitWidth = 4;
  unsigned int colNoWidth = GetMaxColumnNumberWidth();
  if (colNoWidth < 2)
    colNoWidth = 2;

  TPRegexp nukePercent(TString("%"));

  target << "\\documentclass[a4paper]{article}\n"
         << "\\begin{document}\n"
         << "\\title{"
         << GetOutputDescription() << " -- Header Definition"
         << "}\n"
         << "\\author{I. Mari\\c{s}, S. M\\\"uller, F. Sch\\\"ussler, R. Ulrich and M. Unger }\n"
         << "\\date{}\n \\maketitle \n";

  stringstream tablehead;
  tablehead << " \\begin{tabular}{rccp{8cm}}\n"
            << "   "
            << setw(colNoWidth) << "Id" << "&"
            << setw(nameWidth) << "Name" << "&"
            << setw(unitWidth) << "Unit" << "&"
            << setw(descWidth) << "Description" << "\\\\\n"
            << "   \\hline" << endl;

  target << tablehead.str();

  for (unsigned int i = 0; i < cols.size(); ++i) {
    stringstream line;
    line << "   "
         << setw(colNoWidth) << i << "&"
         << setw(nameWidth) << cols[i]->GetName() << "&"
         << setw(unitWidth) << cols[i]->GetUnit() << "&"
         << setw(descWidth) << cols[i]->GetDescription()
         << "\\\\\n";
    TString linestr(line.str());
    nukePercent.Substitute(linestr, TString("\\%"), TString("g"));
    target << linestr.Data();

    if((i % 36) == 0 && i > 0)
      target << "\\end{tabular}\n \\newpage"
	     << tablehead.str();
  }

  target << "\\end{tabular}\n\\end{document}" << endl;
}


/**********************************************************************/
unsigned int
AsciiConverter::GetMaxColumnDescriptionWidth()
{
  const vector<ACColumn*>& cols = GetColumns();
  unsigned int maxW = 0;
  for (unsigned int i = 0; i < cols.size(); ++i) {
    unsigned int len = cols[i]->GetDescription().length();
    if (len > maxW)
      maxW = len;
  }

  return maxW;
}


/**********************************************************************/
unsigned int
AsciiConverter::GetMaxColumnNameWidth()
{
  const vector<ACColumn*>& cols = GetColumns();
  unsigned int maxW = 0;
  for (unsigned int i = 0; i < cols.size(); ++i) {
    unsigned int len = cols[i]->GetName().length();
    if (len > maxW)
      maxW = len;
  }

  return maxW;
}


/**********************************************************************/
unsigned int
AsciiConverter::GetMaxColumnUnitWidth()
{
  const vector<ACColumn*>& cols = GetColumns();
  unsigned int maxW = 0;
  for (unsigned int i = 0; i < cols.size(); ++i) {
    unsigned int len = cols[i]->GetUnit().length();
    if (len > maxW)
      maxW = len;
  }

  return maxW;
}


/**********************************************************************/
unsigned int
AsciiConverter::GetMaxColumnNumberWidth()
{
  ostringstream str;
  str << GetColumns().size();
  return str.str().length();
}
