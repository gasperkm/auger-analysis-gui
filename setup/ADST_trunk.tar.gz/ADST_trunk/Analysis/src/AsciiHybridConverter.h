#ifndef __AsciiHybridConverter_h
#define __AsciiHybridConverter_h

#include <AsciiFDConverter.h>

class RecEvent;

namespace ADST {
  class AsciiHybridConverter : protected AsciiFDConverter {
  public:

    AsciiHybridConverter();
    AsciiHybridConverter(const std::string& outfile);
    AsciiHybridConverter(std::ostream& outstream);
    ~AsciiHybridConverter();

    virtual void WriteFileHeader();

  protected:
    virtual std::string GetOutputDescription();

  private:
    void Init();
  };
} // end namespace ADST

#endif
