#include <AsciiHybridOnlineConverter.h>

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

#include <RecEvent.h>

#include <ACColumn.h>
#include <ACGlobalColumn.h>
#include <ACFDColumn.h>
#include <ACColumnTypes.h>
#include <ACColumnEnergyDeposit.h>

using namespace std;

using namespace ADST;
using namespace ADST::AC;

/**********************************************************************/
AsciiHybridOnlineConverter::AsciiHybridOnlineConverter()
{
  Init();
}

/**********************************************************************/
AsciiHybridOnlineConverter::AsciiHybridOnlineConverter(const std::string& outfile)
 : AsciiFDConverter(outfile)
{
  Init();
}

/**********************************************************************/
AsciiHybridOnlineConverter::AsciiHybridOnlineConverter(std::ostream& outstream)
 : AsciiFDConverter(outstream)
{
  Init();
}

/**********************************************************************/
AsciiHybridOnlineConverter::~AsciiHybridOnlineConverter()
{
}

/**********************************************************************/
void
AsciiHybridOnlineConverter::WriteFileHeader()
{
  std::ostream& outs = GetOutputStream();
  outs << "# " << GetOutputDescription() << "\n"
       << "# \n";
  WriteColumnHeader();
}

/**********************************************************************/
void
AsciiHybridOnlineConverter::Init()
{
  vector<ACColumn*>& cols = GetColumns();
  if (cols.empty()) {
    cols.push_back(new ACColumnEyeId());
    cols.push_back(new ACColumnFdRunId());
    cols.push_back(new ACColumnFdEventId());
    cols.push_back(new ACColumnAugerId());
    cols.push_back(new ACColumnFdGPSSecond());
    cols.push_back(new ACColumnFdGPSNanoSecond());
    cols.push_back(new ACColumnFdYYMMDD());
    cols.push_back(new ACColumnFdHHMMSS());
    cols.push_back(new ACColumnSdId());
    cols.push_back(new ACColumnFdTelescopesInEvent());
    cols.push_back(new ACColumnFdTelescopesInDAQ());
    cols.push_back(new ACColumnMoonCycle());
    cols.push_back(new ACColumnFdRecLevel());
    cols.push_back(new ACColumnFdNumberOfPulsedPixels());
    cols.push_back(new ACColumnFdSDPTheta());
    cols.push_back(new ACColumnFdSDPThetaUncertainty());
    cols.push_back(new ACColumnFdSDPPhi());
    cols.push_back(new ACColumnFdSDPPhiUncertainty());
    cols.push_back(new ACColumnFdSDPChi2());
    cols.push_back(new ACColumnFdSDPNDoF());
    cols.push_back(new ACColumnFdRp());
    cols.push_back(new ACColumnFdRpUncertainty());
    cols.push_back(new ACColumnFdChi0());
    cols.push_back(new ACColumnFdChi0Uncertainty());
    cols.push_back(new ACColumnFdT0());
    cols.push_back(new ACColumnFdT0Uncertainty());
    cols.push_back(new ACColumnFdTimeFitChi2());
    cols.push_back(new ACColumnFdTimeFitFdOnlyChi2());
    cols.push_back(new ACColumnFdTimeFitNDoF());
    cols.push_back(new ACColumnFdCoreUTMCSX());
    cols.push_back(new ACColumnFdCoreUTMCSY());
    cols.push_back(new ACColumnFdCoreAltitude());
    cols.push_back(new ACColumnFdCoreUTMCSYUncertainty());
    cols.push_back(new ACColumnFdCoreUTMCSXUncertainty());
    cols.push_back(new ACColumnFdCoreUTMCSNECorrelation());
    cols.push_back(new ACColumnFdThetaCoreCS());
    cols.push_back(new ACColumnFdThetaCoreCSUncertainty());
    cols.push_back(new ACColumnFdPhiCoreCS());
    cols.push_back(new ACColumnFdPhiCoreCSUncertainty());
    cols.push_back(new ACColumnFdThetaPhiCoreCSCorrelation());
    cols.push_back(new ACColumnFdRA());
    cols.push_back(new ACColumnFdDec());
    cols.push_back(new ACColumnFdRAUncertainty());
    cols.push_back(new ACColumnFdDecUncertainty());
    cols.push_back(new ACColumnFdRADecCorrelation());
    cols.push_back(new ACColumnFdGalacticLongitude());
    cols.push_back(new ACColumnFdGalacticLatitude());
    cols.push_back(new ACColumnFdGalacticLongitudeUncertainty());
    cols.push_back(new ACColumnFdGalacticLatitudeUncertainty());
    cols.push_back(new ACColumnFdGalacticLongLatCorrelation());
    cols.push_back(new ACColumnFddEdXmax());
    cols.push_back(new ACColumnFddEdXmaxUncertainty());
    cols.push_back(new ACColumnFdXmax());
    cols.push_back(new ACColumnFdXmaxUncertainty());
    cols.push_back(new ACColumnFdX0());
    cols.push_back(new ACColumnFdX0Uncertainty());
    cols.push_back(new ACColumnFdLambda());
    cols.push_back(new ACColumnFdLambdaUncertainty());
    cols.push_back(new ACColumnFdGHChi2());
    cols.push_back(new ACColumnFdGHNDoF());
    cols.push_back(new ACColumnFdDGHXmax1());
    cols.push_back(new ACColumnFdDGHXmax2());
    cols.push_back(new ACColumnFdDGHChi2Improv());
    cols.push_back(new ACColumnFdLineFitChi2());
    cols.push_back(new ACColumnFdCalorimetricEnergy());
    cols.push_back(new ACColumnFdCalorimetricEnergyUncertainty());
    cols.push_back(new ACColumnFdTotalEnergy());
    cols.push_back(new ACColumnFdTotalEnergyUncertainty());
    cols.push_back(new ACColumnFdMinimumViewingAngle());
    cols.push_back(new ACColumnFdMaximumViewingAngle());
    cols.push_back(new ACColumnFdMeanViewingAngle());
    cols.push_back(new ACColumnFdCherenkovFraction());
    cols.push_back(new ACColumnFdNumberOfHybridStations());
    cols.push_back(new ACColumnFdHottestHybridStation());
    cols.push_back(new ACColumnFdAxisStationDistance());
    cols.push_back(new ACColumnFdSDPStationDistance());
    cols.push_back(new ACColumnSdFdTimeOffset());
    cols.push_back(new ACColumnFdXmaxDistanceToEye());
    cols.push_back(new ACColumnFdXmaxEyeAttenuation());
    cols.push_back(new ACColumnFdXTrackMin());
    cols.push_back(new ACColumnFdXTrackMax());
    cols.push_back(new ACColumnFdXFOVMin());
    cols.push_back(new ACColumnFdXFOVMax());
    cols.push_back(new ACColumnFdXObservedTrack());
    cols.push_back(new ACColumnFdDegreesObservedTrack());
    cols.push_back(new ACColumnFdTimeObservedTrack());
    cols.push_back(new ACColumnFdHasMieDatabase());
    cols.push_back(new ACColumnBadPeriod());
    cols.push_back(new ACColumnEnergyDeposit());
  }
}

/**********************************************************************/
std::string
AsciiHybridOnlineConverter::GetOutputDescription()
{
  return string("Reconstructed online Hybrid data list, created using the Offline Framework");
}

