#include <AsciiSDConverter.h>

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

#include <RecEvent.h>

#include <ACColumn.h>
#include <ACGlobalColumn.h>
#include <ACColumnTypes.h>

using namespace std;

using namespace ADST;
using namespace ADST::AC;

/**********************************************************************/
AsciiSDConverter::AsciiSDConverter()
{
  Init();
}

/**********************************************************************/
AsciiSDConverter::AsciiSDConverter(const std::string& outfile)
 : AsciiConverter(outfile)
{
  Init();
}

/**********************************************************************/
AsciiSDConverter::AsciiSDConverter(std::ostream& outstream)
 : AsciiConverter(outstream)
{
  Init();
}

/**********************************************************************/
AsciiSDConverter::~AsciiSDConverter()
{
}

/**********************************************************************/
void
AsciiSDConverter::Convert(const RecEvent& event)
{
  std::ostream& os = GetOutputStream();
  const std::vector<ACColumn*>& columns = GetColumns();
  const std::string& colSep = GetColumnSeparator();

  if (event.GetSDEvent().GetRecLevel() < fMinSdRecLevel)
    return;

  for (vector<ACColumn*>::const_iterator colIt = columns.begin(); colIt != columns.end(); ++colIt)
  {
    if (colIt != columns.begin())
      os << colSep;

    ostringstream fieldStr;
    fieldStr << setiosflags(std::ios::scientific) << setprecision(4);

    const ACColumn* col = *colIt;
    const ACGlobalColumn& column = dynamic_cast<const ACGlobalColumn&>(*col);
    column.Convert(fieldStr, event);
    if (column.GetWidth() != 0)
      os << setw(column.GetWidth());
    os << fieldStr.str();
  }
  os << "\n";
}

/**********************************************************************/
void
AsciiSDConverter::WriteFileHeader()
{
  std::ostream& outs = GetOutputStream();
  outs << "# " << GetOutputDescription() << "\n"
       << "# \n";
  WriteColumnHeader();
}

/**********************************************************************/
void
AsciiSDConverter::Init()
{
  vector<ACColumn*>& cols = GetColumns();
  if (cols.empty()) {
    cols.push_back(new ACColumnSdId());
    cols.push_back(new ACColumnAugerId());
    cols.push_back(new ACColumnSdGPSSecond());
    cols.push_back(new ACColumnSdGPSNanoSecond());
    cols.push_back(new ACColumnBadPeriod());
    cols.push_back(new ACColumnSdYYMMDD());
    cols.push_back(new ACColumnSdHHMMSS());
    cols.push_back(new ACColumnMJD());
    cols.push_back(new ACColumnSdT4());
    cols.push_back(new ACColumnSdT5());
    cols.push_back(new ACColumnLDFStatus());
    cols.push_back(new ACColumnSdEnergy());
    cols.push_back(new ACColumnSdEnergyUncertainty());
    cols.push_back(new ACColumnS1000());
    cols.push_back(new ACColumnS1000Uncertainty());
    cols.push_back(new ACColumnS1000BetaSystematics());
    cols.push_back(new ACColumnSdThetaCoreCS());
    cols.push_back(new ACColumnSdThetaCoreCSUncertainty());
    cols.push_back(new ACColumnSdPhiCoreCS());
    cols.push_back(new ACColumnSdPhiCoreCSUncertainty());
    cols.push_back(new ACColumnSdThetaSiteCS());
    cols.push_back(new ACColumnSdPhiSiteCS());
    cols.push_back(new ACColumnCandidateStations());
    cols.push_back(new ACColumnActiveStations());
    cols.push_back(new ACColumnStationsInDAQ());
    cols.push_back(new ACColumnSdCoreSiteCSX());
    cols.push_back(new ACColumnSdCoreSiteCSY());
    cols.push_back(new ACColumnSdCoreSiteCSZ());
    cols.push_back(new ACColumnSdCoreSiteCSXUncertainty());
    cols.push_back(new ACColumnSdCoreSiteCSYUncertainty());
    cols.push_back(new ACColumnSdCoreSiteCSZUncertainty());
    cols.push_back(new ACColumnSdCoreUTMCSX());
    cols.push_back(new ACColumnSdCoreUTMCSY());
    cols.push_back(new ACColumnSdRA());
    cols.push_back(new ACColumnSdDec());
    cols.push_back(new ACColumnSdRAUncertainty());
    cols.push_back(new ACColumnSdDecUncertainty());
    cols.push_back(new ACColumnSdGalacticLatitude());
    cols.push_back(new ACColumnSdGalacticLongitude());
    cols.push_back(new ACColumnSdGalacticLatitudeUncertainty());
    cols.push_back(new ACColumnSdGalacticLongitudeUncertainty());
    cols.push_back(new ACColumnSdPlaneChi2());
    cols.push_back(new ACColumnSdPlaneNDoF());
    cols.push_back(new ACColumnSdBeta());
    cols.push_back(new ACColumnSdBetaUncertainty());
    cols.push_back(new ACColumnSdGamma());
    cols.push_back(new ACColumnSdGammaUncertainty());
    cols.push_back(new ACColumnSdLDFChi2());
    cols.push_back(new ACColumnSdLDFNDoF());
    cols.push_back(new ACColumnSdRadiusOfCurvature());
    cols.push_back(new ACColumnSdRadiusOfCurvatureUncertainty());
    cols.push_back(new ACColumnSdRiseTime());
    cols.push_back(new ACColumnSdRiseTimeUncertainty());
    cols.push_back(new ACColumnSdTimeResidualMean());
    cols.push_back(new ACColumnSdTimeResidualSpread());
    //cols.push_back(new ACColumn());
  }
}

/**********************************************************************/
std::string
AsciiSDConverter::GetOutputDescription()
{
  return string("Reconstructed SD data list, created using the Offline Framework");
}

