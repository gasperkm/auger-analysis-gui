#ifndef __AsciiSDConverter_h
#define __AsciiSDConverter_h

#include <AsciiConverter.h>

namespace ADST {
  class AsciiSDConverter : protected AsciiConverter {
  public:

    AsciiSDConverter();
    AsciiSDConverter(const std::string& outfile);
    AsciiSDConverter(std::ostream& outstream);
    ~AsciiSDConverter();

    virtual void WriteFileHeader();
    virtual void Convert(const RecEvent& event);

    void SetMinSdRecLevel(int minRecLevel) { fMinSdRecLevel = minRecLevel; }
    int GetMinSdRecLevel() { return fMinSdRecLevel; }

  protected:
    virtual std::string GetOutputDescription();

  private:
    void Init();

    int fMinSdRecLevel;
  };
} // end namespace ADST

#endif
