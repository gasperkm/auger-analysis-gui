#ifndef __AugerUpTime_h
#define __AugerUpTime_h

#include <Timing.h>

#include <map>

class TTree;
class TFile;
class TBranch;
class TH2I;
class TBits;


/*************   Numbering conventions:    ***********************

   Telescopes [0..26] with tel=24,25,26 being HEAT
   Eyes [0..4] with eye=4 being HEAT

******************************************************************/

class AugerUpTime {

public:
  AugerUpTime(const char* const fDLifeFile = "", const char* const t2LifeFile = "");
  ~AugerUpTime();

  // BG-histogram
  TH2I* GetPixelVarianceHisto(unsigned int Tel, unsigned int GPS);
  // mean variance over all pixels
  double GetMeanPixelVariance(unsigned int Tel, unsigned int GPS);
  //vector of 440 pixel-variances
  std::vector<unsigned short> GetPixelVariance(unsigned int Tel, unsigned int GPS);
  // vector of 440 pixel-threshold
  std::vector<unsigned short> GetPixelThreshold(unsigned int Tel, unsigned int GPS);
  // vector of 440 pixel-baseline
  std::vector<unsigned short> GetPixelBaseline(unsigned int Tel, unsigned int GPS);

  // check if inside Timing-interval
  bool HasData(unsigned int GPS);

  double GetTelescopeUpFraction(unsigned int Tel, unsigned int GPS);
  unsigned int GetTelescopeStatus(unsigned int Tel, unsigned int GPS);
  double GetEyeUpFraction(unsigned int Eye, unsigned int GPS);
  unsigned int GetEyeStatus(unsigned int Eye, unsigned int GPS);
  double GetFDASVetoFraction(unsigned int Eye, unsigned int GPS);
  double GetCDASVetoFraction(unsigned int Eye, unsigned int GPS);
  double GetCDASConnFraction(unsigned int Eye, unsigned int GPS);
  double GetCDASUpFraction(unsigned int GPS);
  unsigned int GetCDASStatus(unsigned int GPS);

  // including Telescope * Eye * CDAS UpFractions and status
  double GetTotalTelescopeUpFraction(unsigned int Tel, unsigned int GPS, bool withCDAS = true);
  //vector of telescopes including Telescope * Eye * CDAS UpFractions and status
  std::vector<double> GetTotalFDUpFraction(unsigned int GPS, bool withCDAS = true);

  /// return true if telescope is up and running
  bool TelescopeIsOn(unsigned int Tel, unsigned int GPS, bool withCDAS = true);

  // for a given GPS time -> look for nearest data-taking period
  unsigned int GetClosestDataTaking(unsigned int Tel, unsigned int GPS);
  // for a given GPS time during a data-taking period -> look for start of night
  unsigned int GetNightStart(unsigned int Tel, unsigned int GPS);
  // for a given GPS time during a data-taking period -> look for end of night
  unsigned int GetNightStop(unsigned int Tel, unsigned int GPS);

  const Timing & GetTiming() { return *fTiming; }
  unsigned int GetUpTimePeriodStart() { return fTiming->GetFirstGPS(); }  // first GPS time in AugerUpTime-tree
  unsigned int GetUpTimePeriodStop()  { return fTiming->GetLastGPS(); }  // last GPS time in AugerUpTime-tree
  unsigned int GetUpTimeBinWidth() { return fTiming->GetTimeBinSeconds(); }  // binwidth in AugerUpTime-tree [s]

  void Print(unsigned int gpsTime);

  const TBits * GetArrayStatus(unsigned int iGPS);
  /// get status of station iStation
  bool GetStationStatus(unsigned int stationID, unsigned int iGPS);
  /// get number of statios up at time iGPS [s]
  unsigned int GetNT2Stations(unsigned int iGPS);

  /************************************************************/
  static const unsigned int kFirstYear        = 2004;
  static const unsigned int kMaxYears         = 20;
  static const unsigned int kNEyes            = 4; //standard eyes
  static const unsigned int kNTelPerEye       = 6; //standard eye
  static const unsigned int kNHeatTel         = 3;
  static const unsigned int kNTelescopes      = kNTelPerEye * kNEyes+kNHeatTel; //27
  static const unsigned int kNTotalEyes       = kNEyes+1; //standard + Heat

  static const unsigned int kNPixelPerTel     = 440;
  static const unsigned int fSearchMapBinning = 10000; // [s]
  /************************************************************/

private:
  /// find T2 life time bits at a given time iGPS [s]
  bool FindStationBits(unsigned int iGPS);

  // pointer to the AugerUpTime-file with the (mainly) FD-related tree
  TFile* fFDLifeFile;
  TTree* tree;
  TTree* fHeaderTree;
  TBranch
    *fGPSStartB, *fGPSStopB, *fTelescopeUpFractionB, *fTelescopeStatusB, *fEyeUpFractionB,
    *fEyeStatusB, *fCDASUpFractionB, *fCDASStatusB, *fPixelVarianceB, *fPixelThresholdB, *fPixelBaselineB, 
    *fUpTimeVerB, *fFDASVetoFractionB, *fCDASConnFractionB, *fCDASVetoFractionB, *fMeanVarianceB;

  double fTelescopeUpFraction[kNTelescopes];
  unsigned int fTelescopeStatus[kNTelescopes];
  double fEyeUpFraction[kNTotalEyes];
  unsigned int fEyeStatus[kNTotalEyes];
  unsigned int fGPSStart, fGPSStop;
  double fCDASUpFraction;
  unsigned int fCDASStatus;
  double fFDASVetoFraction[kNTotalEyes];
  double fCDASConnFraction[kNTotalEyes];
  double fCDASVetoFraction[kNTotalEyes];
  double fMeanVariance[kNTelescopes];
  unsigned short fPixelVariance[kNTelescopes][kNPixelPerTel];
  unsigned short fPixelThreshold[kNTelescopes][kNPixelPerTel];
  unsigned short fPixelBaseline[kNTelescopes][kNPixelPerTel];

  double fUpTimeVer;

  Timing* fTiming;

  // pointer to file with T2 data and related auxilary variables
  // Note: The slash-slash-bang is a magic comment that prevents ROOT from streaming the members
  TFile* fT2LifeFile; //!
  unsigned int fT2GPSStart; //!
  unsigned int fT2GPSStop; //!
  TBits* fT2StationBits; //!
  TTree* fT2Stations; //!
  TBranch* fT2GPSStartB; //!
  TBranch* fT2GPSStopB; //!
  TBranch* fT2StationsB; //!
  std::map<unsigned int, unsigned int> fFirstT2Index;
  std::map<unsigned int, unsigned int> fLastT2Index;

};


#endif
