#ifndef __GetTriggerProbRealStations_h
#define __GetTriggerProbRealStations_h

#include <map>
#include "T2TriggerProb.h"
#include "AnalysisConsts.h"
#include "RecEvent.h"
#include "Shower.h"

#include <TBits.h>

double GetTriggerProb(const RecEvent& theRecEvent, T2TriggerProb& t2prob, int iPrim)
{
  const TBits& arrayStatus = theRecEvent.GetDetector().GetActiveStations();

  double brassTrigProb = 0.;
  const Shower& theShower = (Shower) theRecEvent.GetGenShower();
  if (theShower.GetEnergy() > 10.) {
    brassTrigProb = t2prob.GetBrassProb(
      theShower, arrayStatus, iPrim
    );
  }
  else if(theRecEvent.GetNEyes() > 0) {
    const Shower& theRecShower = (Shower)theRecEvent.GetHottestEye().GetFdRecShower();
    brassTrigProb = t2prob.GetBrassProb(
      theRecShower, arrayStatus, iPrim
    );
  }
  else {
    const Shower& theRecShower = (Shower)theRecEvent.GetSDEvent().GetSdRecShower();
    if (theRecShower.GetEnergy() < 10. || theRecShower.GetEnergy() > 1.e90)
      return 0.;
    brassTrigProb = t2prob.GetBrassProb(
      theRecShower, arrayStatus, iPrim
    );
  }
  return brassTrigProb;
}


double GetTriggerProbMC(const RecEvent& theRecEvent, T2TriggerProb& t2prob)
{
  int iPrim = theRecEvent.GetGenShower().GetPrimary();
  return GetTriggerProb(theRecEvent, t2prob, iPrim);
}

double GetTriggerProbProton(const RecEvent& theRecEvent, T2TriggerProb& t2prob)
{
  int iPrim = kProtonID;
  return GetTriggerProb(theRecEvent, t2prob, iPrim);
}

double GetTriggerProbIron(const RecEvent& theRecEvent, T2TriggerProb& t2prob)
{
  int iPrim = kIronID;
  return GetTriggerProb(theRecEvent, t2prob, iPrim);
}

#endif
