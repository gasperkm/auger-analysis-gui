#include <RiseTime.h>
#include <Shower.h>
#include <SdRecStation.h>
#include <SdRecShower.h>
#include <SDEvent.h>

#include <TMinuit.h>

#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <cmath>

using namespace std;

static vector<double> risetime;
static vector<double> risetimeError;
static vector<double> spDistance;
static vector<double> spDistanceError;


RiseTime::RiseTime(const SDEvent* sdrec):
  fSDEvent(sdrec)
{
}


RiseTime::~RiseTime()
{
  delete fSDEvent;
}


void
RiseTime::RiseTimeFitFnc(int&/*nPar*/, double* const /*grad*/,
                         double &value, double*  par, const int /*flag*/){

  const double a = par[0];
  const double b= par[1];
  double chi2=0;
  for(int i=0; i<(int)risetime.size(); ++i){
    double funcvalue=40+a*spDistance[i]+b*spDistance[i]*spDistance[i];
    //function uncertainty
    double errorsq=pow((a+2*b*spDistance[i])*spDistanceError[i], 2)/(funcvalue*funcvalue);
    //risetime uncertainty
    errorsq+=pow(risetimeError[i]/risetime[i],2);
    chi2+=(risetime[i]-funcvalue)*(risetime[i]-funcvalue)/errorsq;
  }
  value=chi2;
}



double RiseTime::GetRiseTimeAt1000()
{
  const std::vector<SdRecStation> & stations= fSDEvent->GetStationVector();
  const double theta=fSDEvent->GetSdRecShower().GetZenith();
  for ( unsigned int iS=0;iS<stations.size();iS++)
    {
      if(stations[iS].IsCandidate() && stations[iS].GetTotalSignal()>10.)
        {
          risetime.push_back(stations[iS].GetAssymCorrRiseTime(theta));
          risetimeError.push_back(stations[iS].GetAssymCorrRiseTimeError(theta));
          spDistance.push_back(stations[iS].GetSPDistance());
          spDistanceError.push_back(stations[iS].GetSPDistanceError());
        }
    }

//   TMinuit fit(2);
//   int errFlag = 0;
//   double argList[10];
//   argList[0] = -1;
//   fit.mnexcm("SET PRINTOUT", argList, 1, errFlag);
//   fit.mnexcm("SET NOWARNINGS", argList, 0, errFlag);
//   fit.SetPrintLevel(1);
//   fit.SetFCN(RiseTimeFitFnc);
//   argList[0] = 1;
//   fit.mnexcm("SET ERRORDEF", argList, 1, errFlag);
//   fit.mnparm(0, "a",1.09 ,0.01, 0., 0., errFlag);
//   fit.mnparm(1, "b",0.5 ,  0.1, 0., 0.,  errFlag);
//   argList[0] = 5000;
//   fit.mnexcm("MIGRAD", argList, 1, errFlag);
//   fit.mnexcm("IMPROVE", argList, 1, errFlag);

  return 0.;
}

