// $Id: SDSelection.cc 26791 2014-10-29 18:56:30Z maris $
#include <SDSelection.h>

#include <FdRecLevel.h>
#include <RecEvent.h>
#include <DetectorGeometry.h>
#include <SdTriggerType.h>

#include <vector>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cstdlib>

using namespace std;


// Associate all cut names with their functions
const CutSpec SDSelection::fgSDCutSpecs[] = {
  // ATTENTION: keep this in sync with allSD.cuts

  CutSpec("saturatedCandidates",         saturatedCandidates),
  CutSpec("LDFStatus",                   LDFStatus, 1),
  CutSpec("T4Trigger",                   T4Cut),
  CutSpec("T5Trigger",                   T5Cut),
  CutSpec("minZenithSD",                 minZenithCut, 1),
  CutSpec("maxZenithSD",                 maxZenithCut, 1),
  CutSpec("minRecLevel",                 minRecLevelCut),
  CutSpec("minCandidateStations",        minStationsCut),
  CutSpec("maxCandidateStations",        maxStationsCut),
  CutSpec("badPeriodsRejection",         badPeriodsCut),
  CutSpec("badPeriodsRejectionFromFile", badPeriodsCutFromFile),
  CutSpec("selectSaturation",            saturationCut),
  CutSpec("minLgEnergySD",               minLgEnergyCut, 1),
  CutSpec("maxLgEnergySD",               maxLgEnergyCut, 1),
  CutSpec("Saturation",                  saturationCut),
  CutSpec("timeInterval",                timeIntervalCut, 2),
  CutSpec("heraldSelection",             heraldCut),
  CutSpec("fixBeta",                     betaCut),
  CutSpec("sdId",                        sdIdCut),
  CutSpec("augerId",                     augerIdCut),
  CutSpec("temperature",                 temperature, 2),
  CutSpec("idsFromFile",                 idsFromFile, 1),
  CutSpec("lightning",                   lightning),
  CutSpec("maxRelativeShowerSizeError",  maxRelativeShowerSizeError, 1),
  CutSpec("badSilentStations",           badSilentStations, 2),
  CutSpec("hasStation",                  hasStation, 1),
  CutSpec("hasSilents",                  hasSilents),
  // this must be always the last cutspec. Think \0
  CutSpec("END"),
};


bool SDSelection::fgCutSpecsInitialized = false;
set<unsigned long int> SDSelection::fSdIds;
bool SDSelection::fInitiatedIdsFromFile = false;
vector<unsigned int> SDSelection::fGPSStart;
vector<unsigned int> SDSelection::fGPSStop;


SDSelection::SDSelection(const DetectorGeometry* const* geom,
                         const RecEvent* const* event,
                         int verbosity,
                         bool nMinusOne,
                         const vector<string>& cutFiles) :
  Selection(geom, event, verbosity, nMinusOne, cutFiles)
{
  if (!fgCutSpecsInitialized) {
    AddToCutRegistry(fgSDCutSpecs);
    fgCutSpecsInitialized = true;
  }

  SetSelectionName(string("SD"));
  ReadCuts(cutFiles);
  InitializeCutFunctions();
}


SDSelection::SDSelection(const DetectorGeometry* const* geom,
                         const RecEvent* const* event,
                         int verbosity,
                         bool nMinusOne,
                         const string& cutFile) :
  Selection(geom, event, verbosity, nMinusOne, cutFile)
{
  if (!fgCutSpecsInitialized) {
    AddToCutRegistry(fgSDCutSpecs);
    fgCutSpecsInitialized = true;
  }

  SetSelectionName(string("SD"));
  ReadCuts(cutFile);
  InitializeCutFunctions();
}


bool
SDSelection::saturatedCandidates(Cut& cut)
{
  cut.IsBooleanCut();
  const bool saturated = CurrEvent().GetSDEvent().HasSaturatedCandidates();
  return cut.GetNormalOrAnti(saturated);
}


bool
SDSelection::LDFStatus(Cut& cut)
{
  const double stat = CurrEvent().GetSDEvent().GetSdRecShower().GetLDFStatus();
  cut.SetCurrValue(stat);
  return cut.GetNormalOrAnti(stat >= cut.GetCutValue());
}


bool
SDSelection::minZenithCut(Cut& cut)
{
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  if (!currSDEvent.HasAxis())
    return false;
  const SdRecShower& theShower = currSDEvent.GetSdRecShower();
  const double zenith = theShower.GetZenith()*180./TMath::Pi();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(zenith);

  return cut.GetNormalOrAnti(zenith >= cutVal);
}


bool
SDSelection::maxZenithCut(Cut& cut)
{
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  if (!currSDEvent.HasAxis())
    return false;
  const SdRecShower& theShower = currSDEvent.GetSdRecShower();
  const double zenith = theShower.GetZenith()*180./TMath::Pi();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(zenith);

  return cut.GetNormalOrAnti(zenith < cutVal);
}


bool
SDSelection::T4Cut(Cut& cut)
{
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int t4Flag = currSDEvent.GetT4Trigger();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(t4Flag);

  if (cut.IsAntiCut())
    cerr << " SDSelection::T4Cut()  anti-cut not defined and ignored " << endl;
  if (cutVal == 0) // no T4
    return t4Flag == 0;
  if (cutVal == 1) // FD triggered
    return t4Flag & 1;
  if (cutVal == 2) // SD triggered
    return t4Flag & 2 || t4Flag & 4;
  else /* if (cutVal == 3) */ // both FD && SD triggered
    return t4Flag & 1 && (t4Flag & 2 || t4Flag & 4);
}


bool
SDSelection::T5Cut(Cut& cut)
{
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int t5Flag = currSDEvent.GetT5Trigger();
  const int cutVal = cut.GetCutValue();
  cut.SetCurrValue(t5Flag);

  if (cut.IsAntiCut())
    cerr << " SDSelection::T5Cut()  anti-cut not defined and ignored " << endl;

  if (cutVal == 0)
    return t5Flag != 0;
  if (cutVal == 1)
    return t5Flag & eT5_5T5;
  if (cutVal == 2)
    return t5Flag & eT5_6T5;
  if (cutVal == 3)
    return t5Flag & eT5_Has;

  return false;
}


bool
SDSelection::betaCut(Cut& cut)
{
  cut.IsBooleanCut();
  const bool floatBeta = CurrEvent().GetSDEvent().GetSdRecShower().GetLDF().GetBetaError() > 0;
  return cut.GetNormalOrAnti(!floatBeta);
}


bool
SDSelection::heraldCut(Cut& cut)
{
  cut.IsBooleanCut();

  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const bool estAndRec = (currSDEvent.GetRecLevel()== eHasTriggeredStations);
  const int t5 = currSDEvent.GetT5Trigger();

  const bool heraldGood = !estAndRec && (t5 > 1);
  return cut.GetNormalOrAnti(heraldGood);
}


bool
SDSelection::minStationsCut(Cut& cut)
{
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int nCand = currSDEvent.GetNumberOfCandidates();
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(nCand);
  return cut.GetNormalOrAnti(nCand >= cutVal);
}


bool
SDSelection::maxStationsCut(Cut& cut)
{
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int nCand = currSDEvent.GetNumberOfCandidates();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(nCand);
  return cut.GetNormalOrAnti(nCand <= cutVal);
}


bool
SDSelection::minRecLevelCut(Cut& cut)
{
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int recLevel = currSDEvent.GetRecLevel();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(recLevel);
  return cut.GetNormalOrAnti(recLevel >= cutVal);
}


bool
SDSelection::minLgEnergyCut(Cut& cut)
{
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();

  if (currSDEvent.GetRecLevel() < eHasLDF)
    return false;

  const double lgE = log10(currSDEvent.GetSdRecShower().GetEnergy());
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(lgE);
  return cut.GetNormalOrAnti(lgE >= cutVal);
}


bool
SDSelection::maxLgEnergyCut(Cut& cut)
{
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();

  if (currSDEvent.GetRecLevel() < eHasLDF)
    return false;

  const double lgE = log10(currSDEvent.GetSdRecShower().GetEnergy());
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(lgE);
  return cut.GetNormalOrAnti(lgE <= cutVal);
}


bool
SDSelection::badPeriodsCut(Cut& cut)
{
  cut.IsBooleanCut();
  const bool badPeriod = CurrEvent().GetSDEvent().GetBadPeriodId() > 0;
  return cut.GetNormalOrAnti(!badPeriod);
}


bool
SDSelection::badPeriodsCutFromFile(Cut& cut)
{
  cut.IsBooleanCut();

  // do only once
  if (fGPSStart.empty()) {
    string badFileName;
    const map<string, string>::const_iterator fIt =
      GetUserConfiguration().find("SDBadPeriodsFile");
    if (fIt != GetUserConfiguration().end()) {
      badFileName = fIt->second;
      cerr << "Using Bad Periods file \"" << badFileName << "\"." << endl;
    } else {
      cerr << "Please specify a Bad Periods file in analysis.config" << endl;
      exit(1);
    }

    ifstream badFile(badFileName.c_str());
    if (badFile.is_open()) {
      istringstream lparse;
      string line;
      unsigned int lcount = 0;
      while (getline(badFile, line)) {
        ++lcount;
        if (line.empty() || line[0] == '#')
          continue;
        lparse.str(line);
        lparse.clear();
        int t = 0;
        unsigned int gpsSecondStart = 0;
        unsigned int gpsSecondStop = 0;
        
        bool standardFile = true;
        bool timeIntervalsFile = true;
        if (!(lparse >> t >> gpsSecondStart >> t 
              >> t >> t >> t >> t >> t
              >> t >> gpsSecondStop  >> 
              t >> t >> t >> t >> t >> t))
          standardFile = false;
        
        lparse.str(line);
        lparse.clear();
        
        if (!standardFile && 
            !(lparse >> gpsSecondStart >> gpsSecondStop))
          timeIntervalsFile = false;
        if (!timeIntervalsFile && !standardFile){
          cerr << "Hello Please check structure of your bad periods file, line "
               << lcount << '.' << endl;
          exit(1);
        }

        if (gpsSecondStart > gpsSecondStop) {
          cerr << "Please check your bad periods file, line " << lcount << ": "
                  "gps start > gps stop." << endl;
          exit(1);
        }
        fGPSStart.push_back(gpsSecondStart);
        fGPSStop.push_back(gpsSecondStop);
      }
    } else {
      cerr << "Could not open bad periods file \"" << badFileName << "\"." << endl;
      exit(1);
    }
    cout << "Read " << fGPSStop.size() << " periods " << endl;
  
  }
  
  const unsigned int eventGPS = CurrEvent().GetSDEvent().GetGPSSecond();
  bool badPeriod = false;

  const unsigned int low =
    int(lower_bound(fGPSStop.begin(), fGPSStop.end(), eventGPS) - fGPSStop.begin());
  if (eventGPS > fGPSStart[low] && eventGPS < fGPSStop[low])
    badPeriod = true;

  return cut.GetNormalOrAnti(!badPeriod);
}


bool
SDSelection::saturationCut(Cut& cut)
{
  cut.IsBooleanCut();
  const bool saturated = CurrEvent().GetSDEvent().IsSaturated();
  return cut.GetNormalOrAnti(saturated);
}


bool
SDSelection::timeIntervalCut(Cut& cut)
{
  const int time = CurrEvent().GetYYMMDD();
  const double cutVal1 = cut.GetCutValue();
  const double cutVal2 = cut.GetCutSlope();
  const bool inside = cutVal1 < time && time < cutVal2;
  cut.SetCurrValue(time);

  return cut.GetNormalOrAnti(inside);
}


bool
SDSelection::sdIdCut(Cut& cut)
{
  const int sdId = CurrEvent().GetSDEvent().GetEventId();
  return cut.GetNormalOrAnti(cut.GetCutValue() == sdId);
}


bool
SDSelection::idsFromFile(Cut& cut)
{
  // do only once
  if (!fInitiatedIdsFromFile) {
    fInitiatedIdsFromFile = true;
    const map<string, string>::const_iterator fIt =
      GetUserConfiguration().find("SDIdsFile");
    if (fIt != GetUserConfiguration().end()) {
      const string& sdIdsFileName = fIt->second;
      ifstream idFile(sdIdsFileName.c_str());
      if (!idFile.is_open()) {
        cerr << "Could not open SDIdsFile \"" << sdIdsFileName << "\"." << endl;
        exit(1);
      }
      istringstream lparse;
      string line;
      unsigned int lcount = 0;
      while (getline(idFile, line)) {
        ++lcount;
        if (line.empty() || line[0] == '#')
          continue;
        lparse.str(line);
        lparse.clear();
        unsigned long int id;
        if (!(lparse >> id)) {
          cerr << "Could not read id from SDIdsFile \"" << sdIdsFileName << "\", "
                  "line " << lcount << '.' << endl;
          exit(1);
        }
        fSdIds.insert(id);
      }
      if (fSdIds.empty())
        cerr << "Warning: No event ids found in SDIdsFile \"" << sdIdsFileName << "\"." << endl;
    }
  }

  const bool isAugerId = cut.GetCutValue();
  const unsigned long id =
    isAugerId ? CurrEvent().GetAugerIdNumber() : CurrEvent().GetSDEvent().GetEventId();
  set<unsigned long int>::iterator it = fSdIds.find(id);
  const bool found = it != fSdIds.end();

#ifndef DISABLE_IDSFROMFILE_OPTIMIZATION
  if (found)
    fSdIds.erase(it);
#endif

  return cut.GetNormalOrAnti(found);
}


bool
SDSelection::augerIdCut(Cut& cut)
{
  const string& augerId = CurrEvent().GetAugerId();
  istringstream iss(augerId);
  unsigned long int numericalAugerId = 0;
  iss >> numericalAugerId;
  return cut.GetNormalOrAnti(cut.GetCutValue() == numericalAugerId);
}


bool
SDSelection::temperature(Cut& cut)
{
  const double kelvinToCelsiusCt = -273.15;

  const double temperature = CurrEvent().GetDetector().GetTemperature() + kelvinToCelsiusCt;
  const double cutVal1 = cut.GetCutValue();
  const double cutVal2 = cut.GetCutSlope();
  const bool inside = cutVal1 < temperature && temperature < cutVal2;
  cut.SetCurrValue(temperature);
  return cut.GetNormalOrAnti(inside);
}


bool
SDSelection::badSilentStations(Cut& cut)
{
  if (!CurrEvent().GetSDEvent().HasAxis())
    return false;
  const double allowedDistance = cut.GetCutValue();
  const double maxLDFValue = cut.GetCutSlope();

  const Detector& det = CurrEvent().GetDetector();
  const vector<SdBadStation>& badStations =
    CurrEvent().GetSDEvent().GetBadStationVector();
  TBits array = det.GetActiveStations();
  const DetectorGeometry& detGeom = *GetDetectorGeometry();
  const SdRecShower& sdRecShower = CurrEvent().GetSDEvent().GetSdRecShower();

  const TVector3& showerCore = sdRecShower.GetCoreSiteCS();
  const TVector3& showerAxis = sdRecShower.GetAxisSiteCS();

  for (size_t i = 0; i < badStations.size(); ++i)
    array[badStations[i].GetId()] = false;

  bool returnValue = false;
  for (DetectorGeometry::StationPosMapConstIterator iStation = detGeom.GetStationsBegin();
       iStation != detGeom.GetStationsEnd(); ++iStation) {
    if (array.TestBitNumber(iStation->first)) {
      const int id = iStation->first;
      if (CurrEvent().GetSDEvent().HasStation(id))
        continue;
      const double distance =
        detGeom.GetStationAxisDistance(id, showerAxis, showerCore);

      const double ldf = sdRecShower.GetLDF().Evaluate(distance, eNKG);

      if (distance < allowedDistance && ldf > maxLDFValue) {
        returnValue = true;
        cut.SetCurrValue(ldf);
        break;
      }
    }
  }

  return cut.GetNormalOrAnti(returnValue);
}


bool
SDSelection::lightning(Cut& cut)
{
  cut.IsBooleanCut();
  const bool lightning = CurrEvent().GetSDEvent().IsLightning();
  return cut.GetNormalOrAnti(lightning);
}


bool
SDSelection::maxRelativeShowerSizeError(Cut& cut)
{
  const SdRecShower& curr = CurrEvent().GetSDEvent().GetSdRecShower();
  const double relErr = curr.GetShowerSizeError() / curr.GetShowerSize();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(relErr);
  return cut.GetNormalOrAnti(relErr <= cutVal);
}


bool
SDSelection::hasStation(Cut& cut)
{
  const bool hasIt = CurrEvent().GetSDEvent().HasStation(cut.GetCutValue());
  return cut.GetNormalOrAnti(hasIt);
}


bool
SDSelection::hasSilents(Cut& cut)
{
  cut.IsBooleanCut();
  const vector<SdBadStation>& badStations =
    CurrEvent().GetSDEvent().GetBadStationVector();
  for (vector<SdBadStation>::const_iterator it = badStations.begin(),
       end = badStations.end(); it != end; ++it)
    if (it->GetReason() == eBadSilent)
      return cut.GetNormalOrAnti(true);
  return cut.GetNormalOrAnti(false);
}
