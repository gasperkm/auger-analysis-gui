#ifndef __SDSelection_H
#define __SDSelection_H

#include <Selection.h>

#include <string>
#include <vector>
#include <set>


class SDSelection : public Selection {
public:
  SDSelection(const DetectorGeometry* const* geom,
              const RecEvent* const* event,
              int verbosity = 1,
              bool nMinusOne = true,
              const std::string& cutFile = "sdCuts.txt");

  SDSelection(const DetectorGeometry* const* geom,
              const RecEvent* const* event,
              int verbosity = 1,
              bool nMinusOne = true,
              const std::vector<std::string>& cutFiles = std::vector<std::string>(1, "sdCuts.txt"));

  const std::set<unsigned long int>& GetIds() const { return fSdIds; }

private:
  const static CutSpec fgSDCutSpecs[];
  static bool fgCutSpecsInitialized;

  double GetNEvents() const { return GetNAugerEvents(); }

  static bool saturatedCandidates(Cut&);
  static bool LDFStatus(Cut&);
  static bool minZenithCut(Cut&);
  static bool maxZenithCut(Cut&);
  static bool minLgEnergyCut(Cut&);
  static bool maxLgEnergyCut(Cut&);
  static bool T4Cut(Cut& cut);
  static bool T5Cut(Cut& cut);
  static bool minStationsCut(Cut& cut);
  static bool maxStationsCut(Cut& cut);
  static bool minRecLevelCut(Cut& cut);
  static bool badPeriodsCut(Cut& cut);
  static bool badPeriodsCutFromFile(Cut& cut);
  static bool saturationCut(Cut& cut);
  static bool heraldCut(Cut& cut);
  static bool betaCut(Cut& cut);
  static bool timeIntervalCut(Cut& cut);
  static bool sdIdCut(Cut& cut);
  static bool augerIdCut(Cut& cut);
  static bool temperature(Cut& cut);
  static bool idsFromFile(Cut& cut);
  static bool maxRelativeShowerSizeError(Cut& cut);
  
  static bool lightning(Cut& cut);
  static bool badSilentStations(Cut& cut);
  static bool hasStation(Cut& cut);
  static bool hasSilents(Cut& cut);
  
  static std::set<unsigned long int> fSdIds;
  static std::vector<unsigned int> fGPSStart;
  static std::vector<unsigned int> fGPSStop;
  static bool fInitiatedIdsFromFile;
};


#endif
