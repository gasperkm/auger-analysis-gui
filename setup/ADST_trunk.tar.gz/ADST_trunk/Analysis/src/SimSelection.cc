
#include <SimSelection.h>

#include <FdRecLevel.h>
#include <RecEvent.h>
#include <DetectorGeometry.h>

#include <fstream>
#include <iostream>

using namespace std;

// Associate all cut names with their functions
const CutSpec SimSelection::fgSimCutSpecs[] = {
  CutSpec("primary", primaryCut),

  // this must be always the last cutspec. Think \0
  CutSpec("END"),
};
bool SimSelection::fgCutSpecsInitialized = false;


SimSelection::SimSelection(const DetectorGeometry* const* geom,
                           const RecEvent* const* event,
                           int verbosity,
                           bool nMinusOne,
                           const vector<string>& cutFiles) :
  Selection(geom,event,verbosity,nMinusOne,cutFiles)
{
  if (!fgCutSpecsInitialized) {
    AddToCutRegistry(fgSimCutSpecs);
    fgCutSpecsInitialized = true;
  }

  SetSelectionName(string("Sim"));
  ReadCuts(cutFiles);
  InitializeCutFunctions();
}

SimSelection::SimSelection(const DetectorGeometry* const* geom,
                           const RecEvent* const* event,
                           int verbosity,
                           bool nMinusOne,
                           const string& cutFile) :
  Selection(geom,event,verbosity,nMinusOne,cutFile)
{
  if (!fgCutSpecsInitialized) {
    AddToCutRegistry(fgSimCutSpecs);
    fgCutSpecsInitialized = true;
  }

  SetSelectionName(string("Sim"));
  ReadCuts(cutFile);
  InitializeCutFunctions();
}


bool
SimSelection::primaryCut(Cut& cut) {
  if(cut.GetCutValue() == 0)
    return true;
  const unsigned int primary = CurrEvent().GetGenShower().GetPrimary();
  const unsigned int cutValue = (unsigned int) cut.GetCutValue();
  if (cut.IsAntiCut()) {
    if (primary != cutValue)
      return true;
    else
      return false;
  }
  else {
    if (primary != cutValue)
      return false;
    else
      return true;
  }
}

