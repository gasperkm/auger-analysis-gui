#ifndef __T2TriggerProb_H
#define __T2TriggerProb_H

class Shower;
class TBits;
class DetectorGeometry;

class T2TriggerProb {

public:
  enum ELTPFunctions {
    ePerrone = 0,
    eUnger
  };


public:
  T2TriggerProb(const DetectorGeometry* const* geom);
  ~T2TriggerProb();

  double GetBrassProb(const Shower& theShower,
                      const TBits& arrayStatus,
                      const int iPrim,
                      const ELTPFunctions ltpFunction=ePerrone) const;

  // the old M.U. LTP parameterization
  double GetT2Prob(const double lgE, const double r,
                   const double cosTheta, const int iPrim) const;

  // brand new L.P. parameterization
  double GetTOTprob(const double rm, const double logene,
                    const double coszen, const int prim) const;

private:

  const DetectorGeometry* const* fDetectorGeometry;
  double CalcT2Prob(int iPrim, double age, double lgE, double r) const;
  double MeanXmax(double lgE, int A) const;

};

#endif
