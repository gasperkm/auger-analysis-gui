#ifndef _UtiltyFunctions_H
#define _UtiltyFunctions_H

#include <TVector3.h>

#include <vector>

class GenShower;
class Shower;

namespace UtilityFunctions {

  double GetSDEnergy(const double s1000, const double cosTheta);
  double CircCircIntersectionArea(double dd, double r, double R);
  double Rcutoff(double lgE);
  double GeneratorSurfaceLLCO(double lgE, double deltaPh, double distanceLLCO);
  double GetMCSurface(double lgE);
  double GetCompositionWeight(const GenShower & genShower,
                              unsigned int Np,
                              unsigned int Nf);
  double GetCompositionWeight(int genPrimary,
                              double lgE,
                              unsigned int Np,
                              unsigned int Nf);

  /// get N sigma given probability
  double SigmaFromProb(double);

  // distance to core given slant depth
  double DistanceFromSlantDepth(const unsigned int iMonth,
                                const double slantDepth,
                                const double coreHeightASL,
                                const double cosTheta,
                                const double tolerance=1.);

  /// vertical depth given month [1,12] and height [m a.s.l.]
  double VerticalDepthFromHeight(const double heightASL,
                                 const unsigned int iMonth=4);


  /// height from vertical depth given month [1,12] and depth [g/cm^2]
  double HeightFromVerticalDepth(const double vertDepth,
                                 const unsigned int iMonth=4);

  /**
   * Convert slant depth to height using a parametrization taken from:
   *
   * Keilhauer et al: Investigation of Atmospheric Effects on the Development
   * of Extensive Air Showers and their Detection
   * with the Pierre Auger Observatory
   *
   * This code is using the constants for Malargue spring. According to the
   * primary author, the values for spring correspond most closely to the
   * yearly average.
   */
  double SlantDepthToHeightApproximation(const double depth,
                                         const double cosZenith);

  /// Convert a vector of slant depths to a vector heights
  std::vector<double> SlantDepthVectorToHeightApproximation(const std::vector<double>& sldepth,
                                                            const double cosZenith);

  /// shows ASCII progress bar
  void ShowProgress(unsigned int currEvent, unsigned int nEvent);
}
#endif
