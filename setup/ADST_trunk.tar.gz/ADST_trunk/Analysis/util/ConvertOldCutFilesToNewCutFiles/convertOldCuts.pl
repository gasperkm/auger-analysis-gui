#!/usr/bin/env perl
use strict;
use warnings;
use Getopt::Long;

sub usage {
  my $msg = shift;
  print "$msg\n\n" if defined $msg;
  print <<HERE;
Usage: $0 OLDCUTFILE [NEWCUTFILE]
Converts the legacy cut file format to the modern format.
If NEWCUTFILE is omitted or '-', writes to STDOUT.
If OLDCUTFILE is '-', reads from STDIN.
HERE
  exit(1);
}


GetOptions(
  'h|help' => \&usage,
);
usage() if @ARGV < 1;

my $oldfile = shift @ARGV;
my $newfile = shift @ARGV;
$newfile = '-' if not defined $newfile;

usage("Input file '$oldfile' does not exist.")
  if $oldfile ne '-' and not -f $oldfile;
usage("Output file '$newfile' exists! Cowardly refusing to overwrite!")
  if $newfile ne '-' and -f $newfile;

my $fh;
if ($oldfile eq '-') {
  $fh = \*STDIN;
}
else {
  open $fh, '<', $oldfile
    or die "Could not open file '$oldfile' for reading: $!";
}

my $ofh;
if ($newfile eq '-') {
  $ofh = \*STDOUT;
}
else {
  open $ofh, '>', $newfile
    or die "Could not open file '$newfile' for writing: $!";
}


my $cutName      = qr/\w+/;
my $cFloat       = #qr/[\+−]?(?=\d|\.\d)\d*(?:\.\d*)?(?:[Ee][\+−]?\d+)?/;
                    qr/(?:[\−\+]?\-?(?=\d|\.\d)\d*(?:\.\d*)?(?:[Ee](?:[+−]?\d+))?)/;
my $listOfFloats = qr/$cFloat(?:\s+$cFloat)*/;

print $ofh "ADST cuts version: 1.0\n\n";

my $lineNo = 0;
while (<$fh>) {
  $lineNo++;
  chomp;

  /^\s*(?:#|$)/
    and print($ofh "$_\n"), next;

  my @components;
  use re 'eval';
  @components = /^(\s*\!?\s*)($cutName)((?>\s+))($listOfFloats)(\s*)((?:\|.*)?)$/
    or chomp($_),die "Invalid line ($lineNo) in old cut file: '$_'\n";
  my ($antiCut, $cut, $spacing1, $params, $spacing2, $comment) = map {defined($_) ? $_ : ''} @components;

  my @params = split /\s+/, $params;
  my $nparams = @params; #int(@params / 2) + 1;
  $comment =~ s/\|/#/;

  print $ofh $antiCut . $cut;
  if ($nparams <= 2) {
    print $ofh $spacing1 . $params . $spacing2 . $comment . "\n";
  }
  elsif ($nparams == 4 or $nparams == 5) {
    my $comment_pos = length($spacing1)+length($params)+length($spacing2)-3;

    print $ofh " {" . (" " x $comment_pos) . $comment . "\n";
    my $indent = $antiCut;
    $indent =~ s/\!/ /;

    if ($nparams == 4) {
      print $ofh "$indent  parameters: " . $params[0] . "\n";
      print $ofh "$indent  nMinusOne:  " . join(" ", @params[1..3]) . "\n";
      print $ofh "$indent}\n";
    }
    elsif ($nparams == 5) {
      print $ofh "$indent  parameters: " . join(" ", @params[0,1]) . "\n";
      print $ofh "$indent  nMinusOne:  " . join(" ", @params[2..4]) . "\n";
      print $ofh "$indent}\n";
    }
  }
  else {
    die "Invalid number of parameters on input line $lineNo!\n";
  }
}

close $fh;



