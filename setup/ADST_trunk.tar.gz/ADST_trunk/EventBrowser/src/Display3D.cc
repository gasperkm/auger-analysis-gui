#include "Display3D.h"
#include "RecEvent.h"
#include "EventBrowserConst.h"
#include "EventBrowser.h"
#include "DetectorGeometry.h"
#include "EyeGeometry.h"
#include "TelescopeGeometry.h"
#include "StyleManager.h"

#include <TBox.h>
#include <TCanvas.h>
#include <TView.h>
#include <TH2F.h>
#include <TRotation.h>
#include <TStyle.h>
#include <TMarker.h>
#include <TObjArray.h>
#include <TGraphErrors.h>
#include <TRootEmbeddedCanvas.h>
#include <TGFrame.h>
#include <TGButton.h>
#include <TGButtonGroup.h>
#include <KeySymbols.h>
#include <TEllipse.h>
#include <TLine.h>
#include <TF1.h>
#include <TGSlider.h>
#include <TBits.h>
#include <TPolyMarker3D.h>
#include <TPolyLine3D.h>
#include <TGeoMatrix.h>
#include <TColor.h>

#include <TGeoManager.h>

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>

using namespace std;
using namespace view::Consts;

ClassImp(Display3D);

Display3D::Display3D(TGCompositeFrame* main,
		     const StyleManager* const * styleManager,
		     const DetectorGeometry* const * geom,
		     const RecEvent* const * event,
		     const bool& ismc)
  : fEvent(event),
    fStyleManager(styleManager),
    fDetectorGeometry(geom),
    fIsMC(ismc),
    fShowSDP(false)
{
  f3DObjects = new TObjArray();
  f3DObjects->SetOwner(kTRUE);


  double width = main->GetWidth();
  double height = main->GetHeight();
  //double width2 = main->GetParent()->GetWidth();
  //  double height2 = main->GetParent()->GetHeight();

  //fMain = main;
  main->SetCleanup(kDeepCleanup);


  TGVerticalFrame* vert1 =
    new TGVerticalFrame(main, UInt_t(0.98*width), UInt_t(0.98*height));
  main->AddFrame(vert1,
		 new TGLayoutHints(kLHintsExpandX|kLHintsExpandY,3,3,3,3));

  // ------------------- 3D array view

  TRootEmbeddedCanvas* emCan3D =
    new TRootEmbeddedCanvas("3DPlot", vert1,
			    UInt_t(width), UInt_t(width));
  vert1->AddFrame(emCan3D,
		  new TGLayoutHints(kLHintsExpandX|kLHintsExpandY,3,3,3,3));
  f3DCanvas = emCan3D->GetCanvas();
  f3DCanvas->SetFillColor((*fStyleManager)->Get3DBackgroundColor());

  // get pointer to browser for button connections
  const TGWindow* theBrowserWindow = main->GetParent()->GetParent()->GetParent()->GetParent()->GetParent()->GetParent();
  const EventBrowser *theConstBrowser =
    dynamic_cast<const EventBrowser*>(theBrowserWindow);
  EventBrowser * theBrowser =
    const_cast<EventBrowser*>((const EventBrowser*)theConstBrowser);

  TGHorizontalFrame* horz2 =
    new TGHorizontalFrame(main, UInt_t(0.98*width), UInt_t(0.38*height));
  vert1->AddFrame(horz2, new TGLayoutHints(kLHintsExpandX, 3, 3, 3, 3));
  TGHButtonGroup * FdButtons = new TGHButtonGroup(horz2,"FD options");
  fLightRays   = new TGRadioButton(FdButtons, new TGHotString("rays"),
				   eFDLightRays);
  fSignalTrace = new TGRadioButton(FdButtons, new TGHotString("signal"),
				   eFDSignalTrace);
  horz2->AddFrame(FdButtons,
		  new TGLayoutHints(kLHintsTop|kLHintsLeft,1, 1, 2, 2));
  fLightRays->SetState(kButtonDown);

  TGHButtonGroup * SdButtons = new TGHButtonGroup(horz2,"SD options");
  fShowAllTanks    = new TGCheckButton(SdButtons,
				       new TGHotString("all tanks"),
				       eSDShowAllTanks);
  fShowRadiusPoint = new TGCheckButton(SdButtons,
				       new TGHotString("radius"),
				       eShowRadiusIn3D);
  horz2->AddFrame(SdButtons,
		  new TGLayoutHints(kLHintsTop|kLHintsLeft,1, 1, 2, 2));

  TGHButtonGroup * MCButtons = new TGHButtonGroup(horz2,"MC options");
  fShowMC    = new TGCheckButton(MCButtons,
				 new TGHotString("show MC"),
				 eMCShowFirstInteraction);
  horz2->AddFrame(MCButtons,
		  new TGLayoutHints(kLHintsTop|kLHintsLeft,1, 1, 2, 2));

  TGTextButton* button = new TGTextButton(horz2, " Save EPS ", ePrint3D);
  horz2->AddFrame(button,
  		  new TGLayoutHints(kLHintsCenterY|kLHintsCenterX,1,1,2,2));

  button->Connect("Clicked()", "EventBrowser",
		  theBrowser, "ProcessAugerButtons()");
  button->SetToolTipText("save this 3D canvas to an eps file");

  fShowAllTanks->Connect("Clicked()", "EventBrowser",
			 theBrowser, "ProcessAugerButtons()");

  fLightRays->Connect("Clicked()", "EventBrowser",
		      theBrowser, "ProcessAugerButtons()");
  fLightRays->SetToolTipText("show light rays from shower to pixel");

  fSignalTrace->Connect("Clicked()", "EventBrowser",
			theBrowser, "ProcessAugerButtons()");
  fSignalTrace->SetToolTipText("show reconstructed shower size at the track");

  fShowRadiusPoint->Connect("Clicked()", "EventBrowser",
			    theBrowser, "ProcessAugerButtons()");
  fShowRadiusPoint->SetToolTipText("shows the fitted SD radius"
				   "point as a blue circle");

  fShowMC->Connect("Clicked()", "EventBrowser",
		   theBrowser, "ProcessAugerButtons()");
  fShowMC->SetToolTipText("shows the generated first interaction "
			  "point and MC axis");

  fShowAllTanks->SetGroup(NULL);
  fLightRays->SetGroup(NULL);
  fSignalTrace->SetGroup(NULL);
  fShowRadiusPoint->SetGroup(NULL);
  fShowMC->SetGroup(NULL);

  UpdatePalette();

}

Display3D::~Display3D() {

  f3DObjects->Delete();
  delete f3DObjects;
}


/*****************************************************************************/
void Display3D::UpdatePalette() {

  if ( (*fStyleManager)->ThreeDColorPalette() ) {
    fMinColor = 51;
    fMaxColor = 100;
  }
  else {
    const unsigned int nPalette = 101;
    const unsigned int nCol = 2;
    double red[nCol]  = {0.9,.0};
    double green[nCol]= {0.9,.0};
    double blue[nCol] = {0.9,.0};
    double frac[nCol] = {0.,1.};
    fMinColor =
#if ROOT_VERSION_CODE < ROOT_VERSION(5,16,0)
      TStyle::
#else
      TColor::
#endif
      CreateGradientColorTable(nCol, frac, red, green, blue, nPalette);
    fMaxColor = fMinColor+nPalette-1;
  }

  f3DCanvas->SetFillColor((*fStyleManager)->Get3DBackgroundColor());


}

/*****************************************************************************/
void
Display3D::Update()
{
  Clear();

  if (!fIsMC) {
    fShowMC->SetEnabled(kFALSE);
  }

  // temporarily switch of annoying TGeoManager Info()
  Int_t oldErrorLevel = gErrorIgnoreLevel;
  //gErrorIgnoreLevel = kWarning;
  gErrorIgnoreLevel = kError;

  fFirstEvt = true;

  //f3DObjects->Delete();
  f3DCanvas->cd();

  if (gGeoManager)
    delete gGeoManager;

  TGeoManager* geom = new TGeoManager("EventViewer", "3D Event Viewer");
  if (geom==0) {
    cout << " ERROR in creating TGeoManager " << endl;
    exit(0);
  }

  TGeoMaterial* matVacuum = new TGeoMaterial("Vacuum", 30. ,13 ,3.0);
  fMaterial = new TGeoMedium("Vacuum",2 , matVacuum);

  fWorld = gGeoManager->MakeBox("TOP", fMaterial, 100, 100, 100);
  fWorld->SetVisibility(kFALSE);
  geom->SetTopVolume(fWorld);

  FindTimeWindow();

  DrawSDRecData(false);//bool drewSD = DrawSDRecData();
  DrawDetector();
  DrawSDRecData(true);
  //if (drewSD) fWorld->Draw("same");
  DrawFDRecData();

  TView *view = f3DCanvas->GetView();
  if (view) {
    double minview=5.;
    double dX=fXmaxEvt-fXminEvt;
    if ( dX <  minview ) {
      fXminEvt-=(minview-dX)/2.;
      fXmaxEvt+=(minview-dX)/2.;
    }
    double dY=fYmaxEvt-fYminEvt;
    if ( dY <  minview ) {
      fYminEvt-=(minview-dY)/2.;
      fYmaxEvt+=(minview-dY)/2.;
    }
    double dZ=fZmaxEvt-fZminEvt;
    if ( dZ <  minview ) {
      fZminEvt-=(minview-dZ)/2.;
      fZmaxEvt+=(minview-dZ)/2.;
    }
    view->SetRange(fXminEvt, fYminEvt, fZminEvt,
		   fXmaxEvt, fYmaxEvt, fZmaxEvt);
    view->SetPerspective();
  }


  // update canvas
  f3DCanvas->Modified();
  f3DCanvas->Update();


  // return to old error level
  gErrorIgnoreLevel = oldErrorLevel;

}



void Display3D::Clear() {

  f3DCanvas->Clear();

}




void Display3D::DrawDetector() {

  if (!*fEvent || !*fDetectorGeometry)
    return;

  bool firstPos = true;

  const bool drawSDet = true;
  const bool drawFDet = true;


  ////////////////  SD detecor ///////////////////
  //
  if (drawSDet) {

    const TBits &activeStations = (*fEvent)->GetDetector().GetActiveStations();

    for (DetectorGeometry::StationPosMapConstIterator iStation
	   = (*fDetectorGeometry)->GetStationsBegin();
	 iStation != (*fDetectorGeometry)->GetStationsEnd();
	 ++iStation) {

      int stationId = iStation->first;

      // station color active/inactive
      int color = (*fStyleManager)->Get3DColorStationActive();
      if (!activeStations.TestBitNumber(stationId)) {
	if ( ! fShowAllTanks->IsDown() )
	  continue;
	color = (*fStyleManager)->Get3DColorStationInactive();
      }

      const TVector3 &StationPos = iStation->second;

      const double PosX = StationPos.X()/km;
      const double PosY = StationPos.Y()/km;
      const double PosZ = StationPos.Z()/km;

      TPolyMarker3D *StMark = new TPolyMarker3D(1, 20);
      StMark->SetMarkerColor(color);
      StMark->SetMarkerSize(.5);
      StMark->SetPoint(0, PosX, PosY, PosZ);
      StMark->Draw("same");
    }
  }   // end SDet



  ////////////////  FD detecor ///////////////////
  //
  if (drawFDet) {

    const TBits &activeEyes = (*fEvent)->GetDetector().GetActiveEyes();

    // loop eyes
    for(DetectorGeometry::ConstEyeIterator iEye =
	  (*fDetectorGeometry)->EyesBegin();
	iEye != (*fDetectorGeometry)->EyesEnd();
	++iEye) {

      const int eyeId = iEye->first;
      const EyeGeometry &detEye = iEye->second;

      const TVector3 &eyePosSite = detEye.GetEyePos(); // site CS


      // COLORIZE
      const int cEye = (*fStyleManager)->GetFDEyeColor(eyeId);
      int eyeColor = cEye;
      int lineColor = cEye;

      const bool eyeActive = activeEyes.TestBitNumber(eyeId);
      if (!eyeActive) {

#if ROOT_VERSION_CODE < ROOT_VERSION(5,16,0)
	eyeColor += 100;
	lineColor += 100;
#else
	//eyeColor += 100;
	//lineColor += 100;
#endif
      }

      // siteCS
      const double posX = eyePosSite.X()/km;
      const double posY = eyePosSite.Y()/km;
      const double posZ = eyePosSite.Z()/km;

      if (eyeActive) {
	if (firstPos) {

	  fXminDet = posX;
	  fYminDet = posY;
	  fZminDet = posZ;
	  fXmaxDet = posX;
	  fYmaxDet = posY;
	  fZmaxDet = posZ;
	  firstPos = false;

	}
	else {

	  if (fXminDet>posX)
	    fXminDet = posX;

	  if (fYminDet>posY)
	    fYminDet = posY;

	  if (fZminDet>posZ)
	    fZminDet = posZ;

	  if (fXmaxDet<posX)
	    fXmaxDet = posX;

	  if (fYmaxDet<posY)
	    fYmaxDet = posY;

	  if (fZmaxDet<posZ)
	    fZmaxDet = posZ;
	}
      }


      // telescopes
      for (EyeGeometry::ConstTelescopeIterator iTel = detEye.TelescopesBegin();
	   iTel != detEye.TelescopesEnd();
	   ++iTel) {

	const int telId = iTel->first;

	// CORRECTOR RINGS
	const double length =
	  (*fEvent)->GetDetector().HasCorrectorRing(eyeId, telId)?
	  (*fStyleManager)->GetEyeRadius():
	  (*fStyleManager)->GetEyeRadius()*2./3.;

	int lineWidth = 1;
	if ((*fEvent)->HasEye(eyeId)) {
	  if ((*fEvent)->GetEye(eyeId).MirrorIsInEvent(telId))
	    lineWidth = 3;
	}

	const TString telPointingId =
		  (*fEvent)->GetDetector().GetPointingId(eyeId, telId);

	const double mi_phi = iTel->second.GetAzimuth(telPointingId);
	const double mi_theta = iTel->second.GetElevation(telPointingId);

	// Construct unrotated triangle which represents the telescope in the
	// xy plane, facing the x-direction.
	const TVector3 pnt1Eye(length * cos(-15.*degree),
			       length * sin(-15.*degree),
			       0);

	const TVector3 pnt2Eye(length * cos(+15.*degree),
			       length * sin(+15.*degree),
			       0);

	// Rotation matrix to the eye system
	TRotation r;
	r.RotateYEulerAngles(0., -mi_theta, mi_phi);

	const TVector3 pnt1Site = detEye.TransformEyeToSite(r*pnt1Eye);
	const TVector3 pnt2Site = detEye.TransformEyeToSite(r*pnt2Eye);

	TPolyLine3D *line3D = new TPolyLine3D(2);
	line3D->SetPoint(0, posX, posY, posZ);
	line3D->SetPoint(1, pnt1Site.X()/km, pnt1Site.Y()/km, pnt1Site.Z()/km);
	line3D->SetLineColor(lineColor);
	line3D->SetLineWidth(lineWidth);
	line3D->Draw();

	line3D = new TPolyLine3D(2);
	line3D->SetPoint(0, posX, posY, posZ);
	line3D->SetPoint(1, pnt2Site.X()/km, pnt2Site.Y()/km, pnt2Site.Z()/km);
	line3D->SetLineColor(lineColor);
	line3D->SetLineWidth(lineWidth);
	line3D->Draw();

	line3D = new TPolyLine3D(2);
	line3D->SetPoint(0, pnt1Site.X()/km, pnt1Site.Y()/km, pnt1Site.Z()/km);
	line3D->SetPoint(1, pnt2Site.X()/km, pnt2Site.Y()/km, pnt2Site.Z()/km);
	line3D->SetLineColor(lineColor);
	line3D->SetLineWidth(lineWidth);
	line3D->Draw();


	const bool never=false;

	if ( never ) {
		const TVector3 pnt1EyeFlat(length * cos(mi_phi+15.*degree),
				       length * sin(mi_phi+15.*degree),
				       0);
		const TVector3 pnt2EyeFlat(length * cos(mi_phi-15.*degree),
				       length * sin(mi_phi-15.*degree),
				       0);

		const TVector3 pnt1SiteFlat = detEye.TransformEyeToSite(pnt1Eye);
		const TVector3 pnt2SiteFlat = detEye.TransformEyeToSite(pnt2Eye);

	  // eye pos
	  ostringstream eyeName;
	  eyeName << "eye" << telId << eyeId;

	  const double phi1=(pnt1SiteFlat-eyePosSite).Phi()/degree;
	  const double phi2=(pnt2SiteFlat-eyePosSite).Phi()/degree;
	  double p1= TMath::Min(phi1,phi2);
	  double p2= TMath::Max(phi1,phi2);
	  if ( p2-p1 > 90.) {
	    double tmp=p1;
	    p1=p2; p2=tmp;
	  }
	  TGeoVolume *eye3D = gGeoManager->MakeSphere(eyeName.str().c_str(),
						      fMaterial,
						      0.,0.5*length/km,
						      60.,90.,
						      p1,p2);
	  eye3D->SetLineColor(eyeColor);
	  eye3D->SetFillColor(eyeColor);
	  eye3D->SetFillStyle(0);
	  eye3D->SetLineWidth(0);
	  fWorld->AddNode(eye3D, 1,(new TGeoTranslation(posX, posY, posZ)));
	}

      }
    }
  } // end FDet

} // end draw detector



void Display3D::DrawSDRecData(bool draw) {

  if (!*fEvent)
    return;

  const SDEvent &sevent = (*fEvent)->GetSDEvent();

  if(sevent.GetRecLevel()<eHasTriggeredStations)
    return;

  ////////////// DRAW STATIONS ////////////////////////////

  const vector<SdRecStation> recStationsVec = sevent.GetStationVector();
  const unsigned int nStation = recStationsVec.size();

  if (nStation==0) // NO stations !
    return;


  if (draw)
    fWorld->Draw("same");
  else {

    for (unsigned int iStation = 0; iStation<nStation; iStation++) {

      const SdRecStation &recStations = recStationsVec[iStation];

      const int stationId = recStations.GetId();

      const double timeSec = recStations.GetTimeSecond();
      const double timeNSec = recStations.GetTimeNSecond();
      const Long64_t Time = Long64_t(timeSec)*Long64_t(1e9) +
	                    Long64_t(timeNSec);
      const Detector& det = (*fEvent)->GetDetector();
      const TVector3& StationPos = (recStations.IsDense()?
				    det.GetStationPosition(stationId):
				    (*fDetectorGeometry)->GetStationPosition(stationId));

      const double posX = StationPos.X()/km;
      const double posY = StationPos.Y()/km;
      const double posZ = StationPos.Z()/km;

      bool isRandomTrigger = true;
      if ( sevent.GetRecLevel()>=eHasSdAxis ) {
	if ( recStations.IsCandidate() )
	  isRandomTrigger = false;
      }
      else {
	for (RecEvent::ConstEyeIterator iEye = (*fEvent)->EyesBegin();
	     iEye != (*fEvent)->EyesEnd();
	     ++iEye) {
	  const std::vector<FdRecStation> & fdStations=iEye->GetStationVector();
	  for ( unsigned int iS=0;iS<fdStations.size();iS++ ) {
	    if ( fdStations[iS].GetId() == recStations.GetId() &&
		 fdStations[iS].IsHybrid() ) {
	      isRandomTrigger = false;
	      break;
	    }
	  }
	}
      }

      if ( ! isRandomTrigger ) {
	if (fFirstEvt) {

	  fXminEvt = posX;
	  fYminEvt = posY;
	  fZminEvt = posZ;
	  fXmaxEvt = posX;
	  fYmaxEvt = posY;
	  fZmaxEvt = posZ;
	  fFirstEvt = false;

	}
	else {

	  if (fXminEvt>posX)
	    fXminEvt = posX;

	  if (fYminEvt>posY)
	    fYminEvt = posY;

	  if (fZminEvt>posZ)
	    fZminEvt = posZ;

	  if (fXmaxEvt<posX)
	    fXmaxEvt = posX;

	  if (fYmaxEvt<posY)
	    fYmaxEvt = posY;

	  if (fZmaxEvt<posZ)
	    fZmaxEvt = posZ;
	}
      }


      ostringstream cStat, cMat, cMed;
      cStat << "tubea" << iStation;
      cMat << "mat" << iStation;
      cMed << "med" << iStation;

      int color = 13;
      if ( ! isRandomTrigger ) {
	if (fTimeMax-fTimeMin!=0) {
	  color = fMinColor + (fMaxColor-fMinColor) *
	    (Time-fTimeMin) / (fTimeMax-fTimeMin);
	}
      }

      const double maxRadius = .8;
      const double stationSignal = recStations.GetTotalSignal();
      const double lgSignal = stationSignal<1. ? 1.:
	log10(stationSignal)/log10(fStationMax)*maxRadius;

      const double drawHeight = .1;
      TGeoTranslation *pos = new TGeoTranslation(posX, posY, posZ);
      TGeoVolume *sta = gGeoManager->MakeTube(cStat.str().c_str(),
					      fMaterial,
					      0.,
					      lgSignal, drawHeight);
      sta->SetLineColor(color);
      sta->SetFillColor(color);
      sta->SetLineWidth(1);
      fWorld->AddNode(sta, 1, pos);

    }

    gGeoManager->CloseGeometry();
    gGeoManager->SetVisLevel(4);
    f3DCanvas->Modified();
    f3DCanvas->Update();

    return;
  }



  //////////////// DRAW REC SHOWER /////////////////////
  if (sevent.GetRecLevel()>=eHasSdAxis) {

    const SdRecShower &srec = sevent.GetSdRecShower();

    const TVector3 & coreSite = srec.GetCoreSiteCS();
    const double PosX = coreSite.X()/km;
    const double PosY = coreSite.Y()/km;
    const double PosZ = coreSite.Z()/km;

    TPolyMarker3D *CoreMark = new TPolyMarker3D(1, 20);
    CoreMark->SetMarkerColor(4);
    CoreMark->SetMarkerSize(3);
    CoreMark->SetPoint(0, PosX, PosY, PosZ);
    // CoreMark->Draw(); --- don't

    const TVector3 & dirSite = srec.GetAxisSiteCS();
    const double swap = dirSite.Z()>0.?1.:-1.;
    const double DirX = swap*dirSite.X();
    const double DirY = swap*dirSite.Y();
    const double DirZ = swap*dirSite.Z();

    const double Length = 1.*km;
    TPolyLine3D *Axis = new TPolyLine3D(70);
    if ((*fStyleManager)->ThreeDColorPalette())
      Axis->SetLineColor(4);
    else
      Axis->SetLineColor(kBlack);

    Axis->SetLineWidth(1);
    Axis->SetLineStyle(1);
    for ( int iLength=0;iLength<70;iLength++)
      Axis->SetPoint(iLength,
		     PosX + iLength*DirX*Length,
		     PosY + iLength*DirY*Length,
		     PosZ + iLength*DirZ*Length);
    Axis->Draw();

    const TVector3 & radiusPoint = srec.GetRadiusPoint(); // siteCS
    if ( sevent.HasCurvature() && radiusPoint.Mag() > 0. &&
	 fShowRadiusPoint->IsDown() ) {
      TPolyMarker3D *centerMark = new TPolyMarker3D(1, 24);
      centerMark->SetMarkerColor(kBlue);
      centerMark->SetMarkerSize(1);
      centerMark->SetPoint(0, radiusPoint.X()/km,
			   radiusPoint.Y()/km,
			   radiusPoint.Z()/km);
      centerMark->Draw("same");
    }
  } // has rec shower

}



void Display3D::FindTimeWindow() {

  if (!*fEvent)
    return;

  bool first = true;

  const SDEvent &sevent = (*fEvent)->GetSDEvent();
  //if (sevent.GetRecLevel()>eHasSdAxis) {
  if(sevent.GetRecLevel()>=eHasTriggeredStations) {

    const vector<SdRecStation> recStationsVec = sevent.GetStationVector();
    const unsigned int nStation = recStationsVec.size();
    for (unsigned int iStation = 0; iStation<nStation; iStation++) {

      const SdRecStation &recStation = recStationsVec[iStation];

      //int stationId = recStation.GetId();

      const double stationSignal = recStation.GetTotalSignal();

      const double timeSec = recStation.GetTimeSecond();
      const double timeNSec = recStation.GetTimeNSecond();
      const Long64_t Time = Long64_t(timeSec)*Long64_t(1e9) +
	                    Long64_t(timeNSec);


      bool isRandomTrigger = true;
      if ( sevent.GetRecLevel()>=eHasSdAxis ) {
	if ( recStation.IsCandidate() )
	  isRandomTrigger = false;
      }
      else {
	for (RecEvent::ConstEyeIterator iEye = (*fEvent)->EyesBegin();
	     iEye != (*fEvent)->EyesEnd();
	     ++iEye) {
	  const std::vector<FdRecStation> & fdStations=iEye->GetStationVector();
	  for ( unsigned int iS=0;iS<fdStations.size();iS++ ) {
	    if ( fdStations[iS].GetId() == recStation.GetId() &&
		 fdStations[iS].IsHybrid() ) {
	      isRandomTrigger = false;
	      break;
	    }
	  }
	}
      }

      if ( ! isRandomTrigger ) {

	//cout << " VEM " << Signal << endl;

	if (first) {

	  fStationMax = stationSignal;
	  fTimeMax = Time;
	  fTimeMin = Time;
	  first = false;

	}
	else {

	  if (stationSignal>fStationMax)
	    fStationMax = stationSignal;

	  if (Time > fTimeMax)
	    fTimeMax = Time;

	  if (Time < fTimeMin)
	    fTimeMin = Time;

	}
      }
    }
  }

  bool firstdEdXmax = true;
  fMaxdEdXMax=0.;

  // loop over all eyes and get the pixels
  for (RecEvent::ConstEyeIterator iEye = (*fEvent)->EyesBegin();
       iEye != (*fEvent)->EyesEnd();
       ++iEye) {

    const FDEvent &fevent = *iEye;
    if (fevent.GetRecLevel()>eHasSDP) {


      if ( fevent.GetRecLevel()>=eHasEnergy ) {
	const double dEdXMax=fevent.GetFdRecShower().GetdEdXmax();
	if ( firstdEdXmax ) {
	  firstdEdXmax=false;
	  fMaxdEdXMax = dEdXMax;
	}
	else if ( dEdXMax > fMaxdEdXMax )
	  fMaxdEdXMax = dEdXMax;
      }


      const double ns = 1;
      const double timebinsize = 100.*ns;

      const FdRecGeometry &recGeometry = fevent.GetFdRecGeometry();
      const FdRecPixel &recPixels = fevent.GetFdRecPixel();

      // eye trigger time
      const int eyeTrigSec = fevent.GetGPSSecond();
      const int eyeTrigNSec = fevent.GetGPSNanoSecond();
      const Long64_t eyeTrig = Long64_t(eyeTrigSec) * Long64_t(1e9) +
                               Long64_t(eyeTrigNSec);

      const double Chi_0 = recGeometry.GetChi0();
      const double Rp = recGeometry.GetRp();



      // iterate over pixels used for axis fit
      const int nPixel = recPixels.GetNumberOfPixels();
      for (int iPixel=0; iPixel<nPixel; iPixel++) {

	if (recPixels.GetStatus(iPixel)<=eSDPRecPix)
	  continue;

	// pixel time
	double t_i = recPixels.GetTime(iPixel);

	t_i -= 1000;              // bins of FADC to go to start
	t_i *= timebinsize;       // convert to nanosecond

	const double chi_i = recPixels.GetChi(iPixel);

	const double alpha = Chi_0 - 90.*degree - chi_i;
	const double tof = Rp/kSpeedOfLight / cos(alpha);
	const Long64_t T_i = eyeTrig + Long64_t(t_i) - Long64_t(tof);
	const double signal = recPixels.GetCharge(iPixel);


	if (first) {

	  fMaxPixelSignal = signal;
	  fTimeMax = T_i;
	  fTimeMin = T_i;
	  first = false;

	}
	else {

	  if (signal>fMaxPixelSignal)
	    fMaxPixelSignal = signal;

	  if (T_i > fTimeMax)
	    fTimeMax = T_i;

	  if (T_i < fTimeMin)
	    fTimeMin = T_i;

	}

      } // for pixel

    } // for eyes

  } // if FEVENT

}




void Display3D::DrawFDRecData() {

  if (!*fEvent)
    return;

  const double ns = 1;
  const double timebinsize = 100.*ns;


  //////////////// DRAW SIM DATA //////////////////////////////

  if ( fIsMC && fShowMC->IsDown()) {

    const GenShower& theShower = (*fEvent)->GetGenShower();

    const TVector3 & coreSite = theShower.GetCoreSiteCS();
    const double PosX = coreSite.X()/km;
    const double PosY = coreSite.Y()/km;
    const double PosZ = coreSite.Z()/km;

    // check for old ADSTs
    const TVector3 & dirSite = (theShower.GetAxisSiteCS().Mag()!=0?
				theShower.GetAxisSiteCS():
				theShower.GetAxisCoreCS());
    const double swap = dirSite.Z()>0.?1.:-1.;
    const double DirX = swap*dirSite.X();
    const double DirY = swap*dirSite.Y();
    const double DirZ = swap*dirSite.Z();

    const double Length = 1.;
    TPolyLine3D *Axis = new TPolyLine3D(70);
    if ( (*fStyleManager)->ThreeDColorPalette() )
      Axis->SetLineColor(0);
    else
      Axis->SetLineColor(kBlack);

    Axis->SetLineWidth(1);
    Axis->SetLineStyle(1);
    for ( int iLength=0;iLength<70;iLength++)
      Axis->SetPoint(iLength,
		     PosX + iLength*DirX*Length,
		     PosY + iLength*DirY*Length,
		     PosZ + iLength*DirZ*Length);
    Axis->Draw("same");

    for (RecEvent::ConstEyeIterator iEye = (*fEvent)->EyesBegin();
	 iEye != (*fEvent)->EyesEnd();
	 ++iEye) {

      const FDEvent &fdEvent = *iEye;

      const int eyeId = fdEvent.GetEyeId();

      const EyeGeometry &deteye = (*fDetectorGeometry)->GetEye(eyeId);

      const FdGenGeometry& genGeometry = fdEvent.GetGenGeometry();
      const double Chi_0 = genGeometry.GetChi0();
      const double Rp = genGeometry.GetRp();

      TVector3  sdp(1,0,0);
      sdp.SetTheta(genGeometry.GetSDPTheta());
      sdp.SetPhi(genGeometry.GetSDPPhi());

      if ( fShowMC->IsDown() ) {
	const FdGenShower& genShower = fdEvent.GetGenShower();
	const double chiX1 = genShower.GetX1Chi();

	const TVector3 verticalEye(0,0,1);
	const TVector3 horizontalInSDP = sdp.Cross(verticalEye);
	TVector3 dir = horizontalInSDP;
	dir.Rotate(-chiX1, sdp);
	dir = dir.Unit();

	const double alpha = Chi_0 - 90.*degree - chiX1;

	const double pixeldirlength = Rp/cos(alpha);
	const TVector3 dirEye = dir * pixeldirlength;
	TVector3 dirSite = deteye.TransformEyeToSite(dirEye);
	if ( dirSite.Z() < 0. )
	  dirSite*=-1.;

	if (fXminEvt>dirSite.X()/km)
	  fXminEvt = dirSite.X()/km;

	if (fYminEvt>dirSite.Y()/km)
	  fYminEvt = dirSite.Y()/km;

	if (fZminEvt>dirSite.Z()/km)
	  fZminEvt = dirSite.Z()/km;

	if (fXmaxEvt<dirSite.X()/km)
	  fXmaxEvt = dirSite.X()/km;

	if (fYmaxEvt<dirSite.Y()/km)
	  fYmaxEvt = dirSite.Y()/km;

	if (fZmaxEvt<dirSite.Z()/km)
	  fZmaxEvt = dirSite.Z()/km;

	TPolyMarker3D *p3D = new TPolyMarker3D(1, 24);
	p3D->SetPoint(0, dirSite.X()/km, dirSite.Y()/km, dirSite.Z()/km);
	p3D->SetMarkerColor((int)0);
	p3D->SetMarkerSize((int)2);
	p3D->Draw("same");
      }

    }
  } // if is MC

  //////////////// DRAW EYE REC DATA //////////////////////////////

  const Detector& det = (*fEvent)->GetDetector();

  // loop over all eyes
  for (RecEvent::ConstEyeIterator iEye = (*fEvent)->EyesBegin();
       iEye != (*fEvent)->EyesEnd();
       ++iEye) {

    const FDEvent &fevent = *iEye;
    const int eyeId = fevent.GetEyeId();

    // and get the SDPs
    if (fevent.GetRecLevel() < eHasSDP)
      continue;

    const EyeGeometry &deteye = (*fDetectorGeometry)->GetEye(eyeId);
    const FdRecGeometry &recGeometry = fevent.GetFdRecGeometry();
    const FdRecPixel &recPixels = fevent.GetFdRecPixel();
    const std::vector<Double_t>& apertureTime =
      fevent.GetFdRecApertureLight().GetTime();
    const std::vector<Double_t>& dEdXVec      =
      fevent.GetFdRecShower().GetEnergyDeposit();

    const TVector3 & eyePosSite = deteye.GetEyePos(); // siteCS
    TVector3 eyeSDP(1,0,0);
    eyeSDP.SetTheta(recGeometry.GetSDPTheta());
    eyeSDP.SetPhi(recGeometry.GetSDPPhi());


    const double Chi_0 = recGeometry.GetChi0();
    const double Rp = recGeometry.GetRp();


    // eye trigger time
    const int eyeTrigSec = fevent.GetGPSSecond();
    const int eyeTrigNSec = fevent.GetGPSNanoSecond();
    const Long64_t eyeTrig = Long64_t(eyeTrigSec) * Long64_t(1e9) +
      Long64_t(eyeTrigNSec);


    //////////////// DRAW EYE's REC SHOWER /////////////////////

    if (fevent.GetRecLevel()>=eHasAxis) {

      const FdRecShower &eyerecdata = fevent.GetFdRecShower();
      const TVector3 & dir = eyerecdata.GetAxisSiteCS();  // siteCS
      const TVector3 & pos = eyerecdata.GetCoreSiteCS();  // siteCS

      double posX = pos.X();
      double posY = pos.Y();
      double posZ = pos.Z();

      TPolyMarker3D *CoreMark = new TPolyMarker3D(1, 20);
      CoreMark->SetMarkerColor(2);
      CoreMark->SetMarkerSize(3);
      CoreMark->SetPoint(0, posX/km, posY/km, posZ/km);
      // CoreMark->Draw();  --- don't

      const double swap = dir.Z()>0.?1.:-1.;
      const double DirX = swap*dir.X();
      const double DirY = swap*dir.Y();
      const double DirZ = swap*dir.Z();

      if (DirX==0 && DirY==0 && DirZ==0) {
	cout << " No Fd-axis available. It seems you are using old ADST files."
	     << endl;
      }

      double Length = 1.*km;
      TPolyLine3D *Axis = new TPolyLine3D(70);
      if ( (*fStyleManager)->ThreeDColorPalette() )
	Axis->SetLineColor(2);
      else
	Axis->SetLineColor(kBlack);
      Axis->SetLineWidth(1);
      Axis->SetLineStyle(1);
      for ( int iLength=0;iLength<70;iLength++)
	Axis->SetPoint(iLength,
		       (posX + iLength*DirX*Length)/km,
		       (posY + iLength*DirY*Length)/km,
		       (posZ + iLength*DirZ*Length)/km);
      Axis->Draw();
    }



    if (fevent.GetRecLevel()>eHasSDP&&fShowSDP) {

      // plot SDP --
      const double SDPlength = 200.*km; // km

      const double sdpAngle = recGeometry.GetSDPPhi() - 90.*degree;
      const TVector3 sdpEye(SDPlength*cos(sdpAngle), SDPlength*sin(sdpAngle),0);
      const TVector3 sdpSite = deteye.TransformEyeToSite(sdpEye);

      TPolyLine3D *lineSDP = new TPolyLine3D(2);
      lineSDP->SetPoint(0,
			eyePosSite.X()/km,
			eyePosSite.Y()/km,
			eyePosSite.Z()/km);
      lineSDP->SetPoint(1,
			sdpSite.X()/km,
			sdpSite.Y()/km,
			sdpSite.Z()/km);
      lineSDP->SetLineColor(2);
      lineSDP->SetLineStyle(2);
      lineSDP->SetLineWidth(2);
      lineSDP->Draw();
      // -----------
    }


    // iterate over pixels used for SDP
    const int nPixel = recPixels.GetNumberOfPixels();

    if (nPixel == 0)
      cout << " no pixels !!!! " <<endl;

    for (int iPixel = 0; iPixel < nPixel; ++iPixel) {

      if (recPixels.GetStatus(iPixel) <= eSDPRecPix)
	continue;

      const int telId = recPixels.GetTelescopeId(iPixel);
      const int pmtId = recPixels.GetPixelId(iPixel);

      const TelescopeGeometry& detTel = deteye.GetTelescope(telId);
      const TString telPointingId = det.GetPointingId(eyeId, telId);

      // pixel time
      double t_i = recPixels.GetTime(iPixel);

      t_i -= 1000;              // bins of FADC to go to start
      t_i *= timebinsize;       // convert to nanosecond

      // direction in EYE-CS
      const double pixelPhi = detTel.GetPixelPhi(pmtId - 1, telPointingId) * degree;
      const double pixelTheta = 90.*degree -
	detTel.GetPixelOmega(pmtId - 1, telPointingId) * degree;
      TVector3 pixelDir(1, 0, 0);
      pixelDir.SetTheta(pixelTheta);
      pixelDir.SetPhi(pixelPhi);


      const double chi_i = recPixels.GetChi(iPixel); // EYE CS

      // use the shower geometry and calculate the
      // corresponding point
      const double alpha = Chi_0 - 90.*degree - chi_i;
      const double tof = Rp/kSpeedOfLight / cos(alpha);
      const Long64_t T_i = eyeTrig + Long64_t(t_i) - Long64_t(tof);

      const int pixel_width = 1;
      const double pixeldirlength = Rp/cos(alpha);
      const double pixel_color = fTimeMin-fTimeMax!=0 ?
	fMinColor + (fMaxColor-fMinColor) *
	(T_i-fTimeMin) / (fTimeMax- fTimeMin) :
	13;

      const TVector3 pixelEye = pixelDir * pixeldirlength;
      const TVector3 pixelSite = deteye.TransformEyeToSite(pixelEye);

      const double minPx = std::min(pixelSite.X()/km, eyePosSite.X()/km);
      const double minPy = std::min(pixelSite.Y()/km, eyePosSite.Y()/km);
      const double minPz = std::min(pixelSite.Z()/km, eyePosSite.Z()/km);
      const double maxPx = std::max(pixelSite.X()/km, eyePosSite.X()/km);
      const double maxPy = std::max(pixelSite.Y()/km, eyePosSite.Y()/km);
      const double maxPz = std::max(pixelSite.Z()/km, eyePosSite.Z()/km);

      if (fFirstEvt) {

	fXminEvt = minPx;
	fYminEvt = minPy;
	fZminEvt = minPz;
	fXmaxEvt = maxPx;
	fYmaxEvt = maxPy;
	fZmaxEvt = maxPz;
	fFirstEvt = false;

      } else {

	if (fXminEvt>minPx)
	  fXminEvt = minPx;

	if (fYminEvt>minPy)
	  fYminEvt = minPy;

	if (fZminEvt>minPz)
	  fZminEvt = minPz;

	if (fXmaxEvt<maxPx)
	  fXmaxEvt = maxPx;

	if (fYmaxEvt<maxPy)
	  fYmaxEvt = maxPy;

	if (fZmaxEvt<maxPz)
	  fZmaxEvt = maxPz;

      }


      // draw Xmax position
      if (fevent.GetRecLevel()>eHasGHParameters &&
	  !fSignalTrace->IsDown() ) {

	const FdRecShower &eyerecdata = fevent.GetFdRecShower();
	const TVector3 xmaxPosition = eyerecdata.GetCoreSiteCS() +
	  eyerecdata.GetAxisSiteCS() * eyerecdata.GetCoreXmaxDist();

	TPolyMarker3D * xMaxMark = new TPolyMarker3D(1, 24);
	if ( (*fStyleManager)->ThreeDColorPalette() )
	  xMaxMark->SetMarkerColor(kRed);

	xMaxMark->SetMarkerSize(1.);
	xMaxMark->SetPoint(0,
			   xmaxPosition.X()/km,
			   xmaxPosition.Y()/km,
			   xmaxPosition.Z()/km);
	xMaxMark->Draw("same");
      }



      // 3D rays or signal


      if ( fLightRays->IsDown() ) {
	TPolyLine3D *line3D = new TPolyLine3D(2);
	line3D->SetPoint(0, eyePosSite.X()/km,
			 eyePosSite.Y()/km,
			 eyePosSite.Z()/km);
	line3D->SetPoint(1, pixelSite.X()/km,
			 pixelSite.Y()/km,
			 pixelSite.Z()/km);
	line3D->SetLineColor((int)pixel_color);
	line3D->SetLineWidth((int)pixel_width);
	line3D->Draw("same");
      }
      else if ( fSignalTrace->IsDown() )  {
	TPolyMarker3D *signalMarker = new TPolyMarker3D(1, 20);
	signalMarker->SetMarkerColor((int) pixel_color);
	double markerSize = 0.5;
	if ( fMaxdEdXMax > 0. ) {
	  const double pixTime = recPixels.GetTime(iPixel);
	  double thisdEdX=0.;
	  for ( unsigned int k=1;k<apertureTime.size();k++ ) {
	    if ( apertureTime[k-1] <= pixTime &&
		 apertureTime[k]   >= pixTime ) {
	      thisdEdX=dEdXVec[k];
	      break;
	    }
	  }
	  if ( thisdEdX > 0. ) {
	    markerSize=thisdEdX/fMaxdEdXMax * 1.5;
	    if ( markerSize < 0.5 )
	      markerSize=0.5;
	  }
	}
	signalMarker->SetMarkerSize(markerSize);
	signalMarker->SetPoint(0, pixelSite.X()/km,
			       pixelSite.Y()/km,
			       pixelSite.Z()/km);
	signalMarker->Draw("same");
      }
    } // for pixel
  } // for eyes


}

void Display3D::SaveCanvas(const string &fileName) const {
  cout << " Saving 3D view as \"" << fileName << "\" " << endl;
  f3DCanvas->Print(fileName.c_str());
}



void Display3D::SetFDButtons(EButtonSignals e) {

  switch(e) {
  case eFDLightRays:
    {
      fLightRays->SetState(kButtonDown);
      fSignalTrace->SetState(kButtonUp);
      break;
    }
  case eFDSignalTrace:
    {
      fLightRays->SetState(kButtonUp);
      fSignalTrace->SetState(kButtonDown);
      break;
    }
  default:
    break;
  }
}
