#include <TGFrame.h>

class TGWindow;
class TGTab;
class TGCompositeFrame;

class EventBrowserMenu;
class EventSelection;
class StatusBar;
class StyleManager;

class VPlots;
class FdPlots;
class SdPlots;
class RdPlots;
class MdPlots;
class AugerPlots;
class RiseTimePlots;
class SdSimulationPlots;

class RecEventFile;
class RecEvent;
class DetectorGeometry;

#include <string>
#include <vector>
#include "EventInfo.h"

//#define EBVERSION "2.00"
//#define EBUpdate "     FZK 2006/06/19"

#undef GERMAN

class EventBrowser : public TGMainFrame {

private:
  EventBrowser();

public:
  EventBrowser(const TGWindow* p, UInt_t w, UInt_t h,
               const std::vector<std::string> & fileNames,
               const bool batchMode=false);
  virtual ~EventBrowser();

  void SetBatchMode(const bool mode) { fIsInBatchMode=mode; }

  // SYSTEM ENTRY for signal handling
  Bool_t ProcessMessage (Long_t msg, Long_t parm1, Long_t parm2);
  Bool_t HandleKey(Event_t* event);
  void CloseWindow(); // do the cleaning up
  void ProcessAugerButtons();
  void ProcessFdButtons();

  void KeepAnimatedEpsFiles();

  bool IsMCData() const {return fIsMC;}

  FdPlots* GetHottestFdPlots();
  FdPlots* GetFdPlot(const int i);

private:

  void OpenOfflineOutput (const std::vector<std::string> & filenames);

  void GetDetectorGeometry();
  void UpdateBrowser();
  void UpdateTab(long int);
  void ReadEventList();
  void InitEventTabs();
  void InitKeyStrokes();

public:
  void PrintPS();
  void DumpEventASCII();
  bool ChangeEvent(Long_t);

  std::string ExtractAugerId() const;

private:

  void ChangeTab(Long_t);
  void SaveEvent();
  void SaveSelectedEvents();
  void ShowOfflineConfiguration();
  void UpdateTabsOnOpenFile();

  void FindEvent(UInt_t id);


private:
  bool fIsInBatchMode;

  bool fIsMC;
  std::vector<EventInfo> fEventInfo;

  RecEventFile* fEventFile;
  RecEvent* fEvent;

  int fTotEvent; // total no of events in file

  StyleManager*  fStyleManager;
  DetectorGeometry* fGeometry;


  // GUI stuff

  EventBrowserMenu* fMenu;
  StatusBar* fStatusBar;

  EventSelection* fCuts;
  TGCompositeFrame* fCutFrame;

  // --- the plots inside the tabs
  SdPlots* fSDPlots;
  TGCompositeFrame* fSdFrame;
  RdPlots* fRdPlots;
  TGCompositeFrame* fRdFrame;
  MdPlots* fMdPlots;
  TGCompositeFrame* fMdFrame;
  SdSimulationPlots* fSdSimPlots;
  TGCompositeFrame* fSdSimFrame;

  RiseTimePlots* fRiseTimePlots;
  TGCompositeFrame* fRiseTimeFrame;

  AugerPlots* fAugerPlots;
  TGCompositeFrame* fAugerFrame;

  unsigned int fAugerTabIndex;
  unsigned int fFDTabIndex;
  unsigned int fSDTabIndex;
  unsigned int fSDMCTabIndex;
  unsigned int fRDTabIndex;
  unsigned int fMDTabIndex;
  unsigned int fCutTabIndex;

  std::vector<FdPlots*> fFDPlots;
  std::vector<TGCompositeFrame*> fFdFrame;

  std::vector<VPlots*> fPlotVector;


  // --- the tabs
  TGTab* fTabs;

public:
  static std::string GetVersion();
  static std::string GetRevision();
  static std::string GetDate();
  static void Welcome();

  ClassDef (EventBrowser,1);
};

