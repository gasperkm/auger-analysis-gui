#include "EventSelection.h"
#include "EventBrowser.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "DetectorGeometry.h"

#include <TRootEmbeddedCanvas.h>
#include <TGButtonGroup.h>
#include <TCanvas.h>
#include <TGFrame.h>
#include <TGTextBuffer.h>
#include <TGNumberEntry.h>
#include <TGString.h>
#include <TGLabel.h>
#include <TGComboBox.h>
#include <TGListBox.h>
#include <TGMsgBox.h>
#include <TGFileDialog.h>
#include <TH1F.h>
#include <TLegend.h>
#include <TLatex.h>
#include <TObjArray.h>
#include <TSystem.h>

#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <cmath>
#include <map>

using namespace std;
using namespace view::Consts;

ClassImp(EventSelection);


// default button settings and number entries
const double kEmin=0.;
const double kEmax=99.;
const bool   kT3Checked=false;
const bool   kHybrid=false;
const bool   kHybridHQ=true;
const bool   kFOV=false;
const bool   kFOVHQ=true;
const bool   kT3CheckedHQ=false;
const bool   kT4Checked=false;
const bool   kT4CheckedHQ=false;
const bool   kT5Checked=false;
const bool   kT5CheckedHQ=true;
const bool   kSatChecked=false;
const bool   kSatCheckedHQ=false;
const int    kZmin=0;
const int    kZmax=180;
const int    kZmaxHQFD=85;
const int    kZmaxHQSD=60;
const int    kYYMMDDmin=20040101;
const int    kYYMMDDmax=20991231;
const int    kHHMMSS=120000;
const int    kTankMin=0;
const int    kTankMinHQ=5;
const int    kEyeMin=0;
const int    kEyeMinHQ=1;
const int    kPixelMin=0;
const int    kPixelMinHQ=5;
const int    kFDRecLevel=eNoFdEvent;
const int    kFDRecLevelHQ=eHasEnergy;
const int    kSDRecLevel=eNoSdEvent;
const int    kSDRecLevelHQ=eHasLDF;
const double kSDMaxLgLDFChi2Prob=0;
const double kSDMaxLgAngChi2Prob=0;

const int kRdStationMin=0;
const double kRdRecLevelMin = 0.;
const int kRdminAzimuth = 0;
const int kRdmaxAzimuth = 360;

inline
string plural(const int n)
{
  return (n==1?"":"s");
}


/******************************************************/
EventSelection::EventSelection(TGCompositeFrame *main,
                               const DetectorGeometry *geometry) :
  fRDzenithHist(NULL)
{
  fMain = main;
  fMain->SetCleanup(kDeepCleanup);

  fSelectionObjects = new TObjArray();
  fSelectionObjects->SetOwner(kTRUE);
  fSDenergyHist = NULL;
  fMCenergyHist = NULL;

  const double cutWidth  = 0.20;
  const double plotWidth = 0.42;
  const double textWidth = 0.22;


  TGHorizontalFrame * mainFrame = new TGHorizontalFrame(main, main->GetWidth(),
                                                        main->GetHeight());
  main->AddFrame(mainFrame);

  //============== one vertical frame to hold the cuts

  TGLayoutHints * textLayout =
    new TGLayoutHints(kLHintsTop | kLHintsLeft, 4, 2, 1, 2);
  TGLayoutHints * horizontalLayout =
    new TGLayoutHints(kLHintsExpandX, 2, 2, 2, 2);

  TGVerticalFrame * cutFrame =
    new TGVerticalFrame(mainFrame,
                        (UInt_t) (cutWidth*mainFrame->GetWidth()),
                        mainFrame->GetHeight());
  mainFrame->AddFrame(cutFrame);


  /// frame for cut on shower & date variables
  TGHorizontalFrame * fShowerDateCutFrame = new TGHorizontalFrame(cutFrame);

  cutFrame->AddFrame(fShowerDateCutFrame);

  /// cuts on shower variables

  TGGroupFrame * showerCuts =
    new TGGroupFrame(fShowerDateCutFrame, "Shower", kVerticalFrame);
  showerCuts->SetTitlePos(TGGroupFrame::kLeft);

  TGHorizontalFrame * showerSubFrame  = new TGHorizontalFrame(showerCuts);
  TGVerticalFrame   * showerSubFrame1 = new TGVerticalFrame(showerSubFrame);
  TGVerticalFrame   * showerSubFrame2 = new TGVerticalFrame(showerSubFrame);

  // a) min and max energy
  showerSubFrame1->AddFrame(new TGLabel(showerSubFrame1,"min. lg(E/eV)"));
  fEminTextField = new TGNumberEntry(showerSubFrame1,kEmin,7,-1,
                                     TGNumberFormat::kNESRealOne);
  showerSubFrame1->AddFrame(fEminTextField, horizontalLayout);

  showerSubFrame2->AddFrame(new TGLabel(showerSubFrame2,"max. lg(E/eV)"));
  fEmaxTextField = new TGNumberEntry(showerSubFrame2,kEmax,7,-1,
                                     TGNumberFormat::kNESRealOne);
  showerSubFrame2->AddFrame(fEmaxTextField, horizontalLayout);

  // b) min and max zenith
  showerSubFrame1->AddFrame(new TGLabel(showerSubFrame1,"min. zenith"));
  fZminTextField = new TGNumberEntry(showerSubFrame1,kZmin,7,-1,
                                     TGNumberFormat::kNESInteger,
                                     TGNumberFormat::kNEAAnyNumber,
                                     TGNumberFormat::kNELLimitMinMax,
                                     kZmin,kZmax);
  showerSubFrame1->AddFrame(fZminTextField, horizontalLayout);

  showerSubFrame2->AddFrame(new TGLabel(showerSubFrame2,"max. zenith"));
  fZmaxTextField = new TGNumberEntry(showerSubFrame2,kZmax,7,-1,
                                     TGNumberFormat::kNESInteger,
                                     TGNumberFormat::kNEAAnyNumber,
                                     TGNumberFormat::kNELLimitMinMax,
                                     kZmin,kZmax);
  showerSubFrame2->AddFrame(fZmaxTextField, horizontalLayout);

  // buttons controlling the energy/angular selection
  TGHButtonGroup *energySelectionButtonGroup =
    new TGHButtonGroup(showerCuts,"");
  showerCuts->AddFrame(energySelectionButtonGroup);
  fSDEnergySelectionButton = new TGCheckButton(energySelectionButtonGroup,
                                               "SD   ",eSDEnergySelection);
  fFDEnergySelectionButton = new TGCheckButton(energySelectionButtonGroup,
                                               "FD   ",eFDEnergySelection);
  fMCEnergySelectionButton = new TGCheckButton(energySelectionButtonGroup,
                                               "MC",eMCEnergySelection);
  fRDEnergySelectionButton = new TGCheckButton(energySelectionButtonGroup,
                                               "RD",eRDEnergySelection);

  fRDEnergySelectionButton->Connect("Clicked()", "EventSelection", this,
                                    "HandleButtonSignals()");

  fSDEnergySelectionButton->Connect("Clicked()", "EventSelection", this,
                                    "HandleButtonSignals()");
  fFDEnergySelectionButton->Connect("Clicked()", "EventSelection", this,
                                    "HandleButtonSignals()");
  fMCEnergySelectionButton->Connect("Clicked()", "EventSelection", this,
                                    "HandleButtonSignals()");



  energySelectionButtonGroup->Resize();
  showerSubFrame1->Resize();
  showerSubFrame2->Resize();

  showerSubFrame->AddFrame(showerSubFrame1);
  showerSubFrame->AddFrame(showerSubFrame2);
  showerCuts->AddFrame(showerSubFrame);

  showerSubFrame->Resize();
  showerCuts->Resize();
  fShowerDateCutFrame->AddFrame(showerCuts, textLayout);

  /// cuts on date variables

  TGGroupFrame * dateCuts =
    new TGGroupFrame(fShowerDateCutFrame, "Date", kVerticalFrame);
  dateCuts->SetTitlePos(TGGroupFrame::kLeft);

  TGHorizontalFrame * dateSinceSubFrame = new TGHorizontalFrame(dateCuts);
  TGHorizontalFrame * dateToSubFrame = new TGHorizontalFrame(dateCuts);
  TGVerticalFrame * dateSinceSubFrame1 = new TGVerticalFrame(dateSinceSubFrame);
  TGVerticalFrame * dateSinceSubFrame2 = new TGVerticalFrame(dateSinceSubFrame);
  TGVerticalFrame * dateToSubFrame1 = new TGVerticalFrame(dateToSubFrame);
  TGVerticalFrame * dateToSubFrame2 = new TGVerticalFrame(dateToSubFrame);

  // Since...
  dateCuts->AddFrame(new TGLabel(dateCuts,"Since when (included)"));
  dateSinceSubFrame1->AddFrame(new TGLabel(dateSinceSubFrame1,"YYYYMMDD"));
  fYYMMDDmin = new TGNumberEntry(dateSinceSubFrame1,kYYMMDDmin,8,-1,
                                 TGNumberFormat::kNESInteger,
                                 TGNumberFormat::kNEANonNegative,
                                 TGNumberFormat::kNELLimitMinMax,kYYMMDDmin,kYYMMDDmax);
  dateSinceSubFrame1->AddFrame(fYYMMDDmin, horizontalLayout);
  dateSinceSubFrame2->AddFrame(new TGLabel(dateSinceSubFrame2,"hhmmss"));
  fHHMMSSmin = new TGNumberEntry(dateSinceSubFrame2,kHHMMSS,6,-1,
                                 TGNumberFormat::kNESInteger,
                                 TGNumberFormat::kNEANonNegative,
                                 TGNumberFormat::kNELLimitMinMax,0,235959);
  dateSinceSubFrame2->AddFrame(fHHMMSSmin, horizontalLayout);

  dateSinceSubFrame1->Resize();
  dateSinceSubFrame2->Resize();
  dateSinceSubFrame->AddFrame(dateSinceSubFrame1);
  dateSinceSubFrame->AddFrame(dateSinceSubFrame2);

  dateSinceSubFrame->Resize();
  dateCuts->AddFrame(dateSinceSubFrame);

  // ...to
  dateCuts->AddFrame(new TGLabel(dateCuts,"To when (excluded)"));
  dateToSubFrame1->AddFrame(new TGLabel(dateToSubFrame1,"YYYYMMDD"));
  fYYMMDDmax = new TGNumberEntry(dateToSubFrame1,kYYMMDDmax,8,-1,
                                 TGNumberFormat::kNESInteger,
                                 TGNumberFormat::kNEANonNegative,
                                 TGNumberFormat::kNELLimitMinMax,kYYMMDDmin,kYYMMDDmax);
  dateToSubFrame1->AddFrame(fYYMMDDmax, horizontalLayout);
  dateToSubFrame2->AddFrame(new TGLabel(dateToSubFrame2,"hhmmss"));
  fHHMMSSmax = new TGNumberEntry(dateToSubFrame2,kHHMMSS,6,-1,
                                 TGNumberFormat::kNESInteger,
                                 TGNumberFormat::kNEANonNegative,
                                 TGNumberFormat::kNELLimitMinMax,0,235959);
  dateToSubFrame2->AddFrame(fHHMMSSmax, horizontalLayout);

  dateToSubFrame1->Resize();
  dateToSubFrame2->Resize();
  dateToSubFrame->AddFrame(dateToSubFrame1);
  dateToSubFrame->AddFrame(dateToSubFrame2);

  dateToSubFrame->Resize();
  dateCuts->AddFrame(dateToSubFrame);

  // Put the frame on
  dateCuts->Resize();
  fShowerDateCutFrame->AddFrame(dateCuts, textLayout);

  /// frame for cuts on FD and SD variables

  TGHorizontalFrame * fdSdCutFrame = new TGHorizontalFrame(cutFrame);

  cutFrame->AddFrame(fdSdCutFrame);

  /// cuts on SD variables

  TGGroupFrame * sdCuts = new TGGroupFrame(fdSdCutFrame, "SD", kVerticalFrame);
  sdCuts->SetTitlePos(TGGroupFrame::kLeft);

  sdCuts->AddFrame(new TGLabel(sdCuts,"min. # of tanks"));
  fTankTextField = new TGNumberEntry(sdCuts,kTankMin,4,-1,
                                     TGNumberFormat::kNESInteger,
                                     TGNumberFormat::kNEANonNegative);
  sdCuts->AddFrame(fTankTextField);

  sdCuts->AddFrame(new TGLabel(sdCuts,"min. trigger"));
  TGVerticalFrame * triggerFrame = new TGVerticalFrame(sdCuts);
  fSDTrigger3=new TGRadioButton(triggerFrame,new TGHotString("5T5"),
                                e5T5Trigger);
  fSDTrigger4=new TGRadioButton(triggerFrame,new TGHotString("T4"),eT4Trigger);
  fSDTrigger5=new TGRadioButton(triggerFrame,new TGHotString("6T5"),e6T5Trigger);
  fSDTrigger3->Connect("Clicked()", "EventSelection", this,
                       "HandleButtonSignals()");
  fSDTrigger4->Connect("Clicked()", "EventSelection", this,
                       "HandleButtonSignals()");
  fSDTrigger5->Connect("Clicked()", "EventSelection", this,
                       "HandleButtonSignals()");
  triggerFrame->AddFrame(fSDTrigger4, horizontalLayout);
  triggerFrame->AddFrame(fSDTrigger3, horizontalLayout);
  triggerFrame->AddFrame(fSDTrigger5, horizontalLayout);
  if (kT3Checked)
    fSDTrigger3->SetState(kButtonDown);
  if (kT4Checked)
    fSDTrigger4->SetState(kButtonDown);
  if (kT5Checked)
    fSDTrigger5->SetState(kButtonDown);
  sdCuts->AddFrame(triggerFrame, horizontalLayout);
  sdCuts->Resize();


  fSDRecLevel = new  TGComboBox(sdCuts);
  sdCuts->AddFrame(new TGLabel(sdCuts,"min. reconstruction level"));
  fSDRecLevel->AddEntry("---",eNoSdEvent);
  fSDRecLevel->AddEntry("triggered stations",eHasTriggeredStations);
  fSDRecLevel->AddEntry("axis",eHasSdAxis);
  fSDRecLevel->AddEntry("LDF",eHasLDF);
  fSDRecLevel->AddEntry("curvature",eHasCurvature);
  fSDRecLevel->Select(kSDRecLevel);
  sdCuts->AddFrame(fSDRecLevel);
  fSDRecLevel->Resize((int)(cutFrame->GetWidth()*0.6), 20);
  fSDSaturation=new TGCheckButton(sdCuts, "Select saturation");
  sdCuts->AddFrame(fSDSaturation, horizontalLayout);
  sdCuts->AddFrame(new TGLabel(sdCuts,"max. lg(P(chi^2)) [Ang]"));
  fSDAngChi2 = new TGNumberEntry(sdCuts,kSDMaxLgAngChi2Prob,5,-1,TGNumberFormat::kNESRealOne);
  fSDAngChi2->SetLimits(TGNumberFormat::kNELLimitMax, 0, 0);
  sdCuts->AddFrame(fSDAngChi2);
  sdCuts->AddFrame(new TGLabel(sdCuts,"max. lg(P(chi^2)) [LDF]"));
  fSDLDFChi2 = new TGNumberEntry(sdCuts,kSDMaxLgLDFChi2Prob,5,-1,TGNumberFormat::kNESRealOne);
  fSDLDFChi2->SetLimits(TGNumberFormat::kNELLimitMax, 0, 0);
  sdCuts->AddFrame(fSDLDFChi2);
  fdSdCutFrame->AddFrame(sdCuts, textLayout);

  /// cuts on FD variables
  TGGroupFrame * fdCuts = new TGGroupFrame(fdSdCutFrame, "FD", kVerticalFrame);
  fdCuts->SetTitlePos(TGGroupFrame::kLeft);

  fdCuts->AddFrame(new TGLabel(fdCuts,"min. # of eyes"));
  fEyeTextField = new TGNumberEntry(fdCuts,kEyeMin,1,eNEyeMin,
                                    TGNumberFormat::kNESInteger,
                                    TGNumberFormat::kNEANonNegative);
  fdCuts->AddFrame(fEyeTextField);
  fdCuts->AddFrame(new TGLabel(fdCuts,"min. # of pixels"));
  fPixelTextField = new TGNumberEntry(fdCuts,kPixelMin,3,ePixelMin,
                                      TGNumberFormat::kNESInteger,
                                      TGNumberFormat::kNEANonNegative);
  fPixelTextField->Connect("ValueSet(Long_t)", "EventSelection", this,
                           "HandleButtonSignals()");
  fdCuts->AddFrame(fPixelTextField);

  TGHorizontalFrame * xmaxSubFrame  = new TGHorizontalFrame(fdCuts);
  TGVerticalFrame   * xmaxSubFrame1 = new TGVerticalFrame(xmaxSubFrame);
  TGVerticalFrame   * xmaxSubFrame2 = new TGVerticalFrame(xmaxSubFrame);
  xmaxSubFrame1->AddFrame(new TGLabel(xmaxSubFrame1,"Xmax"));
  fXminTextField = new TGNumberEntry(xmaxSubFrame1,EventInfo::GetMinXmax(),5,eXmin,
                                     TGNumberFormat::kNESInteger,
                                     TGNumberFormat::kNEAAnyNumber,
                                     TGNumberFormat::kNELLimitMinMax,
                                     EventInfo::GetMinXmax(),
                                     EventInfo::GetMaxXmax());
  fXminTextField->Connect("ValueSet(Long_t)", "EventSelection", this,
                          "HandleButtonSignals()");
  xmaxSubFrame1->AddFrame(fXminTextField);
  xmaxSubFrame2->AddFrame(new TGLabel(xmaxSubFrame2,""));
  fXmaxTextField = new TGNumberEntry(xmaxSubFrame2, EventInfo::GetMaxXmax(),5,eXmax,
                                     TGNumberFormat::kNESInteger,
                                     TGNumberFormat::kNEAAnyNumber,
                                     TGNumberFormat::kNELLimitMinMax,
                                     EventInfo::GetMinXmax(),
                                     EventInfo::GetMaxXmax());
  fXmaxTextField->Connect("ValueSet(Long_t)", "EventSelection", this,
                          "HandleButtonSignals()");
  xmaxSubFrame2->AddFrame(fXmaxTextField);
  xmaxSubFrame1->Resize();
  xmaxSubFrame2->Resize();
  xmaxSubFrame->AddFrame(xmaxSubFrame1);
  xmaxSubFrame->AddFrame(xmaxSubFrame2);
  xmaxSubFrame->Resize();
  fdCuts->AddFrame(xmaxSubFrame);

  fFDRecLevel = new  TGComboBox(fdCuts,eFDRecLevel);
  fdCuts->AddFrame(new TGLabel(fdCuts,"min. reconstruction level"));
  fFDRecLevel->AddEntry("---",eNoFdEvent);
  fFDRecLevel->AddEntry("rec. pixels",eHasReconstructedPixels);
  fFDRecLevel->AddEntry("SDP",eHasSDP);
  fFDRecLevel->AddEntry("axis",eHasAxis);
  fFDRecLevel->AddEntry("photons at aperture",eHasAperturePhotons);
  fFDRecLevel->AddEntry("dEdX",eHasLongitudinalProfile);
  fFDRecLevel->AddEntry("Gaisser-Hillas",eHasGHParameters);
  fFDRecLevel->AddEntry("Energy",eHasEnergy);
  fFDRecLevel->Select(kFDRecLevel);
  fFDRecLevel->Connect("Selected(Int_t)", "EventSelection", this,
                       "HandleButtonSignals()");
  fdCuts->AddFrame(fFDRecLevel);
  fFDRecLevel->Resize((int)(cutFrame->GetWidth()*0.6), 20);

  fHybridButton = new TGCheckButton(fdCuts,"Hybrid",eAnyFDButton);
  fHybridButton->Connect("Clicked()", "EventSelection", this, "HandleButtonSignals()");
  fdCuts->AddFrame(fHybridButton);
  fFOVButton = new TGCheckButton(fdCuts, "Xmax in FOV", eAnyFDButton);
  fFOVButton->Connect("Clicked()", "EventSelection", this, "HandleButtonSignals()");
  fdCuts->AddFrame(fFOVButton);

  //Eye selection buttons
  TGVerticalFrame* eyesSubFrame = new TGVerticalFrame(fdCuts);
  const unsigned int nEyes = geometry->GetNEyes();
  vector<TGHorizontalFrame*> coupleSubFrames(int(ceil(0.5*nEyes)));
  unsigned int eyeIndex = 0;
  for (DetectorGeometry::ConstEyeIterator eyeIter = geometry->EyesBegin();
       eyeIter != geometry->EyesEnd(); ++eyeIter, ++eyeIndex) {
    const EyeGeometry& eyeGeometry = eyeIter->second;
    const unsigned int eyeId = eyeIter->first;
    if (!(eyeIndex%2))
      coupleSubFrames[eyeIndex/2] = new TGHorizontalFrame(eyesSubFrame);
    fEyes[eyeId] = new TGCheckButton(coupleSubFrames[eyeIndex/2],
                                     eyeGeometry.GetEyeNameAbbr()+"\t\t",
                                     eAnyFDButton);
    fEyes[eyeId]->SetState(kButtonDown, false);
    coupleSubFrames[eyeIndex/2]->AddFrame(fEyes[eyeId]);
    if (eyeIndex%2 == 1 || (nEyes%2 == 1 && eyeIndex+1 == nEyes)) {
      coupleSubFrames[eyeIndex/2]->Resize();
      eyesSubFrame->AddFrame(coupleSubFrames[eyeIndex/2]);
    }
  }
  fdCuts->AddFrame(new TGLabel(fdCuts,"Eye selection"));
  fdCuts->AddFrame(eyesSubFrame);

  fdCuts->Resize();
  fdSdCutFrame->AddFrame(fdCuts, textLayout);

  /// frame for cuts on Radio variables

  TGHorizontalFrame * rdCutFrame = new TGHorizontalFrame(cutFrame);

  TGGroupFrame * rdCuts = new TGGroupFrame(rdCutFrame, "RD", kVerticalFrame);
  rdCuts->SetTitlePos(TGGroupFrame::kLeft);

  rdCuts->AddFrame(new TGLabel(rdCuts,"min. # of stations"));
  fRdStationTextField = new TGNumberEntry(rdCuts,kRdStationMin,4,-1,
                                          TGNumberFormat::kNESInteger,
                                          TGNumberFormat::kNEANonNegative);
  rdCuts->AddFrame(fRdStationTextField);

  rdCuts->AddFrame(new TGLabel(rdCuts,"min. rec stage"));
  fRdRecLevelTextField = new TGNumberEntry(rdCuts,kRdRecLevelMin,4,-1,
                                           TGNumberFormat::kNESRealOne,
                                           TGNumberFormat::kNEANonNegative);
  rdCuts->AddFrame(fRdRecLevelTextField);

  // azimuth selection ....

  TGHorizontalFrame* rdCutSubFrame  = new TGHorizontalFrame(rdCuts);
  TGVerticalFrame* rdCutSubFrame1 = new TGVerticalFrame(rdCutSubFrame);
  TGVerticalFrame* rdCutSubFrame2 = new TGVerticalFrame(rdCutSubFrame);

  rdCutSubFrame1->AddFrame(new TGLabel(rdCutSubFrame1,"min. phi"));
  fRdminAzimuthTextField = new TGNumberEntry(rdCutSubFrame1,kRdminAzimuth,6,-1,
                                             TGNumberFormat::kNESInteger,
                                             TGNumberFormat::kNEAAnyNumber,
                                             TGNumberFormat::kNELLimitMinMax,
                                             kRdminAzimuth,kRdmaxAzimuth);
  rdCutSubFrame1->AddFrame(fRdminAzimuthTextField);

  rdCutSubFrame2->AddFrame(new TGLabel(rdCutSubFrame2,"max. phi"));
  fRdmaxAzimuthTextField = new TGNumberEntry(rdCutSubFrame2,kRdmaxAzimuth,6,-1,
                                             TGNumberFormat::kNESInteger,
                                             TGNumberFormat::kNEAAnyNumber,
                                             TGNumberFormat::kNELLimitMinMax,
                                             kRdminAzimuth,kRdmaxAzimuth);
  rdCutSubFrame2->AddFrame(fRdmaxAzimuthTextField);

  rdCutSubFrame1->Resize();
  rdCutSubFrame2->Resize();
  rdCutSubFrame->AddFrame(rdCutSubFrame1);
  rdCutSubFrame->AddFrame(rdCutSubFrame2);
  rdCutSubFrame->Resize();

  rdCuts->AddFrame(rdCutSubFrame);
  rdCutFrame->AddFrame(rdCuts, textLayout);
  cutFrame->AddFrame(rdCutFrame, textLayout);

  TGLayoutHints * topLeft3111 =
    new TGLayoutHints(kLHintsTop|kLHintsLeft,3, 1, 1, 1);
  TGLayoutHints * cXcY3333 =
    new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3);

  // get pointer to browser for button connections
  const EventBrowser* theBrowser =
    const_cast<EventBrowser*>((const EventBrowser*)
                              main->GetParent()->GetParent());

  fSelectionButton = new TGCheckButton(cutFrame,"enable selection",
                                       eEnableSelection);
  fSelectionButton->Associate(theBrowser);
  cutFrame->AddFrame(fSelectionButton, topLeft3111);
  fSelectionFromHistButton = new TGCheckButton(cutFrame,
                                               "select from hist-range");
  fSelectionFromHistButton->SetToolTipText("select from range of x-Axis"
                                           " of histograms");
  cutFrame->AddFrame(fSelectionFromHistButton, topLeft3111);

  TGHorizontalFrame * selButtonFrame = new TGHorizontalFrame(cutFrame);

  fResetButton = new TGTextButton(selButtonFrame," reset ",eResetSelection);
  fResetButton->Associate(theBrowser);
  fResetButton->SetToolTipText("reset default values");
  selButtonFrame->AddFrame(fResetButton, topLeft3111);

  fHQSDButton = new TGTextButton(selButtonFrame," HQ SD ",eHQSDSelection);
  fHQSDButton->Associate(theBrowser);
  fHQSDButton->SetToolTipText("select high quality SD");
  selButtonFrame->AddFrame(fHQSDButton, topLeft3111);

  fHQFDButton = new TGTextButton(selButtonFrame," DQ FD ",eHQFDSelection);
  fHQFDButton->Associate(theBrowser);
  fHQFDButton->SetToolTipText("select decent quality FD");
  selButtonFrame->AddFrame(fHQFDButton, topLeft3111);

  fFileSelectionButton = new TGTextButton(selButtonFrame,
                                          " from file ",eFileSelection);
  fFileSelectionButton->Associate(theBrowser);
  fFileSelectionButton->SetToolTipText("select SD event IDs from a text file");
  selButtonFrame->AddFrame(fFileSelectionButton,
                           new TGLayoutHints(kLHintsTop|kLHintsLeft,1,1,1,1));

  cutFrame->AddFrame(selButtonFrame);

  fUpdateButton = new TGTextButton(cutFrame,"update",eUpdateSelection);
  fUpdateButton->Associate(theBrowser);
  fUpdateButton->SetToolTipText("update list of selected events");
  cutFrame->AddFrame(fUpdateButton, topLeft3111);

  //============== a vertical frames to hold the plots and the event finder

  const double kCanvasHeight = 0.43;
  const double kPadLeftMargin = 0.15;
  const double kPadRightMargin = 0.05;
  const double kPadBottomMargin = 0.18;
  const double kPadTopMargin = 0.02;

  TGVerticalFrame * plotFrame =
    new TGVerticalFrame(mainFrame,
                        (UInt_t) (plotWidth*mainFrame->GetWidth()),
                        mainFrame->GetHeight());
  mainFrame->AddFrame(plotFrame);

  TGHorizontalFrame * energyAndZenithFrame =
    new TGHorizontalFrame(plotFrame,
                          plotFrame->GetWidth(),
                          (UInt_t) (kCanvasHeight*plotFrame->GetHeight()));

  TRootEmbeddedCanvas* embeddedCanvasEnergy =
    new TRootEmbeddedCanvas("CanvasEnergy",  energyAndZenithFrame,
                            (UInt_t) (0.5*energyAndZenithFrame->GetWidth()),
                            energyAndZenithFrame->GetHeight());

  energyAndZenithFrame->AddFrame(embeddedCanvasEnergy,cXcY3333);
  fCanvasEnergy = embeddedCanvasEnergy->GetCanvas();
  fCanvasEnergy->SetLeftMargin(kPadLeftMargin);
  fCanvasEnergy->SetRightMargin(kPadRightMargin);
  fCanvasEnergy->SetBottomMargin(kPadBottomMargin);
  fCanvasEnergy->SetTopMargin(kPadTopMargin);
  fCanvasEnergy->cd();
  fCanvasEnergy->Clear();
  fCanvasEnergy->Modified();
  fCanvasEnergy->Update();

  TRootEmbeddedCanvas* embeddedCanvasZenith =
    new TRootEmbeddedCanvas("CanvasZenith",  energyAndZenithFrame,
                            (UInt_t) (0.5*energyAndZenithFrame->GetWidth()),
                            energyAndZenithFrame->GetHeight());
  energyAndZenithFrame->AddFrame(embeddedCanvasZenith,cXcY3333);

  fCanvasZenith = embeddedCanvasZenith->GetCanvas();
  fCanvasZenith->SetLeftMargin(kPadLeftMargin);
  fCanvasZenith->SetRightMargin(kPadRightMargin);
  fCanvasZenith->SetBottomMargin(kPadBottomMargin);
  fCanvasZenith->SetTopMargin(kPadTopMargin);
  fCanvasZenith->cd();
  fCanvasZenith->Clear();
  fCanvasZenith->Modified();
  fCanvasZenith->Update();

  plotFrame->AddFrame(energyAndZenithFrame);

  TGHorizontalFrame * pixelStationFrame =
    new TGHorizontalFrame(plotFrame,
                          plotFrame->GetWidth(),
                          (UInt_t) (0.7*kCanvasHeight*plotFrame->GetHeight()));

  TRootEmbeddedCanvas* embeddedCanvasStations =
    new TRootEmbeddedCanvas("CanvasStations",  pixelStationFrame,
                            (UInt_t) (0.33*pixelStationFrame->GetWidth()),
                            pixelStationFrame->GetHeight());

  pixelStationFrame->AddFrame(embeddedCanvasStations,cXcY3333);
  fCanvasStations = embeddedCanvasStations->GetCanvas();
  fCanvasStations->SetLeftMargin(kPadLeftMargin);
  fCanvasStations->SetRightMargin(kPadRightMargin);
  fCanvasStations->SetBottomMargin(kPadBottomMargin);
  fCanvasStations->SetTopMargin(kPadTopMargin);
  fCanvasStations->cd();
  fCanvasStations->Clear();
  fCanvasStations->Modified();
  fCanvasStations->Update();

  TRootEmbeddedCanvas* embeddedCanvasPixels =
    new TRootEmbeddedCanvas("CanvasPixels",  pixelStationFrame,
                            (UInt_t) (0.33*pixelStationFrame->GetWidth()),
                            pixelStationFrame->GetHeight());
  pixelStationFrame->AddFrame(embeddedCanvasPixels,cXcY3333);
  fCanvasPixels = embeddedCanvasPixels->GetCanvas();
  fCanvasPixels->SetLeftMargin(kPadLeftMargin);
  fCanvasPixels->SetRightMargin(kPadRightMargin);
  fCanvasPixels->SetBottomMargin(kPadBottomMargin);
  fCanvasPixels->SetTopMargin(kPadTopMargin);
  fCanvasPixels->cd();
  fCanvasPixels->Clear();
  fCanvasPixels->Modified();
  fCanvasPixels->Update();

  TRootEmbeddedCanvas* embeddedCanvasEyes =
    new TRootEmbeddedCanvas("CanvasEyes",  pixelStationFrame,
                            (UInt_t) (0.33*pixelStationFrame->GetWidth()),
                            pixelStationFrame->GetHeight());
  pixelStationFrame->AddFrame(embeddedCanvasEyes,cXcY3333);
  fCanvasEyes = embeddedCanvasEyes->GetCanvas();
  fCanvasEyes->SetLeftMargin(kPadLeftMargin);
  fCanvasEyes->SetRightMargin(kPadRightMargin);
  fCanvasEyes->SetBottomMargin(kPadBottomMargin);
  fCanvasEyes->SetTopMargin(kPadTopMargin);
  fCanvasEyes->cd();
  fCanvasEyes->Clear();
  fCanvasEyes->Modified();
  fCanvasEyes->Update();

  plotFrame->AddFrame(pixelStationFrame);

  // event finding

  TGLayoutHints * finderLayout =
    new TGLayoutHints(kLHintsTop | kLHintsRight, 1, 1, 2, 2);
  TGGroupFrame * eventFinder =
    new TGGroupFrame(plotFrame, "find event", kVerticalFrame);
  eventFinder->SetTitlePos(TGGroupFrame::kLeft);

  TGHorizontalFrame * auFinder = new TGHorizontalFrame(eventFinder);
  fFindAUID = new TGNumberEntry(auFinder,0,12,-1,TGNumberFormat::kNESInteger,
                                TGNumberFormat::kNEANonNegative);
  fFindAUButton = new TGTextButton(auFinder,"find",eFindAUID);
  fFindAUButton->Associate(theBrowser);
  fFindAUButton->SetToolTipText("find event given Auger ID");
  auFinder->AddFrame(fFindAUButton, finderLayout);
  auFinder->AddFrame(fFindAUID, finderLayout);
  auFinder->AddFrame(new TGLabel(auFinder,"Auger Id  "), finderLayout);
  eventFinder->AddFrame(auFinder, finderLayout);

  TGHorizontalFrame * sdFinder = new TGHorizontalFrame(eventFinder);
  fFindSDID = new TGNumberEntry(sdFinder,0,10,-1,TGNumberFormat::kNESInteger,
                                TGNumberFormat::kNEANonNegative);
  fFindSDButton = new TGTextButton(sdFinder,"find",eFindSDID);
  fFindSDButton->Associate(theBrowser);
  fFindSDButton->SetToolTipText("find event given SD ID");
  sdFinder->AddFrame(fFindSDButton, finderLayout);
  sdFinder->AddFrame(fFindSDID, finderLayout);
  sdFinder->AddFrame(new TGLabel(sdFinder,"SD Id  "), finderLayout);
  eventFinder->AddFrame(sdFinder, finderLayout);

  TGHorizontalFrame * fdFinder = new TGHorizontalFrame(eventFinder);
  fFindFDEye = new TGNumberEntry(fdFinder,0,1,-1,TGNumberFormat::kNESInteger,
                                 TGNumberFormat::kNEANonNegative);
  fFindFDRun = new TGNumberEntry(fdFinder,0,5,-1,TGNumberFormat::kNESInteger,
                                 TGNumberFormat::kNEANonNegative);
  fFindFDEvent = new TGNumberEntry(fdFinder,0,5,-1,TGNumberFormat::kNESInteger,
                                   TGNumberFormat::kNEANonNegative);
  fFindFDButton = new TGTextButton(fdFinder,"find",eFindFDID);
  fFindFDButton->Associate(theBrowser);
  fFindFDButton->SetToolTipText("find event given FD ID");

  fdFinder->AddFrame(fFindFDButton, finderLayout);
  fdFinder->AddFrame(fFindFDEvent,finderLayout);
  fdFinder->AddFrame(fFindFDRun,finderLayout);
  fdFinder->AddFrame(fFindFDEye,finderLayout);
  fdFinder->AddFrame(new TGLabel(fdFinder,"FD eye/run/event  "),finderLayout);

  eventFinder->AddFrame(fdFinder, finderLayout);

  TGHorizontalFrame * rdFinder = new TGHorizontalFrame(eventFinder);
  fFindRDRun = new TGNumberEntry(rdFinder,0,6,-1,TGNumberFormat::kNESInteger,
                                 TGNumberFormat::kNEANonNegative);
  fFindRDEvent = new TGNumberEntry(rdFinder,0,6,-1,TGNumberFormat::kNESInteger,
                                   TGNumberFormat::kNEANonNegative);
  fFindRDButton = new TGTextButton(rdFinder,"find",eFindRDID);
  fFindRDButton->Associate(theBrowser);
  fFindRDButton->SetToolTipText("find event given RD run and event");
  eventFinder->AddFrame(rdFinder, finderLayout);

  rdFinder->AddFrame(fFindRDButton, finderLayout);
  rdFinder->AddFrame(fFindRDEvent, finderLayout);
  rdFinder->AddFrame(fFindRDRun, finderLayout);
  rdFinder->AddFrame(new TGLabel(rdFinder,"RD run/event  "), finderLayout);

  eventFinder->Resize();
  plotFrame->AddFrame(eventFinder, textLayout);

  //============== a vertical frame to hold the event statistics

  TGVerticalFrame * infoFrame =
    new TGVerticalFrame(mainFrame,
                        (UInt_t) (textWidth*mainFrame->GetWidth()),
                        (UInt_t) (1.7*kCanvasHeight*mainFrame->GetHeight()));
  mainFrame->AddFrame(infoFrame);
  TRootEmbeddedCanvas* embeddedCanvasInfo =
    new TRootEmbeddedCanvas("CanvasInfo",  infoFrame,
                            (UInt_t) (infoFrame->GetWidth()),
                            (UInt_t) (infoFrame->GetHeight()));
  infoFrame->AddFrame(embeddedCanvasInfo,cXcY3333);
  fCanvasInfo = embeddedCanvasInfo->GetCanvas();
  fCanvasInfo->SetLeftMargin(0.095);
  fCanvasInfo->SetRightMargin(0.105);
  fCanvasInfo->SetBottomMargin(0.14);
  fCanvasInfo->SetTopMargin(0.06);

  fCanvasInfo->cd();
  fCanvasInfo->Clear();
  fCanvasInfo->Modified();
  fCanvasInfo->Update();

  ToggleSelectionEnable();
}


EventSelection::~EventSelection()
{
  fMain->Cleanup();
}


/***********************************************************/
void
EventSelection::SelectEvents(const vector<EventInfo>& eventInfo,
                             TGComboBox* const mainEventList)
{
  if (fEventInfoClassVersion < 5) {
    fXminTextField->SetState(false);
    fXmaxTextField->SetState(false);
  }

  if (fSelectionFromHistButton->IsDown())
    GetRangeFromHistograms();

  ResetHistograms();

  mainEventList->RemoveEntries(0, eventInfo.size() - 1);

  fSelectionObjects->Delete();
  fSelectedEvents.clear();

  fCanvasZenith->Clear();
  fCanvasEnergy->Clear();
  fCanvasPixels->Clear();
  fCanvasEyes->Clear();
  fCanvasStations->Clear();

  // get all current cuts
  const double Emin = pow(10., fEminTextField->GetNumber());
  const double Emax = pow(10., fEmaxTextField->GetNumber());
  const double zmin = fZminTextField->GetNumber()*degree;
  const double zmax = fZmaxTextField->GetNumber()*degree;
  const unsigned int YYMMDDmin = fYYMMDDmin->GetNumber() - 20000000;
  const unsigned int HHMMSSmin = fHHMMSSmin->GetNumber();
  const unsigned int YYMMDDmax = fYYMMDDmax->GetNumber() - 20000000;
  const unsigned int HHMMSSmax = fHHMMSSmax->GetNumber();
  const unsigned int minTanks = (unsigned int)(fTankTextField->GetNumber());
  const unsigned int minPix = (unsigned int)(fPixelTextField->GetNumber());
  const int minXmax = fEventInfoClassVersion >= 5 ?
    int(fXminTextField->GetNumber()) : 0;
  const int maxXmax = fEventInfoClassVersion >= 5 ?
    int(fXmaxTextField->GetNumber()) : 0;
  const int minEyes = (unsigned int)(fEyeTextField->GetNumber());

  const int  minSDRecLevel = fSDRecLevel->GetSelected();
  const bool selectT4 = fSDTrigger4->IsDown();
  const bool select5T5 = fSDTrigger3->IsDown();
  const bool select6T5 = fSDTrigger5->IsDown();
  const bool triggerSelected = selectT4 || select5T5 || select6T5;
  const bool selectSat = fSDSaturation->IsDown();
  const double maxPAng = pow(10., fSDAngChi2->GetNumber());
  const double maxPLDF = pow(10., fSDLDFChi2->GetNumber());
  const bool useSD= fSDEnergySelectionButton->IsDown();
  const bool useFD= fFDEnergySelectionButton->IsDown();
  const bool useMC= fMCEnergySelectionButton->IsDown();
  const bool useRD = fRDEnergySelectionButton->IsDown();

  const bool selectHybrids = fHybridButton->IsDown();
  const bool selectInFOV = fFOVButton->IsDown();

  const bool noEandZSelection = (fEminTextField->GetNumber() == kEmin &&
                                 fEmaxTextField->GetNumber() == kEmax &&
                                 fZminTextField->GetNumber() == kZmin &&
                                 fZmaxTextField->GetNumber() == kZmax);

  const bool checkEandZ = !((!useSD && !useFD && !useMC
                            && !useRD
                            ) || noEandZSelection);

  const int minFDRecLevel = fFDRecLevel->GetSelected();

  const unsigned int minRdStations = (unsigned int)(fRdStationTextField->GetNumber());
  const double minRdRecLevel = double(fRdRecLevelTextField->GetNumber());
  double minRdAzimuth = 0;
  double maxRdAzimuth = 0;
  if (useRD){
    minRdAzimuth = (double)fRdminAzimuthTextField->GetNumber()*degree;
    maxRdAzimuth = (double)fRdmaxAzimuthTextField->GetNumber()*degree;
  }

  // reset counters

  int nSD = 0;
  int nFD = 0;
  int nHybrid = 0;
  int nGoldenHybrid = 0;
  int nStereo = 0;
  int nTriple = 0;
  int nQuadruple = 0;
  int nRd=0;

  fCanvasInfo->cd();
  fCanvasInfo->Clear();
  stringstream progress;
  progress << "updating event info";
  TLatex patiencePlease;
  patiencePlease.SetNDC();
  patiencePlease.SetTextAlign(12);
  patiencePlease.SetTextSize(0.05);
  const int nPatience = eventInfo.size()/5;

  for (unsigned int i=0; i<eventInfo.size(); ++i) {

    if (nPatience > 0 && i % nPatience == 0) {
      progress << ".";
      fCanvasInfo->Clear();
      patiencePlease.DrawLatex (0.25,0.6,progress.str().c_str());
      fCanvasInfo->Modified();
      fCanvasInfo->Update();
    }

    const EventInfo  & currentEvent = eventInfo[i];

    const int nEyes = currentEvent.GetNumberOfEyes();
    vector<int> goodEyes;
    bool selected = false;

    if (!fSelectionButton->IsDown()) {

      selected = true;

      for (int eyeIndex=0; eyeIndex < nEyes; ++eyeIndex) {
        goodEyes.push_back(eyeIndex);
      }

    }
    else {  //selection button is down

      bool sdZenithAndEnergyInRange = !checkEandZ;
      bool fdZenithAndEnergyInRange = !checkEandZ;
      bool rdZenithAndEnergyInRange = !checkEandZ;
      bool dateIsSelected = false;
      bool fdIsSelected = false;
      bool sdIsSelected = false;
      bool rdIsSelected = false;
      bool fileIsSelected = fFileSelectedEvents.empty() ? true : false;

      // date selection
      const unsigned int evYYMMDD = currentEvent.GetYYMMDD();
      const unsigned int evHHMMSS = currentEvent.GetHHMMSS();
      if (evYYMMDD >= YYMMDDmin && evYYMMDD <= YYMMDDmax)
        dateIsSelected = !((evYYMMDD == YYMMDDmin && evHHMMSS < HHMMSSmin) ||
                           (evYYMMDD == YYMMDDmax && evHHMMSS >= HHMMSSmax));

      // SD quality selection
      if (currentEvent.GetSDRecLevel() >= minSDRecLevel &&
          currentEvent.GetNumberOfStations() >= minTanks &&
          (!triggerSelected || (selectT4 && currentEvent.IsT4()) ||
           (select6T5 && currentEvent.Is6T5()) ||
           (select5T5 && currentEvent.Is5T5())) &&
          (!selectSat || currentEvent.IsSaturated()) &&
          (currentEvent.GetSDAngChi2Probability() <= maxPAng) &&
          (currentEvent.GetSDLDFChi2Probability() <= maxPLDF) )
        sdIsSelected = true;
      // Make sure that Radio data is only asked for when button is checked!
      if (!useRD) {
        rdIsSelected = true;
      }

      if (useRD &&
          minRdStations <= currentEvent.GetRdNumberOfStations() &&
          minRdRecLevel <= currentEvent.GetRdRecStage() &&
          minRdAzimuth <= currentEvent.GetRdAzimuth() &&
          maxRdAzimuth >= currentEvent.GetRdAzimuth())
        rdIsSelected = true;

      // FD quality selection
      if (nEyes >= minEyes) {
        for (int eyeIndex = 0; eyeIndex < nEyes; ++eyeIndex) {
          if ((minEyes == 0 ||
               (currentEvent.GetFDRecLevel(eyeIndex) >= minFDRecLevel &&
                currentEvent.GetNumberOfTriggeredPixels(eyeIndex) >= minPix &&
                (fEventInfoClassVersion < 5 ||
                 (currentEvent.GetXmax(eyeIndex) >= minXmax &&
                  currentEvent.GetXmax(eyeIndex) < maxXmax)) &&
                (!selectHybrids || currentEvent.IsHybrid(eyeIndex)) &&
                (!selectInFOV || currentEvent.IsXmaxInFOV(eyeIndex)))) &&
              fEyes[currentEvent.GetEyeId(eyeIndex)]->IsDown()) {
            goodEyes.push_back(eyeIndex);
          }
        }
      }

      // if minEyes == 0, ignore all selection
      fdIsSelected = !goodEyes.empty() || (minEyes==0);

      if (fFileSelectedEvents.find(currentEvent.GetSDId())
          != fFileSelectedEvents.end())
        fileIsSelected = true;

      //energy and zenith selection
      if(useMC && checkEandZ && currentEvent.GetMCEnergy() >0) { //MC selection

        if(currentEvent.GetMCEnergy() >= Emin &&
           currentEvent.GetMCEnergy() <  Emax &&
           currentEvent.GetMCZenith() >= zmin &&
           currentEvent.GetMCZenith() <  zmax ) {
          sdZenithAndEnergyInRange=true;
          fdZenithAndEnergyInRange=true;
        }
      }
      else { // data selection
        // SD
        if (useSD && checkEandZ) {
          if(currentEvent.GetSDEnergy() >= Emin &&
             currentEvent.GetSDEnergy() <  Emax &&
             currentEvent.GetSDZenith() >= zmin &&
             currentEvent.GetSDZenith() <  zmax ) {
            sdZenithAndEnergyInRange=true;
          }
          else {
            sdZenithAndEnergyInRange=false;
          }
        }
        else
          sdZenithAndEnergyInRange = true;

        // FD/Hybrid
        if (useFD && checkEandZ) {
          for (unsigned int i = 0; i < goodEyes.size(); ++i) {
            if (currentEvent.GetFDEnergy(goodEyes[i]) >= Emin &&
                currentEvent.GetFDEnergy(goodEyes[i]) <  Emax &&
                currentEvent.GetFDZenith(goodEyes[i]) >= zmin &&
                currentEvent.GetFDZenith(goodEyes[i]) <  zmax) {
              fdZenithAndEnergyInRange = true;
              break;
            }
          }
        } else
          fdZenithAndEnergyInRange = true;

        // RD
        if (useRD && checkEandZ) {
          rdZenithAndEnergyInRange =
            (currentEvent.GetRdZenith() >= zmin) && (currentEvent.GetRdZenith() < zmax);
        } else
          rdZenithAndEnergyInRange = true;
      }

      if ((dateIsSelected && fdIsSelected && sdIsSelected && fileIsSelected) &&
          (fdZenithAndEnergyInRange) &&
          (sdZenithAndEnergyInRange)
          && (rdIsSelected && rdZenithAndEnergyInRange)
          ) {

        selected=true;

      }
    }

    if (selected) {
      fSelectedEvents.push_back(i);
      mainEventList->AddEntry(currentEvent.InfoAsString().c_str(), i);

      FillSDHistos(currentEvent);
      FillMCHistos(currentEvent);
      FillRDHistos(currentEvent);

      FillFDHistos(currentEvent,goodEyes);

      bool hybrid = false;
      for (unsigned int i = 0; i < goodEyes.size(); ++i) {
        if (currentEvent.IsHybrid(goodEyes[i]))
          hybrid = true;
      }

      if (hybrid)
        ++nHybrid;
      if (goodEyes.size()) {
        ++nFD;
        if (goodEyes.size() == 2)
          ++nStereo;
        else if (goodEyes.size() == 3)
          ++nTriple;
        else if (goodEyes.size() == 4)
          ++nQuadruple;
      }

      if (currentEvent.GetSDRecLevel() >= eHasSdAxis) {
        ++nSD;
        if (hybrid)
          ++nGoldenHybrid;
      }
      if (currentEvent.GetRdRecStage() >= 0.5) // 0.5 kBary
        ++nRd;

    }
  }

  if (fSelectedEvents.empty()) {
    mainEventList->AddEntry(" +++ no event matched selection +++ ",0);
    mainEventList->Select(0);
  } else
    fEventIterator = fSelectedEvents.begin();

  DrawHistos();

  // draw statistics

  const double x = 0.1;
  const double dy = 0.06;
  double y = 0.85;

  fCanvasInfo->cd();
  fCanvasInfo->Clear();
  stringstream info;
  TLatex * header = new TLatex();
  fSelectionObjects->Add(header);
  header->SetNDC();
  header->SetTextAlign(12);
  header->SetTextSize(0.06);
  header->SetTextColor(kRed);
  info << fSelectedEvents.size()
       << " event" << plural(fSelectedEvents.size())
       << " selected ";
  header->DrawLatex (x,y,info.str().c_str()); info.str("");
  y-=2*dy;

  TLatex * infotext = new TLatex();
  fSelectionObjects->Add(infotext);

  infotext->SetNDC();
  infotext->SetTextAlign(12);
  infotext->SetTextSize(0.05);

  info << nSD << " SD event" << plural(nSD);
  infotext->DrawLatex (x,y,info.str().c_str()); info.str(""); y-=dy;

  info << nFD << " FD event" << plural(nFD);
  infotext->DrawLatex(x,y,info.str().c_str()); info.str(""); y-=dy;

  info << nHybrid << " brass hybrid event" << plural(nHybrid);
  infotext->DrawLatex(x,y,info.str().c_str()); info.str(""); y-=dy;

  info << nGoldenHybrid << " golden hybrid event" << plural(nGoldenHybrid);
  infotext->DrawLatex(x,y,info.str().c_str()); info.str(""); y-=dy;

  info << nStereo << " stereo event" << plural(nStereo);
  infotext->DrawLatex(x,y,info.str().c_str()); info.str(""); y-=dy;

  info << nTriple << " triple event" << plural(nTriple);
  infotext->DrawLatex(x,y,info.str().c_str()); info.str(""); y-=dy;

  info << nQuadruple << " quadruple event" << plural(nQuadruple);
  infotext->DrawLatex(x,y,info.str().c_str()); info.str(""); y-=dy;

  info << eventInfo.size() << " event"
       << plural(eventInfo.size())
       << " in file ";
  infotext->DrawLatex(x,y,info.str().c_str()); info.str(""); y-=dy;
  info << nRd << " RD event" << plural(nRd);
  infotext->DrawLatex(x,y,info.str().c_str()); info.str(""); y-=dy;

  fCanvasInfo->Modified();
  fCanvasInfo->Update();

}


/*****************************************************************/
void
EventSelection::FillFDHistos(const EventInfo& currentEvent,
                             const vector<int>& iEye)
{
  if (!fSDenergyHist)
    InitHistograms();

  for (unsigned int i=0; i < iEye.size(); ++i) {
    const double fdE = currentEvent.GetFDEnergy(iEye[i]);
    if (fdE > 0) {
      fFDenergyHist->Fill(log10(fdE));
      const double sinTh = sin(currentEvent.GetFDZenith(iEye[i]));
      fFDzenithHist->Fill(sinTh*sinTh);
    }
    fFDPixelHist->Fill(currentEvent.GetNumberOfTriggeredPixels(iEye[i]));

    if (fEventInfoClassVersion >= 5)
      fFDEyeXmaxHist->Fill(currentEvent.GetXmax(iEye[i]));
    else
      fFDEyeXmaxHist->Fill(currentEvent.GetEyeId(iEye[i]));
  }
}


/******************************************************************/
void
EventSelection::FillSDHistos(const EventInfo& currentEvent)
{
  if (!fSDenergyHist)
    InitHistograms();

  const double sdE = currentEvent.GetSDEnergy();
  if (sdE > 0) {
    fSDenergyHist->Fill(log10(sdE));
    const double sinTh = sin(currentEvent.GetSDZenith());
    fSDzenithHist->Fill(sinTh*sinTh);
  }
  fSDTankHist->Fill(currentEvent.GetNumberOfStations());
}


/*************************************************************************/
void
EventSelection::FillRDHistos(const EventInfo& currentEvent)
{
  if (!fRDzenithHist)
    InitHistograms();
  const double sinTh = sin(currentEvent.GetRdZenith());
  if (currentEvent.GetRdNumberOfStations() > 0) {
    fRDzenithHist->Fill(sinTh*sinTh);
    fRDSCountHist->Fill(currentEvent.GetRdNumberOfStations());
  }
}


/******************************************************************/
void
EventSelection::FillMCHistos(const EventInfo& currentEvent)
{
  if (!fMCenergyHist)
    InitHistograms();
  const double mcE=currentEvent.GetMCEnergy();
  if (mcE > 0) {
    fMCenergyHist->Fill(log10(mcE));
    const double sinTh = sin(currentEvent.GetMCZenith());
    fMCzenithHist->Fill(sinTh*sinTh);
  }
}


/***********************************************************/
void
EventSelection::DrawHistos()
{
  bool drawNormalized = false;

  fCanvasEnergy->cd();
  fCanvasEnergy->Clear();

  const int nXe = fSDenergyHist->GetNbinsX();
  fSDenergyHist->SetBinContent(1, fSDenergyHist->GetBinContent(0) + fSDenergyHist->GetBinContent(1));
  fSDenergyHist->SetBinContent(nXe, fSDenergyHist->GetBinContent(nXe) + fSDenergyHist->GetBinContent(nXe+1));
  fFDenergyHist->SetBinContent(1,fFDenergyHist->GetBinContent(0) + fFDenergyHist->GetBinContent(1));
  fFDenergyHist->SetBinContent(nXe, fFDenergyHist->GetBinContent(nXe) + fFDenergyHist->GetBinContent(nXe+1));
  if (fMCenergyHist->GetEntries()) {
    fMCenergyHist->SetBinContent(1, fMCenergyHist->GetBinContent(0) + fMCenergyHist->GetBinContent(1));
    fMCenergyHist->SetBinContent(nXe, fMCenergyHist->GetBinContent(nXe) + fMCenergyHist->GetBinContent(nXe+1));
  }
  double nSDE = fSDenergyHist->GetEntries();
  double nFDE = fFDenergyHist->GetEntries();
  double nMCE = fMCenergyHist->GetEntries();
  if (!drawNormalized) {
    if (nSDE > 0)
      nSDE = 1.;
    if (nFDE > 0)
      nFDE = 1.;
    if (nMCE > 0)
      nMCE = 1.;
  }

  double entriesMin = 2;
  double entriesMax = 0;
  for (int i = 0; i < nXe; ++i) {
    if (nSDE > 0) {
      const double c1 = fSDenergyHist->GetBinContent(i+1);
      fSDenergyHist->SetBinContent(i + 1, c1/nSDE);
      fSDenergyHist->SetBinError(i + 1, sqrt(c1)/nSDE);
      if (c1/nSDE > entriesMax)
        entriesMax =  c1/nSDE;
      if (c1 > 0 && c1/nSDE < entriesMin)
        entriesMin = c1/nSDE;
    }

    if (nFDE > 0) {
      const double c2 = fFDenergyHist->GetBinContent(i+1);
      fFDenergyHist->SetBinContent(i+1,c2/nFDE);
      fFDenergyHist->SetBinError(i+1,sqrt(c2)/nFDE);
      if (c2/nFDE > entriesMax)
        entriesMax = c2/nFDE;
      if (c2 > 0 && c2/nFDE < entriesMin)
        entriesMin = c2/nFDE;
    }

    if (nMCE > 0) {
      const double c2 = fMCenergyHist->GetBinContent(i + 1);
      fMCenergyHist->SetBinContent(i + 1, c2/nMCE);
      fMCenergyHist->SetBinError(i + 1, sqrt(c2)/nMCE);
      if (c2/nMCE > entriesMax)
        entriesMax = c2/nMCE;
      if (c2 > 0 && c2/nMCE < entriesMin)
        entriesMin =  c2/nMCE;
    }
  }

  if (entriesMin > 0 && entriesMax > 0 && entriesMax != entriesMin) {
    fCanvasEnergy->SetLogy(1);
    fSDenergyHist->SetMinimum(0.5*entriesMin);
    fSDenergyHist->SetMaximum(3.*entriesMax);
  } else {
    fSDenergyHist->SetMinimum(0.);
    fSDenergyHist->SetMaximum(3.*entriesMax);
    fCanvasEnergy->SetLogy(0);
  }

  fSDenergyHist->Draw();
  fFDenergyHist->Draw("SAME");
  if (nMCE)
    fMCenergyHist->Draw("SAME");
  fFDenergyHist->SetLineColor(kBlue);
  fSDenergyHist->SetLineColor(kRed);
  fMCenergyHist->SetLineColor(kBlack);
  fFDenergyHist->SetMarkerColor(kBlue);
  fSDenergyHist->SetMarkerColor(kRed);
  fMCenergyHist->SetMarkerColor(kBlack);
  fFDenergyHist->SetMarkerStyle(20);
  fSDenergyHist->SetMarkerStyle(20);
  fMCenergyHist->SetMarkerStyle(24);
  fSDenergyHist->GetXaxis()->SetTitle("lg(E/eV)");

  TLegend* Legi = new TLegend(0.78,0.78,0.93,0.96,NULL,"brNDCARC");

  Legi->SetFillColor(0);
  Legi->SetBorderSize(0);
  Legi->AddEntry(fSDenergyHist,"SD","pl");
  Legi->AddEntry(fFDenergyHist,"FD","pl");
  if(nMCE)
    Legi->AddEntry(fMCenergyHist,"MC","pl");

  Legi->Draw();
  fSelectionObjects->Add(Legi);

  fCanvasEnergy->Modified();
  fCanvasEnergy->Update();

  fCanvasZenith->cd();
  fCanvasZenith->Clear();
  const int nXz = fSDzenithHist->GetNbinsX();
  const double nSDZ = fSDzenithHist->GetEntries();
  const double nFDZ = fFDzenithHist->GetEntries();
  const double nMCZ = fMCzenithHist->GetEntries();

  for (int i = 0; i < nXz; ++i) {
    if (nSDZ > 0) {
      const double c1 = fSDzenithHist->GetBinContent(i+1);
      fSDzenithHist->SetBinContent(i+1,c1/nSDZ);
      fSDzenithHist->SetBinError(i+1,sqrt(c1)/nSDZ);
    }

    if (nFDZ > 0) {
      const double c2 = fFDzenithHist->GetBinContent(i+1);
      fFDzenithHist->SetBinContent(i+1,c2/nFDZ);
      fFDzenithHist->SetBinError(i+1,sqrt(c2)/nFDZ);
    }

    if (nMCZ > 0) {
      const double c2 = fMCzenithHist->GetBinContent(i+1);
      fMCzenithHist->SetBinContent(i+1,c2/nMCZ);
      fMCzenithHist->SetBinError(i+1,sqrt(c2)/nMCZ);
    }
  }

  fSDzenithHist->SetMinimum(0.);

  fSDzenithHist->GetXaxis()->SetTitle("sin^{2} #theta");
  fSDzenithHist->Draw();
  fFDzenithHist->Draw("SAME");
  if (nMCZ)
    fMCzenithHist->Draw("SAME");
  fFDzenithHist->SetLineColor(kBlue);
  fSDzenithHist->SetLineColor(kRed);
  fMCzenithHist->SetLineColor(kBlack);

  fFDzenithHist->SetMarkerColor(kBlue);
  fSDzenithHist->SetMarkerColor(kRed);
  fMCzenithHist->SetMarkerColor(kBlack);
  fFDzenithHist->SetMarkerStyle(20);
  fSDzenithHist->SetMarkerStyle(20);
  fMCzenithHist->SetMarkerStyle(24);
  //Lets do the Same for the Radio stuff
  const int nRdZ = fRDzenithHist->GetEntries();
  if (nRdZ > 0) {
    for (int i = 0; i < nXz; ++i) {
      double crd=fRDzenithHist->GetBinContent(i + 1);
      fRDzenithHist->SetBinContent(i + 1, crd/nRdZ);
      fRDzenithHist->SetBinError(i + 1, sqrt(crd)/nRdZ);
    } // for
    fRDzenithHist->SetLineColor(kGreen + 2); // JR: better?
    fRDzenithHist->SetMarkerColor(kGreen + 2);
    fRDzenithHist->SetMarkerStyle(20);
    fRDzenithHist->GetXaxis()->SetTitle("sin^{2} #theta");
    Legi->AddEntry(fRDzenithHist, "RD");
    if (nSDZ > 0 || nMCZ > 0) {
      fRDzenithHist->Draw("SAME");
      Legi->Draw();
    } else
      fRDzenithHist->Draw("");
    Legi->Draw();
  }

  fCanvasZenith->Modified();
  fCanvasZenith->Update();

  fCanvasStations->cd();
  fCanvasStations->Clear();

  const int nXs = fSDTankHist->GetNbinsX();
  if (fSDTankHist->GetEntries() > 0)
    fCanvasStations->SetLogy(1);
  else
    fCanvasStations->SetLogy(0);

  fSDTankHist->SetBinContent(nXs,fSDTankHist->GetBinContent(nXs)+
                             fSDTankHist->GetBinContent(nXs+1));
  fSDTankHist->Draw();
  fSDTankHist->GetXaxis()->SetTitle("number of tanks");
  fSDTankHist->SetLineColor(kRed);
  if (fRDSCountHist->GetEntries() > 0) {
    fRDSCountHist->SetLineColor(kGreen+2);
    fRDSCountHist->GetXaxis()->SetTitle("number of detectors");
    fCanvasStations->SetLogy(1);
    if (!fSDTankHist->GetEntries())
      fRDSCountHist->Draw("");
    else {
      fSDTankHist->GetXaxis()->SetRangeUser(0., 1.1*max(fSDTankHist->FindLastBinAbove(0., 1),
                                                        fRDSCountHist->FindLastBinAbove(0., 1)));
      fSDTankHist->GetYaxis()->SetRangeUser(0.5, 1.2*max(fSDTankHist->GetBinContent(fSDTankHist->GetMaximumBin()),
                                                         fRDSCountHist->GetBinContent(fRDSCountHist->GetMaximumBin())));
      fSDTankHist->GetXaxis()->SetTitle("number of detectors");
      fRDSCountHist->Draw("SAME");
    }
  }
  Legi->Draw();
  fCanvasStations->Modified();
  fCanvasStations->Update();

  fCanvasPixels->cd();
  fCanvasPixels->Clear();
  const int nXp = fFDPixelHist->GetNbinsX();
  if (fFDPixelHist->GetEntries() > 0)
    fCanvasPixels->SetLogy(1);
  else
    fCanvasPixels->SetLogy(0);
  fFDPixelHist->SetBinContent(nXp,fFDPixelHist->GetBinContent(nXp)
                              +fFDPixelHist->GetBinContent(nXp+1));
  fFDPixelHist->Draw();
  fFDPixelHist->GetXaxis()->SetTitle("number of FLT pixels");
  fCanvasPixels->Modified();
  fCanvasPixels->Update();

  fCanvasEyes->cd();
  fCanvasEyes->Clear();
  fFDEyeXmaxHist->Draw();
  fFDEyeXmaxHist->GetXaxis()->SetTitle((fEventInfoClassVersion>=5?
                                        "Xmax [g/cm^{2}]":
                                        "events per eye"));
  fCanvasEyes->Modified();
  fCanvasEyes->Update();
}


/***********************************************************/
void
EventSelection::ResetSelection()
{
  fEminTextField->SetNumber(kEmin);
  fEmaxTextField->SetNumber(kEmax);
  fZminTextField->SetNumber(kZmin);
  fZmaxTextField->SetNumber(kZmax);
  fYYMMDDmin->SetNumber(kYYMMDDmin);
  fHHMMSSmin->SetNumber(kHHMMSS);
  fYYMMDDmax->SetNumber(kYYMMDDmax);
  fHHMMSSmax->SetNumber(kHHMMSS);
  fTankTextField->SetNumber(kTankMin);
  fEyeTextField->SetNumber(kEyeMin);
  fPixelTextField->SetNumber(kPixelMin);
  fXminTextField->SetNumber(EventInfo::GetMinXmax());
  fXmaxTextField->SetNumber(EventInfo::GetMaxXmax());
  fFDRecLevel->Select(kFDRecLevel);
  fSDRecLevel->Select(kSDRecLevel);
  fSDAngChi2->SetNumber(kSDMaxLgAngChi2Prob);
  fSDLDFChi2->SetNumber(kSDMaxLgLDFChi2Prob);
  fRdStationTextField ->SetNumber(kRdStationMin);
  fRdRecLevelTextField->SetNumber(kRdRecLevelMin);
  fRdmaxAzimuthTextField->SetNumber(kRdmaxAzimuth);
  fRdminAzimuthTextField->SetNumber(kRdminAzimuth);

  if (fSDEnergySelectionButton->GetState() == kButtonDown)
    fSDEnergySelectionButton->SetState(kButtonUp, false);

  if (fFDEnergySelectionButton->GetState() == kButtonDown)
    fFDEnergySelectionButton->SetState(kButtonUp, false);

  if (fMCEnergySelectionButton->GetState() == kButtonDown)
    fMCEnergySelectionButton->SetState(kButtonUp, false);

  if (fRDEnergySelectionButton->GetState() == kButtonDown)
    fRDEnergySelectionButton->SetState(kButtonUp, false);

  if (kT3Checked)
    fSDTrigger3->SetState(kButtonDown);
  else
    fSDTrigger3->SetState(kButtonUp);

  if (kT4Checked)
    fSDTrigger4->SetState(kButtonDown);
  else
    fSDTrigger4->SetState(kButtonUp);

  if (kT5Checked)
    fSDTrigger5->SetState(kButtonDown);
  else
    fSDTrigger5->SetState(kButtonUp);

  if (kSatChecked)
    fSDSaturation->SetState(kButtonDown, false);
  else
    fSDSaturation->SetState(kButtonUp, false);

  if (kFOV)
    fFOVButton->SetState(kButtonDown, false);
  else
    fFOVButton->SetState(kButtonUp, false);

  if (kHybrid)
    fHybridButton->SetState(kButtonDown, false);
  else
    fHybridButton->SetState(kButtonUp, false);

  for (map<unsigned int, TGCheckButton*>::const_iterator eyeIter = fEyes.begin();
       eyeIter != fEyes.end(); ++eyeIter)
    eyeIter->second->SetState(kButtonDown, false);

  fFileSelectedEvents.clear();

  fSDzenithHist->GetXaxis()->SetRangeUser(0., 1.);
  fSDenergyHist->GetXaxis()->SetRangeUser(-1e99, 1e99);
  fFDEyeXmaxHist->GetXaxis()->SetRangeUser(-1e99, 1e99);
  fSDTankHist->GetXaxis()->SetRangeUser(0,9999);
  fFDPixelHist->GetXaxis()->SetRangeUser(0,9999);

  fRdStationTextField->SetNumber(kRdStationMin);
  fRdRecLevelTextField->SetNumber(kRdRecLevelMin);
  fRdminAzimuthTextField->SetNumber(kRdminAzimuth);
  fRdmaxAzimuthTextField->SetNumber(kRdmaxAzimuth);
}


/***********************************************************/
void
EventSelection::SetHQSDSelection()
{
  fZmaxTextField->SetNumber(kZmaxHQSD);
  fTankTextField->SetNumber(kTankMinHQ);
  fSDRecLevel->Select(kSDRecLevelHQ);

  fSDEnergySelectionButton->SetState(kButtonDown);

  if (kT3CheckedHQ)
    fSDTrigger3->SetState(kButtonDown);
  else
    fSDTrigger3->SetState(kButtonUp);
  if (kT4CheckedHQ)
    fSDTrigger4->SetState(kButtonDown);
  else
    fSDTrigger4->SetState(kButtonUp);
  if (kT5CheckedHQ)
    fSDTrigger5->SetState(kButtonDown);
  else
    fSDTrigger5->SetState(kButtonUp);
}


/***********************************************************/
void
EventSelection::SetHQFDSelection()
{
  fZmaxTextField->SetNumber(kZmaxHQFD);
  fPixelTextField->SetNumber(kPixelMinHQ);
  fEyeTextField->SetNumber(kEyeMinHQ);
  fFDRecLevel->Select(kFDRecLevelHQ);

  fFDEnergySelectionButton->SetState(kButtonDown, 0);

  if (kFOVHQ)
    fFOVButton->SetState(kButtonDown);
  else
    fFOVButton->SetState(kButtonUp);

  if (kHybridHQ)
    fHybridButton->SetState(kButtonDown);
  else
    fHybridButton->SetState(kButtonUp);
}


/***********************************************************/
void
EventSelection::DoFileSelection()
{
  TString directory(".");
  TGFileInfo fi;
  fi.fIniDir = StrDup(directory.Data());
  new TGFileDialog(gClient->GetRoot(), fMain, kFDOpen, &fi);
  if (!fi.fFilename)
    return;

  ifstream ifs(fi.fFilename);
  if (!ifs.good()) {
    cerr << " EventSelection::DoFileSelection()"
            "- Error, file " << fi.fFilename << " not found!"
         << endl;
    return;
  }
  while (!ifs.eof()) {
    int id = -1; ifs >> id;
    fFileSelectedEvents.insert(id);
  }
}


/***********************************************************/
bool
EventSelection::ToggleSelectionEnable()
{
  bool enable = false;
  //  EButtonState buttonEnable1; // unused
  EButtonState buttonEnable2;
  if (fSelectionButton->IsDown()) {
    enable = true;
    //    buttonEnable1=kButtonDown; // unused
    buttonEnable2=kButtonEngaged;
  } else {
    //    buttonEnable1=kButtonUp;  // unused
    buttonEnable2=kButtonDisabled;
    enable = false;
  }

  fEminTextField->SetState(enable);
  fEmaxTextField->SetState(enable);
  fZminTextField->SetState(enable);
  fZmaxTextField->SetState(enable);
  fYYMMDDmin->SetState(enable);
  fHHMMSSmin->SetState(enable);
  fYYMMDDmax->SetState(enable);
  fHHMMSSmax->SetState(enable);

  fTankTextField->SetState(enable);
  fSDTrigger3->SetState(buttonEnable2);
  fSDTrigger4->SetState(buttonEnable2);
  fSDTrigger5->SetState(buttonEnable2);
  fSDSaturation->SetState(buttonEnable2);
  fSDRecLevel->SetEnabled(enable);
  fSDAngChi2->SetState(enable);
  fSDLDFChi2->SetState(enable);
  fEyeTextField->SetState(enable);
  fPixelTextField->SetState(enable);
  fXminTextField->SetState(enable);
  fXmaxTextField->SetState(enable);
  fFDRecLevel->SetEnabled(enable);
  fHybridButton->SetState(buttonEnable2);
  fFOVButton->SetState(buttonEnable2);

  for (map<unsigned int, TGCheckButton*>::const_iterator eyeIter = fEyes.begin();
       eyeIter != fEyes.end(); ++eyeIter)
    eyeIter->second->SetState(buttonEnable2);

  if (enable) {
    fHybridButton->SetState(kButtonDown);
    fHybridButton->SetState(kButtonUp);
    for (map<unsigned int, TGCheckButton*>::const_iterator eyeIter = fEyes.begin();
         eyeIter != fEyes.end(); ++eyeIter) {
      eyeIter->second->SetState(kButtonDown);
      eyeIter->second->SetState(kButtonUp);
      eyeIter->second->SetDown(true);
    }
    fFOVButton->SetState(kButtonDown);
    fFOVButton->SetState(kButtonUp);
    fSDSaturation->SetState(kButtonDown, kSatChecked);
    fSDSaturation->SetState(kButtonUp, !kSatChecked);
  } else {
    if (fSDEnergySelectionButton->IsDown()) {
      fSDEnergySelectionButton->SetDown(false);
      fSelectionButton->SetState(kButtonUp);
      ToggleSelectionEnable();
    }
    if (fFDEnergySelectionButton->IsDown()) {
      fFDEnergySelectionButton->SetDown(false);
      fSelectionButton->SetState(kButtonUp);
      ToggleSelectionEnable();
    }
    if (fMCEnergySelectionButton->IsDown()) {
      fMCEnergySelectionButton->SetDown(false);
      fSelectionButton->SetState(kButtonUp);
      ToggleSelectionEnable();
    }
    if (fRDEnergySelectionButton->IsDown()) {
      fRDEnergySelectionButton->SetDown(false);
      fSelectionButton->SetState(kButtonUp);
      ToggleSelectionEnable();
    }
  }

  fUpdateButton->SetEnabled(enable);
  fResetButton->SetEnabled(enable);
  fHQFDButton->SetEnabled(enable);
  fHQSDButton->SetEnabled(enable);
  fFileSelectionButton->SetEnabled(enable);

  fRdStationTextField->SetState(enable);
  fRdRecLevelTextField->SetState(enable);
  fRdminAzimuthTextField->SetState(enable);
  fRdmaxAzimuthTextField->SetState(enable);

  return enable;
}


/***********************************************************/
void
EventSelection::HandleButtonSignals()
{
  const TGButton* button = (TGButton*)gTQSender;
  const UInt_t bid = button->WidgetId();
  const TGNumberEntry* entry = (TGNumberEntry*)gTQSender;
  const UInt_t eid = entry->WidgetId();

  if (bid == e5T5Trigger) {
    fSDTrigger4->SetState(kButtonUp);
    fSDTrigger5->SetState(kButtonUp);
  } else if (bid == eT4Trigger) {
    fSDTrigger3->SetState(kButtonUp);
    fSDTrigger5->SetState(kButtonUp);
  } else if (bid == e6T5Trigger) {
    fSDTrigger4->SetState(kButtonUp);
    fSDTrigger3->SetState(kButtonUp);
  } else if (bid == eAnyFDButton || eid == ePixelMin ||
           eid == eXmin || eid == eXmax || eid == eFDRecLevel) {
    UInt_t selid = -1;
    if (eid == eFDRecLevel) {
      const TGComboBox* combo = (TGComboBox*)gTQSender;
      selid = combo->GetSelected();
    }
    if (fEyeTextField->GetNumber() == 0 && selid != eNoFdEvent)
      fEyeTextField->SetNumber(1);
  } else if (bid == eEnableSelection) {
    ToggleSelectionEnable();
  } else if (bid == eSDEnergySelection ||
           bid == eFDEnergySelection ||
           bid == eMCEnergySelection
           || bid == eRDEnergySelection
           ) {
    const bool useSD = fSDEnergySelectionButton->IsDown();
    const bool useFD = fFDEnergySelectionButton->IsDown();
    const bool useMC = fMCEnergySelectionButton->IsDown();
    const bool useRD = fRDEnergySelectionButton->IsDown();

    if (useMC || useSD || useFD) {
      bool enable = true;
      if (!fSelectionButton->IsDown()) {
        fSelectionButton->SetState(kButtonDown);
        ToggleSelectionEnable();
      }

      fEminTextField->SetState(enable);
      fEmaxTextField->SetState(enable);
      fZminTextField->SetState(enable);
      fZmaxTextField->SetState(enable);
    }
    if (useRD) {
      bool enable = true;
      if (!fSelectionButton->IsDown()) {
        fSelectionButton->SetState(kButtonDown);
        ToggleSelectionEnable();
      }

      fEminTextField->SetState(enable);
      fEmaxTextField->SetState(enable);
      fZminTextField->SetState(enable);
      fZmaxTextField->SetState(enable);

    }
  } else
    cout << " EventSelection::HandleButtonSignals()"
         << " unknown button caller id " << bid
         << " or entry caller id " << eid << endl;
}


/***********************************************************/
void
EventSelection::FindEvent(UInt_t id,
                          const vector<EventInfo>& eventInfo)
{
  if (id == eFindSDID && fFindSDID->GetNumber() == 1234) {
    cout << "========================+=++++++++++++++++++++?+?+?+++????II\n"
            "++==================+==++++++++=++==+++++++?+?+++???????III7\n"
            "++================+=+++++++++++++++??++++????+?????I+??III77\n"
            "++=+======+=++=+=++==~~++===?I+=+??+?+?++??????????????IIIII\n"
            "?++++========~=~~=+I?+==========++?????+????????????????IIII\n"
            "?+++++=++=+?~=?77?=~~:~~~~=~=======+++?+???????????????I??II\n"
            "??+++++?$+?ZOO7I+~~:~~~~~~~~=~====++??++?????+??????????III7\n"
            "??+++?O+?88OI=+I==~~:~:~~~~~=+==++?IIII???????????????IIII77\n"
            "I?+?IO+O8877=?II??~::::~~===++?+?II777$7I????I???I??IIIIIII7\n"
            "????DIIODOO7$+$I7I=~~~~====+?+???77$777$?I+???I?II??I??II777\n"
            "I??DIZI8D7$??I7$$7?======++++??I7777$$$$77I7??????????IIII77\n"
            "I?$D$OZDOO??+Z?Z7$I?===++++?I??III7777?N?O7I7+7???IIIIIIIII7\n"
            "I?DIOO8DOZI7D=Z8Z87I?++?????IIII++?7IO7$8?ZZOOI?I?IIIIIIIII7\n"
            "?IOZOD8DDZZOI$8O88O7II??III7I??++?I8OZZNDOI8DZIIII?IIIII7I77\n"
            "II8Z8DDD8ZZ$8O8ONNZZ$$7II77???+?7$ZZON?ODDZZD8$I?IIIII77I7I7\n"
            "I$DZ8D8DOO888D8N8D888O7777???+??DNNN8$O8NZO$DOI++?7II7I7I777\n"
            "I78Z8DDDZOZDDNNNNDDND88Z$I?+?N??I$ZZZODDDNZOD8$+?7Z7II77777$\n"
            "I7DZ8ND8OZDDDDNDNNNNNND=$NZ7?+?IIOO$II7ZO$O888NI7DDIIIII7777\n"
            "I$D8ODDO8ONDDNNNMNMZDNNN8$?+??I?III7IZZZOOZ8888ODOIIIIII77$$\n"
            "IID8$DDO8DNDNMII7$8N8NMN8O7II7777$$7$$ZZZZO8DDNNO$88IIIIII77\n"
            "I7DNZDDZONNDN77Z$8O$Z8DMDD88Z$7$ZZ$$ZZ$Z$ZO88DNMNZ88ZIIII777\n"
            "I78DDDNOZNNNN7$Z$O$D$ZODNNNNDO$$$ZZZZ$$ZZOODZ$8NNO8D7IIIIII7\n"
            "II88NZN8ONDMN+O7?ZO8O7$Z8DNNDNNOZZZZZZZZZOODZ8Z8$7$II7III777\n"
            "IIZDO8ND8DNNNDI7?OOZ8DDO$8DNNDDD8ZZZOZZOOOOO8OZDDDD8?IIIII77\n"
            "IIZDDD8DZ8DNNDN?III?77I78Z8NDDDDD8ZZOZZO8OO8O88ZZOO8IIIIII77\n"
            "I?IODDDNDDDNDNN8$I7$$$7$$DZOODNNNDDOZZOOOOOO88888DMND?IIIII7\n"
            "I??$OND8DO8NNNNDD$7$$Z$$ZOZZ888D8DDD8O8OOOO8NNDNNMNNMNIIIII7\n"
            "I??I$8NDDNDDDNNNNDZ7$ZOO88OZ88DNDDDN8N88DDNNMMNN8DMNDNNIIIII\n"
            "??++I7Z$$DODNNNNNDZI7$OOO8DD8DNMNNNMMMNNMNMMNMMNMNMNMMNIIIII\n"
            "?++++++??IODNNMNN8OZ$$ZO888NNNDNNNMNMMMNMMMMMMMNNMNNNNZ??III\n"
            "+++++=+==++8NNDD8ZZZ$$$OOO88DNNMMMMMNMMNNMMMMMMNNNNN8???IIII\n"
            "+++========I7??DNNN8ZZZZOOOO88DNNMMMMMMMMMNNNNDDO$I?????IIII\n"
            "+++============DDNNNNN8OO8OOOO88O88888O8O$7++?++??????????II\n"
            "++=+===========+==8DDNDNNO8OOOOZOO88OOOZ$$7++??++?+++??????I\n"
            "+++=========~~~=~===+DDDDDDD8ZZZOOOOZZZ$7II+++++++++++?????I\n"
            "++======~==~~~~~~~~~==+DDDNDD8O$$ZOOZ$$$7?+=++++=+++++++++??\n"
            "++=====~~~~~~~~~~~~~~====DNDDNNND$$ZZZ$7II========+===++++??\n"
            "++===~~~====~~~::~~~~~====?DDDDDD8$ZZ$7IIINZ=======++=++++??\n"
            "+=~==+=~::~::~~++=~~~~~~=7=?+8DNDD88Z8777IDDNZ========++++??\n"
            "==~=~:::::::::::::~~==~~$D+=+==+IDNDDDO87DNNN8N========+++++\n"
            "=~~~:::::::::~~~~~~~~~~=7D8?~?I++?ODDDDO88DDNNDD8~~======+++\n"
            "=~~~::::~~~~~~~~~~~~==~~~+$?I7II+=+IDDDD888I7D8DDD+~~~====++\n"
            "~~~::~~==+++~~~::::::::~~=?IIII7++I??8DDD8DOOOZ8$$?=~~~===++\n"
            "~~~===~:::::::::::::~:~~===++++???I?=?O88D8D8OOI==~~=~~=====\n"
            "~~~::::::::::::::::~:~~~~:~:~~~========???I$ZI=~~~~~~~=~====\n"
            "~:::,,,::,,,,,,,,,:::::::::::::::::~~~~~~=?-=~~~~~~~~~~~~~==" << endl;
    return;
  }

  const unsigned long iAUId    = (unsigned long) fFindAUID->GetNumber();
  const unsigned int  iSDId    = (unsigned int)  fFindSDID->GetNumber();
  const unsigned int  iFDEvent = (unsigned int)  fFindFDEvent->GetNumber();
  const unsigned int  iFDRun   = (unsigned int)  fFindFDRun->GetNumber();
  const unsigned int  iFDEye   = (unsigned int)  fFindFDEye->GetNumber();
  const unsigned int  iRDRun   = (unsigned int)  fFindRDRun->GetNumber();
  const unsigned int  iRDEvent = (unsigned int)  fFindRDEvent->GetNumber();


  vector<int>::const_iterator evIter ;

  for (evIter  = fSelectedEvents.begin();
       evIter != fSelectedEvents.end();
       ++evIter) {
    const EventInfo& currentEvent = eventInfo[*evIter];

    if (id == eFindAUID) {
      if (currentEvent.GetAugerId() == iAUId)
        break;
    }
    if (id == eFindSDID) {
      if (currentEvent.GetSDId() == iSDId)
        break;
    }
    if (id == eFindFDID) {

      bool gotit=false;
      for (int i = 0; i < currentEvent.GetNumberOfEyes(); ++i) {
        if (currentEvent.GetEventId(i) == iFDEvent &&
            currentEvent.GetRunId(i)   == iFDRun &&
            currentEvent.GetEyeId(i)   == iFDEye)
          gotit=true;
      }
      if (gotit)
        break;
    }

    if (id == eFindRDID) {
      if (currentEvent.GetRdEventId()   == iRDEvent &&
          currentEvent.GetRdRunNumber() == iRDRun)
        break;
    }
  }

  if (evIter != fSelectedEvents.end())
    fEventIterator = evIter;
  else {
    ostringstream info;
    if (id == eFindAUID)
      info << "AU event " << iAUId;
    if (id == eFindSDID)
      info << "SD event " << iSDId;
    if (id == eFindFDID) {
      info << "FD event " << iFDEye  << "/"
           << iFDRun  << "/"
           << iFDEvent;
    }
    if (id == eFindRDID) {
      info << "RD event " << iRDRun << "/"
           << iRDEvent;
    }
    info << " not found" ;
    if (fSelectionButton->IsDown())
      info << "\n (hint: try again without selection...)" << endl;

    EMsgBoxIcon icontype = kMBIconExclamation;
    EMsgBoxButton buttonType = kMBOk;

    Int_t retval;
    new TGMsgBox(gClient->GetRoot(), gClient->GetRoot(),
                 "EventSelection",info.str().c_str(),
                 icontype, buttonType, &retval);
  }
}


/***********************************************************/
void
EventSelection::SetCurrentEvent(int iEvent)
{
  for (vector<int>::const_iterator theIter = fSelectedEvents.begin();
       theIter != fSelectedEvents.end(); ++theIter) {
    if (*theIter == iEvent) {
      fEventIterator = theIter;
      return;
    }
  }

  // if still here somethings wrong!
  cerr << " EventSelection::SetCurrentEvent() - Error: event " << iEvent
       << " not in list of selected events!" << endl;
}


/***********************************************************/
int
EventSelection::GetEventNumber(Long_t what)
{
  if (fSelectedEvents.empty())
    return -1;

  if (what == eFirstEvent)
    fEventIterator = fSelectedEvents.begin();
  else if (what == eNextEvent)
    ++fEventIterator;
  else if (what == ePreviousEvent)
    --fEventIterator;
  else if (what == eLastEvent)
    fEventIterator = --fSelectedEvents.end();
  else if (what == eCurrentEvent)
    return *fEventIterator;

  if (fEventIterator>=fSelectedEvents.end()) {
    fEventIterator = --fSelectedEvents.end();
    return -2;
  } else if (fEventIterator<fSelectedEvents.begin()) {
    fEventIterator = fSelectedEvents.begin();
    return -3;
  }
  return *fEventIterator;
}


/***********************************************************/
void
EventSelection::GetRangeFromHistograms()
{
  if (!fSDenergyHist)
    InitHistograms();

  const int ixMin   = fFDEyeXmaxHist->GetXaxis()->GetFirst();
  const double xMin = fFDEyeXmaxHist->GetXaxis()->GetBinLowEdge(ixMin);
  fXminTextField->SetNumber(xMin);

  const int ixMax   = fFDEyeXmaxHist->GetXaxis()->GetLast();
  const double xMax = fFDEyeXmaxHist->GetXaxis()->GetBinUpEdge(ixMax);
  fXmaxTextField->SetNumber(xMax);

  const int iEMin   = fSDenergyHist->GetXaxis()->GetFirst();
  const double eMin = fSDenergyHist->GetXaxis()->GetBinLowEdge(iEMin);
  fEminTextField->SetNumber(eMin);

  const int iEMax   = fSDenergyHist->GetXaxis()->GetLast();
  const double eMax = fSDenergyHist->GetXaxis()->GetBinUpEdge(iEMax);
  fEmaxTextField->SetNumber(eMax);

  const int iZMin   = fSDzenithHist->GetXaxis()->GetFirst();
  const double zMin = fSDzenithHist->GetXaxis()->GetBinLowEdge(iZMin);

  const int iZMax   = fSDzenithHist->GetXaxis()->GetLast();
  const double zMax = fSDzenithHist->GetXaxis()->GetBinUpEdge(iZMax);

  fZminTextField->SetNumber(acos(zMax)/degree);
  fZmaxTextField->SetNumber(acos(zMin)/degree);

  const int iTMin   = fSDTankHist->GetXaxis()->GetFirst();
  const double tMin = fSDTankHist->GetXaxis()->GetBinLowEdge(iTMin);
  fTankTextField->SetNumber(tMin);

  const int iPMin   = fFDPixelHist->GetXaxis()->GetFirst();
  const double pMin = fFDPixelHist->GetXaxis()->GetBinLowEdge(iPMin);
  fPixelTextField->SetNumber(pMin);
}


/***********************************************************/
void
EventSelection::ResetHistograms()
{

  if (!fSDenergyHist)
    return;

  fSDenergyHist->Reset();
  fFDenergyHist->Reset();
  fMCenergyHist->Reset();
  fSDzenithHist->Reset();
  fFDzenithHist->Reset();
  fMCzenithHist->Reset();
  fSDTankHist->Reset();
  fFDPixelHist->Reset();
  fFDEyeXmaxHist->Reset();
  fRDzenithHist->Reset();
  fRDSCountHist->Reset();
}


/***********************************************************/
void
EventSelection::InitHistograms()
{

  fSDenergyHist  = new TH1F("SDenergy","",15,16.001,21.001);
  fFDenergyHist  = new TH1F("FDenergy","",15,16.05,21.05);
  fMCenergyHist  = new TH1F("MCenergy","",15,16.05,21.05);
  fSDTankHist    = new TH1F("nTanks","",50,0.,50);
  fSDzenithHist  = new TH1F("SDcosZenith","",50,-1.,1.);
  fSDzenithHist->GetXaxis()->SetRangeUser(0.,1.);
  fFDzenithHist  = new TH1F("FDcosZenith","",50,-1.,1.);
  fMCzenithHist  = new TH1F("MCcosZenith","",50,-1.,1.);
  fFDPixelHist   = new TH1F("pixels","",50,0.,200);
  fFDEyeXmaxHist = (fEventInfoClassVersion>=5?
                    new TH1F("xmax","",EventInfo::GetNXmax(),
                             EventInfo::GetMinXmax(),
                             EventInfo::GetMaxXmax()):
                    new TH1F("eyes","",4,0.5,4.5)
                    );
  fRDzenithHist  = new TH1F("RDcosZenith","",50,-1.,1.);
  fRDSCountHist  = new TH1F("nRDS","",80.,0.,80.);
}
