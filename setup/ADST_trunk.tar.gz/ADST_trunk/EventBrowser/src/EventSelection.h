#ifndef _include_EventSelection_h__
#define _include_EventSelection_h__

#include <TQObject.h>
#include <vector>
#include "FdRecLevel.h"
#include "SdRecLevel.h"


#include <vector>
#include <map>
#include <set>

class TGCompositeFrame;
class TGNumberEntry;
class TGRadioButton;
class EventInfo;
class DetectorGeometry;
class TGCompositeFrame;
class TGHButtonGroup;
class TGCheckButton;
class TGComboBox;
class TGTextButton;
class TCanvas;
class TObjArray;
class TH1F;


class EventSelection : public TQObject {

public:
  EventSelection (TGCompositeFrame *main, const DetectorGeometry * geometry);
  ~EventSelection();

  void HandleButtonSignals();
  void SelectEvents(const std::vector<EventInfo>& eventInfo,
		    TGComboBox* mainEventList);
  void FindEvent(UInt_t id, const std::vector<EventInfo>& eventInfo);
  void ResetSelection();
  void SetHQFDSelection();
  void SetHQSDSelection();
  void DoFileSelection();
  int GetEventNumber(Long_t what);
  bool ToggleSelectionEnable();
  void SetCurrentEvent(int iEvent);
  void SetEventInfoClassVersion(int iVersion)
  { fEventInfoClassVersion=iVersion; }
  const std::vector<int>& GetSelectedEventList() const
  { return fSelectedEvents; }

private:

  void FillFDHistos(const EventInfo&, const std::vector<int>&);

  void FillSDHistos(const EventInfo&);
  void FillMCHistos(const EventInfo&);
  void DrawHistos();
  void InitHistograms();
  void GetRangeFromHistograms();
  void ResetHistograms();
  int fEventInfoClassVersion;
  void FillRDHistos(const EventInfo&);

  std::vector<int> fSelectedEvents;
  std::vector<int>::const_iterator fEventIterator;
  std::set<int> fFileSelectedEvents;

  TObjArray* fSelectionObjects;

  TGCompositeFrame* fMain;

  TCanvas* fCanvasEnergy;
  TCanvas* fCanvasZenith;
  TCanvas* fCanvasStations;
  TCanvas* fCanvasPixels;
  TCanvas* fCanvasEyes;
  TCanvas* fCanvasInfo;

  TGTextButton* fUpdateButton;
  TGTextButton* fResetButton;
  TGTextButton* fHQFDButton;
  TGTextButton* fHQSDButton;
  TGTextButton* fFileSelectionButton;
  TGTextButton* fFindGPSButton;
  TGTextButton* fFindAUButton;
  TGTextButton* fFindSDButton;
  TGTextButton* fFindFDButton;
  TGTextButton* fFindRDButton;

  TGCheckButton* fSelectionButton;
  TGCheckButton* fSelectionFromHistButton;
  TGNumberEntry* fEminTextField;
  TGNumberEntry* fEmaxTextField;
  TGNumberEntry* fZminTextField;
  TGNumberEntry* fZmaxTextField;

  TGNumberEntry* fYYMMDDmin;
  TGNumberEntry* fYYMMDDmax;
  TGNumberEntry* fHHMMSSmin;
  TGNumberEntry* fHHMMSSmax;

  TGNumberEntry* fXminTextField;
  TGNumberEntry* fXmaxTextField;
  TGCheckButton* fSDEnergySelectionButton;
  TGCheckButton* fFDEnergySelectionButton;
  TGCheckButton* fMCEnergySelectionButton;
  TGCheckButton* fRDEnergySelectionButton;

  TGNumberEntry* fTankTextField;
  TGRadioButton* fSDTrigger3;
  TGRadioButton* fSDTrigger4;
  TGRadioButton* fSDTrigger5;
  TGCheckButton* fSDSaturation;
  TGNumberEntry* fSDAngChi2;
  TGNumberEntry* fSDLDFChi2;
  TGNumberEntry* fRdStationTextField;
  TGNumberEntry* fRdRecLevelTextField;
  TGNumberEntry* fRdminAzimuthTextField;
  TGNumberEntry* fRdmaxAzimuthTextField;

  TGNumberEntry* fEyeTextField;
  TGNumberEntry* fPixelTextField;
  TGCheckButton* fHybridButton;
  TGCheckButton* fFOVButton;
  TGComboBox* fFDRecLevel;
  std::map<unsigned int, TGCheckButton*> fEyes;

  TGComboBox* fSDRecLevel;

  TGNumberEntry* fFindGPSTime;
  TGNumberEntry* fFindAUID;
  TGNumberEntry* fFindSDID;
  TGNumberEntry* fFindFDEye;
  TGNumberEntry* fFindFDRun;
  TGNumberEntry* fFindFDEvent;
  TGNumberEntry* fFindRDRun;
  TGNumberEntry* fFindRDEvent;


  TH1F* fSDenergyHist;
  TH1F* fFDenergyHist;
  TH1F* fMCenergyHist;
  TH1F* fSDzenithHist;
  TH1F* fFDzenithHist;
  TH1F* fMCzenithHist;
  TH1F* fSDTankHist;
  TH1F* fFDPixelHist;
  TH1F* fFDEyeXmaxHist;
  TH1F* fRDzenithHist;
  TH1F* fRDSCountHist;
  ClassDef (EventSelection, 2);
};



#endif
