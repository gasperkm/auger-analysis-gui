#include "FdPlots.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "EventBrowserUtilities.h"
#include "EventBrowserConfig.h"
#include "TReadProgress.h"
#include "RecEvent.h"
#include "DetectorGeometry.h"
#include "EyeGeometry.h"
#include "TelescopeGeometry.h"
#include "GenShower.h"
#include "EventBrowser.h"
#include "StyleManager.h"
#include "LongitudinalProfile.h"

#include <TROOT.h>
#include <TGFrame.h>
#include <TGListBox.h>
#include <TRootEmbeddedCanvas.h>
#include <TGButtonGroup.h>
#include <TGButton.h>
#include <TGLabel.h>
#include <TGTab.h>
#include <TLatex.h>
#include <TF1.h>
#include <TH2F.h>
#include <TPolyLine.h>
#include <TLine.h>
#include <TVector3.h>
#include <TMultiGraph.h>
#include <TGraphErrors.h>
#include <TMarker.h>
#include <TLegend.h>
#include <TStyle.h>
#include <TColor.h>
#include <TSystem.h>
#include <TGaxis.h>

#include <TCanvas.h>
#include <TObjArray.h>

#include <cmath>
#include <algorithm>
#include <sstream>
#include <string>
#include <iostream>
#include <iomanip>

using namespace std;
using namespace view::Consts;

ClassImp(FdPlots);


const double FdPlots::kMaxADC = 5000.;
const double FdPlots::kMinADC = 0.;

FdPlots::FdPlots(TGCompositeFrame* main,
		 const StyleManager* const * styleManager,
		 const DetectorGeometry* const * geom,
		 const RecEvent* const * event,
		 const int eyeID,
		 const bool& isMC) :
  fStyleManager(styleManager),
  fEvent(event),
  fIsMC(isMC),
  fDetectorGeometry(geom),
  fEyeId(eyeID),
  fSDPObjects(0),
  fTimeFitObjects(0),
  fProfileObjects(0),
  fEventInfoObjects(0),
  fSelectedPixelMarker(NULL),
  fShowEyeView(true),
  fShowCloudCamData(false),
  fShowViewableFOV(false),
  fShowTelsInDAQ(false),
  fUseLCEfficiency(false),
  fResiduals(false),
  fShowAllStations(false),
  fShowAllPixels(false),
  fProfileMode(edEdX),
  fSignalColorRangeStart(0),
  fTimeColorRangeStart(0),
  fPixelColorMode(eTime),
  fShowTelApertureLight(false),
  fShowEyeApertureLight(true),
  fRebinField(NULL)
{
  fKeepAnimatedEpsFiles = false;

  const double width = main->GetWidth();
  const double height = main->GetHeight();
  const double kCanvasHeight = 0.38;

  fMain = main;
  fMain->SetCleanup(kDeepCleanup);


  TGLayoutHints* layout2 =
    new TGLayoutHints(kLHintsCenterY|kLHintsLeft,3,3,3,3);
  TGLayoutHints* layout3 = new TGLayoutHints(kLHintsTop|kLHintsLeft,1, 1, 1, 1);
  TGLayoutHints* layout4 =
    new TGLayoutHints(kLHintsExpandX|kLHintsExpandY,3,3,3,3);


  // -----------------------------------------------------------------------
  // three horizontal frames  (two for the canvases, 1 for the buttons)

  TGHorizontalFrame* horz1 =
    new TGHorizontalFrame(main, UInt_t(0.98*width), UInt_t(kCanvasHeight*height));
  TGHorizontalFrame* horz2 =
    new TGHorizontalFrame(main, UInt_t(0.98*width), UInt_t(kCanvasHeight*height));
  TGHorizontalFrame* horz3 =
    new TGHorizontalFrame(main, UInt_t(0.98*width), 40);

  main->AddFrame(horz1, layout4);
  main->AddFrame(horz2, layout4);
  main->AddFrame(horz3, layout3);


  // ------------------------------------------------------------------------
  // two upper canvases for Camera view and time fit

  TRootEmbeddedCanvas* embeddedCanvasCamera =
    new TRootEmbeddedCanvas("CanvasCamera", horz1,
                            UInt_t(0.45*width), UInt_t(kCanvasHeight*height));
  horz1->AddFrame(embeddedCanvasCamera, layout4);
  fCanvasCamera = embeddedCanvasCamera->GetCanvas();
  fCanvasCamera->SetBottomMargin(0.14);
  fCanvasCamera->SetTopMargin(0.06);
  fCanvasCamera->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)",
			 "FdPlots", this,
			 "SelectPixel(Int_t,Int_t,Int_t,TObject*)");

  TRootEmbeddedCanvas* embeddedCanvasTime =
    new TRootEmbeddedCanvas("CanvasTime", horz1, UInt_t(0.45*width),
			    UInt_t(kCanvasHeight*height));
  horz1->AddFrame(embeddedCanvasTime, layout4);
  fCanvasTime = embeddedCanvasTime->GetCanvas();
  fCanvasTime->SetBottomMargin(0.14);
  fCanvasTime->SetTopMargin(0.06);

  // ------------------------------------------------------------------------
  // profile and event info

  TRootEmbeddedCanvas* embeddedCanvasProfile =
    new TRootEmbeddedCanvas("CanvasProfile", horz2, UInt_t(0.45*width),
			    UInt_t(kCanvasHeight*height));
  horz2->AddFrame(embeddedCanvasProfile, layout4);
  fCanvasProfile = embeddedCanvasProfile->GetCanvas();
  fCanvasProfile->SetRightMargin(0.092);
  fCanvasProfile->SetBottomMargin(0.14);
  fCanvasProfile->SetTopMargin(0.06);


  // ------------------------------------------------------------------------
  // tab for event info and pixels

  fEventPixelTab = new TGTab(horz2);//->GetWidth(),vert1->GetHeight());

  TGCompositeFrame* eventInfoFrame = fEventPixelTab->AddTab("Event Info");
  TGCompositeFrame* pixelFrame = fEventPixelTab->AddTab("Pixels");

  TRootEmbeddedCanvas* embeddedCanvasInfo =
    new TRootEmbeddedCanvas("CanvasInfo", eventInfoFrame,
			    UInt_t(0.43*width), UInt_t(0.43*height));
  eventInfoFrame->AddFrame(embeddedCanvasInfo,  layout4);
  fCanvasInfo = embeddedCanvasInfo->GetCanvas();

  TRootEmbeddedCanvas* embeddedCanvasPixels =
    new TRootEmbeddedCanvas("CanvasPixels", pixelFrame,
			    UInt_t(0.43*width), UInt_t(0.43*height));
  pixelFrame->AddFrame(embeddedCanvasPixels, layout4);
  fCanvasPixels = embeddedCanvasPixels->GetCanvas();
  fCanvasPixels->SetTopMargin(0.1);

  horz2->AddFrame(fEventPixelTab, layout4);
  fEventPixelTab->SetEnabled(1, kFALSE);


  // ------------------------------------------------------------------------
  // Profile buttons

  TGHButtonGroup* ProfileButtons = new TGHButtonGroup(horz3,"profile");
  fProfdEdXButton = new TGRadioButton(ProfileButtons,
				      new TGHotString("dE/dX(X)"),eFDdEdX);
  fProfdEdXShowerAgeButton= new TGRadioButton(ProfileButtons,
					      new TGHotString("dE/dX(s) "),
					      eFDdEdXShowerAge);
  fProfNeButton = new TGRadioButton(ProfileButtons, new TGHotString("N(X) "),
				    eFDElectrons);
  fProfLightButton = new TGRadioButton(ProfileButtons,
				       new TGHotString("light  "),eFDAperture);
  fProfdEdXButton->SetToolTipText("energy deposit vs depth");
  fProfLightButton->SetToolTipText("photon flux at aperture vs. time");
  fProfdEdXShowerAgeButton->SetToolTipText("energy deposit vs shower age");
  fProfNeButton->SetToolTipText("electron size as function of depth");

  fProfdEdXButton->SetState(kButtonDown);
  fRebinField = new TGNumberEntry(ProfileButtons, 0 ,3,eProfileRebin,
                                  TGNumberFormat::kNESInteger,
                                  TGNumberFormat::kNEAAnyNumber,
                                  TGNumberFormat::kNELLimitMinMax,
                                  0, 500);
  fRebinField->Resize();
  ProfileButtons->AddFrame(fRebinField);
  horz3->AddFrame(ProfileButtons, layout3);



  // options
  TGHButtonGroup* CheckProfileButtons= new TGHButtonGroup(horz3,"options");
  fResidualButton = new TGCheckButton(CheckProfileButtons,
				      new TGHotString("resid."),
				      eFDresiduals);
  fPixelButton = new TGCheckButton(CheckProfileButtons,
				   new TGHotString("all pix."),
				   eFDAllPixels);
  fStationButton = new TGCheckButton(CheckProfileButtons,
				     new TGHotString("all SD"),
				     eFDAllStations);
  fResidualButton->SetToolTipText("Display axis time residuals relative to"
				  " fit or MC");
  fPixelButton->SetToolTipText("Display all or all FLT pixels (if written to"
			       " file, see RecDataWriter.xml...)");
  fStationButton->SetToolTipText("Display all stations in axis plot");

  horz3->AddFrame(CheckProfileButtons, layout3);

  // ------------------------------------------------------------------------
  // Color buttons

  TGHButtonGroup* ColorButtons = new TGHButtonGroup(horz3, "colors");
  fColorButton1 = new TGRadioButton(ColorButtons,
				    new TGHotString("t  "), eFDTimeColors);
  fColorButton2 = new TGRadioButton(ColorButtons,
				    new TGHotString("Q  "), eFDSignalColors);
  fColorButton3 = new TGRadioButton(ColorButtons,
				    new TGHotString("logQ  "), eFDLogSignalColors);
  fColorButton4 = new TGRadioButton(ColorButtons,
				    new TGHotString("clouds"), eFDCloudColorMode);
  fColorButton1->SetToolTipText("pixel colors from time"
				" (cold: early, hot: late)");
  fColorButton2->SetToolTipText("pixel colors from signal");
  fColorButton3->SetToolTipText("pixel colors from log of signal");
  fColorButton4->SetToolTipText("cloud camera colors");

  fColorButton1->SetState(kButtonDown);
  horz3->AddFrame(ColorButtons, layout3);

  // ------------------------------------------------------------------------
  // Animation

  fAnimateButton =
    new TGTextButton(horz3,new TGHotString("Animate"),eAnimateFD);
  horz3->AddFrame(fAnimateButton,layout2);

  ConnectButtons(main);


  // ------------------------------------------------------
  // --------- other init stuff

  InitObjArrays();
  UpdatePalette();

}


void
FdPlots::KeepAnimatedEpsFiles()
{
  fKeepAnimatedEpsFiles = true;
}


void
FdPlots::InitObjArrays()
{
  fSDPObjects = new TObjArray();
  fSDPObjects->SetOwner(kTRUE);

  fTimeFitObjects = new TObjArray();
  fTimeFitObjects->SetOwner(kTRUE);

  fProfileObjects = new TObjArray();
  fProfileObjects->SetOwner(kTRUE);

  fEventInfoObjects = new TObjArray();
  fEventInfoObjects->SetOwner(kTRUE);

  fTracePlotObjects = new TObjArray();
  fTracePlotObjects->SetOwner(kTRUE);
}


void
FdPlots::ConnectButtons(TGCompositeFrame* main)
{
  const TGWindow* theBrowserWindow = main->GetParent()->GetParent();
  EventBrowser* browser =
    const_cast<EventBrowser*>((const EventBrowser*) theBrowserWindow);
  const char* funcName("ProcessFdButtons()");
  const char* clck("Clicked()");
  const char* prss("Pressed()");
  const char* bName("EventBrowser");

  fProfdEdXButton->Connect(prss, bName,browser, funcName);
  fProfdEdXShowerAgeButton->Connect(prss, bName, browser, funcName);
  fProfLightButton->Connect(prss, bName, browser, funcName);
  fProfNeButton->Connect(prss, bName, browser, funcName);
  fResidualButton->Connect(clck, bName, browser, funcName);
  fPixelButton->Connect(clck, bName, browser, funcName);
  fStationButton->Connect(clck, bName, browser, funcName);
  fColorButton1->Connect(prss, bName, browser, funcName);
  fColorButton2->Connect(prss, bName, browser, funcName);
  fColorButton3->Connect(prss, bName, browser, funcName);
  fColorButton4->Connect(prss, bName, browser, funcName);

  fRebinField->Connect("ValueSet(Long_t)", bName, browser, funcName);

  fAnimateButton->Connect(prss, "FdPlots", this, "AnimateCamera()");


  // reset all buttons TGHButtonGroup pointer - otherwise SetState()
  // will result in nested ProcessFdButtons() calls!!
  fStationButton->SetGroup(NULL);
  fProfdEdXButton->SetGroup(NULL);
  fProfdEdXShowerAgeButton->SetGroup(NULL);
  fProfLightButton->SetGroup(NULL);
  fProfNeButton->SetGroup(NULL);
  fPixelButton->SetGroup(NULL);
  fResidualButton->SetGroup(NULL);
  fColorButton1->SetGroup(NULL);
  fColorButton2->SetGroup(NULL);
  fColorButton3->SetGroup(NULL);
  fColorButton4->SetGroup(NULL);
}

void
FdPlots::UpdatePalette()
{

  // ------------------------------------------------------
  // ----- create signal and time color palette

  if ((*fStyleManager)->FdColorPalette()) {

    const unsigned int nPalette = 101;
    const unsigned int nCol = 4;
    double red[nCol]  = {0. , 0.63, 1., 1.};
    double green[nCol]= {0. , 0.63, 1., 1.};
    double blue[nCol] = {0. , 1. , 0.1, 1.};
    double frac[nCol] = {0. , 0.33, 0.66, 1.};
    fSignalColorRangeStart =
#if ROOT_VERSION_CODE < ROOT_VERSION(5,16,0)
      TStyle::
#else
      TColor::
#endif
      CreateGradientColorTable(nCol, frac, red, green, blue, nPalette);
    fSignalColorLength = nPalette-1;

    // default rainbow colors from ROOT
    fTimeColorRangeStart = 51;
    fTimeColorLength = 49;
  }
  else {
    const unsigned int nPalette = 101;
    const unsigned int nCol = 2;
    double red[nCol]  = {0.,.9};
    double green[nCol]= {0.,.9};
    double blue[nCol] = {0.,.9};
    double frac[nCol] = {0.,1.};
    fSignalColorRangeStart =
#if ROOT_VERSION_CODE < ROOT_VERSION(5,16,0)
      TStyle::
#else
      TColor::
#endif
      CreateGradientColorTable(nCol, frac, red, green, blue, nPalette);
    fSignalColorLength = nPalette-1;
    double red2[nCol]  = {0.9,0.};
    double green2[nCol]= {0.9,0.};
    double blue2[nCol] = {0.9,0.};
    double frac2[nCol] = {0.,1.};
    fTimeColorRangeStart =
#if ROOT_VERSION_CODE < ROOT_VERSION(5,16,0)
      TStyle::
#else
      TColor::
#endif
      CreateGradientColorTable(nCol, frac2, red2, green2, blue2, nPalette);
    fTimeColorLength = nPalette-1;
  }

}



FdPlots::~FdPlots()
{

  fSDPObjects->Delete();
  fTimeFitObjects->Delete();
  fProfileObjects->Delete();
  fEventInfoObjects->Delete();
  fTracePlotObjects->Delete();

  fMain->Cleanup();
}


void
FdPlots::SetProfileMode(const EProfileMode m)
{
  switch (m) {
  case edEdX:
    fProfLightButton->SetState(kButtonUp);
    fProfdEdXButton->SetState(kButtonDown);
    fProfdEdXShowerAgeButton->SetState(kButtonUp);
    fProfNeButton->SetState(kButtonUp);
    break;
  case edEdXShowerAge:
    fProfLightButton->SetState(kButtonUp);
    fProfdEdXButton->SetState(kButtonUp);
    fProfdEdXShowerAgeButton->SetState(kButtonDown);
    fProfNeButton->SetState(kButtonUp);
    break;
  case eLightAtAperture:
    fProfdEdXButton->SetState(kButtonUp);
    fProfdEdXShowerAgeButton->SetState(kButtonUp);
    fProfLightButton->SetState(kButtonDown);
    fProfNeButton->SetState(kButtonUp);
    break;
  case eElectrons:
    fProfdEdXButton->SetState(kButtonUp);
    fProfdEdXShowerAgeButton->SetState(kButtonUp);
    fProfLightButton->SetState(kButtonUp);
    fProfNeButton->SetState(kButtonDown);
    break;
  default:
    break;
  }
  fProfileMode = m;
}


void
FdPlots::SetPixelColorMode(EPixelColorMode mode)
{
  switch(mode) {
  case eTime:
    fColorButton1->SetState(kButtonDown);
    fColorButton2->SetState(kButtonUp);
    fColorButton3->SetState(kButtonUp);
    fColorButton4->SetState(kButtonUp);
    break;

  case eCharge:
  case eADCSum:
    fColorButton1->SetState(kButtonUp);
    fColorButton2->SetState(kButtonDown);
    fColorButton3->SetState(kButtonUp);
    fColorButton4->SetState(kButtonUp);
    break;

  case eLogCharge:
  case eLogADCSum:
    fColorButton1->SetState(kButtonUp);
    fColorButton2->SetState(kButtonUp);
    fColorButton3->SetState(kButtonDown);
    fColorButton4->SetState(kButtonUp);
    break;
  case eCloudColors:
    fColorButton1->SetState(kButtonUp);
    fColorButton2->SetState(kButtonUp);
    fColorButton3->SetState(kButtonUp);
    fColorButton4->SetState(kButtonDown);
    break;
  }
  fPixelColorMode = mode;
}


void
FdPlots::Update()
{

  ComputePixelColorRange();

  DrawCamera();
  DrawTimeFit();
  DrawProfile();
  DrawEventInfo();
  DrawADCTrace();
  UpdateAnimateButton();
}

void
FdPlots::Clear()
{

  fCanvasCamera->GetCanvas()->SetEditable(true);
  fCanvasInfo->Clear();
  fCanvasCamera->Clear();
  fCanvasTime->Clear();
  fCanvasProfile->Clear();
  fCanvasPixels->Clear();
  fCanvasInfo->Update();
  fCanvasCamera->Update();
  fCanvasTime->Update();
  fCanvasProfile->Update();
  fCanvasPixels->Update();
  fCanvasCamera->GetCanvas()->SetEditable(false);

  fSDPObjects->Delete();
  fTimeFitObjects->Delete();
  fProfileObjects->Delete();
  fEventInfoObjects->Delete();
  fTracePlotObjects->Delete();

}

inline
string
ValueWithOptionalError(const double val, const double err,
                       const unsigned int prec)
{
  return stringFromNumber(val, prec) +
    (err > 0 ? "#pm" + stringFromNumber(err, prec) : "");
}

void
FdPlots::DrawEventInfo()
{


  fEventInfoObjects->Delete();

  fCanvasInfo->cd();
  fCanvasInfo->Clear();

  // define offsets
  float x1 = 0.03;
  float x2 = 0.05;
  float x3 = 0.7;
  float y = 0.95;
  float dy = 0.055;


  if (!(*fEvent)->HasEye(fEyeId)) {
    ShowExcuse(fCanvasInfo, fEventInfoObjects, "no event info available");
    return;
  }

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecShower& fdRecShower   = eyeEvent.GetFdRecShower();
  const FdRecGeometry& fdRecGeometry = eyeEvent.GetFdRecGeometry();
  EFdRecLevel recLevel = eyeEvent.GetRecLevel();
  const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);
  const Detector& det= (*fEvent)->GetDetector();

  TLatex latex;
  latex.SetTextSize(0.045);

  //-------------- generic event info:
  const int iEv = eyeEvent.GetEventId();
  const int iRun = eyeEvent.GetRunId();
  ostringstream info; info << "run " << iRun << ", event " << iEv;
  latex.SetTextFont((*fStyleManager)->GetBoldFontType());
  latex.DrawLatex (x1, y, info.str().c_str()); y-=dy;
  info.str("");

  const int GPSsec = eyeEvent.GetGPSSecond();
  const int GPSnsec = eyeEvent.GetGPSNanoSecond();
  info << "time stamp: " << GPSsec << " s " << GPSnsec << " ns";
  latex.SetTextFont((*fStyleManager)->GetNormalFontType());
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");

  string eventType = "Trigger: " + eyeEvent.GetEventType()
    + ", " + eyeEvent.GetEventClass();
  latex.DrawLatex(x2, y, eventType.c_str()); y-=dy;
  info.str("");

  ostringstream sEye;
  sEye << "in " << eye.GetEyeName() << " mirror";
  for (UInt_t i = 0; i < eye.GetNumberOfMirrors(); ++i)
    if (eyeEvent.MirrorIsInEvent(i+1))
      sEye << " " << i+1;
  sEye << " (in DAQ: ";
  for (UInt_t i = 1; i <= eye.GetNumberOfMirrors(); ++i) {
    if (det.IsInDAQ(fEyeId ,i)) {
      sEye << " " << i;
    }
  }
  sEye << ") ";
  latex.DrawLatex(x2, y, sEye.str().c_str()); y-=dy;


  //-------------- geometry reconstruction:

  info.str("");
  info << "geometry: ";
  latex.SetTextFont((*fStyleManager)->GetBoldFontType());

  const double Theta = fdRecShower.GetZenith()/degree;
  const double Phi   = fdRecShower.GetAzimuth()/degree;
  const double ThetaErr= fdRecShower.GetZenithError()/degree;
  const double PhiErr  = fdRecShower.GetAzimuthError()/degree;
  const TVector3& showerCore = fdRecShower.GetCoreSiteCS();
  const double xC = showerCore.X()/1000.;
  const double yC = showerCore.Y()/1000.;
  const double xCErr = fdRecShower.GetCoreEastingError()/1000.;
  const double yCErr = fdRecShower.GetCoreNorthingError()/1000.;
  const double Rp = fdRecGeometry.GetRp()/1000.;
  const double RpErr = fdRecGeometry.GetRpError()/1000.;

  const vector<FdRecStation>& stations = eyeEvent.GetStationVector();
  if (!stations.empty()) {
    double maxVEM = -1.;
    int hottestStation = -1;
    double hottestSPDistance = 99.;
    string triggerName = "unknown";
    for (unsigned int iS=0;iS<stations.size();iS++) {
      if(!stations[iS].IsHybrid()) continue;
      const double VEM = stations[iS].GetSignal();
      if (VEM > maxVEM) {
        maxVEM = VEM;
        hottestStation = stations[iS].GetId();
        triggerName = " (" +
          stations[iS].GetStationTriggerName(fRecStationClassVersion) + ")";
        hottestSPDistance = stations[iS].GetDistanceToAxis();
      }
    }
    if (hottestStation >= 0) {
      info << "hybrid, station ";
      info << hottestStation;
      info << triggerName;
      info << ", showerPlaneDistance = ";
      info << stringFromNumber(hottestSPDistance,0) << " m";
    }
    else
      info << "mono";
  }
  else {
    if (Rp !=0 && xC != 0)
      info << "mono";
    else
      info << "none";
  }
  latex.DrawLatex(x1, y, info.str().c_str()); y-=dy;
  latex.SetTextFont((*fStyleManager)->GetNormalFontType());
  info.str("");
  const double yStartGeom = y;
  // -----
  info << showpoint << setiosflags(ios::fixed) << setprecision(1)
       << "(#theta, #phi) = (" << Theta << "#pm" << ThetaErr << ", "
       << Phi << "#pm" << PhiErr << ") deg";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");
  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "(x, y) = (" <<xC << "#pm" << xCErr <<", " << yC << "#pm"
       << yCErr << ") km";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");
  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "R#scale[0.7]{p} = " << Rp << " #pm " << RpErr << " km";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");

  const bool mieDBstatus = det.HasMieDatabase();
  info.str("");
  info << "profile: ";
  if (recLevel >= eHasEnergy) {
    if (fdRecShower.GetGHType() == eGHTwoPar)
      info << "2-parameter Gaisser-Hillas";
    else {
      info << "4-parameter Gaisser-Hillas";
      if (fdRecShower.GetGHType() == eGHFourParClassic)
        info << " (type: classic)";
      else if (fdRecShower.GetGHType() == eGHFourParWidth)
        info << " (type: fwhm)";
      else
        info << " (unknown type)";
    }
  }
  else
    info << "none";
  latex.SetTextFont((*fStyleManager)->GetBoldFontType());
  latex.DrawLatex(x1, y, info.str().c_str()); y-=dy;
  latex.SetTextFont((*fStyleManager)->GetNormalFontType());
  info.str("");

  const double fullEnergy = fdRecShower.GetEnergy();
  const double power = fullEnergy>0.?(int) log10(fullEnergy):0.;
  const double energy = fdRecShower.GetEnergy()/pow(10.,power);
  const double totEnergyErr  = fdRecShower.GetEnergyError();
  const double atmEnergyErr  = fdRecShower.GetEnergyAtmError();
  const double statEnergyErr = sqrt(totEnergyErr*totEnergyErr
                                     -atmEnergyErr*atmEnergyErr)/pow(10.,power);
  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "E = (" << energy << " #pm "
       << statEnergyErr;
  if (mieDBstatus)
    info << " #pm "<< atmEnergyErr/pow(10., power);
  info << ") #times 10^{" << setprecision(0)  << noshowpoint
       << power << "} eV";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;

  const double Xmax = fdRecShower.GetXmax();
  const double XmaxErr = fdRecShower.GetXmaxError();
  info.str("");
  info << "X#scale[0.7]{max} = " << setiosflags(ios::fixed) << setprecision(0)
       << Xmax << " #pm " << XmaxErr << " g/cm^{2}";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;

  const double dEdXmax = fdRecShower.GetdEdXmax();
  const double dEdXmaxErr = fdRecShower.GetdEdXmaxError();
  info.str("");
  info << "(dE/dX)#scale[0.7]{max} = " << showpoint << setiosflags(ios::fixed)
       << setprecision(2) << dEdXmax << " #pm " << dEdXmaxErr
       << " PeV/(g/cm^{2})";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;

  // shape parameters
  const double X0 = fdRecShower.GetX0();
  const double X0Err = fdRecShower.GetX0Error();
  const double lam = fdRecShower.GetLambda();
  const double lamErr = fdRecShower.GetLambdaError();
  const double FWHM = fdRecShower.GetFWHM();
  const double FWHMErr = fdRecShower.GetFWHMError();
  info.str("");
  info << "(#lambda, X_{0}" << (FWHM>0?", fwhm":"")
       << ") = (" << noshowpoint
       << setiosflags(ios::fixed)
       << ValueWithOptionalError(lam, lamErr, 0) << ", "
       << ValueWithOptionalError(X0, X0Err, 0);
  if (FWHM > 0)
    info << ", " << ValueWithOptionalError(FWHM, FWHMErr, 0);
  info << ") g/cm^{2}";
  const double asym = fdRecShower.GetAsymmetry();
  const double asymErr = fdRecShower.GetAsymmetryError();
  if (asym > 0) {
    info << ", f#scale[0.7]{asym} = "
         << ValueWithOptionalError(asym, asymErr, 2);
  }
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;

  // chkov and mva
  info.str("");
  info << "Cherenkov-fraction = " << noshowpoint
       << setiosflags(ios::fixed)
       << setprecision(0)
       << fdRecShower.GetCherenkovFraction() << "%"
       << ", mva=" << fdRecShower.GetMinAngle()/degree
       << " deg." << endl;
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");


  latex.SetTextFont((*fStyleManager)->GetBoldFontType());
  latex.DrawLatex(x1, y, "databases:"); y-=dy;
  latex.SetTextFont((*fStyleManager)->GetNormalFontType());
  info.str("");
  const int dbColor = kBlack;
  //--------------
  latex.SetTextColor(dbColor);
  info << "Mie attenuation: ";
  if (mieDBstatus) {
    info<< "measured ";
    if (det.HasOverallQualityDatabase()) {
      info << "(h<"
	   << stringFromNumber(det.GetQDBMinCloudBaseHeight()/1000.,1) << " km";
      if (det.HasVAOD(fEyeId)) {
	info <<", VAOD at 3km: " << setprecision(2)
	     << det.GetVAODAtReferenceHeight(fEyeId);
      }
      info << ")";
    }
  }
  else
    info << "model";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");

  //--------------
  if (det.HasLidarData(fEyeId))
    info << "LIDAR: h(cloud)="
         << stringFromNumber(det.GetLidarData(fEyeId).GetCloudHeight()/1000,1)
         << " km, "
         << stringFromNumber(det.GetLidarData(fEyeId).GetCloudCoverage()*100,0)
         << "%";
  else
    info << "LIDAR: no data ";

  if (det.HasCloudCameraData(fEyeId)) {
    const FdRecApertureLight& apLight = eyeEvent.GetFdRecApertureLight();
    info << "; CloudCam: max(#zeta)=("
         << stringFromNumber(apLight.GetMaxCloudCameraFractionInZeta()*100,0) << "/"
         << stringFromNumber(apLight.GetMaxCloudCameraFractionWithLidarInZeta()*100,
                             0) << ")%";
  }
  else
    info << "; CloudCam: no data";

  if (fdRecShower.GetMaxCloudFractionBetweenEyeAndShower() >= 0)
    info << "; CloudMap: max="
         << stringFromNumber(fdRecShower.GetMaxCloudFractionBetweenEyeAndShower()*100,0) << "%";
  else
    info << "; CloudMap: no data";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");

  //--------------
  info << "molecular profile: ";
  if (det.HasGDASDatabase())
    info << "GDAS";
  else
    info << "model";
  info << "; time correction: ";
  switch (eyeEvent.GetTimeCorrectionStatus()) {
  case eGoodCorrection:
    info << "good";
    break;
  case eBadCorrection:
    info << "bad";
    break;
  case eOfflineCorrected:
    info << "offline";
    break;
  case eUndefinedCorrection:
  default:
    info << "unknown";
    break;
  }
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  latex.SetTextColor(kBlack);
  info.str("");

  if (fIsMC && EventBrowserConfig::Get(cfg::eShowMC)) {

    const GenShower& genShower = (*fEvent)->GetGenShower();
    const FdGenGeometry& genGeometry =
      eyeEvent.GetGenGeometry();

    y = yStartGeom;

    info << "[" << showpoint << setiosflags(ios::fixed) << setprecision(1)
	 << genShower.GetZenith()/degree<<","<<genShower.GetAzimuth()/degree<<"]";
    latex.DrawLatex(x3, y, info.str().c_str()); y-=dy;
    info.str("");
    info << "[" << showpoint << setiosflags(ios::fixed) << setprecision(2)
	 << genShower.GetCoreSiteCS().X()/1000.
         <<","<<genShower.GetCoreSiteCS().Y()/1000.<<"]";
    latex.DrawLatex(x3, y, info.str().c_str()); y-=dy;
    info.str("");
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
	 << "[" << genGeometry.GetRp()/1000 <<"]";
    latex.DrawLatex(x3, y, info.str().c_str()); y-=dy;
    info.str("");
    y -= dy;

    const double fullEnergy = genShower.GetEnergy();
    const double power=fullEnergy>0.?(int) (log10(fullEnergy)+1.e-5):0.;
    const double energy = fullEnergy/pow(10.,power);
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
	 << "[" << energy <<  " #times 10^{" << setprecision(0)  << noshowpoint
	 << power << "} ]";
    latex.DrawLatex(x3, y, info.str().c_str()); y-=dy;
    if (fdRecShower.GetX1Error()>0) {
      info.str("");
      info<< showpoint << setiosflags(ios::fixed) << setprecision(1)
	  << "[" << genShower.GetX1() << "]";
      latex.DrawLatex(x3, y, info.str().c_str()); y-=dy;
    }
    info.str("");
    info<< showpoint << setiosflags(ios::fixed) << setprecision(1)
	<< "[" << genShower.GetXmaxInterpolated()
	<< ", " << genShower.GetShortPrimaryName()  << "]";
    latex.DrawLatex(x3, y, info.str().c_str()); y-=4.3*dy;
    info.str("");
  }

  fCanvasInfo->Modified();
  fCanvasInfo->Update();

}


void
FdPlots::AnimateCamera()
{

  if (!(*fEvent)->HasEye(fEyeId))
    return;

  EPixelColorMode saveMode = fPixelColorMode;
  if (fPixelColorMode == eLogCharge)
    SetPixelColorMode(eLogADCSum);
  else
    SetPixelColorMode(eADCSum);

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecPixel& recPix = eyeEvent.GetFdRecPixel();
  const int nPix = recPix.GetNumberOfPixels();

  const int margin = fPixelColorMode==eLogADCSum ? 10 : 10;

  int startEventBin = 0;
  int stopEventBin = 0;
  bool first = true;
  for (int iPix=0; iPix<nPix; ++iPix) {

    if (recPix.GetStatus(iPix) < eTimeFitPix)
      continue;

    const double value = recPix.GetTime(iPix);
    const int valStart = max((int)value - margin, 0);
    const int valStop = min((int)value + margin, (int)recPix.GetTrace(iPix).size()-1);

    if (first) {
      startEventBin = valStart;
      stopEventBin = valStop;
      first = false;
    } else {
      startEventBin = min(startEventBin, valStart);
      stopEventBin = max(stopEventBin, valStop);
    }
  } // loop pixels

  ComputePixelColorRange(startEventBin, stopEventBin);


  const bool saveEPS = fKeepAnimatedEpsFiles;
  const bool saveAnimation = EventBrowserConfig::Get(cfg::eFdSaveAnimation);
  const bool fastAnimation = EventBrowserConfig::Get(cfg::eFdSpeedAnimation);

  ostringstream dirName, animGifName, finalGifName;
  dirName << (*fEvent)->GetAugerId() << ".epsImages";
  finalGifName << (*fEvent)->GetAugerId() << ".gif";
  animGifName << finalGifName.str() << "+";
  if (saveAnimation && saveEPS) {
    gSystem->mkdir(dirName.str().c_str());
  }

  if (saveAnimation)
    gSystem->Unlink(finalGifName.str().c_str()); // delete old file

  for (int i = startEventBin; i <= stopEventBin; i+=(fastAnimation ? 5 : 1)) {
    DrawCamera(i);
    if (saveAnimation) {
      fCanvasCamera->Print(animGifName.str().c_str());
      if (saveEPS) {
        ostringstream canvasName;
        canvasName << dirName.str() << "/"
                   << "eye_" << fEyeId << "_time_" << i << ".eps";
        fCanvasCamera->Print(canvasName.str().c_str());
      }
    }
  }

  if (saveAnimation) {
    bool haveGifSicle = (gSystem->Exec("which gifsicle >& /dev/null")==0);
    if (haveGifSicle) {
      ostringstream gifCommand;
      gifCommand << " mv " << finalGifName.str() << " _tmp.gif;"
                 << " gifsicle --delay=10 --loop=5 _tmp.gif > "
                 << finalGifName.str() << ";"
                 << " rm _tmp.gif ";
      gSystem->Exec(gifCommand.str().c_str());
    }
  }

  SetPixelColorMode(saveMode);
  ComputePixelColorRange();
  DrawCamera();

}

void
FdPlots::DrawCamera(const int timeBin)
{
  const int kPixelBorderLineWidth = 1;
  const int kMismatchedPixelBorderLineWidth = 2;
  const int kBadPixelBorderLineWidth = 2;

  // CLEANUP
  fSDPObjects->Delete();
  fCanvasCamera->cd();
  fCanvasCamera->GetCanvas()->SetEditable(true);
  fCanvasCamera->Clear();

  if (!(*fEvent)->HasEye(fEyeId)) {
    ShowExcuse(fCanvasCamera, fSDPObjects, "no data");
    return;
  }

  const Detector& detector = (*fEvent)->GetDetector();
  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecGeometry& fdRecGeometry = eyeEvent.GetFdRecGeometry();
  const FdRecPixel& pixRec   = eyeEvent.GetFdRecPixel();
  const EFdRecLevel recLevel = eyeEvent.GetRecLevel();

  if (recLevel < eHasTriggeredPixels) {
    ShowExcuse(fCanvasCamera, fSDPObjects, "no triggered pixels in event");
    return;
  }

  // this is a placeholder for Xmax/X1 markers !
  vector<double> pointPhi, pointOmega, pointSize;
  vector<int> pointStyle, pointColor;


  const TBits& telBits = fShowTelsInDAQ ?
    detector.GetMirrorsInDAQ(fEyeId) :
    eyeEvent.GetMirrorsInEvent();

  Double_t phiMin, phiMax;
  Double_t omegaMin, omegaMax;
  const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);
  const Detector::EyePointingIdMap ptIds = detector.GetPointingIdsForEye(fEyeId);
  eye.GetMinMaxPhi(telBits, ptIds, phiMin, phiMax);
  eye.GetMinMaxOmega(telBits, ptIds, omegaMin, omegaMax);

  const Int_t nPix = pixRec.GetNumberOfPixels();
  // -------------------------------------------------------------
  // a, collect station data
  vector<double> stationAzimuths;
  vector<double> stationElevations;
  vector<double> hybridStationAzimuths;
  vector<double> hybridStationElevations;
  const vector<FdRecStation>& stations= eyeEvent.GetStationVector();

  double minStationElev = 0;
  for (unsigned int iS = 0; iS < stations.size(); iS++) {

    if (!stations[iS].IsHybrid() && !fShowAllStations)
      continue;
    double a = stations[iS].GetAzimuth()/degree;
    if(fShowEyeView)
      a = 180.-a;
    const double e = stations[iS].GetElevation()/degree;
    if (iS == 0 || e < minStationElev)
      minStationElev = e;

    if (stations[iS].IsHybrid()) {
      hybridStationAzimuths.push_back(a);
      hybridStationElevations.push_back(e);
    }
    else {
      stationAzimuths.push_back(a);
      stationElevations.push_back(e);
    }
  }

  // -------------------------------------------------------------
  // b, draw position of all pixels in triggered mirrors

  const double kDeltaOmega=2., kDeltaPhi=2.;
  const int kNx=51, kNy=51;

  string hTitle;
  if (timeBin >= 0) {
    ostringstream sTit;
    sTit << "time bin " << timeBin;
    hTitle = sTit.str();
  }

  ostringstream hName;
  hName << "sdpframe_" << eye.GetEyeName();

  TH2F* histCamera;

  const double cameraCanvasMin = -1.;
  if(fShowEyeView) {
    histCamera = new TH2F(hName.str().c_str(), hTitle.c_str(),
                          kNx, 180.-phiMax-kDeltaPhi, 180.-phiMin+kDeltaPhi,
                          kNy, cameraCanvasMin, omegaMax+kDeltaOmega);
  } else {
    histCamera= new TH2F(hName.str().c_str(), hTitle.c_str(),
                         kNx, phiMin-kDeltaPhi, phiMax+kDeltaPhi,
                         kNy, cameraCanvasMin, omegaMax+kDeltaOmega);
  }
  fSDPObjects->Add(histCamera);

  if (!pixRec.HasPixelStatus())
    return;

  // set a dummy entries to get a TPaletteAxis
  if (fPixelColorMode != eTime) {

    double maxADC = 100.;

    for (Int_t i = 0; i < nPix; ++i) {

      if (pixRec.GetStatus(i) > eTriggeredPix) {

        double ADC = pixRec.GetCharge(i);
        if (ADC > maxADC)
          maxADC = ADC;
      }
    }

    const double kADCToKiloPhotons = 5000.;
    const double minCont = (kMinADC-0.0001)/kADCToKiloPhotons;
    for (int i = 1; i <= kNx; ++i) {
      for (int j = 1; j <= kNy; ++j)
        histCamera->SetBinContent(i, j, minCont);
    }

    // go to units of 1000 photons and a little offset
    maxADC += 200.;
    const double maxCont = TMath::Max(maxADC, kMaxADC) / kADCToKiloPhotons;
    histCamera->SetBinContent(kNx/2, kNy/2, maxCont);
    histCamera->SetContour(100);
    histCamera->Draw("COL");
  }
  else {
    histCamera->Draw();
  }

#ifdef GERMAN
  histCamera->GetXaxis()->SetTitle("Azimuthwinkel  [Grad]");
  histCamera->GetYaxis()->SetTitle("Hohenwinkel  [Grad]");
  histCamera->GetYaxis()->SetTitleOffset(.9);
#else
  histCamera->GetXaxis()->SetTitle("azimuth  [deg]");
  histCamera->GetYaxis()->SetTitle("elevation  [deg]");
  histCamera->GetYaxis()->SetTitleOffset(.9);
#endif

  UInt_t nTel = eye.GetNumberOfMirrors();
  for (UInt_t iTel = 0; iTel < nTel; iTel++) {

    if (telBits.TestBitNumber(iTel+1)) {

      const TelescopeGeometry& tel = eye.GetTelescope(iTel+1);
      Int_t nPix = tel.GetNumberOfPixels();

      for (Int_t iPix = 0; iPix < nPix; ++iPix) {

	//Int_t jPix = iTel * nTel + iPix;

	TPolyLine* pixel = GetCameraPixel(iPix, iTel+1);

        if (fPixelColorMode != eTime) {
          if (fPixelColorMode == eCloudColors)
            pixel->SetFillColor(GetCloudColor(iTel+1, iPix+1));
          else
            pixel->SetFillColor(fSignalColorRangeStart);
	  pixel->Draw("f");
	}

	pixel->SetLineWidth(kPixelBorderLineWidth);
	pixel->SetLineColor((*fStyleManager)->GetPixelBorderColor());
	if (detector.IsBadPixel(fEyeId, iTel+1, iPix+1)) {
	  pixel->SetLineColor((*fStyleManager)->GetBadPixelBorderColor());
	  pixel->SetLineWidth(kBadPixelBorderLineWidth);
	}
	else if (detector.IsMismatchedPixel(fEyeId, iTel+1, iPix+1)) {
	  pixel->SetLineColor((*fStyleManager)->GetMismatchedPixelBorderColor());
	  pixel->SetLineWidth(kMismatchedPixelBorderLineWidth);
	}

	pixel->Draw();
	fSDPObjects->Add(pixel);
      }
    }
  } // end for each telescope

  // -------------------------------------------------------------
  // c, draw pixels with data

  for (Int_t i = 0; i < nPix; ++i) {

    if (pixRec.GetStatus(i) >= eTriggeredPix || fShowAllPixels) {

      const int iTel = pixRec.GetTelescopeId(i);
      const int iPix = pixRec.GetPixelId(i) - 1;

      TPolyLine* pixel = GetCameraPixel(iPix, iTel);
      if (fPixelColorMode == eCloudColors) {
        pixel->SetLineColor(kRed);
        pixel->SetFillColor(GetCloudColor(iTel, iPix+1));
        pixel->SetLineWidth(kPixelBorderLineWidth+1);
      }
      else {
        pixel->SetLineColor((*fStyleManager)->GetPixelBorderColor());
        pixel->SetFillColor(GetPixelColor(i, timeBin));
        pixel->SetLineWidth(kPixelBorderLineWidth);
      }

      // check for saturation
      if (pixRec.IsHighGainSaturated(i) &&
	  (fPixelColorMode == eTime ||
	   fPixelColorMode == eCharge ||
	   fPixelColorMode == eLogCharge ||
	   ((fPixelColorMode == eADCSum || fPixelColorMode == eLogADCSum) &&
            IsPixelADCbinSaturated(i, timeBin))))
	pixel->SetFillStyle((*fStyleManager)->GetSaturatedPixelFillStyle());

      if (detector.IsBadPixel(fEyeId, iTel, iPix+1)) {
        pixel->SetLineColor((*fStyleManager)->GetBadPixelBorderColor());
        pixel->SetLineWidth(kBadPixelBorderLineWidth);
      }
      else if (detector.IsMismatchedPixel(fEyeId, iTel, iPix+1)) {
        pixel->SetLineColor((*fStyleManager)->GetMismatchedPixelBorderColor());
        pixel->SetLineWidth(kMismatchedPixelBorderLineWidth);
      }

      pixel->Draw("f");
      pixel->Draw();
      fSDPObjects->Add(pixel);
    }
  }

  // -------------------------------------------------------------

  // -------------------------------------------------------------
  // d, superimpose stations

  if (!hybridStationElevations.empty()) {
    TGraph* hybridStationGraph = new TGraph(hybridStationElevations.size(),
					    &hybridStationAzimuths.front(),
					    &hybridStationElevations.front());
    hybridStationGraph->SetNameTitle("hybridStationGraph", "hybridStationGraph");
    hybridStationGraph->SetMarkerStyle((*fStyleManager)->GetSDTimeFitDataType());
    hybridStationGraph->SetMarkerSize((*fStyleManager)->GetSDTimeFitDataSize());
    hybridStationGraph->Draw("P");

    fSDPObjects->Add(hybridStationGraph);
  }

  if (!stationElevations.empty()) {
    TGraph* stationGraph = new TGraph(stationElevations.size(),
				      &stationAzimuths.front(),
				      &stationElevations.front());
    stationGraph->SetNameTitle("stationGraph", "stationGraph");
    stationGraph->SetMarkerStyle((*fStyleManager)->GetSDTimeFitStationType());
    stationGraph->SetMarkerSize((*fStyleManager)->GetSDTimeFitDataSize());
    stationGraph->Draw("P");

    fSDPObjects->Add(stationGraph);
  }


  // -------------------------------------------------------------
  // draw reconstructed SDP
  if (recLevel >= eHasSDP) {
    bool hasTelescopeSDP = false;
    for (FDEvent::TelescopeDataConstIterator telIt = eyeEvent.TelescopeDataBegin(),
           end = eyeEvent.TelescopeDataEnd(); telIt != end; ++telIt)
      {
        if (!eye.HasTelescope(telIt->first))
          continue;
        const TelescopeGeometry& detTel = eye.GetTelescope(telIt->first);
        //const double sdpPhi = geo.GetSDPPhi();
        //const double sdpTheta = geo.GetSDPTheta();

        const FdRecGeometry& geo = telIt->second.GetRecGeometry();
        if (geo.GetSDPPhi() == 0 && geo.GetSDPTheta() == 0) // hmm...
          continue;

        hasTelescopeSDP = true;
        // Limit SDP to its own telescope
        TString pId = detector.GetPointingId(fEyeId, telIt->first);
        const double omegaMin = detTel.GetPixelMinOmega(pId);
        const double omegaMax = detTel.GetPixelMaxOmega(pId);
        const double phiMin   = detTel.GetPixelMinPhi(pId);
        const double phiMax   = detTel.GetPixelMaxPhi(pId);

        DrawSDP(geo.GetSDPTheta(),
                geo.GetSDPPhi(),
                omegaMin + 0.25, omegaMax, phiMin, phiMax,
                //cameraCanvasMin + 0.25, omegaMax, phiMin, phiMax,
                (*fStyleManager)->GetFDSDPLineColor());

        if (EventBrowserConfig::Get(cfg::eFdShowZeta)) {
          const double zeta = telIt->second.GetRecApertureLight().GetZeta();

          DrawSDP(geo.GetSDPTheta(),
                  geo.GetSDPPhi()-zeta,
                  omegaMin, omegaMax, phiMin, phiMax,
                  (*fStyleManager)->GetFDSDPLineColor());

          DrawSDP(geo.GetSDPTheta(),
                  geo.GetSDPPhi()+zeta,
                  omegaMin, omegaMax, phiMin, phiMax,
                  (*fStyleManager)->GetFDSDPLineColor());
        }

      } // end foreach FdTelescopeData

    if (!hasTelescopeSDP) {
      // fall back to eye-based SDP for old data
      DrawSDP(fdRecGeometry.GetSDPTheta(),
              fdRecGeometry.GetSDPPhi(),
              cameraCanvasMin + 0.25, omegaMax, phiMin, phiMax,
              (*fStyleManager)->GetFDSDPLineColor());

      if (EventBrowserConfig::Get(cfg::eFdShowZeta)) {
        const double zeta = eyeEvent.GetFdRecApertureLight().GetZeta();

        DrawSDP(fdRecGeometry.GetSDPTheta(),
                fdRecGeometry.GetSDPPhi()-zeta,
                omegaMin, omegaMax, phiMin, phiMax,
                (*fStyleManager)->GetFDSDPLineColor());

        DrawSDP(fdRecGeometry.GetSDPTheta(),
                fdRecGeometry.GetSDPPhi()+zeta,
                omegaMin, omegaMax, phiMin, phiMax,
                (*fStyleManager)->GetFDSDPLineColor());
      }
    } // end fallback to eye-SDP

    if (EventBrowserConfig::Get(cfg::eFdShowXmaxInSdp)) {
      // plot marker for Xmax and X1
      const FdRecShower& recShower = eyeEvent.GetFdRecShower();
      const double xmaxChi         = recShower.GetXmaxChi();
      const double x1Chi           = recShower.GetX1Chi();
      const double x1ChiError      = recShower.GetX1ChiError();

      TVector3 vertical(0, 0, 1);
      TVector3 sdp = fdRecGeometry.GetSDP();

      TVector3 horizontalInSDP = sdp.Cross(vertical);
      TVector3 vecXmax = horizontalInSDP;
      vecXmax.Rotate(-xmaxChi, sdp);
      pointPhi  .push_back(vecXmax.Phi()/degree);
      pointOmega.push_back(90. - vecXmax.Theta()/degree);
      pointStyle.push_back(20);
      pointSize.push_back(1.);
      pointColor.push_back((*fStyleManager)->GetFDSDPLineColor());

      if (x1ChiError > 0) {
        TVector3 vecX1 = horizontalInSDP;
        vecX1.Rotate(-x1Chi, sdp);
        pointPhi  .push_back(vecX1.Phi()/degree);
        pointOmega.push_back(90. - vecX1.Theta()/degree);
        pointStyle.push_back(20);
        pointSize.push_back(1.);
        pointColor.push_back((*fStyleManager)->GetFDSDPLineColor());
      }
    }
  }

  // -------------------------------------------------------------
  // draw T3 SDP

  if (EventBrowserConfig::Get(cfg::eFdShowT3Sdp) && eyeEvent.HasT3Reconstruction()) {
    const double backWallAngle =
      (*fDetectorGeometry)->GetEye(fEyeId).GetBackWallAngle();
    const double theta = eyeEvent.GetT3SDPTheta();
    const double phi = eyeEvent.GetT3SDPPhi()-backWallAngle;
    DrawSDP(theta,phi,
	    cameraCanvasMin+0.25,omegaMax,phiMin,phiMax,
	    (*fStyleManager)->GetT3SDPLineColor());
  }



  // -------------------------------------------------------------
  // draw generated SDP

  if (fIsMC && EventBrowserConfig::Get(cfg::eShowMC)) {

    const FdGenGeometry& genGeometry    = eyeEvent.GetGenGeometry();
    DrawSDP(genGeometry.GetSDPTheta(),
	    genGeometry.GetSDPPhi(),
	    cameraCanvasMin+0.25,omegaMax,phiMin,phiMax,
	    (*fStyleManager)->GetMCSDPLineColor());

    if (EventBrowserConfig::Get(cfg::eFdShowXmaxInSdp)) {
      // plot marker for Xmax and X1
      const FdGenShower& genShower = eyeEvent.GetGenShower();
      const double xmaxChi = genShower.GetXmaxChi();
      const double x1Chi = genShower.GetX1Chi();

      TVector3 vertical(0,0,1);
      TVector3 sdp = genGeometry.GetSDP();
      TVector3 horizontalInSDP = sdp.Cross(vertical);
      TVector3 vecXmax = horizontalInSDP;
      vecXmax.Rotate(-xmaxChi, sdp);
      pointPhi.push_back(vecXmax.Phi()/degree);
      pointOmega.push_back(90. - vecXmax.Theta()/degree);
      pointStyle.push_back(24);
      pointSize.push_back(1.2);
      pointColor.push_back((*fStyleManager)->GetMCSDPLineColor());

      TVector3 vecX1 = horizontalInSDP;
      vecX1.Rotate(-x1Chi, sdp);
      pointPhi.push_back(vecX1.Phi()/degree);
      pointOmega.push_back(90. - vecX1.Theta()/degree);
      pointStyle.push_back(2);
      pointSize.push_back(1.2);
      pointColor.push_back((*fStyleManager)->GetMCSDPLineColor());
    }
  } // end is MC

  // -------------------------------------------------------------
  // draw SD SDP projection
  if (EventBrowserConfig::Get(cfg::eFdShowSd)) {

    const SdRecGeometry& sdRecGeometry =
      eyeEvent.GetSdRecGeometry();

    if (sdRecGeometry.GetRp() != 0.) {

      DrawSDP(sdRecGeometry.GetSDPTheta(),
	      sdRecGeometry.GetSDPPhi(),
	      cameraCanvasMin+0.25,omegaMax,phiMin,phiMax,
	      (*fStyleManager)->GetSDSDPLineColor());
    }
  } // show SD in FD


  // plot markers collection
  for (unsigned int iMarker=0; iMarker<pointPhi.size(); ++iMarker) {

    double phi         = pointPhi[iMarker];
    const double Omega = pointOmega[iMarker];
    const int    Color = pointColor[iMarker];
    const int    Style = pointStyle[iMarker];
    const double Size  = pointSize [iMarker];

    if (Omega>omegaMin+.5 && Omega < omegaMax-.5 &&
	phi > phiMin-kDeltaPhi && phi < phiMax+kDeltaPhi) {

      if (fShowEyeView)
	phi = 180. - phi;

      TMarker* mark = new TMarker (phi, Omega, Style);
      mark->SetMarkerColor(Color);
      mark->SetMarkerSize(Size);
      fSDPObjects->Add(mark);
      mark->Draw("SAME");
    }
  }// end loop markers



  // reverse axis if in eyeView mode
  if (fShowEyeView) {
    histCamera->GetXaxis()->SetLabelSize(0);
    histCamera->GetXaxis()->SetLabelColor(kWhite);
    histCamera->GetXaxis()->SetTickLength(0);

    fCanvasCamera->Modified();
    fCanvasCamera->Update();

    TGaxis* reverseAxis = new TGaxis(gPad->GetUxmax(),
				     gPad->GetUymin(),
				     gPad->GetUxmin(),
				     gPad->GetUymin(),
				     180.-histCamera->GetXaxis()->GetXmax(),
				     180.-histCamera->GetXaxis()->GetXmin(),
				     510,"-");
    reverseAxis->SetLabelOffset(-0.04);
    reverseAxis->SetLabelSize(gStyle->GetLabelSize("X"));
    reverseAxis->SetTitleFont(gStyle->GetTitleFont("X"));
    reverseAxis->SetLabelFont(gStyle->GetLabelFont("X"));
    reverseAxis->Draw();
    fSDPObjects->Add(reverseAxis);
  }


  // print info if no cloud data
  if (fPixelColorMode == eCloudColors) {
    if (!(*fEvent)->GetDetector().HasCloudCameraData(fEyeId))
      ShowExcuse(fCanvasCamera, fSDPObjects,
                 "no cloud camera data for this event", kWhite);
    else {
      const FdCloudCameraData& cloudCamData =
        (*fEvent)->GetDetector().GetCloudCameraData(fEyeId);
      const TBits& telBits = eyeEvent.GetMirrorsInEvent();
      UInt_t nTel = eye.GetNumberOfMirrors();
      bool dataMissing = false;
      ostringstream missMess;
      missMess << "no cloud camera data for telescope ";
      for (UInt_t iTel = 0; iTel < nTel; iTel++) {
        if (telBits.TestBitNumber(iTel+1)) {
          if (!cloudCamData.HasCloudFraction(iTel+1,1)) {
            dataMissing = true;
            missMess << iTel+1 << " ";
          }
        }
      }
      if (dataMissing)
        ShowExcuse(fCanvasCamera, fSDPObjects,
                   missMess.str().c_str(), kWhite);
    }
  }

  fCanvasCamera->Modified();
  fCanvasCamera->Update();
  fCanvasCamera->GetCanvas()->SetEditable(false);

}

/***************************************************************************/
TPolyLine*
FdPlots::GetCameraPixel(UInt_t iPix, UInt_t iTel)
  const
{

  const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);
  const TelescopeGeometry& tel = eye.GetTelescope(iTel);
  const TString telPointingId =
    (*fEvent)->GetDetector().GetPointingId(fEyeId, iTel);

  const bool useHardcodedAugerCamera = (tel.GetNumberOfPixels() == 440);

  if (useHardcodedAugerCamera) { // hardcoded pixel-drawing

    const double azim = tel.GetAzimuth(telPointingId)/degree;

    const int nRow = 22;
    const int iCol = iPix / nRow + 1;
    const int iRow = iPix % nRow + 1;

    const double pixelSize = 1.5*degree;

    const double kSqrt3 = sqrt(3.);

    // --- from fdet::Pixel
    const double eta0 = pixelSize;
    const double dOmega = eta0;
    const double dPhi = kSqrt3 * eta0/2;
    const double beta  = - (iCol - ((iRow%2) ? 10. : 10.5)) * dOmega;
    const double alpha = - (11.66667 - iRow) * dPhi;
    // ---

    const double kalpha_m = tel.GetElevation(telPointingId);

    const double sin30Deg = 0.5;
    const double cos30Deg = kSqrt3/2.;

    // construct a hexagon at (0.,0.)
    const double pixelWidth  = (kSqrt3/2.)*degree;
    const double xx = pixelWidth*cos30Deg;
    const double yy = pixelWidth*sin30Deg;

    const int nHex = 7;
    Double_t x[nHex] = {0., xx, xx,  0., -xx, -xx,  0.};
    Double_t y[nHex] = {-pixelWidth, -yy,  yy, pixelWidth, yy, -yy, -pixelWidth};

    // transform (see GAP_2000_032)
    for (int k = 0; k < nHex; ++k) {
      x[k] += beta;
      y[k] += alpha;

      const double sinDelta = sin(y[k] + kalpha_m) * cos(x[k]);
      const double delta    = asin(sinDelta);
      const double sinPhi   = sin(x[k]) / cos(delta);
      const double phi      = asin(sinPhi);

      x[k] = phi / degree + azim;
      y[k] = delta / degree;
    }

    if (fShowEyeView)
      for (int k = 0; k < nHex; ++k)
        x[k] = 180. - x[k];

    return new TPolyLine(nHex,x,y);

  }
  else {
    const double phi = tel.GetPixelPhi(iPix, telPointingId);
    const double omega = tel.GetPixelOmega(iPix, telPointingId);
    const double solidAngle = tel.GetSolidAngle(iPix);
    const double radius = acos(1 - solidAngle/TMath::TwoPi()) * TMath::RadToDeg();
    const unsigned int nPoints = 40;
    const double dPhi = 2*TMath::Pi()/nPoints;
    vector<double> xVec;
    vector<double> yVec;
    double currPhi = 0;
    for (unsigned int i = 0; i < nPoints + 1; ++i) {
      xVec.push_back(phi + cos(currPhi) * radius);
      yVec.push_back(omega + sin(currPhi) * radius);
      currPhi += dPhi;
    }
    if (fShowEyeView)
      for (unsigned int k = 0; k < xVec.size(); ++k)
        xVec[k] = 180 - xVec[k];

    return new TPolyLine(xVec.size(), &xVec.front(), &yVec.front());
  }


}


/****************************************************************************/
void
FdPlots::DrawTimeFit()
{
  fTimeFitObjects->Delete();

  fCanvasTime->cd();
  fCanvasTime->Clear();

  if (!(*fEvent)->HasEye(fEyeId) ||
      (*fEvent)->GetEye(fEyeId).GetRecLevel() < eHasAxis) {
    ShowExcuse(fCanvasTime, fTimeFitObjects, "no time fit available");
    return;
  }

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecPixel& fdPix = eyeEvent.GetFdRecPixel();
  const FdRecGeometry& fdRecGeometry = eyeEvent.GetFdRecGeometry();

  const vector<EPixelStatus>& pixelStatus  = fdPix.GetStatus();
  //  const vector<UShort_t>& pixelId          = fdPix.GetID();
  const vector<Double_t>& pixelTimeErr     = fdPix.GetTimeErr();
  const vector<Double_t>& pixelChi         = fdPix.GetChi();
  const vector<Double_t>& pixelTime        = fdPix.GetTime();

  vector<double> usedPixelTime;
  vector<double> usedPixelTimeError;
  vector<double> usedPixelChi;
  vector<int> usedPixelColor;
  vector<double> rejectedPixelTime;
  vector<double> rejectedPixelTimeError;
  vector<double> rejectedPixelChi;

  bool haveRange = false;
  double maxChi  = 90.;
  double minChi  = 0.;
  double maxTime = 4000;
  double minTime = 0;

  // axis fit

  map<int, TF1*> axisFitsMap;
  vector<TF1*> axisFits;
  if (eyeEvent.GetRecLevel() >= eHasAxis) {

    for (FDEvent::TelescopeDataConstIterator iTel = eyeEvent.TelescopeDataBegin(),
           end = eyeEvent.TelescopeDataEnd(); iTel != end; ++iTel) {
      const FdTelescopeData& telData = iTel->second;
      const FdRecGeometry& telGeometry = telData.GetRecGeometry();
      if (telGeometry.GetTimeFitNdof() <= 0)
        continue;

      ostringstream name;
      name << "timefit" << iTel->first;
      TF1* telAxisFit = MakeTimeFitFunction(name.str(), telGeometry);

      axisFitsMap[iTel->first] = telAxisFit;
      axisFits.push_back(telAxisFit);
    }

    if (axisFits.empty()) { // fall back to eye fit
      TF1* axisFit = MakeTimeFitFunction(string("timefit"), fdRecGeometry);
      axisFits.push_back(axisFit);
    }
  } // end if have axis

  //  MC
  TF1* mcAxis  = NULL;
  if (fIsMC && EventBrowserConfig::Get(cfg::eShowMC)) {
    const FdGenGeometry& fdGen = eyeEvent.GetGenGeometry();
    mcAxis =
      new TF1("mctimefit", gTimeFitFunctionString.c_str(),
	      minChi, maxChi);

    fTimeFitObjects->Add(mcAxis);

    mcAxis->SetNpx(500);

    mcAxis->SetParameters(fdGen.GetRp(),
			  fdGen.GetChi0(),
			  fdGen.GetT0()/100.,
			  kFDSpeedOfLight);

    mcAxis->SetLineWidth(0);
    mcAxis->SetLineColor((*fStyleManager)->GetFDTimeMCLineColor());
  }

  // function to subtract if resiudal button is checked

  TF1* theFunction = NULL;
  if (fResiduals) {
    if (EventBrowserConfig::Get(cfg::eShowMC))
      theFunction = mcAxis;
    else
      theFunction = axisFits[0]; // FIXME used as bool & for stations. Shouldn't be used for stations.
  }

  for (unsigned int i = 0; i < pixelStatus.size(); ++i) {

    if (pixelStatus[i] >= eSDPRecPix) {

      const double chi = pixelChi[i]/degree;
      const double et  = pixelTimeErr[i];
      double t         = pixelTime[i];

      // residuals mode. Identify the right telescope axis fit
      if (theFunction != NULL) {
        const int telId = fdPix.GetTelescopeId(i);
        map<int, TF1*>::iterator it = axisFitsMap.find(telId);
        if (it != axisFitsMap.end()) {
          const double expTime = it->second->Eval(chi);
          t -= expTime;
        }
        else {
          const double expTime = theFunction->Eval(chi);
          t -= expTime;
        }
      }

      if (t > maxTime || !haveRange)
	maxTime = t;
      if (t < minTime || !haveRange)
	minTime = t;

      if (chi > maxChi || !haveRange)
	maxChi = chi;
      if (chi < minChi || !haveRange)
	minChi = chi;

      haveRange = true;

      if (pixelStatus[i] >= eTimeFitPix) {
	usedPixelTime.push_back(t);
	usedPixelTimeError.push_back(et);
	usedPixelChi.push_back(chi);
	usedPixelColor.push_back(CalculatePixelColor(fPixelColorMode == eTime
                                                     ? fdPix.GetTime(i)
                                                     : log10(fdPix.GetCharge(i))));
      }
      else if (pixelStatus[i] == eSDPRecPix) {
	rejectedPixelTime.push_back(t);
	rejectedPixelTimeError.push_back(et);
	rejectedPixelChi.push_back(chi);
      }
    }
  }

  // SD stations

  vector<double> hybridStationTime;
  vector<double> hybridStationTimeError;
  vector<double> hybridStationChi;
  vector<double> stationTime;
  vector<double> stationTimeError;
  vector<double> stationChi;
  const vector<FdRecStation>& stations = eyeEvent.GetStationVector();

  for (unsigned int iS = 0; iS < stations.size(); iS++) {

    if (!stations[iS].IsHybrid() && !fShowAllStations)
      continue;
    if (stations[iS].IsAccidental())
      continue;

    // FIXME this refers to an eye, not a telescope (which it should refer to for the NEW WAY(TM))
    const double chi = stations[iS].GetChi_i()/degree;
    double t = stations[iS].GetTimeEye();
    FdRecStation s;

    if (theFunction != NULL) {
      const double expTime = theFunction->Eval(chi);
      t -= expTime;
    }

    if (stations[iS].IsHybrid()) {
      hybridStationChi.push_back(chi);
      hybridStationTime.push_back(t);
      hybridStationTimeError.push_back(stations[iS].GetTimeError());
    }
    else {
      stationChi.push_back(chi);
      stationTime.push_back(t);
      stationTimeError.push_back(stations[iS].GetTimeError());
    }

    if (t > maxTime  || !haveRange)
      maxTime = t;
    if (t < minTime  || !haveRange)
      minTime = t;

    if (chi > maxChi  || !haveRange)
      maxChi = chi;
    if (chi < minChi  || !haveRange)
      minChi = chi;

    haveRange = true;
  } // end foreach station


  for (unsigned int i = 0; i < axisFits.size(); ++i) {
    axisFits[i]->SetRange(minChi-1., maxChi+1.);
  }
  if (mcAxis != NULL)
    mcAxis->SetRange(minChi-1., maxChi+1.);

  // everything on a 2dim histo:

  const double kBorderMargin = 0.1;
  ostringstream title;
  title << "timeBG" << fEyeId;
  const int nBins = 200;

  TH2F* backGroundHist = new TH2F(title.str().c_str(),"",
                                  nBins,minChi-(maxChi-minChi)*kBorderMargin,
                                  maxChi+(maxChi-minChi)*kBorderMargin,
                                  nBins,minTime-(maxTime-minTime)*kBorderMargin,
                                  maxTime+(maxTime-minTime)*kBorderMargin);

  fTimeFitObjects->Add(backGroundHist);
  backGroundHist->Draw();

  if (theFunction == NULL)
    backGroundHist->GetYaxis()->SetTitle("time [100 ns]");
  else
    if (EventBrowserConfig::Get(cfg::eShowMC))
      backGroundHist->GetYaxis()->SetTitle("time residual to MC [100 ns]");
    else
      backGroundHist->GetYaxis()->SetTitle("time residuals to fit [100 ns]");

  backGroundHist->GetXaxis()->SetTitle("#chi angle [deg]");

  // the fit and MC function

  if (!axisFits.empty() && !fResiduals) {
    for (unsigned int i = 0; i < axisFits.size(); ++i)
      axisFits[i]->Draw("SAME");

    TLatex* legend = new TLatex();
    fTimeFitObjects->Add(legend);

    legend->SetNDC(); legend->SetTextAlign(12); legend->SetTextSize(0.035);
    ostringstream chi2;
    chi2 << "                             "
	 << "#chi^{2}/Ndf=" << setw(7)
	 << stringFromNumber(fdRecGeometry.GetTimeFitChi2(),1) << "/"
	 << (int)fdRecGeometry.GetTimeFitNdof();
    legend->DrawLatex(0.6,0.9,chi2.str().c_str());
  }

  if (mcAxis != NULL && !fResiduals)
    mcAxis->Draw("SAME");


  // ... the Hybrid stations ...

  if (hybridStationChi.size() > 0) {
    TGraphErrors* hybridStationTimeGraph =
      new TGraphErrors(hybridStationChi.size(),
		       &hybridStationChi.front(),
		       &hybridStationTime.front(),
		       NULL,
		       &hybridStationTimeError.front());
    hybridStationTimeGraph->SetNameTitle("hybridStationTimeGraph", "hybridStationTimeGraph");
    hybridStationTimeGraph->SetMarkerStyle((*fStyleManager)->GetSDTimeFitDataType());
    hybridStationTimeGraph->SetMarkerSize((*fStyleManager)->GetSDTimeFitDataSize());
    hybridStationTimeGraph->Draw("P");

    fTimeFitObjects->Add(hybridStationTimeGraph);
  }

  if (stationChi.size() > 0) {
    TGraphErrors* stationTimeGraph = new TGraphErrors(stationChi.size(),
						      &stationChi.front(),
						      &stationTime.front(),
						      NULL,
						      &stationTimeError.front());
    stationTimeGraph->SetNameTitle("stationTimeGraph", "stationTimeGraph");
    stationTimeGraph->SetMarkerStyle((*fStyleManager)->GetSDTimeFitStationType());
    stationTimeGraph->SetMarkerSize((*fStyleManager)->GetSDTimeFitDataSize());
    stationTimeGraph->Draw("P");

    fTimeFitObjects->Add(stationTimeGraph);
  }

  // ... and finally the FD data!
  for (UInt_t i = 0; i < usedPixelChi.size(); ++i) {

    TGraphErrors* timeFitGraph = NULL;
    if (usedPixelChi.size() > 0)
      timeFitGraph = new TGraphErrors(1);
    timeFitGraph->SetPoint(0, double(usedPixelChi[i]),double(usedPixelTime[i]));
    timeFitGraph->SetPointError(0, 0.,double(usedPixelTimeError[i]));

    fTimeFitObjects->Add(timeFitGraph);
    timeFitGraph->SetMarkerStyle((*fStyleManager)->GetFDTimeFitDataType());
    timeFitGraph->SetMarkerSize((*fStyleManager)->GetFDTimeFitDataSize());
    timeFitGraph->SetMarkerColor(usedPixelColor[i]);

    timeFitGraph  ->Draw("P");
  }

  TGraphErrors* timeNoiseGraph = NULL;
  if (rejectedPixelChi.size() > 0)
    timeNoiseGraph = new TGraphErrors(rejectedPixelChi.size(),
				      &rejectedPixelChi.front(),
				      &rejectedPixelTime.front(),
				      NULL,
				      &rejectedPixelTimeError.front());

  if (timeNoiseGraph != NULL) {
    fTimeFitObjects->Add(timeNoiseGraph);
    timeNoiseGraph->SetMarkerStyle((*fStyleManager)->GetFDTimeFitNoiseType());
    timeNoiseGraph->SetMarkerSize((*fStyleManager)->GetFDTimeFitNoiseSize());
    timeNoiseGraph->SetMarkerColor(kBlack);
    timeNoiseGraph->Draw("P");
  }

  // finally the SD "axis"

  if (EventBrowserConfig::Get(cfg::eFdShowSd)) {
    const SdRecGeometry& sdRecGeometry =
      eyeEvent.GetSdRecGeometry();

    if (sdRecGeometry.GetRp() != 0.) {
      TF1* sdAxis;
      if (!fResiduals) {
	sdAxis = new TF1("sdtime",gTimeFitFunctionString.c_str(),
			 minChi,maxChi);
	sdAxis->SetParameters(sdRecGeometry.GetRp(),
			      sdRecGeometry.GetChi0(),
			      sdRecGeometry.GetT0()/100.,
			      kFDSpeedOfLight);
      }
      else {
	sdAxis = new TF1("sdtime","[0]/[3]*tan(([1]-3.14159*x/180.)/2.)+[2]-[4]/[3]*tan(([5]-3.14159*x/180.)/2.)-[6]",
			 minChi,maxChi);
	sdAxis->SetParameters(sdRecGeometry.GetRp(),
			      sdRecGeometry.GetChi0(),
			      sdRecGeometry.GetT0()/100.,
			      kFDSpeedOfLight,
			      fdRecGeometry.GetRp(),
			      fdRecGeometry.GetChi0(),
			      fdRecGeometry.GetT0()/100.);
      }

      fTimeFitObjects->Add(sdAxis);

      sdAxis->SetNpx(500);
      sdAxis->SetLineWidth(0);
      sdAxis->SetLineColor((*fStyleManager)->GetSDTimeFitLineColor());
      sdAxis->Draw("SAME");

    }
  }


  fCanvasTime->Modified();
  fCanvasTime->Update();

}


/****************************************************************************/
void
FdPlots::DrawProfile()
{

  fProfileObjects->Delete();

  fCanvasProfile->cd();
  fCanvasProfile->Clear();



  // check if eye has datat
  if (!(*fEvent)->HasEye (fEyeId)) {
    ShowExcuse(fCanvasProfile, fProfileObjects, "no profiles available");
    return;
  }

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  EFdRecLevel recLevel = eyeEvent.GetRecLevel();
  switch (fProfileMode) {
  case edEdX:
  case edEdXShowerAge:
  case eElectrons:
    DrawdEdXProfile();
    break;
  case eLightAtAperture:
    if (recLevel < eHasAperturePhotons)
      ShowExcuse(fCanvasProfile, fProfileObjects, "no aperture photons available");
    else
      DrawAperturePhotons();
    break;

  } // end switch profile mode

  fCanvasProfile->Modified();
  fCanvasProfile->Update();

}

/****************************************************************************/
void
FdPlots::DrawAperturePhotons()
{

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);

  const bool plotMC = (fIsMC && EventBrowserConfig::Get(cfg::eShowMC));
  const bool hasRec = (eyeEvent.GetRecLevel() >= eHasLongitudinalProfile);
  const bool cumulativeAperture = EventBrowserConfig::Get(cfg::eFdCumulativeAperture);

  const string legendStyle = (cumulativeAperture ? "f" : "l");

  // General concept:
  // We populate this vector of aperture light data from eye and telescopes.
  // Then, we generate a multi-graph from the total aperture light data
  // using the styles in the style file. This multi-graph of total-ap-light
  // is drawn at the end.
  vector<const FdRecApertureLight*> profiles;

  // the total aperture light
  if (fShowEyeApertureLight) {
    const FdRecApertureLight& profileEye = eyeEvent.GetFdRecApertureLight();
    if (!profileEye.GetTotalLightAtAperture().empty() &&
        !profileEye.GetTime().empty() &&
        !profileEye.GetTotalLightAtApertureError().empty()) {
      profiles.push_back(&profileEye);
    }
    if (profiles.size() == 0 && !fShowTelApertureLight) {
      ShowExcuse(fCanvasProfile, fProfileObjects, "no eye aperture photons available");
      return;
    }
  }

  // the aperture light per telescope
  //  const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);
  if (fShowTelApertureLight) {
    for (FDEvent::TelescopeDataConstIterator iTel = eyeEvent.TelescopeDataBegin(),
           end = eyeEvent.TelescopeDataEnd(); iTel != end; ++iTel) {
      const FdTelescopeData& telData = iTel->second;

      const FdRecApertureLight& profileTel = telData.GetRecApertureLight();
      if (!profileTel.GetTotalLightAtAperture().empty() &&
          !profileTel.GetTime().empty() &&
          !profileTel.GetTotalLightAtApertureError().empty()) {
        profiles.push_back(&profileTel);
      }
    }

    if (profiles.size() == 0) {
      ShowExcuse(fCanvasProfile, fProfileObjects, "no telescope aperture photons available");
      return;
    }
  } // end if fShowTelApertureLight

  if (profiles.size() == 0) {
    ShowExcuse(fCanvasProfile, fProfileObjects, "no aperture photons available");
    return;
  }

  TLegend* legLight = 0;
  TMultiGraph* graphTotal = new TMultiGraph();
  bool firstLight = true;

  fProfileObjects->Add(graphTotal);

  unsigned int profileNo = 0;
  for (vector<const FdRecApertureLight*>::const_iterator iProfile = profiles.begin();
       iProfile != profiles.end(); ++iProfile)
    {

      const FdRecApertureLight& profile = **iProfile;

      const unsigned int nTimePoints = profile.GetNumberTimePoints();

      if (firstLight) {
        legLight = new TLegend(0.645, 0.636, 0.928, 0.92, NULL, "brNDCARC");
        fProfileObjects->Add(legLight);
        legLight->SetFillColor(0);
        legLight->SetFillStyle(0);
        legLight->SetBorderSize(0);
      }


      // total detected light
      TGraphErrors* thisTotalApLightGraph = new TGraphErrors(nTimePoints,
                                                             &profile.GetTime().front(),
                                                             &profile.GetTotalLightAtAperture().front(),
                                                             NULL,
                                                             &profile.GetTotalLightAtApertureError().front());
      thisTotalApLightGraph->SetName("graphTotal");
      const unsigned int markerStyleNo = profileNo + (fShowEyeApertureLight ? 0 : 1); // skip one if not showing eye-ap-light
      thisTotalApLightGraph->SetMarkerStyle((*fStyleManager)->GetApertureDataType(markerStyleNo));
      thisTotalApLightGraph->SetMarkerSize((*fStyleManager)->GetApertureDataSize(markerStyleNo));
      thisTotalApLightGraph->SetMarkerColor((*fStyleManager)->GetTotalLightColor());
      thisTotalApLightGraph->SetTitle("");
      thisTotalApLightGraph->GetYaxis()->SetTitle("detected light [photons/m^{2}/100ns]");
      thisTotalApLightGraph->GetXaxis()->SetTitle("time slots [100 ns]");
      if (thisTotalApLightGraph->GetYaxis()->GetXmin() > 0.)
        thisTotalApLightGraph->SetMinimum(0.);

      // Note: The TMultiGraph owns the graphs!
      //fProfileObjects->Add(thisTotalApLightGraph);

      if (firstLight)
        legLight->AddEntry(thisTotalApLightGraph, "data", "p");

      graphTotal->Add(thisTotalApLightGraph, "p");
      profileNo++;
      firstLight = false;
    } // end foreach profile (eye & tel)

  // Draw the data points and the box/axis
  graphTotal->Draw("a");
  graphTotal->GetYaxis()->SetTitle("detected light [photons/m^{2}/100ns]");
  graphTotal->GetXaxis()->SetTitle("time slots [100 ns]");
  TAxis* yAxis = graphTotal->GetYaxis();
  yAxis->SetRangeUser(std::min(yAxis->GetXmin(), 0.), yAxis->GetXmax());


  firstLight = true;
  profileNo = 0;
  /////////////////////////////////////////////////////
  // Draw the reconstructed light component graphs
  for (vector<const FdRecApertureLight*>::const_iterator iProfile = profiles.begin();
       iProfile != profiles.end(); ++iProfile)
    {
      const FdRecApertureLight& profile = **iProfile;

      const unsigned int nTimePoints = profile.GetNumberTimePoints();

      // fitted light contributions

      TGraph* graphFluo, *graphCkovD, *graphCkovM, *graphCkovR, *graphMultScatt;

      if (cumulativeAperture) {
        graphFluo = new TGraph(nTimePoints,
                               &profile.GetTime().front(),
                               &profile.GetLightFluxSumVector(true,true,true,true,true,true).front());
        graphFluo->SetLineColor((*fStyleManager)->GetTotalLightColor());
        if ((hasRec || plotMC) && firstLight)
          legLight->AddEntry(graphFluo, "total light", "l");
      }
      else {
        graphFluo = new TGraph(nTimePoints,
                               &profile.GetTime().front(),
                               &profile.GetFluorLightAtAperture().front());
        graphFluo->SetLineColor((*fStyleManager)->GetFluorLightColor());
        if ((hasRec || plotMC) && firstLight)
          legLight->AddEntry(graphFluo, "fluorescence", "l");
      }

      graphFluo->SetName("graphFluo");

      graphFluo->SetLineWidth((*fStyleManager)->GetLightFitLineSize());
      fProfileObjects->Add(graphFluo);
      if (hasRec)
        graphFluo->Draw("");


      // Mie Scattered Cherenkov Light
      if (cumulativeAperture) {
        graphCkovM = new TGraph(nTimePoints,
                                &profile.GetTime().front(),
                                &profile.GetLightFluxSumVector(false,true,true,true,true,true).front());

        if (hasRec) {
          vector<double> areaX   = profile.GetTime();
          vector<double> areaY   = profile.GetLightFluxSumVector(false,true,true,true,true,true);
          vector<double> directY = profile.GetLightFluxSumVector(false,true,false,true,true,true);

          for (unsigned int i = 0; i < nTimePoints; ++i) {
            areaX.push_back(areaX[nTimePoints-i-1]);
            areaY.push_back(directY[nTimePoints-i-1]);
          }

          TPolyLine* areaCkovM = new TPolyLine(2*nTimePoints, &areaX.front(),
                                               &areaY.front(), "f");
          areaCkovM->SetFillColor((*fStyleManager)->GetMieCLightColor());
          areaCkovM->SetFillStyle((*fStyleManager)->GetMieFillStyle());
          graphCkovM->SetFillStyle((*fStyleManager)->GetMieFillStyle());
          fProfileObjects->Add(areaCkovM);
          areaCkovM->Draw("f");
        }

      } else
        graphCkovM = new TGraph(nTimePoints,
                                &profile.GetTime().front(),
                                &profile.GetMieCherLightAtAperture().front());

      graphCkovM->SetName("graphMieCherenkov");

      graphCkovM->SetLineColor((*fStyleManager)->GetMieCLightColor());
      graphCkovM->SetFillColor((*fStyleManager)->GetMieCLightColor());
      graphCkovM->SetLineWidth((*fStyleManager)->GetLightFitLineSize());
      fProfileObjects->Add(graphCkovM);
      if (hasRec)
        graphCkovM->Draw("");
      if ((hasRec || plotMC) && firstLight)
        legLight->AddEntry(graphCkovM, "Mie Cherenkov", legendStyle.c_str());


      TF1* baseLine = new TF1("baseLine", "0.", 100., 1000.);
      baseLine->SetLineWidth(0);
      baseLine->Draw("SAME");
      fProfileObjects->Add(baseLine);

      // Direct Cherenkov Light
      if (cumulativeAperture) {
        graphCkovD = new TGraph(nTimePoints,
                                &profile.GetTime().front(),
                                &profile.GetLightFluxSumVector(false,true,false,true,true,true).front());
        if (hasRec) {
          vector<double> areaX = profile.GetTime();
          vector<double> areaY = profile.GetLightFluxSumVector(false,true,false,true,true,true);
          vector<double> raylY = profile.GetLightFluxSumVector(false,false,false,true,true,true);

          for (unsigned int i = 0; i < nTimePoints; ++i) {
            areaX.push_back(areaX[nTimePoints-i-1]);
            areaY.push_back(raylY[nTimePoints-i-1]);
          }

          TPolyLine* areaCkovD = new TPolyLine(2 * nTimePoints,
                                               &areaX.front(),
                                               &areaY.front(), "f");
          areaCkovD->SetFillColor((*fStyleManager)->GetDirectCLightColor());
          areaCkovD->SetFillStyle((*fStyleManager)->GetDirectFillStyle());
          graphCkovD->SetFillStyle((*fStyleManager)->GetDirectFillStyle());
          fProfileObjects->Add(areaCkovD);
          areaCkovD->Draw("f");
        }
      }
      else
        graphCkovD = new TGraph(nTimePoints,
                                &profile.GetTime().front(),
                                &profile.GetCherLightAtAperture().front());
      graphCkovD->SetName("graphDirectCherenkov");

      graphCkovD->SetLineColor((*fStyleManager)->GetDirectCLightColor());
      graphCkovD->SetFillColor((*fStyleManager)->GetDirectCLightColor());
      graphCkovD->SetLineWidth((*fStyleManager)->GetLightFitLineSize());
      fProfileObjects->Add(graphCkovD);
      if (hasRec)
        graphCkovD->Draw("");
      if ((hasRec || plotMC) && firstLight)
        legLight->AddEntry(graphCkovD, "direct Cherenkov", legendStyle.c_str());



      // Rayleigh Scattered Cherenkov Light
      if (cumulativeAperture) {

        graphCkovR = new TGraph(nTimePoints,
                                &profile.GetTime().front(),
                                &profile.GetLightFluxSumVector(false,false,false,true,true,true).front());
        if (hasRec) {
          vector<double> areaX = profile.GetTime();
          vector<double> areaY = profile.GetLightFluxSumVector(false,false,false,true,true,true);
          vector<double> scatY = profile.GetLightFluxSumVector(false,false,false,false,true,true);
          for (unsigned int i = 0; i < nTimePoints; ++i) {
            areaX.push_back(areaX[nTimePoints-i-1]);
            areaY.push_back(scatY[nTimePoints-i-1]);
          }

          TPolyLine* areaCkovR = new TPolyLine(2 * nTimePoints,
                                               &areaX.front(), &areaY.front(),
                                               "f");
          areaCkovR->SetFillColor((*fStyleManager)->GetRayCLightColor());
          areaCkovR->SetFillStyle((*fStyleManager)->GetRayleighFillStyle());
          graphCkovR->SetFillStyle((*fStyleManager)->GetRayleighFillStyle());
          fProfileObjects->Add(areaCkovR);
          areaCkovR->Draw("f");
        }
      }
      else
        graphCkovR = new TGraph(nTimePoints,
                                &profile.GetTime().front(),
                                &profile.GetRayCherLightAtAperture().front());

      graphCkovR->SetName("graphRayleighCherenkov");

      graphCkovR->SetLineColor((*fStyleManager)->GetRayCLightColor());
      graphCkovR->SetFillColor((*fStyleManager)->GetRayCLightColor());
      graphCkovR->SetLineWidth((*fStyleManager)->GetLightFitLineSize());
      fProfileObjects->Add(graphCkovR);
      if (hasRec)
        graphCkovR->Draw("");
      if ((hasRec || plotMC) && firstLight)
        legLight->AddEntry(graphCkovR, "Rayleigh Cherenkov", legendStyle.c_str());

      if (profile.HasMultipleScatteredLight()) {
        // Multiple scattered light
        graphMultScatt = new TGraph(nTimePoints,
                                    &profile.GetTime().front(),
                                    &profile.GetLightFluxSumVector(false,false,
                                                                   false,false,
                                                                   true,true).front());

        graphMultScatt->SetName("graphMultiplyScattered");

        if (cumulativeAperture) {

          if (hasRec) {
            vector<double> areaX = profile.GetTime();
            vector<double> areaY = profile.GetLightFluxSumVector(false,false,false,false,true,true);
            areaX.push_back(areaX.back());
            areaX.push_back(areaX.front());
            areaY.push_back(0);
            areaY.push_back(0);

            TPolyLine* areaMultSc = new TPolyLine(nTimePoints+2,
                                                  &areaX.front(), &areaY.front(),
                                                  "f");
            areaMultSc->SetFillColor((*fStyleManager)->GetMultScattLightColor());
            areaMultSc->SetFillStyle((*fStyleManager)->GetMultScattFillStyle());
            graphMultScatt->SetFillStyle((*fStyleManager)->GetMultScattFillStyle());
            fProfileObjects->Add(areaMultSc);
            areaMultSc->Draw("f");
          }
        }

        graphMultScatt->SetLineColor((*fStyleManager)->GetMultScattLightColor());
        graphMultScatt->SetFillColor((*fStyleManager)->GetMultScattLightColor());
        graphMultScatt->SetLineWidth((*fStyleManager)->GetLightFitLineSize());
        fProfileObjects->Add(graphMultScatt);
        if (hasRec)
          graphMultScatt->Draw("");
        if ((hasRec || plotMC) && firstLight)
          legLight->AddEntry(graphMultScatt, "multiple scattered", legendStyle.c_str());
      }

//#warning this might sometimes only draw part of the aerosoles ...
      if (firstLight && EventBrowserConfig::Get(cfg::eAtmoShowAerosols))
        SuperimposeAerosols(fCanvasProfile, profile.GetTime());

      firstLight = false;

      if (fUseLCEfficiency) {
        const vector<Double_t>& lceff = profile.GetFluorLightCollEfficiency();
        if (lceff.size() != 0) {
          const vector<Double_t>& telTime = profile.GetTime();
          TGraph lceffGraph(lceff.size(), &telTime.front(), &lceff.front());

          const FdRecApertureLight& eyeApL = eyeEvent.GetFdRecApertureLight();
          const unsigned int nEyeTimePoints = eyeApL.GetTime().size();
          const vector<Double_t>& eyeTime = eyeApL.GetTime();
          vector<Double_t> eyeFlux = eyeApL.GetLightFluxSumVector(true,true,true,true,true,true);
          vector<Double_t> corrFlux(nEyeTimePoints);
          for (unsigned int i = 0; i < nEyeTimePoints; ++i) {
            corrFlux[i] = eyeFlux[i] * lceffGraph.Eval(eyeTime[i]);
          }

          TGraph* graph = new TGraph(nEyeTimePoints,
                                     &eyeTime.front(),
                                     &corrFlux.front());
          graph->SetLineColor(kRed);
          ostringstream telname;
          telname << "totalLightEyeTimesLCEff" << profileNo+1;
          graph->SetNameTitle(telname.str().c_str(), telname.str().c_str());
          graph->SetLineColor((*fStyleManager)->GetEyeLightWithLCEffColor()
                              + profileNo*2 * (profileNo%2 ? 1 : -1));
          graphTotal->Add(graph, "l");

          vector<Double_t> corrTelFlux(nTimePoints);
          vector<Double_t> telFlux = profile.GetTotalLightAtAperture();
          for (unsigned int i = 0; i < nTimePoints; ++i) {
            corrTelFlux[i] = lceff[i] < 1.e-9 ? 0. : telFlux[i] / lceff[i];
          }
          TGraph* const telgraph = new TGraph(nTimePoints,
                                              &telTime.front(),
                                              &corrTelFlux.front());
          telgraph->SetLineColor((*fStyleManager)->GetTelLightWithLCEffColor()
                                 + profileNo * (profileNo%2 ? 1 : -1));
          ostringstream name;
          name << "totalLightTelDivLCEff" << profileNo+1;
          telgraph->SetNameTitle(name.str().c_str(), name.str().c_str());
          graphTotal->Add(telgraph, "l");
        }
      } // if using lc-eff
      profileNo++;
    } // loop eye and tel reco profiles

  // possibly plot MC info
  if (plotMC) {

    vector<const FdGenApertureLight*> profilesGen;

    // the total gen aperture light
    const FdGenApertureLight& profileEye = eyeEvent.GetGenApertureLight();
    if (profileEye.GetNumberTimePoints() > 0)
      profilesGen.push_back(&profileEye);

    // the gen aperture light per telescope
    for (FDEvent::TelescopeDataConstIterator iTel = eyeEvent.TelescopeDataBegin(),
           end = eyeEvent.TelescopeDataEnd(); iTel != end; ++iTel) {
      const FdTelescopeData& telData = iTel->second;
      const FdGenApertureLight& profileTel = telData.GetGenApertureLight();
      if (profileTel.GetNumberTimePoints() > 0)
	profilesGen.push_back(&profileTel);
    }

    for (vector<const FdGenApertureLight*>::const_iterator iProfile = profilesGen.begin();
	 iProfile != profilesGen.end(); ++iProfile) {

      const FdGenApertureLight& genProfile = **iProfile;
      const int genSize = genProfile.GetNumberTimePoints();

      const vector<double>& fluo  = genProfile.GetFluorLightAtAperture();
      const vector<double>& dirC  = genProfile.GetCherLightAtAperture();
      const vector<double>& mieC  = genProfile.GetMieCherLightAtAperture();
      const vector<double>& rayC  = genProfile.GetRayCherLightAtAperture();
#ifdef PRIM_CHER
      const vector<double>& dirCPrim  = genProfile.GetCherPrimaryLightAtAperture();
      const vector<double>& mieCPrim  = genProfile.GetMieCherPrimaryLightAtAperture();
      const vector<double>& rayCPrim  = genProfile.GetRayCherPrimaryLightAtAperture();
#endif
      const vector<double>& total = genProfile.GetTotalLightAtAperture();
      const vector<double>& time  = genProfile.GetTime();

      vector<double> fudgedTime;
      for (unsigned int j = 0; j < time.size(); ++j)
        fudgedTime.push_back(time[j] + 0.5);

      if (!legLight && firstLight) { // we still have no legend
        legLight = new TLegend(0.645, 0.636, 0.928, 0.92, NULL, "brNDCARC");
        fProfileObjects->Add(legLight);
        legLight->SetFillColor(0);
        legLight->SetFillStyle(0);
        legLight->SetBorderSize(0);
      }


      // TOTAL SIM PHOTONS
      TGraph *genTotal;
      if (cumulativeAperture) {
        genTotal = new TGraph(genSize, &fudgedTime.front(), &total.front());
        genTotal->SetLineColor((*fStyleManager)->GetTotalLightColor());
      }
      else {
        genTotal = new TGraph(genSize, &fudgedTime.front(), &fluo.front());
        genTotal->SetLineColor((*fStyleManager)->GetFluorLightColor());
      }
      genTotal->SetName("graphGenTotal");

      genTotal->SetLineWidth((*fStyleManager)->GetLightMCLineSize());
      genTotal->SetLineStyle(2);
      fProfileObjects->Add(genTotal);
      if (firstLight) {
        genTotal->Draw("A");
      } else {
        genTotal->Draw("");
      }

      if (mieC.size() > 0) {
        TGraph *genCkovM;
        if (cumulativeAperture)
          genCkovM = new TGraph(genSize, &fudgedTime.front(),
                                &genProfile.GetLightFluxSumVector(false,true,true,true,true,true).front());
        else
          genCkovM = new TGraph(genSize, &time.front(), &mieC.front());
        genCkovM->SetName("graphGenMieCherenkov");
        genCkovM->SetLineColor((*fStyleManager)->GetMieCLightColor());
        genCkovM->SetLineWidth((*fStyleManager)->GetLightMCLineSize());
        genCkovM->SetLineStyle(2);
        fProfileObjects->Add(genCkovM);
        genCkovM->Draw("");
      }

      if (dirC.size() > 0) {
        TGraph *genCkovD;
        if (cumulativeAperture)
          genCkovD = new TGraph(genSize , &fudgedTime.front(),
                                &genProfile.GetLightFluxSumVector(false,true,false,true,true,true).front());
        else
          genCkovD = new TGraph(genSize, &fudgedTime.front(), &dirC.front());

        genCkovD->SetName("graphGenDirectCherenkov");
        genCkovD->SetLineColor((*fStyleManager)->GetDirectCLightColor());
        genCkovD->SetLineWidth((*fStyleManager)->GetLightMCLineSize());
        genCkovD->SetLineStyle(2);
        fProfileObjects->Add(genCkovD);
        genCkovD->Draw("");
      }

      if (rayC.size() > 0) {
        TGraph *genCkovR = new TGraphErrors (genSize, &fudgedTime.front(), &rayC.front());
        genCkovR->SetName("graphGenRayleighCherenkov");
        genCkovR->SetLineColor((*fStyleManager)->GetRayCLightColor());
        genCkovR->SetLineWidth((*fStyleManager)->GetLightMCLineSize());
        genCkovR->SetLineStyle(2);
        fProfileObjects->Add(genCkovR);
        genCkovR->Draw("");
      }

#ifdef PRIM_CHER
      if (mieCPrim.size() > 0) {
        TGraph *genCkovMPrim;
        if (cumulativeAperture)
          genCkovMPrim = new TGraph(genSize, &time.front(),
                                    &genProfile.GetLightFluxSumVector(false,true,true,true,true,true).front());
        else
          genCkovMPrim = new TGraph (genSize, &time.front(), &mieCPrim.front());
        genCkovMPrim->SetName("graphGenPrimaryMieCherenkov");
        genCkovMPrim->SetLineColor((*fStyleManager)->GetMieCLightColor());
        genCkovMPrim->SetLineWidth((*fStyleManager)->GetLightMCLineSize());
        genCkovMPrim->SetLineStyle(2);
        fProfileObjects->Add(genCkovMPrim);
        genCkovMPrim->Draw("");
        if (firstLight)
          legLight->AddEntry(genCkovMPrim, "primary Mie", "l");
      }

      if (dirCPrim.size() > 0) {
        TGraph *genCkovDPrim;
        if (cumulativeAperture)
          genCkovDPrim =
            new TGraph(genSize, &time.front(),
                       &genProfile.GetLightFluxSumVector(false,false,false,
                                                         false,false,false,
                                                         true,false,true).front());
        else
          genCkovDPrim = new TGraph(genSize, &time.front(), &dirCPrim.front());
        genCkovDPrim->SetName("graphGenPrimaryDirectCherenkov");
        genCkovDPrim->SetLineColor((*fStyleManager)->GetDirectCLightColor());
        genCkovDPrim->SetLineWidth((*fStyleManager)->GetLightMCLineSize());
        genCkovDPrim->SetLineStyle(2);
        fProfileObjects->Add(genCkovDPrim);
        genCkovDPrim->Draw("");
        if (firstLight)
          legLight->AddEntry(genCkovDPrim, "primary direct", "l");
      }

      if (rayCPrim.size() > 0) {
        TGraph *genCkovRPrim = new TGraphErrors(genSize,
                                                &time.front(),
                                                &rayCPrim.front());
        genCkovRPrim->SetName("graphGenPrimaryRayleighCherenkov");
        genCkovRPrim->SetLineColor((*fStyleManager)->GetRayCLightColor());
        genCkovRPrim->SetLineWidth((*fStyleManager)->GetLightMCLineSize());
        genCkovRPrim->SetLineStyle(2);
        fProfileObjects->Add (genCkovRPrim);
        genCkovRPrim->Draw("");
        if (firstLight)
          legLight->AddEntry(genCkovRPrim, "primary Rayleigh", "l");
      }
#endif

      firstLight = false;

    } // loop generated light profiles
  } // end of MC

  // draw data another time to appear on top
  graphTotal->Draw("P");

  // draw legend
  if (legLight)
    legLight->Draw();

}


/****************************************************************************/
void
FdPlots::DrawdEdXProfile()
{

  const FDEvent& fdEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecShower& shower = fdEvent.GetFdRecShower();
  const GenShower& genShower = (*fEvent)->GetGenShower();

  if (shower.GetDepth().empty() ||
      shower.GetEnergyDeposit().empty() ||
      fdEvent.GetRecLevel() < eHasGHParameters) {
    ShowExcuse(fCanvasProfile, fProfileObjects, "no profile available");
    return;
  }

  const bool useAge = fProfdEdXShowerAgeButton->IsDown();
  const bool plotMC = (fIsMC && EventBrowserConfig::Get(cfg::eShowMC) && !fResiduals);
  const double scaleFactor = fProfileMode == eElectrons ?
    1./kdEdXPerElectron : 1.;

  // ---- data and GH fit

  fGaisserHillas.SetShowerParameters(shower);
  fGaisserHillas.SetXisAge(useAge);
  fGaisserHillas.SetScaleFactor(scaleFactor);

  const vector<double>& depth = shower.GetDepth();
  const vector<double> age = shower.GetShowerAge();
  const double firstDepth = useAge ?
    fmin(0.7, age.front()) : fmin(300.1, depth.front()-50.);
  const double lastDepth = useAge ?
    fmax(1.3, age.back()) : fmax(1299.99,depth.back()+50.);

  ostringstream funcName;
  funcName << "f" << fEyeId;
  TF1* ghFunction = new TF1(funcName.str().c_str(),&fGaisserHillas,
                            firstDepth, lastDepth, 0);
  ghFunction->SetNpx(1000);
  ghFunction->SetLineColor((*fStyleManager)->GetProfileFitLineColor());
  ghFunction->SetLineWidth(1);
  fProfileObjects->Add(ghFunction);

  LongitudinalProfile profile;
  const LongitudinalProfile::EProfXaxis xAxisType = useAge ?
    LongitudinalProfile::eAge : LongitudinalProfile::eDepth;
  const LongitudinalProfile::EProfYaxis yAxisType =
    (fProfileMode == edEdX || fProfileMode == edEdXShowerAge) ?
    LongitudinalProfile::edEdX : LongitudinalProfile::eNe;
  const LongitudinalProfile::EProfResidual residualType =
    !fResiduals ? LongitudinalProfile::eNone :
    plotMC ? LongitudinalProfile::eMC : LongitudinalProfile::eFit;

  profile.SetProfile(fdEvent, genShower, xAxisType, yAxisType,
                     residualType, ghFunction);

  TGraphErrors* profileGraph = profile.GetGraph(fRebinField->GetIntNumber());
  profileGraph->SetMarkerStyle((*fStyleManager)->GetProfileDataType());
  profileGraph->SetMarkerSize((*fStyleManager)->GetProfileDataSize());
  fProfileObjects->Add(profileGraph);

  TGraphErrors* dataMax = NULL;
  if ((*fStyleManager)->ShowFittedXmax() && !useAge) {
    const double x = shower.GetXmax();
    const double y = shower.GetdEdXmax()*scaleFactor;
    const double xErr = shower.GetXmaxError();
    const double yErr = shower.GetdEdXmaxError()*scaleFactor;
    dataMax = new TGraphErrors(1,&x,&y,&xErr,&yErr);
    dataMax->SetTitle("dataMax");
    dataMax->SetLineWidth(2);
    dataMax->SetMarkerStyle(20);
    dataMax->SetMarkerColor((*fStyleManager)->GetProfileFitLineColor());
    dataMax->SetLineColor((*fStyleManager)->GetProfileFitLineColor());
    dataMax->SetMarkerSize((*fStyleManager)->GetFittedXmaxSize());
    fProfileObjects->Add(dataMax);
  }

  //----------  MC
  TGraph* mcdEdXGraph = NULL;
  TGraph* mcMax = NULL;

  if (plotMC) {
    vector<double> xAxis = useAge ?
      genShower.GetShowerAge() : genShower.GetDepth();
    mcdEdXGraph  = new TGraph(xAxis.size(), &xAxis.front(),
                              &genShower.GetEnergyDeposit().front());
    mcdEdXGraph->SetName("mcdEdXGraph");
    mcdEdXGraph->SetLineColor((*fStyleManager)->GetGeneratedProfileColor());

    if ((*fStyleManager)->ShowGeneratedXmax() && !useAge) {
      const double x = useAge?1.:genShower.GetXmaxInterpolated();
      const double y = genShower.GetdEdXmax()*scaleFactor;
      mcMax= new TGraph(1,&x,&y);
      mcMax->SetName("mcMax");
      mcMax->SetMarkerStyle(20);
      mcMax->SetMarkerColor((*fStyleManager)->GetGeneratedProfileColor());
      mcMax->SetLineColor((*fStyleManager)->GetGeneratedProfileColor());
      mcMax->SetMarkerSize((*fStyleManager)->GetGeneratedXmaxSize());
      fProfileObjects->Add(mcMax);
    }
  }

  // finally, draw everything

  const double frameX1 = firstDepth;
  const double frameX2 = lastDepth;
  const double frameY1 = fmin(0.,profileGraph->GetYaxis()->GetXmin());
  const double frameY2 = profileGraph->GetYaxis()->GetXmax();

  TH1F* tmpHist = fCanvasProfile->DrawFrame(frameX1,frameY1,frameX2,frameY2);
  if (fProfileMode == eElectrons)
    tmpHist->GetYaxis()->SetTitle("N_{e}");
  else
    tmpHist->GetYaxis()->SetTitle("dE/dX [PeV/(g/cm^{2})]");
  if (useAge)
    tmpHist->GetXaxis()->SetTitle("shower age");
  else
    tmpHist->GetXaxis()->SetTitle("slant depth [g/cm^{2}]");

  if (!fResiduals && shower.HasProfileCorrelations())
    DrawGHErrorBand(frameX1,frameX2);

  if (EventBrowserConfig::Get(cfg::eAtmoShowAerosols))
    SuperimposeAerosols(fCanvasProfile, useAge?age:depth);

  if (fShowViewableFOV)
    SuperimposeViewableFOV(fCanvasProfile, useAge);

  profileGraph->Draw("P");

  if (!fResiduals) {
    ghFunction->Draw("SAME");
    if (mcMax)
      mcMax->Draw("p");
    if (dataMax)
      dataMax->Draw("p");
    if (mcdEdXGraph)
      mcdEdXGraph->Draw("L");
  }

  // legends
  if ((*fStyleManager)->DrawProfileFitLegend()) {
    TLegend* legLight = new TLegend(0.659,0.662,0.942,0.8377,NULL,"brNDCARC");
    legLight->SetFillColor(0);
    legLight->SetBorderSize(0);
    if (mcdEdXGraph != NULL)
      legLight->AddEntry(mcdEdXGraph, "generated", "l");
    legLight->AddEntry(profileGraph, "reconstructed", "p");
    legLight->AddEntry(ghFunction, "Gaisser-Hillas fit", "l");
    legLight->Draw();
    fProfileObjects->Add(legLight);
  }

  if (!fShowViewableFOV) {
    TLatex* legend = new TLatex();
    legend->SetNDC(); legend->SetTextAlign(12); legend->SetTextSize(0.035);
    ostringstream chi2;
    chi2 << "#chi^{2}/Ndf=" << setw(7)
         << stringFromNumber(shower.GetGHChi2(),1) << "/"
         << (int)shower.GetGHNdf();
    legend->DrawLatex(0.7,0.9,chi2.str().c_str());
    fProfileObjects->Add(legend);
  }
}


/*****************************************************************************/
void
FdPlots::SelectPixel(Int_t event, Int_t px, Int_t py,
                     TObject* /*sel*/)
{

  // Actions in reponse to mouse button events.

  TCanvas* c = (TCanvas*) gTQSender;
  TPad* pad = (TPad*) c->GetSelectedPad();

  if ((event == kButton1Down) ||
      (event == kButton1Double)) {

    Double_t ClickPhi = pad->AbsPixeltoX(px);
    Double_t ClickOmega = pad->AbsPixeltoY(py);
    ClickPhi = pad->PadtoX(ClickPhi);
    ClickOmega = pad->PadtoY(ClickOmega);

    const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
    const FdRecPixel& pixRec = eyeEvent.GetFdRecPixel();

    const Detector& detector = (*fEvent)->GetDetector();
    const TBits& telBits = fShowTelsInDAQ ?
      detector.GetMirrorsInDAQ(fEyeId) :
      eyeEvent.GetMirrorsInEvent();

    Double_t phiMin,phiMax;
    Double_t omegaMin,omegaMax;
    const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);
    eye.GetMinMaxPhi(telBits, phiMin, phiMax);
    eye.GetMinMaxOmega(telBits, omegaMin, omegaMax);

    if(fShowEyeView) {
      phiMin= 180.-phiMin;
      phiMax=180.-phiMax;

      if(phiMin> phiMax) {
	Double_t tempPhi=phiMin;
	phiMin=phiMax;
	phiMax=tempPhi;
      }
    }

    if(ClickPhi>=phiMin && ClickPhi <= phiMax &&
       ClickOmega>=omegaMin && ClickOmega<=omegaMax) {

      //      Double_t PixOmega=0.; // unused
      //       Double_t PixPhi=0.; // unused
      Double_t DeltaOmega= 180.;//abs(omegaMax-omegaMin);
      Double_t DeltaPhi= 180.;//abs(phiMax - phiMin);
      Int_t SelectedPixel=0;
      const Double_t kMaxDeltaOmega=1.5;
      const Double_t kMaxDeltaPhi=1.5;

      UInt_t nTel = eye.GetNumberOfMirrors();
      for (UInt_t iTel=0; iTel<nTel; iTel++) {

	const UInt_t telId = iTel+1;

	if (telBits.TestBitNumber(telId)) {
	  const TelescopeGeometry& tel = eye.GetTelescope(telId);
          const TString telPointingId = (*fEvent)->GetDetector().GetPointingId(fEyeId, telId);
	  UInt_t nPix = tel.GetNumberOfPixels();
	  for (unsigned int iPix = 0; iPix < nPix; ++iPix) {

	    const Int_t jPix = iTel * nPix + iPix;

	    const double omega = tel.GetPixelOmega(iPix, telPointingId);
	    double phi = tel.GetPixelPhi(iPix, telPointingId);

	    if(fShowEyeView)
	      phi=180.-phi;

	    if(fabs(omega-ClickOmega) < DeltaOmega &&
	       fabs(phi-ClickPhi) < DeltaPhi &&
	       fabs(omega-ClickOmega)< kMaxDeltaOmega &&
	       fabs(phi-ClickPhi) < kMaxDeltaPhi) {
	      DeltaOmega=fabs(omega-ClickOmega);
              //	      PixOmega=omega;  // unused
	      DeltaPhi=fabs(phi-ClickPhi);
              //	      PixPhi=phi; // unused
	      SelectedPixel=jPix;
	    }
	  }
	}
      }

      const Int_t nPix = pixRec.GetNumberOfPixels();
      for (int pix = 0; pix < nPix; ++pix){
	UShort_t idPix=pixRec.GetID(pix);

	if (idPix == SelectedPixel && pixRec.HasADCTrace(pix)) {
	  fEventPixelTab->SetTab(1);
	  DrawADCTrace(pix);
	  DrawSelectedPixelMarker(pix);
	}
      }

    } // angles inside range
  } // found mouseclick in pad
} // end select pixels



/*********************************************************************************/
void
FdPlots::DrawADCTrace(int currRecPixel)
{
  fTracePlotObjects->Delete();

  fCanvasPixels->cd();
  fCanvasPixels->Clear();

  if (!(*fEvent)->HasEye (fEyeId)) {
    TLatex* legend = new TLatex();
    fTracePlotObjects->Add(legend);
    legend->DrawLatex(0.4, 0.5, "no data");
    fCanvasPixels->Modified();
    fCanvasPixels->Update();
    return;
  }

  const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);

  string histTitle = "pixelHist" + stringFromNumber(fEyeId);
  string spotRecHistTitle = "SpotRecPixelHist" + stringFromNumber(fEyeId);
  string pulseTitle="pulseHist" + stringFromNumber(fEyeId);

  const int spotRecTraceColor = (*fStyleManager)->GetSpotRecTraceColor();
  bool hasSpotRecTraces=false;


  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecPixel& pixRec = eyeEvent.GetFdRecPixel();

  const int nTracePixel = pixRec.GetNumberOfTracePixels();
  const int nPixel = pixRec.GetNumberOfPixels();

  static TLatex* pixelLegend = 0;
  TH1F* pixelHist = 0;
  TH1F* spotRecPixelHist = 0;
  TH1F* pixelPulse = 0;

  delete pixelLegend;
  pixelLegend=new TLatex();
  pixelLegend->SetNDC();
  pixelLegend->SetTextAlign(12);
  pixelLegend->SetTextSize(0.035);

  if (nTracePixel>0) {

    if (currRecPixel<0) {
      char title[]="sum of photon traces";
      const UInt_t tmax=5000;
      vector<vector<double> > sumTrace;
      vector<vector<double> > spotRecSumTrace;
      vector<double> emptyVector(tmax,0.);

      const UInt_t nTel = eye.GetNumberOfMirrors();
      for (UInt_t iTel=0; iTel<nTel; iTel++) {
	sumTrace.push_back(emptyVector);
	spotRecSumTrace.push_back(emptyVector);
      }

      int iFirst=99999, iLast=0;

      for (int k=0; k<nPixel; ++k) {

	if (pixRec.GetStatus(k) >= ePulseRecPix && pixRec.HasADCTrace(k)) {

	  const vector<double>& trace = pixRec.GetTrace(k);

	  vector<double> spotRecTrace;
	  if (pixRec.HasSpotRecADCTrace(k)) {
	    spotRecTrace=pixRec.GetSpotRecTrace(k);
	    hasSpotRecTraces=true;
	  }

	  const UInt_t iTel = pixRec.GetTelescopeId(k);
	  const UInt_t iOff = UInt_t(eyeEvent.GetMirrorTimeOffset(iTel)/100);

	  const UInt_t i1 = pixRec.GetPulseStart(k);
	  const UInt_t i2 = pixRec.GetPulseStop(k);
	  if (i1!=i2) {
	    for (UInt_t i = i1; (i <= i2&&(i+iOff<tmax)); ++i) {
	      sumTrace[iTel-1][i+iOff]+=trace[i];
	      if(spotRecTrace.size() > i)
		spotRecSumTrace[iTel-1][i+iOff]+=spotRecTrace[i];;

	    }
	    if (i1+iOff<(UInt_t) iFirst && i1+iOff<tmax)
	      iFirst=i1+iOff;
	    if (i2+iOff>(UInt_t) iLast && i2+iOff<tmax)
	      iLast=i2+iOff;
	  }
	}
      }

      if (iLast>iFirst) {
	pixelHist = new TH1F(histTitle.c_str(), title, iLast-iFirst,
			     (double)iFirst, (double)iLast);
	spotRecPixelHist = new TH1F(spotRecHistTitle.c_str(), title,
				    iLast-iFirst, (double)iFirst,
				    (double)iLast);

	for (int k=iFirst;k<iLast; ++k) {
	  double telCount=0.;
	  double sum=0.;
	  double spotRecSum=0.;
	  for (unsigned int tel=0;tel<nTel; tel++) {
	    if (sumTrace[tel][k] !=0.) {
	      telCount+=1.;
	      sum+=sumTrace[tel][k];
	    }
	    if (spotRecSumTrace[tel][k] !=0.) {
	      telCount+=1.;
	      spotRecSum+=spotRecSumTrace[tel][k];
	    }

	  }

	  if(telCount>0.) {
	    sum/=telCount;
	    spotRecSum/=telCount;
	    pixelHist->SetBinContent(k-iFirst+1,sum);
	    spotRecPixelHist->SetBinContent(k-iFirst+1,spotRecSum);
	  }
	}

	pixelHist->Draw();
	if(hasSpotRecTraces) {
	  spotRecPixelHist->SetLineColor(spotRecTraceColor);
	  spotRecPixelHist->Draw("same");
	}

      }
      else
	pixelLegend->DrawLatex(0.4,0.5,"No trace data available");

    } // end trace-sum
    else {

      const UShort_t iEye = fEyeId;
      const UShort_t iTel = pixRec.GetTelescopeId(currRecPixel);
      const UShort_t iPix = pixRec.GetPixelId(currRecPixel);

      const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(iEye);
      const TelescopeGeometry& tel = eye.GetTelescope(iTel);
      const UInt_t nFADCBins = tel.GetFADCSize();
      const Double_t fadcBinWidth = tel.GetFADCBinning();
      const double conversionFactor = fadcBinWidth/100.;
      const double telescopeTimeOffset = eyeEvent.GetMirrorTimeOffset(iTel)/100.;

      if (pixRec.HasADCTrace(currRecPixel)) {

	string title = "Eye " + stringFromNumber(iEye) +
	  " Mirror " + stringFromNumber(iTel) +
	  " Pixel " + stringFromNumber(iPix);

	pixelHist = new TH1F(histTitle.c_str(), title.c_str(),
			     nFADCBins,0.,conversionFactor*nFADCBins);
	spotRecPixelHist = new TH1F(spotRecHistTitle.c_str(),title.c_str(),
				    nFADCBins,0.,conversionFactor*nFADCBins);
	pixelPulse = new TH1F(pulseTitle.c_str(),title.c_str(),
			      nFADCBins,0.,conversionFactor*nFADCBins);

	pixelHist->Draw();

	static TGraphErrors* pixLimits=NULL;
	static TLine* pulseTime=NULL;
	static TLine* pixelThreshold = 0;

	const vector<double>& trace=pixRec.GetTrace(currRecPixel);

	vector<double> spotRecTrace;
	if (pixRec.HasSpotRecADCTrace(currRecPixel))
	  spotRecTrace=pixRec.GetSpotRecTrace(currRecPixel);

	for (unsigned int i = 0; i < trace.size(); ++i) {
	  pixelHist->SetBinContent(i+1,trace[i]);
	  pixelPulse->SetBinContent(i+1,(trace[i]));
	}

	for (unsigned int i = 0; i < spotRecTrace.size(); ++i)
	  spotRecPixelHist->SetBinContent(i+1,spotRecTrace[i]);

	const int color = GetPixelColor(currRecPixel);

	pixelHist->SetLineColor(color);
	spotRecPixelHist->SetLineColor(spotRecTraceColor);
	pixelPulse->SetLineColor(color);
	pixelPulse->SetFillColor(color);

	if(pixRec.HasSpotRecADCTrace(currRecPixel))
	  spotRecPixelHist->Draw("same");

	double traceMax=pixelHist->GetMaximum();
	if(pixRec.GetStatus(currRecPixel)>=ePulseRecPix) {
	  const double meanTimeError=pixRec.GetTimeErr(currRecPixel);
	  const double x1=(double) pixRec.GetPulseStart(currRecPixel)*conversionFactor;
	  const double x2=pixRec.GetTime(currRecPixel)-telescopeTimeOffset;
	  const double x3=(double) pixRec.GetPulseStop(currRecPixel)*conversionFactor;
	  //int threshold = pixRec.GetThreshold(currRecPixel);

	  const double limitsX[1]={x2};
	  const double limitsY[1]={traceMax*1.03};
	  const double limitsEY[1]={0.};
	  const double limitsEX[1]={meanTimeError};

	  pixelHist->GetXaxis()->SetRangeUser(x1-3.*(x2-x1),x3+3.*(x3-x2));
	  pixelPulse->GetXaxis()->SetRangeUser(x1, x3);
	  pixelPulse->Draw("same");

	  delete pixLimits;
	  delete pulseTime;
	  delete pixelThreshold;

	  pixLimits= new TGraphErrors(1,limitsX,limitsY,limitsEX,limitsEY);
	  pixLimits->SetMarkerStyle(20);
	  if ((*fStyleManager)->FdColorPalette()) {
	    pixLimits->SetMarkerColor(kRed);
	    pixLimits->SetLineColor(kRed);
	  }
	  pixLimits->SetMarkerSize(1);
	  pixLimits->Draw("p");

	  pulseTime=
	    new TLine(limitsX[0],
		      -(2.*pixRec.GetRMS(currRecPixel)),limitsX[0],limitsY[0]);
	  pulseTime->SetLineColor(kBlack);
	  pulseTime->SetLineStyle(7);
	  pulseTime->SetLineWidth(1);
	  pulseTime->Draw("same");

	  if (eyeEvent.GetRecLevel() >= eHasAxis) {
	    const FdRecGeometry& fdRecGeometry =
	      eyeEvent.GetFdRecGeometry();
	    TF1 axis("timefit",gTimeFitFunctionString.c_str(),
		     -500,500);
	    axis.SetParameters(fdRecGeometry.GetRp(),
			       fdRecGeometry.GetChi0(),
			       fdRecGeometry.GetT0()/100.,
			       kFDSpeedOfLight);
	    const double time=
	      axis.Eval(pixRec.GetChi(currRecPixel)/degree)-telescopeTimeOffset;
	    TMarker* axisFitMarker=new TMarker(time,0, 22);
	    fTracePlotObjects->Add(axisFitMarker);
	    axisFitMarker->SetMarkerColor(kRed);
	    axisFitMarker->SetMarkerSize(1.2);
	    axisFitMarker->Draw("same");
	  }


	  if (EventBrowserConfig::Get(cfg::eFdShowSd)) {
	    const SdRecGeometry& sdRecGeometry =
	      eyeEvent.GetSdRecGeometry();

	    if (sdRecGeometry.GetRp() != 0.) {
	      TF1 sdAxis("sdtime",gTimeFitFunctionString.c_str(),
			 -500,500);
	      sdAxis.SetParameters(sdRecGeometry.GetRp(),
				   sdRecGeometry.GetChi0(),
				   sdRecGeometry.GetT0()/100.,
				   kFDSpeedOfLight);

	      const double time=
		sdAxis.Eval(pixRec.GetChi(currRecPixel)/degree)-telescopeTimeOffset;
	      TMarker* SDaxisFitMarker=new TMarker(time,0, 22);
	      fTracePlotObjects->Add(SDaxisFitMarker);
	      SDaxisFitMarker->SetMarkerColor(1); //black
	      SDaxisFitMarker->SetMarkerSize(1.2);
	      SDaxisFitMarker->Draw("same");
	    }
	  } // if shower SD
	} // PixelStatus is pulsed

	if (EventBrowserConfig::Get(cfg::eShowMC)) {
	  if (pixRec.HasSimTrace(currRecPixel, FdApertureLight::eFluorescence)) {
	    const int simTraceOffset = pixRec.GetSimTraceOffset(currRecPixel);
	    const vector<double> simtrace =
	      pixRec.GetSimTrace(currRecPixel, FdApertureLight::eFluorescence);
	    const int simTraceSize = simtrace.size();
	    const string hName = "Eye_" + stringFromNumber(iEye) +
	      "_Mirror_" + stringFromNumber(iTel) +
	      "_Pixel_" + stringFromNumber(iPix) + "_fluo";
	    TH1F* simpixelHist = new TH1F(hName.c_str(), hName.c_str(),
					  simTraceSize,
					  simTraceOffset*conversionFactor,
					  (simTraceOffset+simTraceSize)*
					  conversionFactor);
	    for (int i = 0; i < simTraceSize; ++i)
	      simpixelHist->SetBinContent(i+1, simtrace[i]);
	    simpixelHist->SetLineColor(1);
	    simpixelHist->SetLineStyle(5);
	    simpixelHist->Draw("same");
	    fTracePlotObjects->Add(simpixelHist);
	  } // fluo
	  if (pixRec.HasSimTrace(currRecPixel, FdApertureLight::eDirect)) {
	    const int simTraceOffset = pixRec.GetSimTraceOffset(currRecPixel);
	    const vector<double> simtrace =
	      pixRec.GetSimTrace(currRecPixel, FdApertureLight::eDirect);
	    const int simTraceSize = simtrace.size();
	    const string hName = "Eye_" + stringFromNumber(iEye) +
	      "_Mirror_" + stringFromNumber(iTel) +
	      "_Pixel_" + stringFromNumber(iPix) + "_direct";
	    TH1F* simpixelHist = new TH1F(hName.c_str(), hName.c_str(),
					  simTraceSize,
					  simTraceOffset*conversionFactor,
					  (simTraceOffset+simTraceSize)*
					  conversionFactor);
	    for (int i = 0; i < simTraceSize; ++i)
	      simpixelHist->SetBinContent(i+1, simtrace[i]);

	    simpixelHist->SetLineColor(1);
	    simpixelHist->SetLineStyle(2);
	    simpixelHist->Draw("same");
	    fTracePlotObjects->Add(simpixelHist);
	  } // direct
	  if (pixRec.HasSimTrace(currRecPixel, FdApertureLight::eMie)) {
	    const int simTraceOffset = pixRec.GetSimTraceOffset(currRecPixel);
	    const vector<double> simtrace =
	      pixRec.GetSimTrace(currRecPixel, FdApertureLight::eMie);
	    const int simTraceSize = simtrace.size();
	    const string hName = "Eye_" + stringFromNumber(iEye) +
	      "_Mirror_" + stringFromNumber(iTel) +
	      "_Pixel_" + stringFromNumber(iPix) + "_mie";
	    TH1F* simpixelHist = new TH1F(hName.c_str(), hName.c_str(),
					  simTraceSize,
					  simTraceOffset*conversionFactor,
					  (simTraceOffset+simTraceSize)*
					  conversionFactor);
	    for (int i = 0; i < simTraceSize; ++i) {
	      simpixelHist->SetBinContent(i+1, simtrace[i]);
	    }
	    simpixelHist->SetLineColor(1);
	    simpixelHist->SetLineStyle(3);
	    simpixelHist->Draw("same");
	    fTracePlotObjects->Add(simpixelHist);
	  } // mie
	  if (pixRec.HasSimTrace(currRecPixel, FdApertureLight::eRayleigh)) {
	    const int simTraceOffset = pixRec.GetSimTraceOffset(currRecPixel);
	    const vector<double> simtrace =
	      pixRec.GetSimTrace(currRecPixel, FdApertureLight::eRayleigh);
	    const int simTraceSize = simtrace.size();
	    const string hName = "Eye_" + stringFromNumber(iEye) +
	      "_Mirror_" + stringFromNumber(iTel) +
	      "_Pixel_" + stringFromNumber(iPix) + "_rayleigh";
	    TH1F* simpixelHist = new TH1F(hName.c_str(), hName.c_str(),
					  simTraceSize,
					  simTraceOffset*conversionFactor,
					  (simTraceOffset+simTraceSize)*
					  conversionFactor);
	    for (int i = 0; i < simTraceSize; ++i)
	      simpixelHist->SetBinContent(i+1, simtrace[i]);

	    simpixelHist->SetLineColor(1);
	    simpixelHist->SetLineStyle(4);
	    simpixelHist->Draw("same");
	    fTracePlotObjects->Add(simpixelHist);
	  } // rayleigh
	} // if showMC
      } // HasTrace
      else {
	pixelLegend->DrawLatex(0.4,0.5,"No trace data available"
			       " -> Check RecDataWriter.xml");
      }
    } // currRecPixel > 0

    if(pixelHist!=NULL) {
      pixelHist->GetYaxis()->SetTitle("detected light [photons/100ns]");
      pixelHist->GetYaxis()->SetTitleOffset(1.2);
      pixelHist->GetYaxis()->SetTitleSize(0.05);
      pixelHist->GetXaxis()->SetTitle("time slot [100ns]");
      pixelHist->GetXaxis()->SetTitleSize(0.05);
      pixelHist->GetXaxis()->SetTitleOffset(1.05);
    }

  }
  else
    pixelLegend->DrawLatex(0.4,0.5,"No trace data available");

  fCanvasPixels->Modified();
  fCanvasPixels->Update();

  if (pixelHist)
    fTracePlotObjects->Add(pixelHist);
  if (spotRecPixelHist)
    fTracePlotObjects->Add(spotRecPixelHist);
  if (pixelPulse)
    fTracePlotObjects->Add(pixelPulse);

}

/****************************************************************************/
void
FdPlots::DrawSelectedPixelMarker(int currRecPixel)
{

  delete fSelectedPixelMarker;
  fSelectedPixelMarker=NULL;

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecPixel& pixRec = eyeEvent.GetFdRecPixel();

  const Int_t idPix=pixRec.GetID(currRecPixel);

  const int kPixelMarkerStyle=20;

  int pixelColor = (*fStyleManager)->GetDefaultPixelMarkerColor();

  const Detector& detector = (*fEvent)->GetDetector();
  const TBits& telBits = fShowTelsInDAQ ?
    detector.GetMirrorsInDAQ(fEyeId) :
    eyeEvent.GetMirrorsInEvent();

  double omega=0.;
  double phi=0.;

  const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);

  const UInt_t nTel = eye.GetNumberOfMirrors();
  for (UInt_t iTel=0; iTel<nTel; ++iTel) {
    const TString telPointingId = (*fEvent)->GetDetector().GetPointingId(fEyeId, iTel);

    if (telBits.TestBitNumber(iTel+1)) {

      const UInt_t telId = iTel+1;
      const TelescopeGeometry& tel = eye.GetTelescope(telId);
      const UInt_t nPix = tel.GetNumberOfPixels();

      for (UInt_t iPix = 0; iPix < nPix; ++iPix) {

	const Int_t jPix = iTel * nPix + iPix;

	if (idPix == jPix) {
	  omega = tel.GetPixelOmega(iPix, telPointingId);
	  phi = tel.GetPixelPhi(iPix, telPointingId);

	  if (GetPixelColor(currRecPixel) == 1)
	    pixelColor = 10; //white
	  if (fShowEyeView)
	    phi = 180.-phi;
	}
      }
    }
  }

  fCanvasCamera->cd();
  fCanvasCamera->SetEditable(true);

  fSelectedPixelMarker= new TMarker(phi, omega, kPixelMarkerStyle);
  fSelectedPixelMarker->SetMarkerColor(pixelColor);
  fSelectedPixelMarker->Draw("same");

  fCanvasCamera->GetCanvas()->Modified();
  fCanvasCamera->GetCanvas()->Update();
  fCanvasCamera->GetCanvas()->SetEditable(false);
}



void
FdPlots::ComputePixelColorRange(const int startBin, const int stopBin)
{
  if (!(*fEvent)->HasEye(fEyeId))
    return;

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecPixel& recPix = eyeEvent.GetFdRecPixel();

  if (!recPix.HasPixelStatus())
    return;

  const int nPix = recPix.GetNumberOfPixels();

  bool first = true;
  for (int iPix = 0; iPix < nPix; ++iPix) {

    if (fPixelColorMode == eTime && recPix.GetStatus(iPix) < eTimeFitPix)
      continue;

    if (fPixelColorMode != eTime && recPix.GetStatus(iPix) < ePulseRecPix)
      continue;

    const int nBin =
      (fPixelColorMode == eADCSum ||
       fPixelColorMode == eLogADCSum) ?
      min((int)recPix.GetTrace(iPix).size()-1, stopBin) - max(0, startBin):
      1;

    const int telId = recPix.GetTelescopeId(iPix);
    const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);
    const TelescopeGeometry& tel = eye.GetTelescope(telId);
    const Double_t fadcBinWidth = tel.GetFADCBinning();

    const int mirrorOffset = eyeEvent.GetMirrorTimeOffset(telId);

    for (int iBin=0; iBin<nBin; ++iBin) {

      const int bin =
        (fPixelColorMode == eADCSum ||
         fPixelColorMode == eLogADCSum)
        ? int(min((int)recPix.GetTrace(iPix).size()-1,
                  max(0, startBin) + iBin)
              - mirrorOffset/fadcBinWidth)
        : 0;

      double value = 0;
      switch (fPixelColorMode) {
      case eTime:
        value = recPix.GetTime(iPix);
        break;
      case eCharge:
        value = recPix.GetCharge(iPix);
        break;
      case eLogCharge:
        value = log10(recPix.GetCharge(iPix));
        break;
      case eADCSum:
        value = recPix.GetTraceSum(iPix, bin, bin+1);
        break;
      case eLogADCSum:
        {
          const double val = recPix.GetTraceSum(iPix, bin, bin+1)
            + recPix.GetMeanPixelRMS()*4;
          if (val<=0)
            continue;
          value = val>0 ? log10(val) : 0;
          break;
        }
      case eCloudColors:
        value = 0; // no pixelcolor range used for clouds...
        break;
      }

      if (first) {

        fPixelColorRangeMin = value;
        fPixelColorRangeMax = value;
        first = false;

      } else {

        if (fPixelColorRangeMax < value)
          fPixelColorRangeMax = value;

        if (fPixelColorRangeMin > value)
          fPixelColorRangeMin = value;

      }
    } // loop bins for ADC sum
  } // loop pixels

  if (fPixelColorRangeMin < 0)
    fPixelColorRangeMin = 0;
}


int
FdPlots::GetPixelColor(const int iPix, const int timeBin)
  const
{
  int color = (*fStyleManager)->GetDefaultPixelColor();

  if (!(*fEvent)->HasEye(fEyeId))
    return color;

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecPixel& pixRec = eyeEvent.GetFdRecPixel();

  if (!pixRec.HasPixelStatus())
    return color;

  const int telId = pixRec.GetTelescopeId(iPix);
  const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);
  const TelescopeGeometry& tel = eye.GetTelescope(telId);
  const Double_t fadcBinWidth = tel.GetFADCBinning();

  const int mirrorOffset = eyeEvent.GetMirrorTimeOffset(telId);
  const int timeBinCorrected = int(timeBin - mirrorOffset/fadcBinWidth);

  switch (fPixelColorMode) {

  case eTime:
    {
      const double index = pixRec.GetTime(iPix);
      if (pixRec.GetStatus(iPix) >= eTimeFitPix)
        color = CalculatePixelColor(index);
      else if (pixRec.GetStatus(iPix) >= eSDPRecPix)
        color = (*fStyleManager)->GetPulseRecPixelColor();
      else if (pixRec.GetStatus(iPix) >= eTriggeredPix)
        color = (*fStyleManager)->GetTriggeredPixelColor();
      break;
    }

  case eCharge:
    {
      const double index = pixRec.GetCharge(iPix);
      if (pixRec.GetStatus(iPix) >= ePulseRecPix)
        color = CalculatePixelColor(index);
      else if (pixRec.GetStatus(iPix) >= eTriggeredPix)
        color = (*fStyleManager)->GetTriggeredPixelColor();
      break;
    }

  case eLogCharge:
    {
      const double index = log10(pixRec.GetCharge(iPix));
      if (pixRec.GetStatus(iPix) >= ePulseRecPix)
        color = CalculatePixelColor(index);
      else if (pixRec.GetStatus(iPix) >= eTriggeredPix)
        color = (*fStyleManager)->GetTriggeredPixelColor();
      break;
    }

  case eADCSum:
    {
      const double index = pixRec.GetTraceSum(iPix, timeBinCorrected, timeBinCorrected+1);
      color = CalculatePixelColor(index);
      break;
    }

  case eLogADCSum:
    {
      color = kBlack;
      const double value = pixRec.GetTraceSum(iPix, timeBinCorrected, timeBinCorrected+1);
      if (value>0) {
        const double index = value>0 ? log10(value) : 0;
        color = CalculatePixelColor(index);
      }
      break;
    }
  case eCloudColors:
    color = fSignalColorRangeStart;
    break;
  } // end of switch color mode

  return color;
}


bool
FdPlots::IsPixelADCbinSaturated(const int iPix, const int timeBin)
  const
{
  if (!(*fEvent)->HasEye(fEyeId))
    return false;

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecPixel& pixRec = eyeEvent.GetFdRecPixel();

  const int telId = pixRec.GetTelescopeId(iPix);
  const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(fEyeId);
  const TelescopeGeometry& tel = eye.GetTelescope(telId);
  const Double_t fadcBinWidth = tel.GetFADCBinning();

  const int mirrorOffset = eyeEvent.GetMirrorTimeOffset(telId);
  const int timeBinCorrected = int(timeBin - mirrorOffset/fadcBinWidth);

  return pixRec.GetTraceSum(iPix, timeBinCorrected, timeBinCorrected+1)
    >= 0.999 * pixRec.GetTraceMax(iPix);
}


/******************************************************************************/
int
FdPlots::CalculatePixelColor(double index)
  const
{
  const int colorIndexStart = (fPixelColorMode == eTime ?
			       fTimeColorRangeStart :
			       fSignalColorRangeStart);
  const int colorIndexLength = (fPixelColorMode == eTime ?
				fTimeColorLength :
				fSignalColorLength);
  if (index < fPixelColorRangeMin)
    index = fPixelColorRangeMin;
  if (index > fPixelColorRangeMax)
    index = fPixelColorRangeMax;
  const int colorIndex = colorIndexStart +
    int(colorIndexLength * (index-fPixelColorRangeMin) /
	(fPixelColorRangeMax-fPixelColorRangeMin));
  return colorIndex;
}


/******************************************************************************/
std::string
FdPlots::PrintPostScript()
{
  TString name;
  const int iEye=fEyeId;
  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const int iEvent = eyeEvent.GetEventId();
  const int iRun = eyeEvent.GetRunId();

  int tabID=0;
  if(fEventPixelTab!=NULL) tabID=fEventPixelTab->GetCurrent();
  const int kInfoTab=0, kPixelTab=1;

  cout << "\n processing Fd plots for Eye "<<iEye<<" ...\n";

  ostringstream epsFileBase;
  epsFileBase << "/tmp/tmp" <<  iEye << "_" << iRun << "_" << iEvent;

  string SDPFile = epsFileBase.str() + "_SDP.eps";
  fCanvasCamera->cd();
  fCanvasCamera->Print(SDPFile.c_str());

  string axisFile = epsFileBase.str() + "_axis.eps";
  fCanvasTime->cd();
  fCanvasTime->Print(axisFile.c_str());

  string profileFile = epsFileBase.str() + "_profile.eps";
  fCanvasProfile->cd();
  fCanvasProfile->Print(profileFile.c_str());

  string infoFile = epsFileBase.str() + "_event_info.eps";

  switch(tabID) {
  case kInfoTab:
    fCanvasInfo->cd();
    fCanvasInfo->Print(infoFile.c_str());
    break;
  case kPixelTab:
    fCanvasPixels->cd();
    fCanvasPixels->Print(infoFile.c_str());
    break;
  default:
    fCanvasInfo->cd();
    fCanvasInfo->Print(infoFile.c_str());
    break;
  }

  ostringstream filename;
  filename << "Eye" << iEye << "_Run" << iRun
	   << "_Event" << iEvent <<".ps";

  ostringstream command;
  command << ADST_BIN_DIR << "/FdEvent2ps.csh"
          << " " << iEye << " " << iRun << " " << iEvent
          << " Eye" << iEye <<"_Run" << iRun <<"_Event" << iEvent;

  int bad = system(command.str().c_str());

  return(bad ? string("") : filename.str());
}


void
FdPlots::EnablePixelTraceTab()
{
  fEventPixelTab->SetEnabled(1, kTRUE);
}


// Draw the aerosol profile into a canvas given the X-axis vector of
// the data displayed in the canvas. The vector must correspond to the
// x-data type and points in the canvas. I.e. for the normal dE/dX
// plot, it must be the event's slant depth vector, etc.
void
FdPlots::SuperimposeAerosols(TCanvas* canvas,
			     const std::vector<Double_t>& xReferenceVector)
{
  // Note: x/X in this function aren't necessarily depth. They could
  // as well be shower age or time.

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecShower &fdRecShower = eyeEvent.GetFdRecShower();

  if (fdRecShower.GetDepth().empty() ||
      fdRecShower.GetEnergyDeposit().empty() ||
      !(*fEvent)->GetDetector().HasAerosolData() ||
      xReferenceVector.empty())
    return;

  const std::vector<Double_t>& height = fdRecShower.GetHeight();
  const FdAerosols& aerosols          = (*fEvent)->GetDetector().GetAerosolData(fEyeId);
  const vector<Double_t>& mieAtt      = aerosols.GetMieAttenuationLength();
  const vector<Double_t>& mieHeight   = aerosols.GetMieAttenuationHeight();

  // This is because ROOT TGraph's Eval can't handle reversed X-axis
  // We're still associating the right height/depth. The appearance of
  // the graph remains the same. Just the "drawing order" becomes
  // left-to-right.
  TGraph* heightToXReference = NULL;
  if (height.front() > height.back()) {
    std::vector<Double_t> reverseHeight(height.rbegin(), height.rend());
    std::vector<Double_t> reverseReference(xReferenceVector.rbegin(), xReferenceVector.rend());
    heightToXReference =
      new TGraph(reverseReference.size(),
		 &reverseHeight.front(), &reverseReference.front());
  }
  else {
    heightToXReference =
      new TGraph(xReferenceVector.size(),
		 &height.front(), &xReferenceVector.front());
  }

  vector<Double_t> alphaX;
  vector<Double_t> alpha;
  Double_t alphaMax = 0.;
  const double minH = heightToXReference->GetX()[0];
  const double maxH = heightToXReference->GetX()[ heightToXReference->GetN()-1 ];
  for (unsigned int i = 0; i < mieHeight.size(); ++i) {
    if (mieHeight[i] < minH || mieHeight[i] > maxH)
      continue;
    const double x = heightToXReference->Eval(mieHeight[i]);
    alphaX.push_back(x);
    alpha.push_back(finite(mieAtt[i]) ? 1./mieAtt[i] : 0.);
    if (alpha.back() > alphaMax)
      alphaMax = alpha.back();
  }

  TGraph* aerosolsGraph =
    new TGraph(alphaX.size(), &alphaX.front(), &alpha.front());
  aerosolsGraph->SetName("aerosolsGraph");
  delete heightToXReference;

  fProfileObjects->Add(aerosolsGraph); // TODO This probably breaks if the aerosols would be drawn into an entirely different canvas.
  canvas->cd();

  gPad->Modified(); // necessary for the residuals!
  gPad->Update();

  //scale to the pad coordinates
  const double rightmax = 1.1*alphaMax;
  const double scale = (gPad->GetUymax()-gPad->GetUymin()) / rightmax;
  const double offset = gPad->GetUymin();
  Double_t* y = aerosolsGraph->GetY();
  for (int i = 0; i < aerosolsGraph->GetN(); ++i)
    y[i] = y[i]*scale + offset;

  //draw an axis on the right side
  TGaxis* axis = new TGaxis(
                            gPad->GetUxmax(), gPad->GetUymin(),
                            gPad->GetUxmax(), gPad->GetUymax(),
                            0, rightmax, 510, "+L"
                            );
  axis->SetLineColor((*fStyleManager)->GetAerosolProfileColor());
  axis->SetLabelColor((*fStyleManager)->GetAerosolProfileColor());
  axis->SetTitleColor((*fStyleManager)->GetAerosolProfileColor());
  axis->SetTitleOffset(0.8);
  axis->SetTitleSize(0.055); // Same as normal axis, it seems
  axis->SetLabelSize(0.05); // Same as normal axis, it seems
  axis->SetTitle("alpha [m^{-1}]");
  axis->Draw();

  aerosolsGraph->Draw("LP");
  aerosolsGraph->SetTitle("");
  aerosolsGraph->SetMarkerStyle((*fStyleManager)->GetAerosolProfileType());
  aerosolsGraph->SetMarkerSize(1);
  aerosolsGraph->SetMarkerColor((*fStyleManager)->GetAerosolProfileColor());
  aerosolsGraph->SetLineColor((*fStyleManager)->GetAerosolProfileColor());

  return;
}


void
FdPlots::SuperimposeViewableFOV(TCanvas* canvas, const bool useAge)
{

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  const FdRecShower& fdRecShower = eyeEvent.GetFdRecShower();
  if (fdRecShower.GetDepth().empty() ||
      fdRecShower.GetEnergyDeposit().empty() ||
      fdRecShower.GetZVector().empty())
    return;

  const vector<double>& xiVec = fdRecShower.GetZVector();
  const vector<double>& mvaVec = fdRecShower.GetMinViewingAngles();
  const double xMax  = fdRecShower.GetXmax();
  const double xLow = fdRecShower.GetXFOVMin();
  const double xUp  = fdRecShower.GetXFOVMax();
  const double dX = (xUp-xLow)/(xiVec.size()-1);

  vector<double> xiX;
  double xiYMax = 0.;
  double mvaYMax = 90.;
  bool first = true;
  double currDepth = xLow;
  for (unsigned int i = 0; i < xiVec.size(); ++i) {

    const double x = useAge?FdRecShower::ShowerAge(currDepth,xMax):currDepth;
    const double xi = xiVec[i];
    const double mva = (mvaVec.empty()?0.:mvaVec[i])/degree;;

    xiX.push_back(x);
    if (first || xi > xiYMax)
      xiYMax = xi;
    if (mva > mvaYMax)
      mvaYMax = mva;

    first = false;
    currDepth+=dX;
  }

  canvas->cd();

  gPad->Modified(); // necessary for the residuals!
  gPad->Update();

  TGraph* xiGraph =
    new TGraph(xiX.size(), &xiX.front(), &xiVec.front());
  fProfileObjects->Add(xiGraph);

  //scale to the pad coordinates
  const double xiAxisMax = 1.1*xiYMax;
  const double scale = (gPad->GetUymax()-gPad->GetUymin()) / xiAxisMax;
  const double offset = gPad->GetUymin();
  Double_t* y = xiGraph->GetY();
  for (int i = 0; i < xiGraph->GetN(); ++i)
    y[i] = fabs(y[i])*scale + offset; // fabs for old PRL adsts

  //draw an xiAxis on the right side
  TGaxis* xiAxis = new TGaxis(
                              gPad->GetUxmax(), gPad->GetUymin(),
                              gPad->GetUxmax(), gPad->GetUymax(),
                              0, xiAxisMax, 510, "-=S"
                              );
  xiAxis->SetLineColor((*fStyleManager)->GetAerosolProfileColor());
  xiAxis->SetLabelColor((*fStyleManager)->GetAerosolProfileColor());
  xiAxis->SetTitleColor((*fStyleManager)->GetAerosolProfileColor());
  xiAxis->SetTitleOffset(1.2);
  xiAxis->SetTitleSize(0.035);
  xiAxis->SetLabelSize(0.03);
  xiAxis->SetTickSize(0.02);
  xiAxis->SetLabelOffset(-0.023);
  xiAxis->SetTitle("#xi(X) [g/cm^{2}]  ");
  xiAxis->Draw();

  xiGraph->Draw("LP");
  xiGraph->SetTitle("");
  xiGraph->SetMarkerStyle((*fStyleManager)->GetAerosolProfileType());
  xiGraph->SetMarkerSize(1);
  xiGraph->SetMarkerColor((*fStyleManager)->GetAerosolProfileColor());
  xiGraph->SetLineColor((*fStyleManager)->GetAerosolProfileColor());

  // for old PRL(2010) adsts
  if (mvaVec.empty())
    return;

  TGraph* mvaGraph =
    new TGraph(xiX.size(), &xiX.front(), &mvaVec.front());
  fProfileObjects->Add(mvaGraph);

  //scale to the pad coordinates
  const double mvaAxisMax = 1.1*mvaYMax;
  const double scaleMVA = (gPad->GetUymax()-gPad->GetUymin()) / mvaAxisMax;
  const double offsetMVA = gPad->GetUymin();
  y = mvaGraph->GetY();
  for (int i = 0; i < mvaGraph->GetN(); ++i)
    y[i] = y[i]/degree*scaleMVA + offsetMVA;

  //draw an mvaAxis on the right side
  TGaxis* mvaAxis = new TGaxis(
                               gPad->GetUxmax(), gPad->GetUymin(),
                               gPad->GetUxmax(), gPad->GetUymax(),
                               0, mvaAxisMax, 510, "+=S"
                               );
  const int mvaColor = kTeal-8;
  mvaAxis->SetLineColor(mvaColor);
  mvaAxis->SetLabelColor(mvaColor);
  mvaAxis->SetTitleColor(mvaColor);
  mvaAxis->SetTitleOffset(1.3);
  mvaAxis->SetTitleSize(0.035);
  mvaAxis->SetLabelSize(0.03);
  mvaAxis->SetTickSize(0.02);
  mvaAxis->SetLabelOffset(0.013);
  mvaAxis->SetTitle("mva [deg.]  ");
  mvaAxis->Draw();

  mvaGraph->Draw("LP");
  mvaGraph->SetTitle("");
  mvaGraph->SetMarkerStyle((*fStyleManager)->GetAerosolProfileType());
  mvaGraph->SetMarkerSize(1);
  mvaGraph->SetMarkerColor(mvaColor);
  mvaGraph->SetLineColor(mvaColor);

  pair<double, double> expectedFOV =
    fdRecShower.GetExpectedFOVRange(40.,20*degree);
  TLine* fovMin = new TLine(expectedFOV.first,
                            gPad->GetUymin(),
                            expectedFOV.first,
                            gPad->GetUymax());
  fovMin->SetLineStyle(2);
  fovMin->Draw("SAME");
  TLine* fovMax = new TLine(expectedFOV.second,
                            gPad->GetUymin(),
                            expectedFOV.second,
                            gPad->GetUymax());
  fovMax->Draw("SAME");
  fovMax->SetLineStyle(2);

  if (expectedFOV.first >= expectedFOV.second) {
    TLatex* legend = new TLatex();
    legend->SetNDC(); legend->SetTextAlign(12); legend->SetTextSize(0.035);
    legend->DrawLatex(0.6,0.8,"empty FOV range");
    fProfileObjects->Add(legend);
  }

  fProfileObjects->Add(fovMax);
  fProfileObjects->Add(fovMin);


  return;
}


void
FdPlots::DrawSDP(double theta, double phi, double omegaMin,
		 double omegaMax, double phiMin, double phiMax,
		 int color)
{
  const double kDeltaPhi = 2.;

  TVector3 sdp(1,0,0);
  sdp.SetTheta(theta);
  sdp.SetPhi(phi);
  TVector3 v = sdp.Orthogonal();

  vector<double> px, py;
  const double step = 0.5 * degree;
  const unsigned int steps = unsigned(360.*degree / step);
  for (unsigned int i = 0; i < steps; ++i) {
    v.Rotate(step, sdp); // rotation around SDP
    double phi = v.Phi()/degree;
    const double omega = 90. - v.Theta()/degree;

    if (omega > omegaMin && omega < omegaMax &&
	phi > phiMin-kDeltaPhi && phi < phiMax+kDeltaPhi) {

      if (fShowEyeView)
	phi = 180. - phi;


      vector<double>::iterator xIter =
        lower_bound(px.begin(), px.end(), phi);
      vector<double>::iterator yIter =
        py.begin() + (xIter - px.begin());
      px.insert(xIter, phi);
      py.insert(yIter, omega);

    }
  }

  TPolyLine* sdpline = new TPolyLine(px.size(), &px.front(), &py.front());
  sdpline->SetLineColor(color);
  fSDPObjects->Add(sdpline);
  sdpline->Draw("C");
}


TF1*
FdPlots::MakeTimeFitFunction(const std::string& name, const FdGeometry& geo)
{
  TF1* timeFitFun =
    new TF1(name.c_str(), gTimeFitFunctionString.c_str(),
            0., 90.);
  fTimeFitObjects->Add(timeFitFun);

  timeFitFun->SetNpx(500);

  timeFitFun->SetParameters(geo.GetRp(),
                            geo.GetChi0(),
                            geo.GetT0()/100.,
                            kFDSpeedOfLight);
  timeFitFun->SetLineWidth(0);
  timeFitFun->SetLineColor((*fStyleManager)->GetFDTimeFitLineColor());
  return timeFitFun;
}

// called by Update(): Checks whether there's pixel data available in
// the FDEvent and sets the status of the Animate button accordingly
void
FdPlots::UpdateAnimateButton()
{
  if (!(*fEvent)->HasEye(fEyeId)) {
    fAnimateButton->SetEnabled(false);
    return;
  }

  const FDEvent& eyeEvent = (*fEvent)->GetEye(fEyeId);
  if (eyeEvent.GetRecLevel() < eHasTriggeredPixels ||
      eyeEvent.GetFdRecPixel().GetNumberOfTracePixels() == 0 ||
      eyeEvent.GetFdRecPixel().GetNumberOfPixels() == 0)
    {
      fAnimateButton->SetEnabled(false);
      return;
    }

  fAnimateButton->SetEnabled(true);

}


/****************************************************************************/
// Show one of the "got no data"-like excuses in one of the plots
void
FdPlots::ShowExcuse(TCanvas* where, TObjArray* manager,
		    const char* excuse, const int color)
  const
{
  TLatex* legend = new TLatex();
  manager->Add(legend);

  legend->SetNDC();
  legend->SetTextAlign(22);
  legend->SetTextSize(0.04);
  legend->SetTextColor(color);
  legend->DrawLatex(0.5, 0.5, excuse);
  where->Modified();
  where->Update();
  return;
}

void
FdPlots::SaveCameraCanvas(const string& name)
  const
{
  fCanvasCamera->SaveAs(name.c_str());
}


int
FdPlots::GetCloudColor(int telescopeId, int pixelId)
  const
{

  const Detector& detector = (*fEvent)->GetDetector();
  if (detector.HasCloudCameraData(fEyeId)) {
    const FdCloudCameraData& cloudCamData = detector.GetCloudCameraData(fEyeId);

    if (cloudCamData.HasCloudFraction(telescopeId, pixelId)) {
      const double cloudFraction = cloudCamData.GetCloudFraction(telescopeId,
                                                                 pixelId);
      if (cloudFraction < 0.1)
        return kBlack;
      else if (cloudFraction < 0.3)
        return kBlue+3;
      else if (cloudFraction < 0.5)
        return kBlue-6;
      else if (cloudFraction < 0.7)
        return kBlue-9;
      else if (cloudFraction < 0.9)
        return kBlue-10;
      else
        return kWhite;
    }
  }

  return kBlack;

}


void
FdPlots::DrawGHErrorBand(double xMin, double xMax)
{

  vector<double> x;
  vector<double> y;
  const unsigned int nPoints = 500;
  const double dX = (xMax-xMin)/nPoints;
  const double delta = dX/2.;
  double thisX = xMin+delta;

  fGaisserHillas.SetNSigma(1.);
  while (thisX < xMax-delta) {
    x.push_back(thisX);
    y.push_back(fGaisserHillas(&thisX));
    thisX += dX;
  }

  fGaisserHillas.SetNSigma(-1.);
  while (thisX > xMin+delta) {
    thisX -= dX;
    x.push_back(thisX);
    y.push_back(fGaisserHillas(&thisX));
  }

  fGaisserHillas.SetNSigma(0.);

  TPolyLine* ghErrorBand = new TPolyLine(x.size(), &x.front(), &y.front(),
                                         "f");
  ghErrorBand->SetFillColor((*fStyleManager)->GetProfileFitErrorColor());
  ghErrorBand->SetFillStyle((*fStyleManager)->GetProfileFitErrorFillStyle());
  fProfileObjects->Add(ghErrorBand);
  ghErrorBand->Draw("f");

}
