#ifndef _include_MdPlots_h__
#define _include_MdPlots_h__

#include <TQObject.h>
#include "VPlots.h"
#include "ArrayPlot.h"
#include "FileInfo.h"
#include <vector>
#include <string>

class TGCompositeFrame;
class TGHorizontalFrame;
class TGVerticalFrame;
class TGLayoutHints;
class TCanvas;
class TGHSlider;
class TGListBox;
class TObjArray;
class RecEvent;
class SdRecStation;
class MdRecModule;
class Traces;
class GenStation;
class StyleManager;
class SDEvent;
class DetectorGeometry;
class TGVButtonGroup;
class TGRadioButton;
class TGCheckButton;
class ArrayPlot;
class TGDoubleHSlider;
class TGTab;
class TGTextButton;
class TLatex;
class TGraph;
class TH1;
class TH1D;
class TVector3;
class TPad;

class MdPlots : public TQObject, public VPlots {

private:
  MdPlots();

public:
  MdPlots (TGCompositeFrame* main, 
	   const StyleManager* const * styleManager,
	   const DetectorGeometry* const * geom,		  
	   const RecEvent* const * event, 
	   const bool& ismc);
    
  ~MdPlots();

  void Clear();
  void Update();
  void DoMdButton();
  void SelectStation();  

  std::string PrintPostScript();
  void UpdateArrayPlot();
  void DrawSDMarkers();

  void SetRecStationClassVersion(const int version)
      {fRecStationClassVersion= version;}
 
  void PrevHisto();
  void NextHisto();

private:
  
  void UpdateStationsList(bool selectFirstStation=true);
  void UpdateTracesPlots(int a=1);
  void MdEventInfo(TCanvas *);
  void SdMCInfo();
  int GetColor(Long64_t x);//, double y, double z);
  void GetMaxAndMinTime();
  void Update(bool selectFirstStation=true);

  void DrawLDF();
  void DrawTimeResiduals();
  void EnableNavigationButtonsTraces(Bool_t enable);
  TLatex* DrawLegend(TObjArray* objArray, TString text, Double_t x=0.4, Double_t y=0.5, Double_t size=0.055);
  void DrawNoTracesLegend(Int_t nroPad);
  void CreateTracesPads(TCanvas* myCanvas, UInt_t counterSize);
  void SetTracesHistoAtrr(TH1* h, UInt_t xmin, UInt_t xmax, TString title, Bool_t isFirst);
  void SetTracesGraphAtrr(TGraph* h, TString htitle, TString hname, UInt_t xmin, UInt_t xmax, Bool_t isFirst);
  void GetTraceData(MdRecModule* module, std::vector<unsigned int>* traceSum,std::vector<int>* bins ,std::vector<int>* channels, double startTimeCorrection);
  double GetTimeCorrectionForTrace(MdRecModule* module, SDEvent theSdEvent, const double traceStartSecond0, double traceStartNano0, TVector3 position0);
  void DrawSDTraces(Double_t mdSignalStartNano, Double_t sdSignalStartNano, const SdRecStation* const theSdStation, TH1* mdHisto, bool isFirst, bool isLast);
  TH1D* GetAverageSdTrace(const SdRecStation* theSdStation);
  void UpdateCanvas(TCanvas* myCanvas);
  void RestartTraceCanvas(TCanvas* myCanvas);
  void DeleteObject(TString);
  void DrawHisto(TCanvas * myCanvas, TH1 * histo, const SdRecStation* const theSdStation, double startTimeForMuon, double
  		sdSignal2TraceStartNano, int nroPad, Bool_t isFirst, Bool_t isLast);

  const StyleManager* const * fStyleManager; // for plotting style options
  const RecEvent* const * fEvent;   // this is just the current event reference
  const bool& fIsMC;
  const DetectorGeometry* const * fDetectorGeometry;
  
  ArrayPlot * fArrayPlot;

  int fRecStationClassVersion;
  int fSdColorStatus;
  Long64_t fMaxTime;
  Long64_t fMinTime;
  double fMaxTimeRes;
  double fMinTimeRes;

  bool fSdMdCombinedView;
 
  bool fHasFADCTraces;
  bool fHasVEMTraces;
  bool fMdArrayOnStatus;
  bool fMdLDFOnStatus;

  TGCompositeFrame *fMain;
  TGListBox *fStationsListBox;
  
  TGTab *fMDEventTab;
  TGTab *fMDEventInfoTab;

  TCanvas *fCanvasArray;
  TCanvas *fCanvasLDF;
  TCanvas *fCanvasTRes;
  TCanvas *fCanvasInfo;
  TCanvas *fCanvasMCInfo;

  TCanvas *fCanvasStations;
  TCanvas *fCanvasRAWTraces;
  TCanvas *fCanvasRAWTracesChannel;
  TCanvas *fCanvasCountHisto;
  /*TCanvas *fCanvasDummy;
  TCanvas *fCanvasDummy2;*/

  TCanvas *fCanvasTest;
  TGHSlider *fArrayZoomButton;

  TObjArray * fEventObjects;
  TObjArray * fTracesObjects;
  TObjArray * fArrayObjects;

  TGRadioButton * fColButton1;
  TGRadioButton * fColButton2;
  TGRadioButton * fColButton3;
  TGRadioButton * fColButton4;
  TGRadioButton * fArrayButton;
  TGRadioButton * fTracesButton;
  TGRadioButton * fLDFButton;
  TGRadioButton * fLDFResButton;
  TGRadioButton * fEventTimeRes; 
  TGRadioButton * fEventCurvTimeRes;
  TGRadioButton * fEventNoTimeRes;

  TGCheckButton * fEventShowCombinedView;

  //Histogram navigation buttons
  TGTextButton * fPrevRawTraces;
  TGTextButton * fNextRawTraces;
  TGTextButton * fPrevRawTracesChannel;
  TGTextButton * fNextRawTracesChannel;
  TGTextButton * fPrevCountHisto;
  TGTextButton * fNextCountHisto;
  int fCurrentFirstHisto;
  int fLastHisto;

  //Header ID for the station list
  const static int headerId = -1;
  int lastStationId; 

  ClassDef (MdPlots, 7);
};

#endif
