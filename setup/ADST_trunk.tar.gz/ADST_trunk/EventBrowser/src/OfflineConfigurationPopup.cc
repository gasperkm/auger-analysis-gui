#include "OfflineConfigurationPopup.h"
#include "FileInfo.h"

#include "TGWindow.h"
#include "TGFrame.h"
#include "TGTextEdit.h"
#include "TGButton.h"
#include "TGLayout.h"

#include <sstream>
#include <string>
using namespace std;

OfflineConfigurationPopup::OfflineConfigurationPopup(const TGWindow *main, 
						     const FileInfo & theFileInfo,
						     UInt_t w, UInt_t h)
{

  fMain = new TGTransientFrame(gClient->GetRoot(), main, w, h);
  fMain->Connect("CloseWindow()", "OfflineConfigurationPopup", this, "CloseWindow()");

  // use hierarchical cleaning
  fMain->SetCleanup(kDeepCleanup);

  fEdit = new TGTextEdit(fMain, w, h, kSunkenFrame | kDoubleBorder);
  fMain->AddFrame(fEdit, (new TGLayoutHints(kLHintsExpandX | kLHintsExpandY, 3, 3, 3, 3)));
  fEdit->Connect("Saved()",  "OfflineConfigurationPopup", this, "DoSave()");
  fEdit->Connect("Closed()", "OfflineConfigurationPopup", this, "DoClose()");

  TGHorizontalFrame *Horizontal = new TGHorizontalFrame (fMain, w, UInt_t(0.1*h));
  fMain->AddFrame (Horizontal, new TGLayoutHints (kLHintsExpandX, 3, 3, 3, 3));


  fSave = new TGTextButton(Horizontal, "  &Save as ...  ");
  fFind = new TGTextButton(Horizontal, "  &Find ... ");
  fFindAgain = new TGTextButton(Horizontal, "  Find &again ");
  fOK = new TGTextButton(Horizontal, "  &Close  ");

  // fOK->Connect("Clicked()", "TGTextEdit", fEdit, "ProcessMessage(Long_t,Long_t,Long_t)");
  fSave->Connect("Clicked()", "OfflineConfigurationPopup", this, "DoSave()");
  fFind->Connect("Clicked()", "OfflineConfigurationPopup", this, "DoSearch()");
  fFindAgain->Connect("Clicked()", "OfflineConfigurationPopup", this, "DoSearchAgain()");
  fOK->Connect("Clicked()", "OfflineConfigurationPopup", this, "DoOK()");
   
  Horizontal->AddFrame(fSave,(new TGLayoutHints(kLHintsBottom | kLHintsCenterX, 0, 0, 5, 5)));
  Horizontal->AddFrame(fFind,(new TGLayoutHints(kLHintsBottom | kLHintsCenterX, 0, 0, 5, 5)));
  Horizontal->AddFrame(fFindAgain,(new TGLayoutHints(kLHintsBottom | kLHintsCenterX, 0, 0, 5, 5)));
  Horizontal->AddFrame(fOK,(new TGLayoutHints(kLHintsBottom | kLHintsCenterX, 0, 0, 5, 5)));

  fMain->MapSubwindows();

  fMain->Resize();

  fMain->CenterOnParent(kTRUE, TGTransientFrame::kRight);

  ReadFileInfo(theFileInfo);

  fMain->SetWindowName("Offline configuration for this ADST file");
  fMain->SetIconName("Offline configuration for this ADST file");

}


OfflineConfigurationPopup::~OfflineConfigurationPopup()
{
  delete fMain;
}

void OfflineConfigurationPopup::ReadFileInfo(const FileInfo & theFileInfo) 
{

  TGText txt;

  ostringstream adstInfo;
  
  
  adstInfo << "This file was produced by " << theFileInfo.GetUser() 
	   << " on host " << theFileInfo.GetHost() << "\n";
  adstInfo << "ADST version: " << theFileInfo.GetRecEventVersion() << "\n";
  adstInfo << "Offline version: " << theFileInfo.GetOfflineVersion() << "\n";
  adstInfo << "The Offline XML settings were as follows: ";
  

  txt.LoadBuffer(adstInfo.str().c_str());
  fEdit->AddText(&txt);

  txt.LoadBuffer(theFileInfo.GetOfflineConfiguration().c_str());
  fEdit->AddText(&txt);

}

void OfflineConfigurationPopup::Popup()
{
  fMain->MapWindow();
}



void OfflineConfigurationPopup::CloseWindow()
{
  // Called when closed via window manager action.

  delete this;
}

void OfflineConfigurationPopup::DoOK()
{
  // Handle ok button.

  fMain->SendCloseMessage();
}

void OfflineConfigurationPopup::DoSearch()
{
  // Handle search button.

  fEdit->SendMessage(fEdit, MK_MSG(kC_COMMAND, kCM_MENU),
		     TGTextEdit::kM_SEARCH_FIND, 0);
}

void OfflineConfigurationPopup::DoSearchAgain()
{
  // Handle search button.

  fEdit->SendMessage(fEdit, MK_MSG(kC_COMMAND, kCM_MENU),
		     TGTextEdit::kM_SEARCH_FINDAGAIN, 0);
}

void OfflineConfigurationPopup::DoSave()
{
  fEdit->SendMessage(fEdit, MK_MSG(kC_COMMAND, kCM_MENU),
		     TGTextEdit::kM_FILE_SAVEAS, 0);
}

void OfflineConfigurationPopup::DoClose()
{
  // Handle close button.

  fMain->SendCloseMessage();
}
