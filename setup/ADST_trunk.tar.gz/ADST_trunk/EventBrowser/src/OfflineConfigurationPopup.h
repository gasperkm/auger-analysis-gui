#include "Rtypes.h" 

class TGTransientFrame;
class TGTextEdit;
class TGTextButton;
class TGLayoutHints;
class TGWindow;
class FileInfo;

class OfflineConfigurationPopup {


public:
  OfflineConfigurationPopup(const TGWindow *main, const FileInfo & theFileInfo,
			    UInt_t w=600, UInt_t h=400);
  virtual ~OfflineConfigurationPopup();
  
  void   Popup();
  
  // slots
  void   CloseWindow();
  void   DoOK();
  void   DoSearch();
  void   DoSearchAgain();
  void   DoSave();
  void   DoClose();
  
private:
  TGTransientFrame *fMain;   // main frame of this widget
  TGTextEdit       *fEdit;   // text edit widget
  TGTextButton     *fOK;     // OK button
  TGTextButton     *fSave;    
  TGTextButton     *fFind;     
  TGTextButton     *fFindAgain;
  void ReadFileInfo(const FileInfo & theFileInfo);
};
