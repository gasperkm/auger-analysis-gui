
#ifndef _include_RdPlots_h__
#define _include_RdPlots_h__

#include <TQObject.h>
#include "VPlots.h"
#include "FileInfo.h"

#include <string>

class TGCompositeFrame;
class TGHorizontalFrame;
class TGVerticalFrame;
class TGLayoutHints;
class TCanvas;
class TGHSlider;
class TGListBox;
class TObjArray;
class RecEvent;
class RdRecStation;
class GenStation;
class StyleManager;
class DetectorGeometry;
class TGVButtonGroup;
class TGRadioButton;
class TGCheckButton;
class ArrayPlot;
class TGDoubleHSlider;
class TGTab;

class RdPlots : public TQObject, public VPlots {

private:
  RdPlots();

public:
  RdPlots (TGCompositeFrame *main, 
     const StyleManager* const * styleManager,
     const DetectorGeometry* const * geom,      
     const RecEvent* const * event, const bool& ismc);
    
  ~RdPlots();

  void Clear();
  void Update();
  void DoRdButton(); 
  void DoRdReleased();
  void DoRdPressed();
  void SelectStation();  
  void HandleArrayClicked(Int_t event, Int_t pt, Int_t py, TObject *sel);
  std::string PrintPostScript();
  void UpdateArrayPlot();

  inline void SetHasStationTraces(bool hastraces) {fHasStationTraces=hastraces;};
  inline void SetHasRdChannelTraces(bool hastraces) {fHasRdChannelTraces=hastraces;};
  void SetShowFD(const bool what) {fShowFD = what;}
  void SetShowMC(const bool what) {fShowMC = what;}
  void SetShowMCTraces(const bool what){ fShowMCTraces= what; }
  void SetShowAllTraces(const bool what) { fShowAllTraces = what;}

  void SetRecStationClassVersion(const int version)
      {fRecStationClassVersion= version;}
 
private:
  void UpdateStationsList();
  /// updates the lower tab plots (trace, spectrum, 2D-Field, etc...)
  void UpdateTraceTabPlots(unsigned int stNumber=1);
  /// updates the tab plots in the upper right except the ArrayPlot
  void UpdateTabPlots();
  void RdEventInfo(TCanvas *);
  void RdMCInfo(TCanvas*);
  void RdLDFInfo(TCanvas*);
  void RdStationInfo(TCanvas*);
  void DrawAllTraces(const RdRecStation & recstation);
  void DrawChannelTraces(const RdRecStation & recstation);
  void DrawSpectrum(const RdRecStation &);
  void DrawChannelSpectrum(const RdRecStation &);
  void Draw2DField(const RdRecStation&);
  void DrawScintillators(const RdRecStation&);
  void DrawTwoDLDF();
  void DrawLDF(const int pol=0);
  void DrawResiduals();
  void DrawLorentz();
  std::string GetPolarisationName(int pol);
  std::string GetPolarisationNameLDF(int pol);
  std::string GetRecStage(double recStage);

  const StyleManager* const * fStyleManager; // for plotting style options
  const RecEvent* const * fEvent;   // this is just the current event reference
  const bool& fIsMC;
  const DetectorGeometry* const * fDetectorGeometry;

  bool fShowFD;
  bool fShowMC;
  bool fShowAllTraces;

  bool fShowShowerArray;
  int  fSdTimeRes; // 1-plane time res, 2- curv time res, 0-no time res
  bool fSdFallTime;
  bool fSdRiseTime;
  bool fSdT50;
 
  int fSdColorStatus;
  int fRecStationClassVersion;
  bool fRStations;
  bool fHasRStations;
  bool fRdArrayOnStatus;
  bool fSdLDFOnStatus;
  bool fHasStationTraces;
  bool fHasRdChannelTraces; // false=Draw the trace true= draw the spectrum
  bool fShowMCTraces;
  bool fDrawChannel;
  bool fDrawTriggerWindow;
  bool fDrawNoiseWindow;
  bool fDrawPeakLine;
  bool fDrawVertPolarization;
  bool fDrawEastPolarization;
  bool fDrawNorthPolarization;
  bool fDrawVxBPolarization;
  bool fDrawVxVxBPolarization;
  bool fDrawVPolarization;
  bool fDrawResAxis;
  bool fDrawSdAxis;
  bool fDrawMCAxis;
  int fCurrentStation;
  
  

  TGCompositeFrame *fMain;
  TGListBox *fStationsListBox;
  
  TGTab *fRdEventTab;
  TGTab *fRdEventInfoTab;
  TGTab* fRdGeoTab;
  TGTab* fRdStationTab;

  TCanvas *fCanvasArray;
  TCanvas *fCanvasTwoDLDF;
  TCanvas *fCanvasLDF;
  TCanvas *fCanvasResiduals;
  TCanvas *fCanvasLorentz;
  TCanvas *fCanvasField;
  TCanvas *fCanvasScint;
  TCanvas *fCanvasInfo;
  TCanvas *fCanvasMCInfo;
  TCanvas *fCanvasLDFInfo;
  TCanvas *fCanvasStations;
  TCanvas *fCanvasTrace;
  TCanvas *fCanvasSpectrum;
  TCanvas *fCanvasStationInfo;
 
  
  TCanvas *fCanvasTest;
  TGHSlider *fArrayZoomButton;
  ArrayPlot *fArrayPlot;

  TObjArray * fPMTObjects;
  TObjArray * fEventObjects;
  TObjArray * fTracesObjects;
  TObjArray * fPlotsObjects;

  TGRadioButton* fStationButton;
  TGRadioButton* fChannelButton;
/*  TGRadioButton* fLDFMCCoreButton;
  TGRadioButton* fLDFAxisCS;
  TGRadioButton* fLDFCoreCS;
  */
  
  TGCheckButton * fRdTriggerWindowButton; 
  TGCheckButton * fRdNoiseWindowButton;
  TGCheckButton * fRdPeakLineButton;
  TGCheckButton * fRdVertPolarizationButton;
  TGCheckButton * fRdEastPolarizationButton;
  TGCheckButton * fRdNorthPolarizationButton;
  TGCheckButton * fRdVxBPolarizationButton;
  TGCheckButton * fRdVxVxBPolarizationButton;
  TGCheckButton * fRdVPolarizationButton;


  TGRadioButton* fResAxisButton;
  TGRadioButton* fResStationButton;
  TGRadioButton* fRadioAxisButton;
  TGRadioButton* fSdAxisButton;
  TGRadioButton* fMCAxisButton;
    
  ELDFType fLDFType; 
  
  
 
  ClassDef (RdPlots, 3);
};

#endif
