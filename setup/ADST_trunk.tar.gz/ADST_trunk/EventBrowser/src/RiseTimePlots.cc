#include "RiseTimePlots.h"
#include "ArrayPlot.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "RecEvent.h"
#include "Detector.h"
#include "DetectorGeometry.h"
#include "GenStation.h"
#include "Detector.h"
#include "SDEvent.h"
#include "StyleManager.h"

#include <TGeoMaterial.h>
#include <TGeoMedium.h>
#include <TGeoMatrix.h>
#include <TGeoManager.h>

#include <TGTab.h>
#include <TGFrame.h>
#include <TRootEmbeddedCanvas.h>
#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TGraphAsymmErrors.h>
#include <TF1.h>
#include <TGDoubleSlider.h>
#include <TLegend.h>
#include <TObjArray.h>
#include <TLine.h>
#include <TGSlider.h>
#include <TGCanvas.h>
#include <TLatex.h>
#include <TGButtonGroup.h>
#include <TGButton.h>
#include <TGLabel.h>
#include <TSystem.h>
#include <TGListBox.h>
#include <TColor.h>
#include <TMarker.h>
#include <TTimeStamp.h>
#include <TPolyMarker3D.h>
#include <TPolyLine3D.h>
#include <TGNumberEntry.h>
#include <TClass.h>
#include <TH2.h>

#include <iostream>
#include <vector>
#include <sstream>
#include <iomanip>

using namespace std;

ClassImp(RiseTimePlots);

RiseTimePlots::RiseTimePlots (TGCompositeFrame *main,
			      const StyleManager * styleManager, 
			      const DetectorGeometry * const * geom,		  
			      const RecEvent * const * event,const bool * isMC) :
  fStyleManager(styleManager),
  fEvent (event),
  fIsMC(isMC),
  fDetectorGeometry(geom),
  fArrayPlot(0),   
  fMain(main),
  fMainVertical1(0),
  fMainVertical2(0),
  fMainHorizontalLayout(0),
  fCheckPreviousId(1000)
{
   
 
  fEventObjects= new TObjArray();
  fEventObjects->SetOwner(kTRUE);
 
  fMain->SetCleanup(kDeepCleanup);
    
  const double width  = main->GetWidth();
  const double height = main->GetHeight();
    
    
  TGHorizontalFrame* fHor = new TGHorizontalFrame(main, UInt_t(width), UInt_t(height));    
  main->AddFrame(fHor, fMainHorizontalLayout);
  const UInt_t framewidth= UInt_t(0.75*width); 
   
  fMainVertical1 = new TGVerticalFrame(fHor, framewidth, UInt_t(0.90*height));
  fMainVertical2 = new TGVerticalFrame(fHor, UInt_t(width-framewidth), UInt_t(0.90*height));

  fMainHorizontalLayout = new TGLayoutHints (kLHintsTop, 3, 3, 3, 3);
  fHor->AddFrame(fMainVertical1, fMainHorizontalLayout);
  fHor->AddFrame(fMainVertical2, fMainHorizontalLayout);    
  
}

RiseTimePlots::~RiseTimePlots() 
{  
  fEventObjects->Delete();
  delete fEventObjects;
  
  fMain->Cleanup();
  
}

void RiseTimePlots::Clear()
{

  fEventObjects->Delete();
  fArrayPlot->Clear();
}

void RiseTimePlots::Update(){
  cout<<"Updating rise time plots"<<endl; 

}



void RiseTimePlots::DrawRisetime()
{  

  fCanvasRiseTime->cd();
  fCanvasRiseTime->Clear();
  
  vector<double> sPDistance;
  vector<double> sPDistanceErr;
    
  vector<double> timeEnd;
  vector<double> riseTime;
  vector<double> riseTimeRMS;
    
  vector<double> corrRiseTime;
  vector<double> corrRiseTimeError;
    
  const std::vector<SdRecStation> & stations= (*fEvent)->GetSDEvent().GetStationVector();
  const double zenith= (*fEvent)->GetSDEvent().GetSdRecShower().GetZenith();
    
  int n=0;
  for ( unsigned int iS=0;iS<stations.size();iS++) {
	
    if(stations[iS].IsCandidate())//&& stations[iS].GetSPDistance()!=0){
      if(stations[iS].GetSPDistance()!=0){  
	sPDistance.push_back(stations[iS].GetSPDistance());
	sPDistanceErr.push_back(stations[iS].GetSPDistanceError());
      }
    riseTime.push_back(stations[iS].GetRiseTime());
    riseTimeRMS.push_back(stations[iS].GetRiseTimeRMS());
    corrRiseTime.push_back(stations[iS].GetAssymCorrRiseTimeKG(zenith));	   
    corrRiseTimeError.push_back(stations[iS].GetAssymCorrRiseTimeErrorKG(zenith));	   
    ++n;
  }


  TGraphErrors * riseTimeGraph= new TGraphErrors(n,&sPDistance[0],&riseTime[0],0,&riseTimeRMS[0]);
  fEventObjects->Add(riseTimeGraph);
  riseTimeGraph->GetXaxis()->SetTitle("r[m]");
  riseTimeGraph->GetYaxis()->SetTitle("Time [ns]");
  riseTimeGraph->SetTitle("");
  riseTimeGraph->SetLineColor(fStyleManager->GetRiseTimeColor());
  riseTimeGraph->Draw("ap");
  
  TGraphErrors * riseTimeCorrGraph= new TGraphErrors(n,&sPDistance[0],&corrRiseTime[0],0,&corrRiseTimeError[0]);
  fEventObjects->Add(riseTimeCorrGraph);
  riseTimeCorrGraph->GetXaxis()->SetTitle("r[m]");
  riseTimeCorrGraph->GetYaxis()->SetTitle("Time [ns]");
  riseTimeCorrGraph->SetTitle("");
  riseTimeCorrGraph->SetLineColor(4);
  riseTimeCorrGraph->Draw("psame");
  fCanvasRiseTime->GetCanvas()->Modified();
  fCanvasRiseTime->GetCanvas()->Update();
  
  
}


std::string RiseTimePlots::PrintPostScript() {
  return string("");
}
