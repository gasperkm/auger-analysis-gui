#ifndef _include_RiseTimePlots_h__
#define _include_RiseTimePlots_h__

#include <TQObject.h>
#include <string>
#include "VPlots.h"

class RecEvent;
class GenStation;
class SdRecStation;
class SDEvent;
class DetectorGeometry;
class StyleManager;
class ArrayPlot;

class TGVButtonGroup;
class TGRadioButton;
class TGCheckButton;

class TGCompositeFrame;
class TGHorizontalFrame;
class TGVerticalFrame;
class TGLayoutHints;
class TCanvas;
class TGCanvas;
class TGHSlider;
class TGListBox;
class TObjArray;
class TGTab;
class TGeoVolume;
class TGDoubleHSlider; 
class TGNumberEntry;


class RiseTimePlots : public TQObject, public VPlots {

private:
  RiseTimePlots();

public:
  RiseTimePlots (TGCompositeFrame *main, 
	   const StyleManager * styleManager,
	   const DetectorGeometry * const * geom,		  
	   const RecEvent * const * event, const bool * ismc);
    
  ~RiseTimePlots();

  void Clear();
  void Update();
  std::string PrintPostScript();

private:

  
  void DrawRisetime();
  const StyleManager * fStyleManager; // for plotting style options
  const RecEvent * const * fEvent;   // this is just the current event reference
  const bool * fIsMC;
  const DetectorGeometry * const *fDetectorGeometry;
  ArrayPlot * fArrayPlot; 

  TGCompositeFrame *fMain;
  TGVerticalFrame *fMainVertical1;
  TGVerticalFrame *fMainVertical2;
  
  TGLayoutHints *fMainHorizontalLayout; ///>general layout
  TGTab *fSDEventTab;
  
  TCanvas *fCanvasRiseTime;
  TObjArray * fEventObjects;
  
  int fCheckPreviousId; 

  ClassDef (RiseTimePlots, 4);
};
#endif
