#include "SdSimulationPlots.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "RecEvent.h"
#include "Detector.h"
#include "DetectorGeometry.h"
#include "GenStation.h"
#include "Detector.h"
#include "SDEvent.h"
#include "StyleManager.h"
#include "ParticleType.h"
#include "TraceType.h"


#include <TGeoMaterial.h>
#include <TGeoMedium.h>
#include <TGeoMatrix.h>
#include <TGeoManager.h>
#include <TStyle.h>

#include <TGTab.h>
#include <TGFrame.h>
#include <TRootEmbeddedCanvas.h>
#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TGraphAsymmErrors.h>
#include <TF1.h>
#include <TGDoubleSlider.h>
#include <TLegend.h>
#include <TObjArray.h>
#include <TLine.h>
#include <TGSlider.h>
#include <TGCanvas.h>
#include <TLatex.h>
#include <TGButtonGroup.h>
#include <TGButton.h>
#include <TGLabel.h>
#include <TSystem.h>
#include <TGListBox.h>
#include <TColor.h>
#include <TMarker.h>
#include <TTimeStamp.h>
#include <TPolyMarker3D.h>
#include <TPolyLine3D.h>
#include <TGNumberEntry.h>
#include <TClass.h>
#include <TH2.h>

#include <iostream>
#include <vector>
#include <cstdlib>
#include <sstream>
#include <string>
#include <iomanip>

using namespace std;
using namespace view::Consts;

ClassImp(SdSimulationPlots);


#define round(x) (x<0? ceil( (x)-0.5 ) : floor( (x)+0.5 ))

SdSimulationPlots::SdSimulationPlots(TGCompositeFrame* main,
                              const StyleManager* styleManager,
                              const DetectorGeometry* const* geom,
                              const RecEvent* const* event, const bool* isMC) :
  fStyleManager(styleManager),
  fEvent (event),
  fIsMC(isMC),
  fDetectorGeometry(geom),
  fMainVertical1 (0),
  fMainVertical2 (0),
  fMainHorizontalLayout (0),
  fHasParticles(false),
  fHasPEDistributions(false),
  fHasVEMTraces(false)
{
  Int_t oldErrorLevel = gErrorIgnoreLevel;
  gErrorIgnoreLevel = kError;
  fMinMomentum=15.;
  fCheckPreviousId= 1000;

  fEventObjects= new TObjArray();
  fEventObjects->SetOwner(kTRUE);

  fPMTObjects= new TObjArray();
  fPMTObjects->SetOwner(kTRUE);

  fParticleObj= new TObjArray();
  fParticleObj->SetOwner(kTRUE);

  fPMTTracesObj= new TObjArray();
  fPMTTracesObj->SetOwner(kTRUE);

  fTracesObjects= new TObjArray();
  fTracesObjects->SetOwner(kTRUE);



  fMain= main;
  fMain->SetCleanup(kDeepCleanup);

  const UInt_t width = main->GetWidth();
  const UInt_t height = main->GetHeight();

  const UInt_t leftWidth = UInt_t(0.20*width);
  const UInt_t rightWidth = UInt_t(0.80*width);

  const UInt_t upperHeight = UInt_t(0.6*height);
  const UInt_t lowerHeight = UInt_t(0.5*height);



  TGLayoutHints* mainHorizontalLayout = new TGLayoutHints (kLHintsTop, 3, 3, 3, 3);
  TGLayoutHints* centered = new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,
                                              3,3,3,3);

  TGHorizontalFrame* horizontalMain = new TGHorizontalFrame(main, width, height);
  main->AddFrame(horizontalMain, mainHorizontalLayout);

  fMainVertical1 = new TGVerticalFrame(horizontalMain, leftWidth, height);
  horizontalMain->AddFrame(fMainVertical1, mainHorizontalLayout);

  fMainVertical2 = new TGVerticalFrame(horizontalMain, rightWidth, height);
  horizontalMain->AddFrame(fMainVertical2, mainHorizontalLayout);

  const UInt_t boxWidth=  UInt_t(leftWidth);
  fStationsListBox = new TGListBox(fMainVertical1, 8);
  fStationsListBox->Connect("Selected(Int_t)", "SdSimulationPlots",
                            this, "SelectStation(bool, bool, bool)");

  fStationsListBox->Resize(boxWidth, upperHeight);
  fMainVertical1->AddFrame(fStationsListBox, centered);



  //  TGVerticalFrame* horBut = new TGVerticalFrame(fVertFrame, leftWidth,
  //                                               UInt_t(0.10*height));
  // fVertFrame->AddFrame(horBut, fMainHorizontalLayout);


  TGVButtonGroup* particleButtons= new TGVButtonGroup(fMainVertical1, "Particles");
  fMainVertical1->AddFrame(particleButtons, centered);

  fMuonButton    = new TGCheckButton(particleButtons, "Muons",
                                     eSDMuons);
  fMuonButton->SetToolTipText("show muons");
  fMuonButton->SetState(kButtonDown);
  fElectronButton= new TGCheckButton(particleButtons, "Electrons",
                                     eSDElectrons);
  fElectronButton->SetToolTipText("show electrons");
  fElectronButton->SetState(kButtonDown);
  fPhotonButton  = new TGCheckButton(particleButtons, "Photons",
                                     eSDPhotons);

  fPhotonButton->SetToolTipText("show photons (NB: makes the browser slow...)");
  fOtherButton   = new TGCheckButton(particleButtons, "Other",
                                     eSDOtherParticles);
  fOtherButton->SetToolTipText("show all other");

  fMuonButton->Connect("Clicked()", "SdSimulationPlots",
                       this, "DoParticleButton()");
  fElectronButton->Connect("Clicked()", "SdSimulationPlots",
                           this, "DoParticleButton()");
  fPhotonButton->Connect("Clicked()", "SdSimulationPlots",
                         this, "DoParticleButton()");
  fOtherButton->Connect("Clicked()", "SdSimulationPlots",
                        this, "DoParticleButton()");


  TGVButtonGroup* tracesButtons= new TGVButtonGroup(fMainVertical1,"Traces");
  tracesButtons->SetRadioButtonExclusive();

  fVEMButton = new TGRadioButton(tracesButtons, "VEM", eVEM);
  fVEMButton->SetToolTipText("calibrated traces");
  fVEMButton->SetState(kButtonDown);

  fPEButton = new TGRadioButton(tracesButtons, "PE",
                                ePhotoelectrons);
  fPEButton->SetToolTipText("PE");

  fPartButton = new TGRadioButton(tracesButtons, "particles",
                                  eParticles);
  fPartButton->SetToolTipText("Particles");
  fPartButton->SetEnabled(false);

  fPartButton->Connect("Clicked()", "SdSimulationPlots",
                       this, "DoTracesButton()");
  fPEButton->Connect("Clicked()", "SdSimulationPlots",
                     this, "DoTracesButton()");
  fVEMButton->Connect("Clicked()", "SdSimulationPlots",
                      this, "DoTracesButton()");


  fMainVertical1->AddFrame(tracesButtons, centered);

  TGVerticalFrame* vertHor = new TGVerticalFrame(fMainVertical1, UInt_t(0.5*width),
                                                 UInt_t(0.1*height));

  TGHorizontalFrame* horHor = new TGHorizontalFrame(vertHor, UInt_t(0.5*width),
                                                    UInt_t(0.1*height));
  fMainVertical1->AddFrame(vertHor);
  vertHor->AddFrame(horHor);
  fTracesSlider = new TGDoubleHSlider(vertHor, 150, kDoubleScaleBoth,
                                      eTracesSliderLow,
                                      kHorizontalFrame,TColor::Number2Pixel(16),
                                      kFALSE, kFALSE);

  fTracesSlider->Connect("PositionChanged()", "SdSimulationPlots",
                         this, "DoTracesSlider(Int_t)");
  vertHor->AddFrame(fTracesSlider);
  fTracesSlider->SetRange(-5,5);
  fTimeInterval.push_back(-5.);
  fTimeInterval.push_back( 5.);
  fTracesSlider->SetPosition( fTimeInterval[0], fTimeInterval[1]);

  TGTextButton* particleUpdateButton= new TGTextButton(vertHor,
                                                       "update particles",
                                                       eParticlesUpdate);
  particleUpdateButton->Connect("Pressed()", "SdSimulationPlots",
                                this, "UpdateParticles()");
  vertHor->AddFrame(particleUpdateButton);



  TRootEmbeddedCanvas *fCanvasTracesEmb = new TRootEmbeddedCanvas("fCanvasTracesEmb",
                                                                  fMainVertical2,
                                                                  rightWidth,
                                                                  upperHeight);
  fMainVertical2->AddFrame(fCanvasTracesEmb, centered);
  fCanvasTraces= fCanvasTracesEmb->GetCanvas();


  TGHorizontalFrame* hor3 = new TGHorizontalFrame(fMainVertical2, rightWidth,
                                                  upperHeight);
  fMainVertical2->AddFrame(hor3,centered);


  const UInt_t tankWidth = UInt_t(0.4* rightWidth);
  TRootEmbeddedCanvas *fCanvasTankEmb = new TRootEmbeddedCanvas("fCanvasTankEmb",
                                                                hor3,
                                                                tankWidth,
                                                                lowerHeight);

  hor3->AddFrame(fCanvasTankEmb, centered);
  fCanvasTank= fCanvasTankEmb->GetCanvas();
  fCanvasTank->SetFillColor(fStyleManager->GetTankBackgroundColor());

  ostringstream cStat, cMat, cMed;
  cStat << "tubea";
  cMat << "mat";
  TGeoManager *tank = new TGeoManager ("station", "station");
  if (tank == 0) {
    cout << " ERROR in creating TGeoManager " << endl;
    exit (0);
  }
  TGeoMaterial *matVacuum = new TGeoMaterial ("Vacuum", 30. ,13 ,1000.,0.3 );
  //  TGeoMaterial *water = new TGeoMaterial ("Water", 30. ,13 ,1000.);
  TGeoMedium* fMaterial = new TGeoMedium ("Vacuum",2 , matVacuum);
  fSta = gGeoManager->MakeBox(cStat.str().c_str(), fMaterial, 2., 4., 2.);

  TGeoVolume* station= gGeoManager->MakeTube(cStat.str().c_str(),
                                             fMaterial, 1.78, 1.8, 1.2/2.);
  /*  <PMTPosition PMTId="1" unit="cm">  0.0    120.0  0. </PMTPosition>
      <PMTPosition PMTId="2" unit="cm">  103.92 -60.0  0. </PMTPosition>
      <PMTPosition PMTId="3" unit="cm"> -103.92 -60.0  0. </PMTPosition>*/

  TGeoVolume* pMT1 = gGeoManager->MakeSphere("pmt1", fMaterial,
                                             0.17, 0.18, 90, 180.);
  TGeoVolume* pMT2 = gGeoManager->MakeSphere("pmt2", fMaterial,
                                             0.17, 0.18, 90, 180.);
  TGeoVolume* pMT3 = gGeoManager->MakeSphere("pmt3", fMaterial,
                                             0.17, 0.18, 90, 180.);
  TGeoTranslation* trans0= new TGeoTranslation("trans0", 0, 0, 0);
  TGeoTranslation* trans1= new TGeoTranslation("trans1", 1.039, -0.6, 1.2/2.);
  TGeoTranslation* trans2= new TGeoTranslation("trans2", 0, 1.2, 1.2/2.);
  TGeoTranslation* trans3= new TGeoTranslation("trans3",-1.038 ,-0.6, 1.2/2.);

  fSta->AddNode(pMT1, 1, trans1);
  fSta->AddNode(pMT2, 2, trans2);
  fSta->AddNode(pMT3, 3, trans3);
  fSta->AddNode(station, 1, trans0);


  station->SetFillColor(10);
  station->SetLineColor(10);
  pMT1->SetFillColor(10);
  pMT1->SetLineColor(10);
  pMT2->SetFillColor(10);
  pMT2->SetLineColor(10);
  pMT3->SetFillColor(10);
  pMT3->SetLineColor(10);
  tank->SetTopVolume (fSta);
  gGeoManager->CloseGeometry();
  gGeoManager->SetVisLevel(2);


  fCanvasAllTraces = new TGCanvas(hor3, 0.6*rightWidth, UInt_t(lowerHeight));
  fCompFrame = new TGCompositeFrame(fCanvasAllTraces->GetViewPort(),
                                    10, 10, kHorizontalFrame,
                                    TGFrame::GetWhitePixel());
  fCompFrame->SetCleanup(kDeepCleanup);
  fCompFrame->SetLayoutManager(new TGTileLayout(fCompFrame, 8));

  fCanvasAllTraces->SetContainer(fCompFrame);
  hor3->AddFrame(fCanvasAllTraces,
                 new TGLayoutHints(kLHintsExpandX | kLHintsExpandY,
                                   0, 0, 2, 2));

  TGHorizontalFrame* horl = new TGHorizontalFrame(fMainVertical1,
                                                  leftWidth,
                                                  UInt_t(0.05*height));

  fMomentumTextField = new TGNumberEntry(horl, fMinMomentum,
                                         10, -1, TGNumberFormat::kNESRealOne,
                                         TGNumberFormat::kNEANonNegative);

  horl->AddFrame(new TGLabel(horl, "min. momentum (MeV): "),
                 new TGLayoutHints(kLHintsBottom,1,1,1,1));
  horl->AddFrame(fMomentumTextField, new TGLayoutHints(kLHintsBottom,0,0,0,0));
  fMainVertical1->AddFrame(horl);
  // return to old error level
  gErrorIgnoreLevel = oldErrorLevel;

}

SdSimulationPlots::~SdSimulationPlots()
{
  if (fTracesObjects->GetEntries())
    fTracesObjects->Delete();

  if (fPMTTracesObj->GetEntries())
    fPMTTracesObj->Delete();

  if (fEventObjects->GetEntries())
    fEventObjects->Delete();
  if (fPMTObjects->GetEntries())
    fPMTObjects->Delete();
  if (fParticleObj->GetEntries())
    fParticleObj->Delete();


  delete fEventObjects;
  delete fTracesObjects;
  delete fPMTTracesObj;
  delete fPMTObjects;
  delete fParticleObj;

  fMain->Cleanup();

}

void SdSimulationPlots::UpdateParticles(){

  if (fPEButton->IsOn())
    return;
  unsigned int stationId= fStationsListBox->GetSelected();
  DrawParticles(fCanvasTank, stationId, true);
  DrawParticleDistributions(stationId);
}


void SdSimulationPlots::SetTracesRange(Int_t /*pos*/, bool /*min*/){

  fCanvasTraces->cd();
  fCanvasTraces->SetEditable(true);
  double maximum= -1;
  for( int i=0; i<fPMTTracesObj->GetEntries(); ++i)
    if (fPMTTracesObj->At(i)->IsA()->InheritsFrom(TH1::Class())){
      TH1D& histo=*(TH1D *) fPMTTracesObj->At(i);
      maximum= max(maximum, histo.GetMaximum());
      histo.GetXaxis()->SetRangeUser(fTimeInterval[0], fTimeInterval[1]);
    }

  for( int i=0; i<fPMTTracesObj->GetEntries(); ++i)
    if (fPMTTracesObj->At(i)->IsA()->InheritsFrom(TH1::Class())){
      TH1D& histo=*(TH1D *) fPMTTracesObj->At(i);
      histo.GetYaxis()->SetRangeUser(0., maximum);
    }

  for(int i=1; i<4; ++i)
    fCanvasTraces->GetPad(i)->Modified();

  fCanvasTraces->Modified();
  fCanvasTraces->Update();
  fCanvasTraces->SetEditable(false);


}

int
SdSimulationPlots::GetColor(const double minTime, const double maxTime, const double time){
  double minCol= 90.;
  double maxCol= 100.;
  int color= 0;
  if (maxTime-minTime>0)
    color= (int)(minCol+ (maxCol-minCol)*(time-minTime)/(maxTime-minTime));

  return color;
}


void SdSimulationPlots::DoTracesSlider(Int_t pos){

  TGFrame *frm = (TGFrame *) gTQSender;
  int id=-1;
  if (frm->IsA()->InheritsFrom(TGDoubleSlider::Class())) {
    TGDoubleSlider *sl = (TGDoubleSlider*) frm;
    id = sl->WidgetId();
  }
  switch(id){
  case eTracesSliderLow:{
    fTimeInterval.clear();
    fTimeInterval.push_back(fTracesSlider->GetMinPosition());
    fTimeInterval.push_back(fTracesSlider->GetMaxPosition());
    SetTracesRange(pos, true);
  }
    break;
  }

}

void SdSimulationPlots::DoParticleButton(Int_t id){

  if (id == -1) {
    TGButton *btn = (TGButton *) gTQSender;
    id = btn->WidgetId();
  }

  ///stupid fix barrrrrrr
  if (fCheckPreviousId ==id){
    fCheckPreviousId=-1; return;
  }

  fCheckPreviousId =id;
  const bool traces= true;
  const bool particles= true;
  const bool distributions= true;

  switch (id){
    case eSDMuons:
    case eSDElectrons:
    case eSDPhotons:
    case eSDOtherParticles:
    case eSDAllParticles:
      fUpdateSlider= false;
      SelectStation(traces, particles, distributions);
      break;
    default:
      break;
  }

}


void SdSimulationPlots::DoTracesButton(Int_t id){


  if (id == -1) {
    TGButton *btn = (TGButton *) gTQSender;
    id = btn->WidgetId();
  }
  ///stupid fix barrrrrrr
  if (fCheckPreviousId ==id){
    fCheckPreviousId=-1;
    return;
  }
  fCheckPreviousId =id;

  //update only the traces
  const bool traces= true;
  const bool particles= false;
  const bool distributions= false;

  switch (id){
    case eVEM:
      SelectStation(traces, particles, distributions);
      break;
    case ePhotoelectrons:
      fUpdateSlider= true;
      SelectStation(traces, particles, distributions);
      break;
    case eParticles:
      fUpdateSlider= true;
      SelectStation(traces, particles, distributions);
      break;
    default:
      break;
  };
}



void SdSimulationPlots::DoNothing(){
}

void SdSimulationPlots::Clear()
{

  if (fTracesObjects->GetEntries())
    fTracesObjects->Delete();

  if (fPMTTracesObj->GetEntries())
    fPMTTracesObj->Delete();

  if (fEventObjects->GetEntries())
    fEventObjects->Delete();

  if (fPMTObjects->GetEntries())
    fPMTObjects->Delete();

  if (fParticleObj->GetEntries())
    fParticleObj->Delete();

#if ROOT_VERSION_CODE <= ROOT_VERSION(5,12,0)
  // note: remove acts on IDs (this is very inefficient and
  // will not work for station lists containt ID>maxStation
  const int maxStation = 20000;
  fStationsListBox->RemoveEntries(0,maxStation);
  fStationsListBox->Layout();
#else
  fStationsListBox->RemoveAll();
#endif

  fCanvasTraces->Clear();
  fCanvasTraces->GetCanvas()->Modified();
  fCanvasTraces->GetCanvas()->Update();

  fCompFrame->Cleanup();
  fCompFrame->Layout();

//  fCanvasAllTraces->Clear();
//  fCanvasAllTraces->Layout();

//   fCanvasAllTraces->MapSubwindows();
//   fCanvasAllTraces->Layout();

  fCanvasTank->Modified();
  fCanvasTank->Update();

}

void SdSimulationPlots::Update(){

  // temporarily switch of annoying TGeoManager Info()
  Int_t oldErrorLevel = gErrorIgnoreLevel;
  gErrorIgnoreLevel = kError;
  Clear();

  SetReferenceTime();
  fVEMButton->SetEnabled(fHasVEMTraces);
  if (fVEMButton->IsEnabled())
    fVEMButton->SetState(kButtonDown);
  fPEButton->SetEnabled(fHasPEDistributions);

  if (fHasStations){
    UpdateStationsList();
  }
  else{
    fCanvasTraces->SetEditable(kTRUE);
    fCanvasTraces->Divide(0, 1);
    fCanvasTraces->cd(1);
    TLatex * legend=new TLatex();
    legend->SetNDC();
    legend->SetTextAlign(12);
    legend->SetTextSize(0.05);
    legend->SetTextColor(kRed);
    legend->DrawLatex(0.4,0.5,"no stations available");
    fEventObjects->Add(legend);
    legend->Draw();
    fCanvasTraces->GetCanvas()->Modified();
    fCanvasTraces->GetCanvas()->Update();
    fCanvasTraces->SetEditable(kFALSE);
  }
  // return to old error level
  gErrorIgnoreLevel = oldErrorLevel;

}


void SdSimulationPlots::DrawParticleDistributions(unsigned int stId){

  if (fTracesObjects->GetEntries())
    fTracesObjects->Delete();
  fCompFrame->Cleanup();

  if (!fHasParticles)
    return;

  UInt_t width= UInt_t(0.9*fCanvasAllTraces->GetWidth());
  UInt_t height= UInt_t(0.9*fCanvasAllTraces->GetHeight());
  if (!(*fEvent)->GetSDEvent().HasSimStation(stId)){
    TRootEmbeddedCanvas *mytempCanv = new TRootEmbeddedCanvas("momentum", fCanvasAllTraces->GetContainer(),
                                                              width, height);
    fCanvasAllTraces->AddFrame(mytempCanv, new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3));
    mytempCanv->GetCanvas()->cd();
    TLatex * legend=new TLatex();
    legend->SetNDC();
    legend->SetTextAlign(12);
    legend->SetTextSize(0.035);
    legend->DrawLatex(0.4,0.5,"no particles");
    fEventObjects->Add(legend);
    legend->Draw();
    fCanvasAllTraces->MapSubwindows();
    fCanvasAllTraces->Layout();
    return;
  }
  const GenStation& genSt= *(*fEvent)->GetSDEvent().GetSimStationById(stId);
  const double MeV= 1e6;
  const vector<SDParticle>& particles= genSt.GetParticles();

  if (particles.empty()){
    TRootEmbeddedCanvas *mytempCanv = new TRootEmbeddedCanvas("momentum", fCanvasAllTraces->GetContainer(),
                                                              width, height);
    fCanvasAllTraces->AddFrame(mytempCanv, new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3));
//    mytempCanv->cd();
    TLatex * legend=new TLatex();
    legend->SetNDC();
    legend->SetTextAlign(12);
    legend->SetTextSize(0.035);
    legend->DrawLatex(0.4,0.5,"no particles");
    fEventObjects->Add(legend);
    legend->Draw();
    fCanvasAllTraces->MapSubwindows();
    fCanvasAllTraces->Layout();
    return;
  }


  const double maxmom= 5;
  const double minmom= fMinMomentum?log10(fMinMomentum)-0.01:-1;
  const int mombins=40;

  TH1D* momDistr= new TH1D("momDistr", "", mombins, minmom, maxmom);
  momDistr->GetXaxis()->SetTitle("log_{10}(p / MeV)");
  fTracesObjects->Add(momDistr);

  TH1D* momDistrMu= new TH1D("momDistrMu", "", mombins, minmom, maxmom);
  fTracesObjects->Add(momDistrMu);
  momDistrMu->SetLineColor(fStyleManager->GetMuonColor());
  momDistrMu->SetFillColor(fStyleManager->GetMuonColor());
  momDistrMu->SetFillStyle(fStyleManager->GetMuonStyle());

  TH1D* momDistrEl= new TH1D("momDistrEl", "", mombins, minmom, maxmom);
  fTracesObjects->Add(momDistrEl);
  momDistrEl->SetLineColor(fStyleManager->GetElectronColor());
  momDistrEl->SetFillColor(fStyleManager->GetElectronColor());
  momDistrEl->SetFillStyle(fStyleManager->GetElectronStyle());

  TH1D* momDistrGa= new TH1D("momDistrGa", "", mombins, minmom, maxmom);
  fTracesObjects->Add(momDistrGa);
  momDistrGa->SetLineColor(fStyleManager->GetPhotonColor());
  momDistrGa->SetFillColor(fStyleManager->GetPhotonColor());
  momDistrGa->SetFillStyle(fStyleManager->GetPhotonStyle());


  TH1D* momDistrOt= new TH1D("momDistrOt", "", mombins, minmom, maxmom);
  fTracesObjects->Add(momDistrOt);
  momDistrOt->SetLineColor(fStyleManager->GetOtherPartColor());
  momDistrOt->SetFillColor(fStyleManager->GetOtherPartColor());
  momDistrOt->SetFillStyle(fStyleManager->GetOtherPartStyle());


  TH1I* particleDistr= new TH1I("particleDistr", "", 13, 1, 14);
  particleDistr->GetXaxis()->SetLabelSize(0.08);

  particleDistr->GetXaxis()->SetBinLabel(1,"#gamma");
  particleDistr->GetXaxis()->SetBinLabel(2,"e^{+}");
  particleDistr->GetXaxis()->SetBinLabel(3,"e^{-}");
  particleDistr->GetXaxis()->SetBinLabel(4,"#mu^{+}");
  particleDistr->GetXaxis()->SetBinLabel(5,"#mu^{-}");
  particleDistr->GetXaxis()->SetBinLabel(6,"#tau^{+}");
  particleDistr->GetXaxis()->SetBinLabel(7,"#tau^{-}");
  particleDistr->GetXaxis()->SetBinLabel(8,"#pi^{0}");
  particleDistr->GetXaxis()->SetBinLabel(9,"#pi^{+}");
  particleDistr->GetXaxis()->SetBinLabel(10,"#pi^{-}");
  particleDistr->GetXaxis()->SetBinLabel(11,"n");
  particleDistr->GetXaxis()->SetBinLabel(12,"p^{#pm}");
  particleDistr->GetXaxis()->SetBinLabel(13,"?");

  fTracesObjects->Add(particleDistr);

  TH2D* momTimeDistr= new TH2D("momTimeDistr", "",
                               50, fTracesSlider->GetMinPosition(), fTracesSlider->GetMaxPosition(),
                               20, 0, 5);
  momTimeDistr->GetXaxis()->SetTitle("time [25 ns]");
  momTimeDistr->GetYaxis()->SetTitle("log_{10}(p / MeV)");
  fTracesObjects->Add(momTimeDistr);

  const unsigned int simNSecond= (*fEvent)->GetGenShower().GetCoreTimeNanoSecond();
  const unsigned int simSecond= (*fEvent)->GetGenShower().GetCoreTimeSecond();

  for(unsigned int part=0; part<particles.size();  ++part){
    double momentum= particles[part].GetMomentum().Mag()/MeV;
    if (momentum<fMinMomentum)
      continue;

    double partSecond= particles[part].GetSecond();
    double partNSecond=particles[part].GetNSecond();
    const double timeDiff= ( simSecond+ partSecond- fReferenceTime[0])*1e9/25.
      +(partNSecond+simNSecond- fReferenceTime[1])/25.;

    if (timeDiff<fTracesSlider->GetMinPosition() || timeDiff>fTracesSlider->GetMaxPosition())
      continue;

    momDistr->Fill(log10(momentum));

    switch(particles[part].GetType()){
    case ePhoton:
      if (! fPhotonButton->IsOn())
        continue;
      particleDistr->Fill(1);
      momDistrGa->Fill(log10(momentum));
      break;
    case ePositron:
      if (! fElectronButton->IsOn())
        continue;
      particleDistr->Fill(2);
      momDistrEl->Fill(log10(momentum));
      break;
    case eElectron:
      if (! fElectronButton->IsOn())
        continue;
      particleDistr->Fill(3);
      momDistrEl->Fill(log10(momentum));
      break;
    case eMuon    :
      if (!fMuonButton->IsOn())
        continue;
      particleDistr->Fill(4);
      momDistrMu->Fill(log10(momentum));
      break;
    case eAntiMuon:
      if (!fMuonButton->IsOn())
        continue;
      particleDistr->Fill(5);
      momDistrMu->Fill(log10(momentum));
      break;
    case eTau     :
      if (!fOtherButton->IsOn())
        continue;
      particleDistr->Fill(6);
      momDistrOt->Fill(log10(momentum));
      break;
    case eAntiTau :
      if (!fOtherButton->IsOn())
        continue;
      particleDistr->Fill(7);
      momDistrOt->Fill(log10(momentum));
      break;
    case ePiZero :
      if (!fOtherButton->IsOn())
        continue;
      particleDistr->Fill(8);
      momDistrOt->Fill(log10(momentum));
      break;
    case ePiPlus :
      if (!fOtherButton->IsOn())
        continue;
      particleDistr->Fill(9);
      momDistrOt->Fill(log10(momentum));
      break;
    case ePiMinus :
      if (!fOtherButton->IsOn())
        continue;
      particleDistr->Fill(10);
      momDistrOt->Fill(log10(momentum));
      break;
    case eNeutron:
      if (!fOtherButton->IsOn())
        continue;
      particleDistr->Fill(11);
      momDistrOt->Fill(log10(momentum));
      break;
    case eProton:
      if (!fOtherButton->IsOn())
        continue;
      particleDistr->Fill(12);
      momDistrOt->Fill(log10(momentum));
      break;
    default:
    {
      if (!fOtherButton->IsOn())
        continue;
      particleDistr->Fill(13);
    }
    }

    momTimeDistr->Fill(timeDiff, log10(particles[part].GetMomentum().Mag()/MeV));
  }

  TRootEmbeddedCanvas *mytempCanv =
    new TRootEmbeddedCanvas("momentum", fCanvasAllTraces->GetContainer(),
                            width, height);

//  fEventObjects->Add(mytempCanv);
  fCanvasAllTraces->AddFrame(mytempCanv, new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3));
  TCanvas* myScanv= mytempCanv->GetCanvas();

  myScanv->cd();
  //  myScanv->SetLogy();
  momDistr->Draw("");
  momDistrGa->Draw("same");
  momDistrEl->Draw("same");
  momDistrMu->Draw("same");
  momDistrOt->Draw("same");
  momDistr->Draw("same");

  myScanv->Modified();
  myScanv->Update();


  mytempCanv = new TRootEmbeddedCanvas("particles", fCanvasAllTraces->GetContainer(), width, height);
//  fEventObjects->Add(mytempCanv);
  fCanvasAllTraces->AddFrame(mytempCanv, new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3));
  myScanv= mytempCanv->GetCanvas();
  //  myScanv->SetLogy();
  myScanv->cd();
  particleDistr->SetFillColor(kYellow);
  particleDistr->SetBarWidth(0.5);
  particleDistr->SetBarOffset(0.25);
  particleDistr->Draw("BARP");
  myScanv->Modified();
  myScanv->Update();

  mytempCanv = new TRootEmbeddedCanvas("momTime", fCanvasAllTraces->GetContainer(), width, height);
//  fTracesObjects->Add(mytempCanv);
  fCanvasAllTraces->AddFrame(mytempCanv, new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3));
  myScanv= mytempCanv->GetCanvas();
  gStyle->SetPalette(1);
  myScanv->SetRightMargin(0.15);
  myScanv->SetLeftMargin(0.15);
  //  myScanv->SetLogz();
  myScanv->cd();
  momTimeDistr->Draw("colz");
  myScanv->Modified();
  myScanv->Update();

  gStyle->SetPalette(0);


  fCanvasAllTraces->MapSubwindows();
  fCanvasAllTraces->Layout();
}





void SdSimulationPlots::DrawParticles(TCanvas *myCanvas,
                                      unsigned int stId,
                                      bool /*updateSlider*/ ){

  if (fParticleObj->GetEntries())
    fParticleObj->RemoveAll();

  myCanvas->cd();
  fSta->Draw();
  if (!fHasParticles){
    TLatex * erlegend=new TLatex();
    erlegend->SetNDC();
    erlegend->SetTextAlign(12);
    erlegend->SetTextSize(0.055);
    erlegend->SetTextColor(4);
    erlegend->DrawLatex(0.4,0.5,"no particles");
    myCanvas->Modified();
    myCanvas->Update();
    return;
  }
  fMinMomentum =  fMomentumTextField->GetNumber();
  if (!(*fEvent)->GetSDEvent().HasSimStation(stId)){
    cout << "I don't do anything as I don't have the station" << endl;
    return;
  }

  const SdRecStation& recSt= *(*fEvent)->GetSDEvent().GetStationById(stId);
  const GenStation& genSt= *(*fEvent)->GetSDEvent().GetSimStationById(stId);
  const vector<SDParticle>& particles= genSt.GetParticles();

  if (particles.empty()){
    return;
  }


  const Detector & det= (*fEvent)->GetDetector();
  const TVector3 & StationPos =(recSt.IsDense()?
                                det.GetStationPosition(stId):
                                (*fDetectorGeometry)->GetStationPosition(stId));
  double posX = StationPos.X();
  double posY = StationPos.Y();
  double posZ = StationPos.Z();

  const double GeV= 1e6;

  //  double minTime=1000000; // unused
  //  double maxTime= -1000000; // unused

  const unsigned int simNSecond= (*fEvent)->GetGenShower().GetCoreTimeNanoSecond();
  const unsigned int simSecond= (*fEvent)->GetGenShower().GetCoreTimeSecond();

  //   maxTime=minTime+50; // unused

  for(unsigned int part=0; part<particles.size();  ++part){

    const double partSecond= particles[part].GetSecond();
    const double partNSecond=particles[part].GetNSecond();
    const double timeDiff= ( simSecond+ partSecond- fReferenceTime[0])*1e9/25.
      +(partNSecond+simNSecond - fReferenceTime[1])/25.;

//     if (updateSlider)
    if (timeDiff<fTracesSlider->GetMinPosition()
       || timeDiff>fTracesSlider->GetMaxPosition())
      continue;

    double partposX = particles[part].GetPosition().X()-posX;
    double partposY = particles[part].GetPosition().Y()-posY;
    double partposZ = particles[part].GetPosition().Z()-posZ-1.2/2.;
    double momX = particles[part].GetMomentum().X()/GeV;
    double momY = particles[part].GetMomentum().Y()/GeV;
    double momZ = particles[part].GetMomentum().Z()/GeV;

    if (particles[part].GetMomentum().Mag()/GeV<fMinMomentum) continue;
    int color;
    switch (particles[part].GetType()){
    case  ePhoton:
      if (fPhotonButton->IsOn())
        color=fStyleManager->GetPhotonColor();
      else
        continue;
      break;
    case eMuon:
    case eAntiMuon:
      if (fMuonButton->IsOn())
        color= fStyleManager->GetMuonColor();
      else
        continue;
      break;
    case eElectron:
    case ePositron:
      if (fElectronButton->IsOn())
        color= fStyleManager->GetElectronColor();
      else
        continue;
      break;
    default:
      if (fOtherButton->IsOn())
        color= 18;
      else
        continue;
      break;
    };


    TGeoTranslation *partpos = new TGeoTranslation(partposX,
                                                   partposY, partposZ);
    fParticleObj->Add(partpos);
    TPolyMarker3D *particleMark = new TPolyMarker3D (1, 20);
    fParticleObj->Add(particleMark);
    particleMark->SetMarkerColor (color);
    particleMark->SetMarkerSize (0.5);
    particleMark->SetPoint (0, partposX, partposY, partposZ);
    particleMark->Draw("same");

    TPolyLine3D *line3D = new TPolyLine3D(2);
    fParticleObj->Add(line3D);
    line3D->SetPoint(0, partposX, partposY, partposZ);
    line3D->SetPoint(1, partposX-momX/1e4, partposY-momY/1e4, partposZ-momZ/1e4);
    line3D->SetLineColor(color);
    line3D->Draw("same");

  }

  myCanvas->Modified();
  myCanvas->Update();
}


void SdSimulationPlots::UpdateStationsList(){


#if ROOT_VERSION_CODE <= ROOT_VERSION(5,12,0)
  // note: remove acts on IDs (this is very inefficient and
  // will not work for station lists containt ID>maxStation
  const int maxStation = 20000;
  fStationsListBox->RemoveEntries(0,maxStation);
  fStationsListBox->Layout();
#else
  fStationsListBox->RemoveAll();
#endif


  const std::vector<SdRecStation>& stations=
    (*fEvent)->GetSDEvent().GetStationVector();
  int n=0;
  ostringstream name;
  unsigned int firstId= 0;
  unsigned int lastId= 0;
  const TVector3 showerCore= (*fEvent)->GetGenShower().GetCoreSiteCS();
  const TVector3 showerAxis= (*fEvent)->GetGenShower().GetAxisSiteCS();


  for ( unsigned int iS=0;iS<stations.size();iS++){
    name << "ala bala portocala ia te du si manca para";
    if (stations[iS].IsAccidental())
      continue;
    name.str("");
    unsigned int currId= stations[iS].GetId();
    name << currId << " " << round(stations[iS].GetTotalSignal()*100)/100.;
    if (stations[iS].GetRecoveredSignal()!=0) {
      name << "(" << round(stations[iS].GetRecoveredSignal()*100)/100. << ")";
    }
    name << " VEM ";

    TVector3 stationPos;
    double dist=0;
    if (stations[iS].IsDense()){
      stationPos = (*fEvent)->GetDetector().GetStationPosition(currId);
      dist = (*fDetectorGeometry)->GetStationAxisDistance(stationPos, showerAxis, showerCore);
    }
    else
      dist = (*fDetectorGeometry)->GetStationAxisDistance(currId, showerAxis, showerCore);


    name << round( dist) << " m ";

    if (firstId == 0)
      firstId = stations[iS].GetId();

    fStationsListBox->InsertEntry(name.str().c_str(), currId, lastId);
    lastId = currId;
    ++n;
  }

  for ( unsigned int iS=0;iS<stations.size();iS++){
    if (!stations[iS].IsAccidental())
      continue;

    unsigned int currId= stations[iS].GetId();
    name.str("");
    name << currId << " " << round(stations[iS].GetTotalSignal()*100)/100.;

    if (stations[iS].GetRecoveredSignal()!=0) {
      name << "(" << (int)(stations[iS].GetRecoveredSignal()*100)/100. << ")";
    }
    name << " VEM ";

    TVector3 stationPos;
    double dist=0;

    if (stations[iS].IsDense()){
      stationPos= (*fEvent)->GetDetector().GetStationPosition(currId);
      dist= (*fDetectorGeometry)->GetStationAxisDistance(stationPos, showerAxis, showerCore);
    }
    else
      dist= (*fDetectorGeometry)->GetStationAxisDistance(currId, showerAxis, showerCore);

    name << round(dist) << " m ";


    if (stations[iS].IsDoublet()) name << " d";
    if (stations[iS].IsTriplet()) name << " t";
    if (firstId==0)
      firstId=currId;
    fStationsListBox->AddEntry(name.str().c_str(), currId);
    ++n;
  }

  fStationsListBox->MapSubwindows();
  fStationsListBox->Layout();
  fStationsListBox->Select(firstId);
  SelectStation(true, true, true);
}



void
SdSimulationPlots::SelectStation(bool traces, bool particles,
                                 bool distributions)
{

  const int stationId= fStationsListBox->GetSelected();
  if (stationId<=0)
    return;

  const SDEvent& sdEvent = (*fEvent)->GetSDEvent();

  if (traces && fHasVEMTraces){
    if (fPMTTracesObj->GetEntries())
      fPMTTracesObj->Delete();
    if ( fPMTObjects->GetEntries())
      fPMTObjects->Delete();

    fCanvasTraces->GetCanvas()->SetEditable(true);
    fCanvasTraces->Clear();
    fCanvasTraces->Divide(3, 1);

    for(int i=1; i<4; ++i) {
      if (fVEMButton->IsOn()){
        if ( sdEvent.HasSimStation(stationId) )
          DrawVEMTraces(fCanvasTraces, i,
                        *sdEvent.GetSimStationById(stationId),
                        *sdEvent.GetStationById(stationId));

      }
      else{
        if (fPEButton->IsOn() && fHasPEDistributions)
          DrawPEDistributions(fCanvasTraces, i,
                              *sdEvent.GetSimStationById(stationId),
                              fUpdateSlider);
        else
          if (fPartButton->IsOn() && fHasParticles)
            DrawPEDistributions(fCanvasTraces, i,
                                *sdEvent.GetSimStationById(stationId),
                                fUpdateSlider);
      }
    }

    fCanvasTraces->GetCanvas()->Modified();
    fCanvasTraces->GetCanvas()->Update();
    fTimeInterval.clear();
    fTimeInterval.push_back(fTracesSlider->GetMinPosition());
    fTimeInterval.push_back(fTracesSlider->GetMaxPosition());
    SetTracesRange(int (fTracesSlider->GetMinPosition()), true);

  }

  if (particles)
    DrawParticles(fCanvasTank, stationId);

  if (distributions && fHasParticles)
    DrawParticleDistributions(stationId);

}

void SdSimulationPlots::SetReferenceTime(){

  fReferenceTime.clear();
  fHasStations = false;
  fHasPEDistributions = false;
  fHasParticles = false;
  unsigned int evSecond= (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreTimeSecond();
  unsigned int evNSecond= (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreTimeNanoSecond();

  const bool hasRecSt= !(*fEvent)->GetSDEvent().GetStationVector().empty();
  const bool hasSimSt= (*fEvent)->GetSDEvent().HasGenStations();

  fHasStations =  hasRecSt || hasSimSt;

  if (hasRecSt)
    fHasVEMTraces=(*fEvent)->GetSDEvent().HasVEMTraces();


  if (hasSimSt){
    fHasPEDistributions = (*fEvent)->GetSDEvent().HasPEDistributions();
    fHasParticles =(*fEvent)->GetSDEvent().HasParticles();
  }


  if (evSecond == 0 && evNSecond == 0){
    evSecond= (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreTimeSecond();
    evNSecond= (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreTimeNanoSecond();
    if (evSecond == 0 && evNSecond == 0 && hasRecSt){
      evSecond= (unsigned int) (*fEvent)->GetSDEvent().GetStationVector()[0].GetTimeSecond();
      evNSecond= (unsigned int) (*fEvent)->GetSDEvent().GetStationVector()[0].GetTimeNSecond();
    }
  }

  fReferenceTime.push_back(evSecond);
  fReferenceTime.push_back(evNSecond);


}



void
SdSimulationPlots::DrawVEMTraces(TCanvas*myCanvas,
                                 int iTrace, const  GenStation& simStation,
                                 const  SdRecStation& recStation)
{

  if (!fHasVEMTraces)
    return;

  const unsigned int stationId = (unsigned int) simStation.GetId();
  if ( stationId == 0 )
    return;


  const double stSecond= recStation.GetTimeSecond();
  const double stNSecond= recStation.GetTimeNSecond();

  const double timeDiff= (stSecond- fReferenceTime[0])*1e9/25.+ (stNSecond - fReferenceTime[1])/25.;

  double minx=0;
  double maxx= 100;
  // ------------- muon trace --------------
  myCanvas->cd(iTrace);


  ostringstream histName;
  ostringstream histTitle;   histTitle<<"";
  TLegend * legend = new TLegend(0.667086,0.694277,0.933811,0.941209,NULL,"brNDC");
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);

  const int start=0;
  const int startSlot=recStation.GetSignalStartSlot();

  bool firstDrawn=false;
  vector<float> vem= recStation.GetVEMTrace(iTrace);
  int end = vem.size();
  if (vem.empty())
    return;
  if (false){
    histName<<"total1"<<stationId<<"_"<<iTrace;
    TH1F *trace_vem = new TH1F (histName.str().c_str(),histTitle.str().c_str(),
                                end-start, start+timeDiff-startSlot, end+timeDiff-startSlot);
    fPMTTracesObj->Add(trace_vem);
    if (vem.size()!=0)
      for (int j=start;j<end; ++j){
        trace_vem->Fill((j-startSlot)+timeDiff, vem[j]);
      }


    trace_vem->SetLineColor(6);
    trace_vem->GetYaxis()->SetTitle("Signal [VEM peak]");
    trace_vem->GetXaxis()->SetTitle("t [25 ns]");
    trace_vem->Draw(firstDrawn?"same":"");

    if (!firstDrawn){
      maxx= trace_vem->GetXaxis()->GetXmax();
      minx= trace_vem->GetXaxis()->GetXmin();
    }
    legend->AddEntry(trace_vem,"calib. trace","lf");
    firstDrawn=true;
  }

  if (fMuonButton->IsOn()){
    vector<float> muon= simStation.GetMuonTrace(iTrace);
    if (muon.empty())
      muon = recStation.GetPMTTraces(eMuonTrace,
                                     UShort_t(iTrace)).GetVEMComponent();

    histName << " muon " << stationId << "_" << iTrace;

    TH1F *muontrace = new TH1F (histName.str().c_str(),histTitle.str().c_str(),
                                end-start, start+timeDiff-startSlot, end+timeDiff-startSlot);
    fPMTTracesObj->Add(muontrace);
    const  bool hasmutrace=  (muon.size()!=0);
    if (hasmutrace)
      for (int j=start;j<end; ++j){
        muontrace->Fill((j-startSlot)+timeDiff, muon[j]);
      }

    muontrace->SetLineColor(fStyleManager->GetMuonColor());
    muontrace->SetFillColor(fStyleManager->GetMuonColor());
    muontrace->SetFillStyle(fStyleManager->GetMuonStyle());
    muontrace->GetYaxis()->SetTitle("Signal [VEM peak]");
    muontrace->GetXaxis()->SetTitle("t [25 ns]");

    muontrace->Draw(firstDrawn?"same":"");

    if (!firstDrawn){
      maxx= muontrace->GetXaxis()->GetXmax();
      minx= muontrace->GetXaxis()->GetXmin();
    }
    legend->AddEntry(muontrace,"#mu^{#pm}","lf");
    firstDrawn=true;
  }

  if (fElectronButton->IsOn()){
    vector<float> electron = simStation.GetElectronTrace(iTrace);
    if (electron.empty())
      electron = recStation.GetPMTTraces(eElectronTrace,
                                     UShort_t(iTrace)).GetVEMComponent();

    histName.str("");
    histName << "electron" << stationId << "_" << iTrace;

    TH1F *electrontrace = new TH1F (histName.str().c_str(),histTitle.str().c_str(),
                                    end-start, start+timeDiff-startSlot, end+timeDiff-startSlot);
    fPMTTracesObj->Add(electrontrace);

    const  bool haseltrace=  (electron.size()!=0);
    if (haseltrace)
      for (int j=start;j<end; ++j){
        electrontrace->Fill((j-startSlot)+timeDiff, electron[j]);
      }
    electrontrace->GetYaxis()->SetTitle("Signal [VEM peak]");
    electrontrace->GetXaxis()->SetTitle("t [25 ns]");

    electrontrace->SetLineColor(fStyleManager->GetElectronColor());
    electrontrace->SetFillColor(fStyleManager->GetElectronColor());
    electrontrace->SetFillStyle(fStyleManager->GetElectronStyle());
    electrontrace->Draw(firstDrawn?"same":"");
    legend->AddEntry(electrontrace,"e^{#pm}","lf");
    if (!firstDrawn){
      maxx= electrontrace->GetXaxis()->GetXmax();
      minx= electrontrace->GetXaxis()->GetXmin();
    }
    firstDrawn=true;
  }

  if (fPhotonButton->IsOn()){
    vector<float> photon= simStation.GetPhotonTrace(iTrace);
    if (photon.empty())
      photon = recStation.GetPMTTraces(ePhotonTrace,
                                       UShort_t(iTrace)).GetVEMComponent();

    histName.str("");
    histName << "photon" << stationId << "_" << iTrace;

    TH1F *photontrace = new TH1F (histName.str().c_str(),histTitle.str().c_str(),
                                  end-start, start+timeDiff-startSlot, end+timeDiff-startSlot);
    fPMTTracesObj->Add(photontrace);

    const  bool hasphotrace=  (photon.size()!=0);
    if (hasphotrace)
      for (int j=start;j<end; ++j){
        photontrace->Fill((j-startSlot)+timeDiff, photon[j]);
      }
    photontrace->SetLineColor(fStyleManager->GetPhotonColor());
    photontrace->SetFillColor(fStyleManager->GetPhotonColor());
    photontrace->SetFillStyle(fStyleManager->GetPhotonStyle());
    photontrace->GetYaxis()->SetTitle("Signal [VEM peak]");
    photontrace->GetXaxis()->SetTitle("t [25 ns]");
    photontrace->Draw(firstDrawn?"same":"");
    if (!firstDrawn){
      maxx= photontrace->GetXaxis()->GetXmax();
      minx= photontrace->GetXaxis()->GetXmin();
    }
    legend->AddEntry(photontrace,"#gamma","lf");
    firstDrawn=true;
  }

  fTracesSlider->SetRange(minx, maxx);
  fTracesSlider->SetPosition(minx, maxx);
  fTimeInterval.clear();
  fTimeInterval.push_back(fTracesSlider->GetMinPosition());
  fTimeInterval.push_back(fTracesSlider->GetMaxPosition());
  // fTracesSlider->Update();
  legend->Draw(firstDrawn?"same":"");
}






void SdSimulationPlots::DrawTraces(TGCanvas *myCanvas){

  if (fTracesObjects->GetEntries())
    fTracesObjects->Delete();
  fCompFrame->Cleanup();
  const std::vector<SdRecStation> & stations= (*fEvent)->GetSDEvent().GetStationVector();
  int startGen=800;
  int endGen=0;
  for ( unsigned int iS=0;iS<stations.size();iS++){
    const int start= stations[iS].GetSignalStartSlot();
    const int end= stations[iS].GetSignalEndSlot();
    if (start<startGen) startGen=start;
    if (end>endGen) endGen=end;
  }

  UInt_t width= UInt_t(0.86*myCanvas->GetWidth());
  UInt_t height= UInt_t(0.25*myCanvas->GetHeight());

  TRootEmbeddedCanvas *mytempCanv;
  for ( unsigned int iS=0;iS<stations.size();iS++){
    TString name;
    const int color=4;
    ostringstream title1;
    title1 << "CANVxxxx" << iS;
    mytempCanv = new TRootEmbeddedCanvas(title1.str().c_str(),
                                         myCanvas->GetContainer(),
                                         width, height);
    myCanvas->AddFrame(mytempCanv, new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3));
    TCanvas* myScanv= mytempCanv->GetCanvas();
    myScanv->cd();
    vector<float> vem;
    if ( stations[iS].GetVEMTrace(1).size()!=0)
      vem=stations[iS].GetVEMTrace(1);
    else {
      if ( stations[iS].GetVEMTrace(2).size()!=0)
        vem=stations[iS].GetVEMTrace(2);
      else
        if ( stations[iS].GetVEMTrace(3).size()!=0)
          vem=stations[iS].GetVEMTrace(3);
    }

    ostringstream title2;
    title2 << "tracexxxx";
    title2 << iS;

    TH1F *trace = new TH1F (title2.str().c_str(),"",
                            endGen-startGen, startGen, endGen);
    fTracesObjects->Add(trace);
    if (vem.size()!=0)
      for (int j=startGen;j<endGen; ++j)
        trace->Fill(j, vem[j]);
    trace->SetLineColor(color);
    trace->SetFillColor(color);
    trace->GetYaxis()->SetTitle("S [VEM peak]");
    trace->GetXaxis()->SetTitle("t [25 ns]");
    trace->Draw();
    myScanv->Modified();
    myScanv->Update();
  }

  myCanvas->MapSubwindows();
  myCanvas->Layout();

}


void SdSimulationPlots::DrawPEDistributions(TCanvas* myCanvas, int iTrace,
                                            const  GenStation& simStation,
                                            bool updateSlider){

  unsigned int stationId = (unsigned int) simStation.GetId();

  if (stationId==0) return;

  myCanvas->cd(iTrace);

  bool first= false;
  TH1D test;
  TLegend * legend = new TLegend(0.667086,0.694277,0.933811,
                                 0.941209,NULL,"brNDC");

  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);

  int miniter=  100000;
  int maxiter= -100000;
  bool atLeastOne= false;


  //  for ( unsigned int comp=0; comp<4; ++comp ){

//#warning implement the PE distributions display ...

  for ( vector<PETimeDistribution>::const_iterator peIter=
          simStation.GetPETimeDistributions().begin();
        peIter != simStation.GetPETimeDistributions().end(); ++peIter){

    const PETimeDistribution& timeDistr= *peIter;
    map<int, unsigned int> mymap= timeDistr.GetMap();

    if (mymap.empty() )
      continue;

    atLeastOne= true;
    for(map<int, unsigned int>::iterator iter= mymap.begin();
        iter!= mymap.end(); ++iter){
      if ((iter->first) <miniter)
        miniter= iter->first;
      if ((iter->first)>maxiter)
        maxiter= iter->first;
    }

  }
  if (!atLeastOne){
    cout << "Not even one PE time " << endl;
    return;
  }

  unsigned int comp = 0;
  for (vector<PETimeDistribution>::const_iterator peIter =
         simStation.GetPETimeDistributions().begin();
       peIter != simStation.GetPETimeDistributions().end(); ++peIter) {

    const PETimeDistribution& timeDistr = *peIter;

    if (int(timeDistr.GetPMTId()) != iTrace)
      continue;

    map<int, unsigned int> mymap= timeDistr.GetMap();

    if (mymap.empty() )
      continue;
    ++comp;

    const ETraceType trType=  timeDistr.GetComponent();

    ostringstream histName;
    histName << stationId << "comp" << comp << "_" << iTrace;

    TH1D* test = new TH1D(histName.str().c_str(), "", maxiter-miniter,
                          miniter, maxiter);
    fPMTTracesObj->Add(test);
    ostringstream legEntry;
    switch (trType){
    case eTotalTrace:
      legEntry << "total";
      test->SetLineColor(kBlack);
      break;
    case ePhotonTrace:
      if (!fPhotonButton->IsOn())
        continue;
      test->SetLineColor(fStyleManager->GetPhotonColor());
      test->SetFillColor(fStyleManager->GetPhotonColor());
      test->SetFillStyle(fStyleManager->GetPhotonStyle());
      legEntry << "#gamma" ;

      break;

    case eElectronTrace:
      if (!fElectronButton->IsOn())
        continue;
      test->SetLineColor(fStyleManager->GetElectronColor());
      test->SetFillColor(fStyleManager->GetElectronColor());
      test->SetFillStyle(fStyleManager->GetElectronStyle());
      legEntry << "e^{#pm}";
      break;

    case eMuonTrace:
      if (!fMuonButton->IsOn())
        continue;
      test->SetLineColor(fStyleManager->GetMuonColor());
      test->SetFillColor(fStyleManager->GetMuonColor());
      test->SetFillStyle(fStyleManager->GetMuonStyle());
      legEntry << "#mu^{#pm}" ;
      break;

    default:
//#warning fix the other traces...
      continue;
    };


    test->GetXaxis()->SetTitle("time [ns]");
    test->GetYaxis()->SetTitle("PE");


    for(map<int, unsigned int>::iterator iter= mymap.begin();
        iter!= mymap.end(); ++iter){
      test->Fill(iter->first, iter->second);
    }
    test->Draw(first? "same":"");
    legend->AddEntry("test", legEntry.str().c_str(), "l");
    legend->Draw("same");
    first=true;
  }
  if (updateSlider){
    fTimeInterval.clear();
    fTimeInterval.push_back(fTracesSlider->GetMinPosition());
    fTimeInterval.push_back(fTracesSlider->GetMaxPosition());
    fTracesSlider->SetRange(miniter, maxiter);
    fTracesSlider->SetPosition(miniter, maxiter);
  }
}


std::string SdSimulationPlots::PrintPostScript() {

  return string("");

}


