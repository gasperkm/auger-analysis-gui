#ifndef _include_SdSimulationPlots_h__
#define _include_SdSimulationPlots_h__

#include <TQObject.h>
#include <string>
#include <vector>
#include "VPlots.h"

class RecEvent;
class GenStation;
class SdRecStation;
class SDEvent;
class DetectorGeometry;
class StyleManager;

class TGVButtonGroup;
class TGRadioButton;
class TGCheckButton;

class TGCompositeFrame;
class TGHorizontalFrame;
class TGVerticalFrame;
class TGLayoutHints;
class TCanvas;
class TGCanvas;
class TGHSlider;
class TGListBox;
class TObjArray;
class TGeoVolume;
class TGDoubleHSlider; 
class TGNumberEntry;


class SdSimulationPlots : public TQObject, public VPlots {

private:
  SdSimulationPlots();

public:
  SdSimulationPlots (TGCompositeFrame *main, 
	   const StyleManager * styleManager,
	   const DetectorGeometry * const * geom,		  
	   const RecEvent * const * event, const bool * ismc);
    
  ~SdSimulationPlots();

  void Clear();
  void Update();
  std::string PrintPostScript();
  
  void DoParticleButton(Int_t id=-1); 
  void DoNothing(); 
  void DoTracesSlider(Int_t pos); 
  void DoTracesButton(Int_t id=-1);

  void SelectStation(bool traces=true, 
		     bool particles=true, bool distributions=true);    
  void UpdateParticles(); 

private:
  

  void UpdateStationsList();

  void DrawParticles(TCanvas *myCanvas, 
		     unsigned int stId, 
		     bool updateSlider=false); 
  
  void DrawTraces(TGCanvas* ); 
  void DrawPEDistributions(TCanvas* myCanvas, int iTrace, 
			   const  GenStation& simStation, bool updateSlider); 
  void DrawVEMTraces(TCanvas* myCanvas, int iTrace, 
		     const  GenStation& simStation, 
		     const  SdRecStation& recStation); 
  
  void DrawParticleDistributions(unsigned int stId); 
  void SetTracesRange(Int_t pos, bool min); 
  
  void SetReferenceTime(); 
  
  int GetColor(const double time1, const double time2, 
               const double time3); 

  const StyleManager * fStyleManager; // for plotting style options
  const RecEvent * const * fEvent;   // this is just the current event reference
  const bool * fIsMC;
  const DetectorGeometry * const *fDetectorGeometry;

  double  fMinMomentum;
  int fCheckPreviousId; 
  TGCompositeFrame *fMain;

  TGVerticalFrame *fMainVertical1;
  TGVerticalFrame *fMainVertical2;
  TGNumberEntry* fMomentumTextField;   
  TGCompositeFrame* fCompFrame;
  
  TGListBox *fStationsListBox; ///> stations list box

  TGLayoutHints *fMainHorizontalLayout; ///>general layout
  
  TCanvas *fCanvasTraces;
  TCanvas *fCanvasTank;
  TCanvas *fCanvasStations;
  TGCanvas *fCanvasAllTraces;

  TObjArray * fTracesObjects;
  TObjArray * fPMTObjects;
  TObjArray * fPMTTracesObj;
  TObjArray * fEventObjects;
  TObjArray * fParticleObj;
  
  TGeoVolume *fSta;
  
  TGCheckButton*  fMuonButton;
  TGCheckButton*  fElectronButton; 
  TGCheckButton*  fPhotonButton; 
  TGCheckButton*  fOtherButton; 

  
  TGRadioButton*  fVEMButton;
  TGRadioButton*  fPEButton; 
  TGRadioButton*  fPartButton; 
  TGDoubleHSlider* fTracesSlider; 

  std::vector<unsigned int> fReferenceTime; 
  std::vector<double> fTimeInterval; 

  bool fHasParticles; 
  bool fHasPEDistributions;
  bool fHasVEMTraces;
  bool fHasStations;
  bool fUpdateSlider;

  
  ClassDef (SdSimulationPlots, 2);
};
#endif
