#ifndef _include_StatusBar_h__
#define _include_StatusBar_h__

#include <TQObject.h>

class TGCompositeFrame;
class TGComboBox;
class StatusBar : public TQObject {

public:
  StatusBar(TGCompositeFrame *main, UInt_t width, UInt_t height);
  ~StatusBar();
  TGComboBox* GetEventList() {return fEventList;}

private:
    
  TGCompositeFrame* fMain;
  TGComboBox* fEventList;  
  ClassDef (StatusBar, 1);
};



#endif
