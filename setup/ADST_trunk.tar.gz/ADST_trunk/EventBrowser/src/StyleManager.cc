
#include "StyleManager.h"

#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

#include <TStyle.h>
#include <TROOT.h>
#include <TSystem.h>
#include <TColor.h>
#include <TString.h>
#include <TPRegexp.h>

StyleManager::StyleManager() :
  fIsInitialized(false),
  fStartUpTab(0),
  fNormalFontType(0),
  fBoldFontType(0),
  fPixelBorderColor(14),
  fBadPixelBorderColor(2),
  fMismatchedPixelBorderColor(4),
  fDefaultPixelColor(18),
  fPulseRecPixelColor(15),
  fDefaultPixelMarker(1),
  fSaturatedPixelFillStyle(3335),
  fFDSDPLineColor(2),
  fSDSDPLineColor(1),
  fMCSDPLineColor(4),
  fT3SDPLineColor(6),
  fFdColorPalette(true),
  f3DColorPalette(true),
  fFDTimeFitDataSize(0.5),
  fSDTimeFitDataSize(0.5),
  fFDTimeFitNoiseSize(0.4),
  fFDTimeFitDataType(20),
  fSDTimeFitDataType(21),
  fSDTimeFitStationType(24),
  fFDTimeFitNoiseType(24),
  fFDTimeFitLineColor(2),
  fSDTimeFitLineColor(1),
  fFDTimeMCLineColor(5),
  fProfileDataSize(0.8),
  fProfileDataType(20),
  fProfileFitLineColor(kRed+1),
  fProfileFitErrorColor(kRed-6),
  fProfileFitErrorFillStyle(3001),
  fShowFittedXmax(true),
  fFittedXmaxSize(0.8),
  fShowGeneratedXmax(true),
  fDrawProfileFitLegend(true),
  fGeneratedXmaxSize(0.8),
  fGeneratedProfileColor(4),
  fAerosolProfileColor(9),
  fAerosolProfileType(7),
  fLightMCLineSize(2),
  fLightFitLineSize(2),
  fTotalLightColor(1),
  fFluorLightColor(3),
  fMieCLightColor(8),
  fMultScattLightColor(6),
  fRayCLightColor(4),
  fDirectCLightColor(2),
  fRayCumulativeFillStyle(3001),
  fMieCumulativeFillStyle(3001),
  fMultScattCumulativeFillStyle(3001),
  fDirCumulativeFillStyle(3001),
  fSpotRecTraceColor(12),
  fSourceColor(12),
  fSDColor(1),
  fMCColor(50),
  fStartUpZoom(0.75),
  fAxisProjectionLength(5.),
  fTankInDAQColor(18),
  fTankDefaultColor(18),
  fTankNoiseColor(14),
  fTankBadColor(1),
  fSdGroundTimeStartColor(1),
  fSdGroundTimeStopColor(1),
  fSdGroundTimeResidualStartColor(1),
  fSdGroundTimeResidualStopColor(1),
  fSdShowerPlaneAzimuthStartColor(1),
  fSdShowerPlaneAzimuthStopColor(1),
  fTankTOTStyle(20),
  fTankDefaultStyle(24),
  fTankInDAQSize(0.8),
  fTankBadSize(0.8),
  fDefaultEyeColor(11),
  fEyeRadius(6000.),
  fLDFFuncColor(2),
  fLDFSilColor(38),
  fLDFAccColor(50),
  fLDFSatColor(2),
  fLDFSatRecColor(4),
  fLDFCandColor(1),
  fLDFOnArrayColor(1),
  fLDFMarkerSize(0.8),
  fRiseTimeColor(35),
  fFallTimeColor(46),
  fTimeResColor(1),
  fMuonColorPalette(true),

  f3DBackgroundColor(12),
  f3DColorStationActive(17),
  f3DColorStationInactive(15),
  fPhotonColor(5),
  fElectronColor(2),
  fMounColor(4),
  fOtherPartColor(18),
  fPhotonStyle(3001),
  fElectronStyle(3001),
  fMounStyle(3001),
  fOtherPartStyle(3001),
  fTankDenseColor(40),
  fTankBackgroundColor(40),
  fMaxZoom(20)

{

  ReadStyleFile();
  SetGlobalStyle();

}


StyleManager::~StyleManager() {

}

void StyleManager::ReadStyleFile(char * fileName) {

  ifstream in;
  if (fileName == NULL) {
    ostringstream stylePath;
    stylePath << ADST_CONFIG_DIR << "/default.sty";
    in.open(stylePath.str().c_str());
  }
  else
    in.open(fileName);

  string buffer;
  while (in.good() && !in.eof()) {
    getline(in, buffer);
    StripComments(buffer);
    if (TPRegexp("^\\s*$").MatchB(TString(buffer)))
      continue;

    stringstream line(buffer);
    string descriptor;
    line >> descriptor;

    if (descriptor == "startUpTab") {
      int tabNumber;
      line >> tabNumber;
      fStartUpTab = tabNumber;
    }
    else if (descriptor == "normalFontType") {
      int fType;
      line >> fType;
      fNormalFontType = fType;
    }
    else if (descriptor == "boldFontType") {
      int fType;
      line >> fType;
      fBoldFontType = fType;
    }
    else if (descriptor == "FDtimeFitDataSize") {
      double size;
      line >> size;
      fFDTimeFitDataSize = size;
    }
    else if (descriptor == "SDtimeFitDataSize") {
      double size;
      line >> size;
      fSDTimeFitDataSize = size;
    }
    else if (descriptor == "FDtimeFitNoiseSize") {
      double size;
      line >> size;
      fFDTimeFitNoiseSize = size;
    }
    else if (descriptor == "FDtimeFitDataType") {
      int type;
      line >> type;
      fFDTimeFitDataType = type;
    }
    else if (descriptor == "SDtimeFitDataType") {
      int type;
      line >> type;
      fSDTimeFitDataType = type;
    }
    else if (descriptor == "SDtimeFitStationType") {
      int type;
      line >> type;
      fSDTimeFitStationType = type;
    }
    else if (descriptor == "FDtimeFitNoiseType") {
      int type;
      line >> type;
      fFDTimeFitNoiseType = type;
    }
    else if (descriptor == "defaultPixelColor") {
      int color;
      line >> color;
      fDefaultPixelColor = color;
    }
    else if (descriptor == "pixelBorderColor") {
      int color;
      line >> color;
      fPixelBorderColor = color;
    }
    else if (descriptor == "badPixelBorderColor") {
      int color;
      line >> color;
      fBadPixelBorderColor = color;
    }
    else if (descriptor == "mismatchedPixelBorderColor") {
      int color;
      line >> color;
      fMismatchedPixelBorderColor = color;
    }
    else if (descriptor == "pulseRecPixelColor") {
      int color;
      line >> color;
      fPulseRecPixelColor = color;
    }
    else if (descriptor == "triggeredPixelColor") {
      int color;
      line >> color;
      fTriggeredPixelColor = color;
    }
    else if (descriptor == "defaultPixelMarkerColor") {
      int color;
      line >> color;
      fDefaultPixelMarker = color;
    }
    else if (descriptor == "saturatedPixelFillStyle") {
      int style;
      line >> style;
      fSaturatedPixelFillStyle = style;
    }
    else if (descriptor == "FDSDPLineColor") {
      int color;
      line >> color;
      fFDSDPLineColor = color;
    }
    else if (descriptor == "SDSDPLineColor") {
      int color;
      line >> color;
      fSDSDPLineColor = color;
    }
    else if (descriptor == "MCSDPLineColor") {
      int color;
      line >> color;
      fMCSDPLineColor = color;
    }
    else if (descriptor == "T3SDPLineColor") {
      int color;
      line >> color;
      fT3SDPLineColor = color;
    }
    else if (descriptor == "FDColorPalette") {
      int what;
      line >> what;
      if (what != 0)
        fFdColorPalette = true;
      else
        fFdColorPalette = false;
    }
    else if (descriptor == "3DColorPalette") {
      int what;
      line >> what;
      if (what != 0)
        f3DColorPalette = true;
      else
        f3DColorPalette = false;
    }
    else if (descriptor == "FDtimeFitLineColor") {
      int color;
      line >> color;
      fFDTimeFitLineColor = color;
    }
    else if (descriptor == "SDtimeFitLineColor") {
      int color;
      line >> color;
      fSDTimeFitLineColor = color;
    }
    else if (descriptor == "FDtimeMCLineColor") {
      int color;
      line >> color;
      fFDTimeMCLineColor = color;
    }
    else if (descriptor == "SDcolor") {
      int color;
      line >> color;
      fSDColor = color;
    }
    else if (descriptor == "SourceColor") {
      int color;
      line >> color;
      fSourceColor = color;
    }
    else if (descriptor == "MCcolor") {
      int color;
      line >> color;
      fMCColor = color;
    }
    else if (descriptor == "FDEyeColor") {
      int color, iEye;
      line >> iEye;
      line >> color;
      fFDEyeColor[iEye] = color;
    }
    else if (descriptor == "profileDataSize") {
      double size;
      line >> size;
      fProfileDataSize = size;
    }
    else if (descriptor == "fittedXmaxSize") {
      double size;
      line >> size;
      fFittedXmaxSize = size;
    }
    else if (descriptor == "generatedXmaxSize") {
      double size;
      line >> size;
      fGeneratedXmaxSize = size;
    }
    else if (TPRegexp("^apertureDataSize\\d*$").MatchB(TString(descriptor))) {
      double size;
      line >> size;
      fApertureDataSize.push_back(size);
    }
    else if (descriptor == "lightFitLineSize") {
      int size;
      line >> size;
      fLightFitLineSize = size;
    }
    else if (descriptor == "lightMCLineSize") {
      int size;
      line >> size;
      fLightMCLineSize = size;
    }
    else if (descriptor == "profileFitLineColor") {
      int color;
      line >> color;
      fProfileFitLineColor = color;
    }
    else if (descriptor == "profileFitErrorColor") {
      int color;
      line >> color;
      fProfileFitErrorColor = color;
    }
    else if (descriptor == "profileFitErrorFillStyle") {
      int style;
      line >> style;
      fProfileFitErrorFillStyle = style;
    }
    else if (descriptor == "generatedProfileColor") {
      int color;
      line >> color;
      fGeneratedProfileColor = color;
    }
    else if (descriptor == "aerosolProfileColor") {
      int color;
      line >> color;
      fAerosolProfileColor = color;
    }
    else if (descriptor == "aerosolProfileType") {
      int type;
      line >> type;
      fAerosolProfileType = type;
    }
    else if (descriptor == "totalLightColor") {
      int color;
      line >> color;
      fTotalLightColor = color;
    }
    else if (descriptor == "fluorLightColor") {
      int color;
      line >> color;
      fFluorLightColor = color;
    }
    else if (descriptor == "multScattLightColor") {
      int color;
      line >> color;
      fMultScattLightColor = color;
    }
    else if (descriptor == "mieCLightColor") {
      int color;
      line >> color;
      fMieCLightColor = color;
    }
    else if (descriptor == "rayCLightColor") {
      int color;
      line >> color;
      fRayCLightColor = color;
    }
    else if (descriptor == "directCLightColor") {
      int color;
      line >> color;
      fDirectCLightColor = color;
    }
    else if (descriptor == "rayleighCherFillStyle") {
      int style;
      line >> style;
      fRayCumulativeFillStyle = style;
    }
    else if (descriptor == "mieCherFillStyle") {
      int style;
      line >> style;
      fMieCumulativeFillStyle = style;
    }
    else if (descriptor == "multScattFillStyle") {
      int style;
      line >> style;
      fMultScattCumulativeFillStyle = style;
    }
    else if (descriptor == "eyeLightWithLCEff") {
      int color;
      line >> color;
      fEyeLightWithLCEffColor = color;
    }
    else if (descriptor == "telLightWithLCEff") {
      int color;
      line >> color;
      fTelLightWithLCEffColor = color;
    }
    else if (descriptor == "directCherFillStyle") {
      int style;
      line >> style;
      fDirCumulativeFillStyle = style;
    }
    else if (descriptor == "spotRecTraceColor") {
      int color;
      line >> color;
      fSpotRecTraceColor = color;
    }
    else if (descriptor == "showFittedXmax") {
      int flag;
      line >> flag;
      if (flag > 0)
        fShowFittedXmax = true;
      else
        fShowFittedXmax = false;
    }
    else if (descriptor == "showGeneratedXmax") {
      int flag;
      line >> flag;
      if (flag > 0)
        fShowGeneratedXmax = true;
      else
        fShowGeneratedXmax = false;
    }
    else if (descriptor == "drawProfileFitLegend") {
      int flag;
      line >> flag;
      if (flag > 0)
        fDrawProfileFitLegend = true;
      else
        fDrawProfileFitLegend = false;
    }
    else if (descriptor == "profileDataType") {
      int type;
      line >> type;
      fProfileDataType = type;
    }
    else if (descriptor == "startUpZoom") {
      double size;
      line >> size;
      fStartUpZoom = size;
    }
    else if (TPRegexp("^apertureDataType\\d*$").MatchB(TString(descriptor))) {
      int type;
      line >> type;
      fApertureDataType.push_back(type);
    }
    else if (descriptor == "tankInDAQColor") {
      int color;
      line >> color;
      fTankInDAQColor = color;
    }
    else if (descriptor == "tankDefaultColor") {
      int color;
      line >> color;
      fTankDefaultColor = color;
    }
    else if (descriptor == "tankNoiseColor") {
      int color;
      line >> color;
      fTankNoiseColor = color;
    }
    else if (descriptor == "SdGroundTimeStartColor") {
      int color;
      line >> color;
      fSdGroundTimeStartColor = color;
    }
    else if (descriptor == "SdGroundTimeStopColor") {
      int color;
      line >> color;
      fSdGroundTimeStopColor = color;
    }
    else if (descriptor == "SdGroundTimeResidualStartColor") {
      int color;
      line >> color;
      fSdGroundTimeResidualStartColor = color;
    }
    else if (descriptor == "SdGroundTimeResidualStopColor") {
      int color;
      line >> color;
      fSdGroundTimeResidualStopColor = color;
    }
    else if (descriptor == "SdShowerPlaneAzimuthStartColor") {
      int color;
      line >> color;
      fSdShowerPlaneAzimuthStartColor = color;
    }
    else if (descriptor == "SdShowerPlaneAzimuthStopColor") {
      int color;
      line >> color;
      fSdShowerPlaneAzimuthStopColor = color;
    }
    else if (descriptor == "tankTOTStyle") {
      int style;
      line >> style;
      fTankTOTStyle = style;
    }
    else if (descriptor == "tankDefaultStyle") {
      int style;
      line >> style;
      fTankDefaultStyle = style;
    }
    else if (descriptor == "defaultEyeColor") {
      int color;
      line >> color;
      fDefaultEyeColor = color;
    }
    else if (descriptor == "eyeRadius") {
      double length;
      line >> length;
      fEyeRadius = length;
    }
    else if (descriptor == "axisProjectionLength") {
      double length;
      line >> length;
      fAxisProjectionLength = length;
    }
    else if (descriptor == "tankInDAQSize") {
      double size;
      line >> size;
      fTankInDAQSize = size;
    }
    else if (descriptor == "LDFFuncColor") {
      int color;
      line >> color;
      fLDFFuncColor = color;}
    else if (descriptor == "LDFSilColor") {
      int color;
      line >> color;
      fLDFSilColor = color; }
    else if (descriptor == "LDFAccColor") {
      int color;
      line >> color;
      fLDFAccColor = color; }
    else if (descriptor == "LDFSatColor") {
      int color;
      line >> color;
      fLDFSatColor = color; }
    else if (descriptor == "LDFSatRecColor") {
      int color;
      line >> color;
      fLDFSatRecColor = color;}
    else if (descriptor == "LDFCandColor") {
      int color;
      line >> color;
      fLDFCandColor = color;}
    else if (descriptor == "LDFOnArrayColor") {
      int color;
      line >> color;
      fLDFOnArrayColor = color;}
    else if (descriptor == "LDFMarkerSize") {
      double color;
      line >> color;
      fLDFMarkerSize = color;}
    else if (descriptor == "RiseTimeColor") {
      int color;
      line >> color;
      fRiseTimeColor = color;}
    else if (descriptor == "FallTimeColor") {
      int color;
      line >> color;
      fFallTimeColor = color;}
    else if (descriptor == "TimeResColor") {
      int color;
      line >> color;
      fTimeResColor = color;}
    else if (descriptor == "MuonColorPalette") {
      int what;
      line >> what;
      if (what != 0)
        fMuonColorPalette = true;
      else
        fMuonColorPalette = false;
    }
    else if (descriptor == "3DBackgroundColor") {
      int color;
      line >> color;
      f3DBackgroundColor = color;}
    else if (descriptor == "3DColorStationActive") {
      int color;
      line >> color;
      f3DColorStationActive  = color;}
    else if (descriptor == "3DColorStationInactive") {
      int color;
      line >> color;
      f3DColorStationInactive = color;}
    else if (descriptor == "PhotonColor"){
      int color;
      line >> color;

      fPhotonColor = color;}
    else if (descriptor == "ElectronColor"){
      int color;
      line >> color;
      fElectronColor = color;
    }
    else if (descriptor== "MuonColor"){
      int color;
      line >> color;
      fMounColor = color;}

    else if (descriptor== "OtherPartColor"){
      int color;
      line >> color;
      fOtherPartColor = color;}

    else if (descriptor == "PhotonStyle"){
      int style;
      line >> style;
      fPhotonStyle = style;}
    else if (descriptor == "ElectronStyle"){
      int style;
      line >> style;
      fElectronStyle = style;
    }
    else if (descriptor== "MuonStyle"){
      int style;
      line >> style;
      fMounStyle = style;}
    else if (descriptor== "OtherPartStyle"){
      int style;
      line >> style;
      fOtherPartStyle = style;}
    else if (descriptor == "TankDenseColor"){
      int color;
      line >> color;
      fTankDenseColor = color;}
    else if (descriptor == "TankBackgroundColor"){
      int color;
      line >> color;
      fTankBackgroundColor = color;}
    else if (descriptor == "MaxZoom"){
      int color;
      line >> color;
      fMaxZoom  = color;}

    else if (descriptor != "\n" && descriptor != "")
      cerr << " StyleManager::ReadStyleFile() - ignoring unknown descriptor " << descriptor << endl;
    if (!in.good()) break;
  } // end while not eof

  // Default for the vectors
  if (fApertureDataType.empty()) {
    fApertureDataType.push_back(20);
  }
  if (fApertureDataSize.empty()) {
    fApertureDataSize.push_back(0.81);
  }

  fIsInitialized = true;
}

void StyleManager::SetGlobalStyle() {

  gROOT->SetStyle("Plain");
  gStyle->SetOptTitle(1);
  gStyle->SetTitleBorderSize(0);//border size of Title PavelLabel
  gStyle->SetTitleX(0.1f);
  gStyle->SetTitleW(0.8f);
  gStyle->SetOptStat(0);

  gStyle->SetLabelSize(0.05,"x");
  gStyle->SetTitleSize(0.055,"x");
  gStyle->SetLabelSize(0.05,"y");
  gStyle->SetTitleSize(0.055,"y");
  gStyle->SetLabelSize(0.05,"z");
  gStyle->SetTitleSize(0.055,"z");

  gStyle->SetTitleOffset(1.1, "Y");
  gStyle->SetTitleOffset(1.15, "X");
  gStyle->SetLabelOffset(0.01, "Y");
  gStyle->SetLabelOffset(0.01, "X");

  gStyle->SetPadLeftMargin(0.15);
  gStyle->SetPadRightMargin(0.05);
  gStyle->SetPadTopMargin(0.05);
  gStyle->SetPadBottomMargin(0.15);

  gStyle->SetPalette(1);

  const int font = fNormalFontType;
  gStyle->SetLabelFont(font, "XYZ");
  gStyle->SetTitleFont(font, "XYZ");
  gStyle->SetStatFont(font);
  gStyle->SetTitleFont(font);
  gStyle->SetTextFont(font);
  gStyle->GetAttDate()->SetTextFont(font);

}

int StyleManager::GetFDEyeColor(int iEye) const {
  std::map<int,int>::const_iterator eyeIter = fFDEyeColor.find(iEye);
  if(eyeIter != fFDEyeColor.end())
    return eyeIter->second;
  else
    return 1;
}

void StyleManager::UpdateMuonPalette() {
  if (fMuonColorPalette) {
    const unsigned int nPalette = 101;
    const unsigned int nCol = 2;
    double red[nCol]  = {0.5 , 0.8 };
    double green[nCol]= {1.  , 0.1 };
    double blue[nCol] = {1.  , 1.  };
    double frac[nCol] = {0.  , 1.  };
    fMuonMapColorRangeStart =
#if ROOT_VERSION_CODE < ROOT_VERSION(5,16,0)
      TStyle::
#else
      TColor::
#endif
      CreateGradientColorTable(nCol, frac, red, green, blue, nPalette);
    fMuonMapColorRangeLength = nPalette-1;
  }
  else {
    const unsigned int nPalette = 101;
    const unsigned int nCol = 2;
    double red[nCol]  = {0.,.9};
    double green[nCol]= {0.,.9};
    double blue[nCol] = {0.,.9};
    double frac[nCol] = {0.,1.};
    fMuonMapColorRangeStart =
#if ROOT_VERSION_CODE < ROOT_VERSION(5,16,0)
      TStyle::
#else
      TColor::
#endif
      CreateGradientColorTable(nCol, frac, red, green, blue, nPalette);
    fMuonMapColorRangeLength = nPalette-1;
  }
}

int StyleManager::CalculateMuonMapColor(int contourIter, int noOfContours) const {
  int colorIndexLength = fMuonMapColorRangeLength;
  if (contourIter<0) contourIter = 0;
  if (contourIter>fMuonMapColorRangeLength)
    contourIter = fMuonMapColorRangeLength;
  int colorIndex = fMuonMapColorRangeStart +
    int(colorIndexLength * contourIter/noOfContours);

  return colorIndex;
}

void StyleManager::StripComments(string& line) {
  TString buffer(line);
  TPRegexp comments("#.*$");
  comments.Substitute(buffer, "");
  line = string(buffer.Data());
}

double StyleManager::GetApertureDataSize(const unsigned int no)
const
{
  return no >= fApertureDataSize.size()
         ? fApertureDataSize[0]
         : fApertureDataSize[no];
}

int StyleManager::GetApertureDataType(const unsigned int no)
const
{
  return no >= fApertureDataType.size()
         ? fApertureDataType[0]
         : fApertureDataType[no];
}

