/**
   \file
   ChannelRRecDataQuantities quantities to be stored in ParameterStorage objects of ChannelRecData
   \version $Id: ChannelRRecDataQuantities.h 28752 2016-04-11 10:30:41Z aherve $
*/

#ifndef _revt_ChannelRRecDataQuantities_h_
#define _revt_ChannelRRecDataQuantities_h_

// static const char CvsId_revt_ChannelRRecDataQuantities[] = "$Id: ChannelRecData.h ";

/**
 * all quantities are in auger units
 * all times are with respect to the event time (REvent::GetHeader().GetTime(); )
 * if you add a quantity, please explain this quantity in a comment, and include in which module it is set
 */

namespace revt {
  
enum ChannelRRecDataQuantities {
  eRiseTime =  1,         /// rise time of found pulse [RdChannelRiseTimeCalculator]
  eAmplitudeLNATemperatureCorrectionFactor = 2, /// correction factor of amplitude dependence of LNA  [RdChannelChannelAmplitudeDependenceCorrector]
  eAmplitudeFilterAmpTemperatureCorrectionFactor = 3,  /// correction factor of amplitude dependence of filter amplifier [RdChannelChannelAmplitudeDependenceCorrector]

  eAERAScintSignalHeight =  4,          // strength of the scintillator signal according to definition [RdScintSignalReconstructor]
  eAERAScintIntergratedSignal =  5,     // integrated scintillator signal according to definition [RdScintSignalReconstructor]
  eAERAScintVEM =  6,                   // scintillator signal in Vertical Equivalent Muons according to definition [RdScintSignalReconstructor]
  eAERAScintDepositedEnergy =  7,       // deposited Energy in the Scintillator according to definition [RdScintSignalReconstructor]
  eAERAScintNoise  =  8,                // RMS of the Trace inside Noisewindow [RdScintSignalReconstructor] 
  eAERAScintSignalTime =  9,            // time at which the signal was found, relative to the event start time [RdScintSignalReconstructor]
  eAERAScintSignalWindowStart = 10,     // Start time for the Top Scint integration window [RdScintSignalReconstructor.xml] 
  eAERAScintSignalWindowStop = 11,      // Start time for the Top Scint integration window [RdScintSignalReconstructor.xml] 
  eAERAScintMinSignal =  12,            // Minimum signalheight for scintillator to be considered [RdScintSignalReconstructor.xml]
  eChannelSignalToNoise =  13,							// SNR calculated in [RdChannelRiseTimeCalculator]
 

};


}

#endif

// Configure (x)emacs for this file ...
// Local Variables:
// mode: c++
// compile-command: "make -C .. -k"
// End:
