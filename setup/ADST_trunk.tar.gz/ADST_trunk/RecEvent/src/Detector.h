// $Id: Detector.h 28752 2016-04-11 10:30:41Z aherve $
#ifndef __Detector_H
#define __Detector_H

#include <FdLidarData.h>
#include <FdCloudCameraData.h>
#include <FdAerosols.h>

#include <TObject.h>
#include <TVector3.h>
#include <TBits.h>
#include <TString.h>

#include <MeteoData.h>

#include <map>
#include <set>


// class to hold detector data

class Detector : public TObject {

public:

  enum MeteoSite {
    eCLF,
    eLosLeones,
    eLosMorados,
    eLomaAmarilla,
    eCoihueco,
    eBLS
  };

  typedef std::map<unsigned int, TVector3> DenseStPosMap;
  typedef std::map<int, TString> EyePointingIdMap;

  Detector();
  /// get stations bits currently active
  const TBits& GetActiveStations() const { return fActiveStations; }
  /// set stations currently active
  void SetActiveStations(const TBits& stationBits);

  /// get eyes currently active
  const TBits& GetActiveEyes() const { return fActiveEyes; }
  /// set eyes currently active
  void SetActiveEyes(const TBits& eyeBits);

  /// set if the event has the up time or is used the default always up
  void SetHasFdUpTime(const bool uptime);
  /// return true if event has the up time, false if is used the default always up
  bool HasFdUpTime() const;

  /// get GPS time offset between FD and SD
  double GetSDFDTimeOffset(const int iEye) const;
  /// set GPS time offset between FD and SD
  void SetFDSDTimeOffset(const int iEye, const double offset);

  /// get the temperature  [K]
  double GetTemperature() const { return fTemperature; }
  /// set the temperature [K]
  void SetTemperature(const double temperature) { fTemperature = temperature; }
  /// get the pressure [bar]
  double GetPressure() const { return fPressure; }
  /// set the pressure [bar]
  void SetPressure(const double pressure) { fPressure = pressure; }

  void SetTemperaturePressureGPSSeconds(const int time)
  { fTemperaturePressureGPSSeconds = time; }
  int GetTemperaturePressureGPSSeconds() const
  { return fTemperaturePressureGPSSeconds; }

  /// weather station information is used for T and p
  void SetHasWeatherStationData() { fIsWS = true; }

  /// weather station information is used for T and p
  bool HasWeatherStationData() const { return fIsWS; }

  /// set mirrors in DAQ
  void SetMirrorsInDAQ(const int iEye, const TBits& statusBits);
  /// get mirrors in DAQ as TBits
  const TBits& GetMirrorsInDAQ(const int iEye) const;
  /// check if mirror was in DAQ
  bool IsInDAQ(const int iEye, const int iTel) const;

  /// set Mie scattering data base status
  void SetHasMieDatabase() { fHasMieDatabase = true; }
  /// return true if Mie database was available and used
  bool HasMieDatabase() const { return fHasMieDatabase; }
  /// set Mie scattering data base status
  void SetHasGDASDatabase() { fHasGDASDatabase = true; }
  /// return true if Mie database was available and used
  bool HasGDASDatabase() const { return fHasGDASDatabase; }

  /// ask for VAOD of eye iEye
  bool HasVAOD(const int iEye) const;
  /// ask for any VAOD
  bool HasVAODs() const;
  /// get VAOD at reference height (as set in RecDataWriter.xml)
  double GetVAODAtReferenceHeight(const int iEye) const;
  /// get VAODs at reference height (as set in RecDataWriter.xml)
  const std::map<int, double>& GetVAODsAtReferenceHeight() const;
  /// set VAOD at reference height (as set in RecDataWriter.xml)
  void SetVAODAtReferenceHeight(const int iEye, const double vaod);

  /// returns true if OverallQuality DB was available
  bool HasOverallQualityDatabase() const { return fHasQDB; }
  /// get horizontal uniformity
  double GetQDBHorizonalUniformity() const { return fQDBHorizonalUniformity; }
  /// get cloud coverage
  double GetQDBCloudCoverage() const { return fQDBCloudCoverage; }
  /// get minimum cloud base height [m]
  double GetQDBMinCloudBaseHeight() const { return fQDBMinCloudBaseHeight; }
  /// get minimum cloud base depth [g/cm^2]
  double GetQDBMinCloudBaseDepth() const { return fQDBMinCloudBaseDepth; }
  /// set overall quality DB status
  void SetHasOverallQualityDatabase() { fHasQDB = true; }
  /// set horizontal uniformity
  void SetQDBHorizontalUniformity(const double c) { fQDBHorizonalUniformity = c; }
  /// set cloud coverage
  void SetQDBCloudCoverage(const double c) { fQDBCloudCoverage = c; }
  /// set minimum cloud base [m]
  void SetQDBMinCloudBaseHeight(const double c) { fQDBMinCloudBaseHeight = c; }
  /// set minimum cloud base [g/cm^2]
  void SetQDBMinCloudBaseDepth(const double c) { fQDBMinCloudBaseDepth = c; }

  /// ask for aerosol data of eye iEye
  bool HasAerosolData(const int iEye) const;
  /// ask for aerosol data of any eye
  bool HasAerosolData() const;
  /// get aerosols for eye iEye
  const FdAerosols& GetAerosolData(const int iEye) const;
  /// get all aerosols
  const std::map<int, FdAerosols>& GetAerosolData() const;
  /// set aerosols for eye iEye
  void SetAerosolData(const int iEye, const FdAerosols& aerosols);

  /// Get a telescope's pointing id (cf. TelescopeGeometry)
  TString GetPointingId(const int iEye, const int iTel) const;
  /// Get all telescope pointing ids for an eye (cf. EyeGeometry)
  EyePointingIdMap GetPointingIdsForEye(const int iEye) const;
  /// Set a telescope's pointing id (cf. TelescopeGeometry)
  void SetPointingId(const int iEye, const int iTel, const TString& pointingId);

  /// Lidar Stuff ----
  bool HasLidarData(const int iEye) const;
  bool HasLidarData() const;

  const FdLidarData& GetLidarData(const int iEye) const;

  void SetLidarData(const int iEye, const FdLidarData& thisData);

  /// Cloud Stuff ----
  bool HasCloudCameraData(const int iEye) const;
  bool HasCloudCameraData() const;
  const FdCloudCameraData& GetCloudCameraData(const int iEye) const;
  void SetCloudCameraData(const int iEye, const FdCloudCameraData& thisData);

  bool HasCloudMap() const { return !fCloudPixelData.empty(); }
  bool HasCloudFraction(const unsigned int pixelId) const
  { return fCloudPixelData.find(pixelId) != fCloudPixelData.end(); }
  double GetCloudFraction(const unsigned int pixelId) const
  { return (fCloudPixelData.find(pixelId)->second)/100.; }
  void SetCloudFraction(const unsigned int pixelId, const double fraction)
  { fCloudPixelData[pixelId] = Char_t(fraction * 100); }
  void ClearCloudMap() { return fCloudPixelData.clear(); }

  /// set corrector ring status of telescopes
  void SetCorrectorRingStatus(const int iEye, const TBits& statusBits);
  /// get corrector ring status of telescopes
  bool HasCorrectorRing(const int iEye, const int iTel) const;

  int GetGlobalPixelIndex(const int eyeId, const int telId, const int pixelId) const;

  void AddMismatchedPixel(const int eyeId, const int telId, const int pixelId);
  bool IsMismatchedPixel(const int eyeId,
                         const int telId, const int pixelId) const;

  void AddBadPixel(const int eyeId, const int telId, const int pixelId);
  bool IsBadPixel(const int eyeId, const int telId, const int pixelId) const;
  const std::set<int>& GetBadPixelSet() const { return fBadPixels; }

  void SetDenseStation(const unsigned int iStation,
                       const double x, const double y, const double z);
  /// get station coordinates in Site CS [km]
  const TVector3& GetStationPosition(const unsigned int i) const;
  TVector3& GetStationPosition(const unsigned int i);

  /// get weather information as function of weather station and information type
  float GetWeatherInformation(const MeteoSite site, const WeatherInfoType wtype) const;

  float GetWeatherInformation(const WeatherInfoType wtype) const;

  bool HasWeatherInformation() const {return !fMeteo.empty();}
  const std::vector<MeteoData>& GetWeatherInformationVector() const {return fMeteo;}

  /// add weather information of one meteo site
  void AddMeteoSiteInfo(const MeteoData data) { fMeteo.push_back(data); }

  void SetRdStation(const unsigned int iAnt,
                    const double x, const double y, const double z);
  const TVector3& GetRdStationPosition(const unsigned int i) const;
  TVector3& GetRdStationPosition(const unsigned int i);

private:
  TBits fActiveStations;
  TBits fActiveEyes;
  std::map<int, TBits> fTelDAQBits;
  std::map<int, double> fSDFDTimeOffset;
  std::map<int, TBits> fCorrectorRingStatus;
  std::map<int, double> fVAODs;
  std::set<int> fMismatchedPixels;
  std::set<int> fBadPixels;
  std::map<int, EyePointingIdMap> fTelPointingIds;
  DenseStPosMap fDenseStations;
  double fTemperature;
  double fPressure;
  Int_t fTemperaturePressureGPSSeconds;

  bool fIsWS; // if it is from the weather station

  bool fHasMieDatabase;
  bool fHasGDASDatabase;

  bool fHasFdUpTime;

  bool fHasQDB;
  double fQDBHorizonalUniformity;
  double fQDBCloudCoverage;
  double fQDBMinCloudBaseHeight;
  double fQDBMinCloudBaseDepth;

  std::map<int, FdLidarData> fLidarInformation;
  std::map<int, FdCloudCameraData> fCloudCameraInformation;
  std::map<int, FdAerosols> fAerosols;
  std::map<unsigned int, Char_t> fCloudPixelData;

  std::vector<MeteoData> fMeteo;

  DenseStPosMap fAntennasPos;

  ClassDef(Detector, 26);

};


#endif
