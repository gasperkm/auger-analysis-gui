// $Id: EyeGeometry.cc 29056 2016-07-05 16:39:37Z munger $
#include <Detector.h>
#include <EyeGeometry.h>
#include <TelescopeGeometry.h>

#include <cmath>
#include <string>
#include <iostream>

using namespace std;


EyeGeometry::EyeGeometry() :
  fEyeCoordinates(0,0,0),
  fBackWallAngle(0),
  fEyePhiZ(0),
  fEyeThetaZ(0)
  //fEyeName
  //fEyeNameAbbreviation
{
  // fast access init
  for (unsigned int i = 0; i < 3; ++i)
    for (unsigned int j = 0; j < 3; ++j) {
      fTransformerSiteLocal[i][j] = 0;
      fTransformerLocalSite[i][j] = 0;
    }
  fTransformerInit = false;
}


/// set eye x-coordinate in Site CS [km]
EyeGeometry::EyeGeometry(const Double_t x, const Double_t y, const Double_t z,
                         const Double_t phi, const Double_t phiEye, const Double_t thetaEye,
                         const std::string& eyeName, const std::string& eyeNameAbbr) :
  fEyeCoordinates(x, y, z),
  fBackWallAngle(phi),
  fEyePhiZ(phiEye),
  fEyeThetaZ(thetaEye),
  fEyeName(eyeName),
  fEyeNameAbbreviation(eyeNameAbbr)
{
  // fast access init
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) {
      fTransformerSiteLocal[i][j] = 0;
      fTransformerLocalSite[i][j] = 0;
    }
  fTransformerInit = false;
}


/// get maximum and minimum angles of mirror
void
EyeGeometry::GetMinMaxPhi(const TBits& miBits, Double_t& minPhi, Double_t& maxPhi)
  const
{
  Detector::EyePointingIdMap pointingIds;
  const EyeGeometry::MinMaxFOV_t minmax = CalculateMinMaxFOV(miBits, pointingIds);

  maxPhi = minmax.MaxPhi;
  minPhi = minmax.MinPhi;
}


void
EyeGeometry::GetMinMaxOmega(const TBits& miBits, Double_t& minOmega, Double_t& maxOmega)
  const
{
  Detector::EyePointingIdMap pointingIds;
  const EyeGeometry::MinMaxFOV_t minmax = CalculateMinMaxFOV(miBits, pointingIds);

  maxOmega = minmax.MaxOmega;
  minOmega = minmax.MinOmega;
}


void
EyeGeometry::GetMinMaxPhi(const TBits& miBits, const Detector::EyePointingIdMap& pointingIds,
                          Double_t& minPhi, Double_t& maxPhi)
  const
{
  const EyeGeometry::MinMaxFOV_t minmax = CalculateMinMaxFOV(miBits, pointingIds);

  maxPhi = minmax.MaxPhi;
  minPhi = minmax.MinPhi;
}


void
EyeGeometry::GetMinMaxOmega(const TBits& miBits, const Detector::EyePointingIdMap& pointingIds,
                            Double_t& minOmega, Double_t& maxOmega)
  const
{
  const EyeGeometry::MinMaxFOV_t minmax = CalculateMinMaxFOV(miBits, pointingIds);

  maxOmega = minmax.MaxOmega;
  minOmega = minmax.MinOmega;
}


vector<UShort_t>
EyeGeometry::GetTelescopeIDs()
  const
{
  vector<UShort_t> telIDs;
  for (ConstTelescopeIterator iTel = fTelescopes.begin();
       iTel != fTelescopes.end(); ++iTel)
    telIDs.push_back(iTel->first);

  return telIDs;
}


void
EyeGeometry::AddTelescope(const UInt_t telid,
                          const map<TString, Double_t>& telElevations,
                          const map<TString, Double_t>& telAzimuths,
                          const UInt_t nFADC, const Double_t bFADC,
                          const map<TString, TelescopeGeometry::PixelList_t>& telPixPhis,
                          const map<TString, TelescopeGeometry::PixelList_t>& telPixOmegas)
{
  AddTelescope(telid,
               TelescopeGeometry(telElevations, telAzimuths, nFADC, bFADC,
                                 telPixPhis, telPixOmegas));
}


void
EyeGeometry::AddTelescope(const UInt_t telid, const TelescopeGeometry& tel)
{
  if (fTelescopes.find(telid) != fTelescopes.end()) {
    cerr << "ERROR: Telescope id=" << telid << " already exists!" << endl;
    return;
  }

  fTelescopes.insert(make_pair(telid, tel));
}


TelescopeGeometry&
EyeGeometry::GetTelescope(const UInt_t id)
{
  const TelescopeList_t::iterator it = fTelescopes.find(id);
  if (it != fTelescopes.end())
    return it->second;
  else {
    cerr << "ERROR: Telescope id=" << id << " not available!" << endl;
    static TelescopeGeometry empty;
    return empty;
  }
}


const TelescopeGeometry&
EyeGeometry::GetTelescope(const UInt_t id)
  const
{
  const TelescopeList_t::const_iterator it = fTelescopes.find(id);
  if (it != fTelescopes.end())
    return it->second;
  else {
    cerr << "ERROR: Telescope id=" << id << " not available!" << endl;
    static const TelescopeGeometry empty;
    return empty;
  }
}


EyeGeometry::MinMaxFOV_t
EyeGeometry::CalculateMinMaxFOV(const TBits& miBits,
                                const Detector::EyePointingIdMap& pointingIds)
  const
{
  EyeGeometry::MinMaxFOV_t minmax;

  bool first = true;

  for (ConstTelescopeIterator iTel = fTelescopes.begin();
       iTel != fTelescopes.end(); ++iTel) {

    const UInt_t telId = iTel->first;

    if (miBits.TestBitNumber(telId)) {
      // Fetch this telescope's pointing id
      const Detector::EyePointingIdMap::const_iterator pIt = pointingIds.find(telId);
      const TString pId = (pIt == pointingIds.end()) ? "" : pIt->second;

      const Double_t maxPhiTel = iTel->second.GetPixelMaxPhi(pId);
      const Double_t minPhiTel = iTel->second.GetPixelMinPhi(pId);
      const Double_t maxOmegaTel = iTel->second.GetPixelMaxOmega(pId);
      const Double_t minOmegaTel = iTel->second.GetPixelMinOmega(pId);

      if (first) {
        minmax.MinPhi = minPhiTel;
        minmax.MaxPhi = maxPhiTel;
        minmax.MinOmega = minOmegaTel;
        minmax.MaxOmega = maxOmegaTel;
        first = false;
      } else {
        if (minPhiTel < minmax.MinPhi)
          minmax.MinPhi = minPhiTel;
        if (maxPhiTel > minmax.MaxPhi)
          minmax.MaxPhi = maxPhiTel;
        if (minOmegaTel < minmax.MinOmega)
          minmax.MinOmega = minOmegaTel;
        if (maxOmegaTel > minmax.MaxOmega)
          minmax.MaxOmega = maxOmegaTel;
      }
    }

  }

  return minmax;
}


// warning: z-rotation not applied!
TVector3
EyeGeometry::GetApproximateEyeVecFromSiteVec(TVector3 sv, const bool isPosition)
  const
{
  cerr << "GetApproximateEyeVecFromSiteVec is deprecated!" << endl;

  // translate
  if (isPosition)
    sv -= fEyeCoordinates;

  // rotate
  const double sinAng = sin(fBackWallAngle);
  const double cosAng = cos(fBackWallAngle);
  const double xEye = cosAng*sv.X() + sinAng*sv.Y();
  const double yEye = -sinAng*sv.X() + cosAng*sv.Y();
  return TVector3(xEye, yEye, sv.Z());
}


void
EyeGeometry::InitTransformerMatrices()
  const
{
  //cout << " InitTransformerMatrices " << endl;
  //cout << "angles back " << fBackWallAngle*180/3.141 << " theta " << fEyeThetaZ*180/3.141 << " phi " << fEyePhiZ*180/3.141 << endl;

  // local eye CS in site CS

  // z direction
  const double sinThetaZ = sin(fEyeThetaZ);
  fTransformerLocalSite[2][0] = sinThetaZ*cos(fEyePhiZ);
  fTransformerLocalSite[2][1] = sinThetaZ*sin(fEyePhiZ);
  fTransformerLocalSite[2][2] = cos(fEyeThetaZ);

  // x direction
  const double tmp = fTransformerLocalSite[2][1] / fTransformerLocalSite[2][2];
  fTransformerLocalSite[0][0] = 0.5*tmp - sqrt(0.25*tmp*tmp + 1); // second solution ???
  fTransformerLocalSite[0][1] = 0; // X points to east on the tangential ellipsoid plane !
  fTransformerLocalSite[0][2] = sqrt(1 - fTransformerLocalSite[0][0]*fTransformerLocalSite[0][0]);

  // y direction
  cross(fTransformerLocalSite[2], fTransformerLocalSite[0],
        fTransformerLocalSite[1]);

  // site CS in local CS (inverse matrix)
  for (unsigned int i = 0; i < 3; ++i)
    for (unsigned int j = 0; j < 3; ++j)
      fTransformerSiteLocal[i][j] = fTransformerLocalSite[i][j];

  const bool result = invert3by3(fTransformerSiteLocal);

  if (!result)
    cerr << "\n\n"
            " !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
            "\n"
            " matrix inversion not possible! Detector geometry invalid!"
            "\n"
            " !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\n";
  else
    fTransformerInit = true;
}


void
EyeGeometry::cross(const double a[3], const double b[3], double c[3])
{
  c[0] = a[1]*b[2] - a[2]*b[1];
  c[1] = a[2]*b[0] - a[0]*b[2];
  c[2] = a[0]*b[1] - a[1]*b[0];
}


/****************************************************
 *
 * inversion of 3-by-3 matrix A
 *
 * (returns false if matrix singular)
 ***************************************************/
bool
EyeGeometry::invert3by3(double a[3][3])
{
  const double kSmall = 1e-80;

  const double determinant = a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])
                            -a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])
                            +a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]);

  const double absDet = fabs(determinant);

  if (absDet < kSmall) {
    cout << " invert3by3: Error-matrix singular (absDet=" << absDet << ')' << endl;
    return false;
  }

  double b[3][3];

  b[0][0] = a[1][1]*a[2][2] - a[1][2]*a[2][1];
  b[1][0] = a[1][2]*a[2][0] - a[2][2]*a[1][0];
  b[2][0] = a[1][0]*a[2][1] - a[1][1]*a[2][0];

  b[0][1] = a[0][2]*a[2][1] - a[2][2]*a[0][1];
  b[1][1] = a[0][0]*a[2][2] - a[2][0]*a[0][2];
  b[2][1] = a[0][1]*a[2][0] - a[0][0]*a[2][1];

  b[0][2] = a[0][1]*a[1][2] - a[1][1]*a[0][2];
  b[1][2] = a[0][2]*a[1][0] - a[1][2]*a[0][0];
  b[2][2] = a[0][0]*a[1][1] - a[0][1]*a[1][0];

  for (unsigned int i = 0; i < 3; ++i)
    for (unsigned int j = 0; j < 3; ++j)
      a[i][j] = b[i][j] / determinant;

  return true;
}


TVector3
EyeGeometry::multiply(const double m[3][3], const TVector3& v)
{
  TVector3 out(0, 0, 0);
  for (unsigned int i = 0; i < 3; ++i)
    for (unsigned int j = 0; j < 3; ++j)
      out[i] += v[j] * m[j][i];
  return out;
}


TVector3
EyeGeometry::TransformEyeToSite(const TVector3& vec)
  const
{
  return TransformLocalToSite(TransformEyeToLocal(vec));
}


TVector3
EyeGeometry::TransformSiteToEye(const TVector3& vec)
  const
{
  return TransformLocalToEye(TransformSiteToLocal(vec));
}


TVector3
EyeGeometry::TransformEyeToLocal(const TVector3& vec)
  const
{
  const double sinAng = sin(-fBackWallAngle);
  const double cosAng = cos(-fBackWallAngle);
  return TVector3( cosAng*vec.X() + sinAng*vec.Y(),
                  -sinAng*vec.X() + cosAng*vec.Y(),
                   vec.Z());
}


TVector3
EyeGeometry::TransformLocalToEye(const TVector3& vec)
  const
{
  const double sinAng = sin(fBackWallAngle);
  const double cosAng = cos(fBackWallAngle);
  return TVector3( cosAng*vec.X() + sinAng*vec.Y(),
                  -sinAng*vec.X() + cosAng*vec.Y(),
                   vec.Z());
}


TVector3
EyeGeometry::TransformSiteToLocal(const TVector3& vec)
  const
{
  if (!fTransformerInit)
    InitTransformerMatrices();
  const TVector3 vecShift = vec - fEyeCoordinates;
  return multiply(fTransformerSiteLocal, vecShift);
}


TVector3
EyeGeometry::TransformLocalToSite(const TVector3& vec)
  const
{
  if (!fTransformerInit)
    InitTransformerMatrices();
  return vec + fEyeCoordinates;
}


bool
EyeGeometry::MergeEyeFrom(const EyeGeometry& source)
{
  bool retval = false;

  for (ConstTelescopeIterator srcTelIt = source.TelescopesBegin();
       srcTelIt != source.TelescopesEnd(); ++srcTelIt) {

    const UInt_t srcTelId = srcTelIt->first;

    // eye doesn't exist yet, copy it
    if (!HasTelescope(srcTelId)) {
      fTelescopes[srcTelId] = srcTelIt->second;
      retval = true;
    } else // telescope exists, merge telescope pointings
      retval = GetTelescope(srcTelId).MergeTelescopeFrom(srcTelIt->second) || retval;

  }

  return retval;
}
