// $Id: EyeGeometry.h 20044 2011-12-23 20:01:16Z darko $
#ifndef __EyeGeometry_H
#define __EyeGeometry_H

#include <TelescopeGeometry.h>
#include <Detector.h>

#include <TObject.h>
#include <TVector3.h>
#include <TString.h>
#include <TBits.h>
#include <TMath.h>

#include <map>
#include <string>


//  class to hold FD event

class EyeGeometry : public TObject {

public:
  typedef std::map<UInt_t, TelescopeGeometry> TelescopeList_t;
  typedef TelescopeList_t::iterator TelescopeIterator;
  typedef TelescopeList_t::const_iterator ConstTelescopeIterator;
  struct MinMaxFOV_t {
    Double_t MinPhi;
    Double_t MinOmega;
    Double_t MaxPhi;
    Double_t MaxOmega;
  };

public:
  EyeGeometry();
  EyeGeometry(const Double_t x, const Double_t y, const Double_t z,
              const Double_t phi, const Double_t phiEye, const Double_t thetaEye,
              const std::string& eyeName, const std::string& eyeNameAbbr);

  /// get maximum and minimum angles of mirror
  void GetMinMaxPhi(const TBits& miBits,
                    Double_t& minPhi, Double_t& maxPhi) const;
  void GetMinMaxOmega(const TBits& miBits,
                      Double_t& minOmega, Double_t& maxOmega) const;
  void GetMinMaxPhi(const TBits& miBits, const Detector::EyePointingIdMap& pointingIds,
                    Double_t& minPhi, Double_t& maxPhi) const;
  void GetMinMaxOmega(const TBits& miBits, const Detector::EyePointingIdMap& pointingIds,
                      Double_t& minOmega, Double_t& maxOmega) const;

  /// get the number of mirrors of eye
  UShort_t GetNumberOfMirrors() const { return fTelescopes.size(); }

  /// get eye pos in Site CS [m]
  const TVector3& GetEyePos() const { return fEyeCoordinates; }

  /// get eye name
  const TString& GetEyeName() const { return fEyeName; }

  /// get abbreviated eye name
  const TString& GetEyeNameAbbr() const { return fEyeNameAbbreviation; }

  /// get eye backwall angle [rad]
  Double_t GetBackWallAngle() const { return fBackWallAngle; }

  /// get local eye vertical vector phi
  Double_t GetEyePhiZ() const { return fEyePhiZ; }

  /// get local eye vertical vector theta
  Double_t GetEyeThetaZ() const { return fEyeThetaZ; }

  /// get list of valid tel IDs
  std::vector<UShort_t> GetTelescopeIDs() const;

  /// xy rotation from Site to Eye coordinate system
  /// translation is applied if isPosition=true
  TVector3 GetApproximateEyeVecFromSiteVec(TVector3 siteVec, const bool isPosition) const;
  TVector3 TransformEyeToSite(const TVector3& siteVec) const;
  TVector3 TransformSiteToEye(const TVector3& siteVec) const;
  TVector3 TransformEyeToLocal(const TVector3& siteVec) const;
  TVector3 TransformLocalToEye(const TVector3& siteVec) const;
  TVector3 TransformSiteToLocal(const TVector3& siteVec) const;
  TVector3 TransformLocalToSite(const TVector3& siteVec) const;

  void AddTelescope(const UInt_t telid,
                    const std::map<TString, Double_t>& telElevations,
                    const std::map<TString, Double_t>& telAzimuths,
                    const UInt_t nFADC, const Double_t bFADC,
                    const std::map<TString, TelescopeGeometry::PixelList_t>& telPixPhis,
                    const std::map<TString, TelescopeGeometry::PixelList_t>& telPixOmegas);
  void AddTelescope(const UInt_t telid, const TelescopeGeometry& tel);
  bool HasTelescope(const UInt_t id) const { return fTelescopes.find(id) != fTelescopes.end(); }
  TelescopeGeometry& GetTelescope(const UInt_t id);
  const TelescopeGeometry& GetTelescope(const UInt_t id) const;
  TelescopeIterator TelescopesBegin() { return fTelescopes.begin(); }
  TelescopeIterator TelescopesEnd() { return fTelescopes.end(); }
  ConstTelescopeIterator TelescopesBegin() const { return fTelescopes.begin(); }
  ConstTelescopeIterator TelescopesEnd() const { return fTelescopes.end(); }

  /** Merge the telescopes and telescope pointings with those
   *  of another EyeGeometry and store them in the object.
   *  Returns ture if the object was modified.
   *  The object into which the information is merged takes precedence
   *  on conflicts.
   */
  bool MergeEyeFrom(const EyeGeometry& source);

private:
  MinMaxFOV_t CalculateMinMaxFOV(const TBits& MiBits,
                                 const Detector::EyePointingIdMap& pointingIds) const;
  void InitTransformerMatrices() const;
  static bool invert3by3(double a[3][3]);
  static void cross(const double a[3], const double b[3], double c[3]);
  static TVector3 multiply(const double m[3][3], const TVector3& v);

private:
  TelescopeList_t fTelescopes;

  TVector3 fEyeCoordinates;
  Double_t fBackWallAngle;
  Double_t fEyePhiZ;
  Double_t fEyeThetaZ;
  TString fEyeName;
  TString fEyeNameAbbreviation;

  // fast access pfusch ---------
  mutable double fTransformerLocalSite[3][3]; //!
  mutable double fTransformerSiteLocal[3][3]; //!
  mutable bool fTransformerInit; //!
  // -----------------------------

  ClassDef(EyeGeometry, 5);

};


#endif
