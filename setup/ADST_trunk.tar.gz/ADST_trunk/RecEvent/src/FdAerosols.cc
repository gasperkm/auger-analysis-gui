#include <FdAerosols.h>

#include <iostream>
using namespace std;


ClassImp(FdAerosols);


//=============================================================================
/*!
  \class   FdAerosols
  \brief   Aerosol information from the Aerosol database

  \version 1.0
  \date    December 12 2008
  \author  S. Mueller
*/
//=============================================================================
