#ifndef __FdCloudCameraData_H
#define __FdCloudCameraData_H

#include <map>
#include <vector>

#include <TObject.h>


/**
 * Cloud camera information
 * Each fdet::Eye may obtain this class which holds the cloud fraction
 * known due to the cloud camera.
 * The information is stored in a map of telescopes associated with
 * a vector of cloud fraction. To keep storage in ADST low, we save a Char_t
 * (e.g. Char_t(5) == 5%) but return Float_t.
 */

class FdCloudCameraData : public TObject {

public:
  Bool_t HasCloudFraction(const Int_t telId, const Int_t pixelId) const;
  Float_t GetCloudFraction(const Int_t telId, const Int_t pixelId) const;
  void SetCloudFraction(const Int_t telId, const Int_t pixelId, const Float_t cloudFraction);

  Bool_t IsEmpty() { return fCloudMap.empty(); }

private:
  ///map<telescopeId,vector<pixelId> > The vector contains cloud fraction for each pixel (e.g. 1,...,440)
  std::map<int, std::vector<Char_t> > fCloudMap;

  ClassDef(FdCloudCameraData, 1);

};


#endif
