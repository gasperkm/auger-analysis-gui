#ifndef __FdGenApertureLight_H
#define __FdGenApertureLight_H

#include <FdApertureLight.h>


//=============================================================================
//
//  reconstructed profile data definition
//
//=============================================================================

class FdGenApertureLight : public FdApertureLight {

public:
  // class holding all variables dealing with the
  // shower light at aperture

private:
  ///time of arrival at camera \f$[100ns]\f$
  //Int_t fDiaT0;

  ///bin with of time traces in \f$[100ns]\f$
  //Double_t fDia_dT;

  ClassDef(FdGenApertureLight, 2);

};


#endif
