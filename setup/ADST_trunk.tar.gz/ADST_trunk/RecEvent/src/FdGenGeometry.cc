// $Id: FdGenGeometry.cc 20035 2011-12-22 02:46:23Z darko $
#include <FdGenGeometry.h>


ClassImp(FdGenGeometry);


//=============================================================================
/*!
  \class   FdGenGeometry
  \brief   Generated shower axis parameters (SDP, \f$\chi_0\f$ etc.)

  \version 1.0
  \date    Jan 20 2004
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/
//=============================================================================
