#ifndef __FdGeometry_h__
#define __FdGeometry_h__

#include <TObject.h>
#include <TVector3.h>

#include <cmath>


class FdGeometry : public TObject {

public:
  FdGeometry();

  // setters

  void SetSDP(const Double_t theta, const Double_t phi) { fSDPTheta = theta; fSDPPhi = phi; }

  void SetAxis(const Double_t t0, const Double_t rp, const Double_t chi0)
  { fT0 = t0; fRp = rp; fChi0 = chi0;}

  // getters

  /// get SDP theta [rad]
  Double_t GetSDPTheta() const { return fSDPTheta; }
  /// get SDP phi [rad]
  Double_t GetSDPPhi() const { return fSDPPhi; }
  /// get SDP vector
  TVector3 GetSDP() const;

  /// get T0 [ns]
  Double_t GetT0() const { return fT0; }
  /// get Rp [m]
  Double_t GetRp() const { return fRp; }
  /// get Chi0 [rad]
  Double_t GetChi0() const { return fChi0; }
  /// calculate distance from eye to core
  Double_t GetCoreEyeDistance() const { return fRp / std::sin(fChi0); }

private:
  Double_t fSDPTheta;
  Double_t fSDPPhi;

  Double_t fT0;
  Double_t fRp;
  Double_t fChi0;

  ClassDef(FdGeometry, 1);

};


#endif
