// $Id: FdLidarData.cc 20035 2011-12-22 02:46:23Z darko $
#include <FdLidarData.h>
#include <FdRecLevel.h>

#include <iostream>
using namespace std;


ClassImp(FdLidarData);


//=============================================================================
/*!
  \class   FdLidarData
  \brief   Cloud information from the Lidar database

  \version 1.0
  \date    June 13 2007
  \author  M. Greeno, F. Sch&uuml;ssler, I. Maris, R. Ulrich, M. Unger
*/
//=============================================================================

FdLidarData::FdLidarData() :
  fCloudCoverage(-1),
  fCloudHeight(-1),
  fCloudDepth(-1),
  fCloudThickness(-1),
  fCloudSlantThickness(-1),
  fCloudVAOD(-1),
  fLidarRange(-1)
{ }


FdLidarData::FdLidarData(const Double_t cloudCoverage, const Double_t cloudHeight,
                         const Double_t cloudDepth, const Double_t cloudThickness,
                         const Double_t cloudSlantThickness, const Double_t cloudVAOD,
                         const Double_t range)
{
  fCloudCoverage = cloudCoverage;
  fCloudHeight = cloudHeight;
  fCloudDepth = cloudDepth;
  fCloudThickness = cloudThickness;
  fCloudSlantThickness = cloudSlantThickness;
  fCloudVAOD = cloudVAOD;
  fLidarRange = range;
}
