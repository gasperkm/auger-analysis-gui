#ifndef __FdLidarData_H
#define __FdLidarData_H

#include <TObject.h>


//  Lidar cloud information

class FdLidarData : public TObject {

public:
  FdLidarData();
  FdLidarData(const Double_t cloudCoverage, const Double_t cloudHeight,
              const Double_t cloudDepth, const Double_t cloudThickness,
              const Double_t cloudSlantThickness, const Double_t cloudVAOD,
              const Double_t range); //should be extended with all available Lidar-Variables + LidarRange

  //getters
  Double_t GetCloudCoverage() const { return fCloudCoverage; } ///< returns cloud coverage in percent

  Double_t GetCloudHeight() const { return fCloudHeight; } /// get cloud height from Lidar database [m]

  Double_t GetCloudThickness() const { return fCloudThickness; } /// get cloud thickness from Lidar database [m]

  // slant depth is requiring either FD or SD geometry, -1 if none available
  Double_t GetCloudDepth() const { return fCloudDepth; } /// get cloud depth from Lidar database [g/cm^2]

  // slant thickness is requiring either FD or SD geometry, -1 if none available
  Double_t GetCloudSlantThickness() const { return fCloudSlantThickness; } /// get cloud thickness from Lidar database [g/cm^2]

  Double_t GetCloudVAOD() const { return fCloudVAOD; } /// get cloud VAOD [m]

  Double_t GetLidarRange() const { return fLidarRange; } /// get lidar range variable

  //setters
  void SetCloudCoverage(const Double_t coverage) { fCloudCoverage = coverage; } /// set cloud coverage [percent]

  void SetCloudHeight(const Double_t height) { fCloudHeight = height; } /// set cloud height [m]

  void SetCloudDepth(const Double_t depth) { fCloudDepth = depth; } /// set cloud depth [g/cm^2]

  void SetCloudThickness(const Double_t thickness) { fCloudThickness = thickness; } /// set cloud thickness [m]

  void SetCloudSlantThickness(const Double_t thickness) { fCloudSlantThickness = thickness; } /// set cloud thickness [g/cm^2]

  void SetCloudVAOD(const Double_t vaod) { fCloudVAOD = vaod; } /// set cloud VAOD [m]

  void SetLidarRange(const Double_t range) { fLidarRange = range; } /// set lidar range variable

private:
  Double_t fCloudCoverage;
  Double_t fCloudHeight;
  Double_t fCloudDepth;
  Double_t fCloudThickness;
  Double_t fCloudSlantThickness;
  Double_t fCloudVAOD;
  Double_t fLidarRange;

  ClassDef(FdLidarData, 2);

};


#endif
