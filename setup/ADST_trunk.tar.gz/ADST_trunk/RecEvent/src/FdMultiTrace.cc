// $Id: FdMultiTrace.cc 26094 2014-07-16 11:39:36Z darko $
#include <FdMultiTrace.h>


ClassImp(FdMultiTrace);
