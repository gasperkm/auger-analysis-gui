#ifndef __FdMultiTrace_H_
#define __FdMultiTrace_H_

#include <FdTrace.h>

#include <TObject.h>

#include <map>

//  trace data definition

class FdMultiTrace : public TObject {

public:
  bool HasComponent(const int source) const { return fTraceComponents.count(source); }

  const FdTrace& GetComponent(const int source) const { return fTraceComponents.find(source)->second; }
  FdTrace& GetComponent(const int source) { return fTraceComponents[source]; }

  void AddComponent(const FdTrace& t, const int source) { fTraceComponents[source] = t; }

private:
  std::map<int, FdTrace> fTraceComponents;

  ClassDef(FdMultiTrace, 1);

};


#endif
