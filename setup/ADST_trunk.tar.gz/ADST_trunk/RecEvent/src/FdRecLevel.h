#ifndef __FdRecLevel_H
#define __FdRecLevel_H


// pixel reconstruction level

enum EPixelStatus {

  /// background pixel
  eBackGroundPix = 0,

  /// triggered pixel
  eTriggeredPix,

  /// reconstructed pixel
  ePulseRecPix,

  /// pixel part of SDP
  eSDPRecPix,

  /// pixel part of time fit
  eTimeFitPix

};


// / number of event reconstruction levels
//const UShort_t kNumRecLevels=12, // currently defined reconstruction levels

enum EFdRecLevel {

  /// no Fd event found
  eNoFdEvent = 0,

  /// Fd event found
  eHasFdEvent = 1,

  /// Fd has triggered pixels
  eHasTriggeredPixels = 2,

  /// some pixels were reconstructed
  eHasReconstructedPixels = 3,

  /// Fd SDP found
  eHasSDP = 4,

  /// Fd Axis found
  eHasAxis = 5,

  /// photons at aperture reconstructed
  eHasAperturePhotons = 6,

  /// profile reconstructed
  eHasLongitudinalProfile = 7,

  /// profile reconstructed
  eHasdEdXProfile = 8,

  /// Gaisser-Hillas parameters reconstructed
  eHasGHParameters = 9,

  /// shower energy reconstructed
  eHasEnergy = 10

};


enum EFdGeomRecLevel {

  /// no geometry reconstruction
  eNoGeometry = 0,

  /// Fd only reconstruction
  eMonoGeometry = 1,

  /// Fd only reconstruction with axis/core fit
  eAxisMonoGeometry = 2,

  /// Hybrid reconstruction
  eHybridGeometry = 3,

  /// Hybrid reconstruction with axis/core fit
  eAxisHybridGeometry = 4

};

/// status of online 10MHz time correction
enum ETimeCorrectionStatus {
  eUndefinedCorrection = 0,
  eGoodCorrection,
  eBadCorrection,
  eOfflineCorrected
};

enum EGaisserHillasType {
  eGHUndefinedType = 0,
  eGHTwoPar,
  eGHFourParClassic,
  eGHFourParWidth
};

#endif
