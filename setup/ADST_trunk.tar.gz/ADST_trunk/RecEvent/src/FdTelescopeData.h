#ifndef __FdTelescopeData_H
#define __FdTelescopeData_H

#include <TObject.h>
#include <FdRecGeometry.h>
#include <FdRecApertureLight.h>
#include <FdGenApertureLight.h>

//=============================================================================
//
//  telescope event properties
//
//=============================================================================
class FdTelescopeData : public TObject {

  // class holding all variables dealing with telescope event properties

public:
  // getters
  const FdRecGeometry& GetRecGeometry() const { return fRecGeometry; }
  FdRecGeometry& GetRecGeometry() { return fRecGeometry; }

  const FdRecApertureLight& GetRecApertureLight() const { return fRecApertureLight; }
  FdRecApertureLight& GetRecApertureLight() { return fRecApertureLight; }

  const FdGenApertureLight& GetGenApertureLight() const { return fGenApertureLight; }
  FdGenApertureLight& GetGenApertureLight() { return fGenApertureLight; }

private:
  FdRecGeometry fRecGeometry;
  FdRecApertureLight fRecApertureLight;
  FdGenApertureLight fGenApertureLight;

  ClassDef(FdTelescopeData, 1);
};

#endif
