
#include <FdTrace.h>

ClassImp(FdTrace);

//=============================================================================
/*!
  \class   FdTrace
  \brief   Reconstructed pixel traces
  
  \version 1.0
  \date    Aug 2006
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/
//=============================================================================
FdTrace::FdTrace()
{
}

FdTrace::FdTrace(const std::vector<Double_t> &trace) :
  fTrace(trace)
{
}

