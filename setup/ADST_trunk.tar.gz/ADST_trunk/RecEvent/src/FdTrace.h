#ifndef __FdTrace_H
#define __FdTrace_H

#include <TObject.h>
#include <vector>
//
//  trace data definition
//
class FdTrace : public TObject {

public:

  FdTrace();
  FdTrace(const std::vector<Double_t> &trace);

  /// get vector of ADC trace [photons/100 ns]
  const std::vector<Double_t>& GetTrace() const {return fTrace;}
  std::vector<Double_t>& GetTrace() {return fTrace;}

private:

  std::vector<Double_t> fTrace;

  ClassDef(FdTrace,1);

};
#endif
