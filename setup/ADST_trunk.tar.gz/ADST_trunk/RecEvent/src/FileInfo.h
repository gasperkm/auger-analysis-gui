// $Id: FileInfo.h 28752 2016-04-11 10:30:41Z aherve $
#ifndef __FileInfo_H
#define __FileInfo_H

#include <SimInfo.h>

#include <TObject.h>

#include <string>



//  header for reconstructed run

enum ELDFType {
  eNKG,
  ePL,
  eHP,
  eLOG,
  eNKGFermi,
  eTabulated
};


// class to define the general configuration of the written file

class FileInfo : public TObject {

  friend class RecEventFile;

public:
  FileInfo();

  virtual ~FileInfo() { }

  void SetHasMC() { fHasMC = true; }
  bool HasMC() const { return fHasMC; }

  void SetHasVEMTraces() { fHasVEMTraces = true; }
  bool HasVEMTraces() const { return fHasVEMTraces; }

  void SetHasSdAllTraces() { fHasSdAllTraces = true; }
  bool HasSdAllTraces() const { return fHasSdAllTraces; }

  void SetHasFdTraces() { fHasFdTraces = true; }
  bool HasFdTraces() const { return fHasFdTraces; }

  void SetHasFdSpotRecTraces() { fHasFdSpotRecTraces = true; }
  bool HasFdSpotRecTraces() const { return fHasFdSpotRecTraces; }

  void SetOfflineVersion(const std::string& ver) { fOfflineVersion = ver; }
  const std::string& GetOfflineVersion() const { return fOfflineVersion; }

  void SetHost(const std::string& host) { fHost = host; }
  const std::string& GetHost() const { return fHost; }

  void SetUser(const std::string& user) { fUser = user; }
  const std::string& GetUser() const { return fUser; }

  void SetOfflineConfiguration(const std::string& config) { fOfflineConfiguration = config; }
  const std::string& GetOfflineConfiguration() const { return fOfflineConfiguration; }

  void SetRecEventVersion(const std::string& ver) { fADSTVersion = ver; }
  const std::string& GetRecEventVersion() const { return fADSTVersion; }

  void SetLDFType(const ELDFType ldftype) { fLDFType = ldftype; }
  ELDFType GetLDFType() const { return fLDFType; }

  const SimInfo& GetSimInfo() const { return fSim; }
  void SetHasRdStation() { fHasRadioStation = true; }
  void SetHasRdChannel() { fHasRadioChannel = true; }
  bool HasRdStation() const { return fHasRadioStation; }
  bool HasRdChannel() const { return fHasRadioChannel; }
  int GetRdEventClassVersion() const { return fRdEventClassVersion; }
  void SetRdLDFType(const ELDFType ldftype) { fRdLDFtype = ldftype; }
  ELDFType GetRdLDFType() const { return fRdLDFtype; }

  /// ROOT class versions of major ADST classes during file production
  int GetEventInfoClassVersion() const { return fEventInfoClassVersion; }
  int GetRecEventClassVersion() const { return fRecEventClassVersion; }
  int GetSDEventClassVersion() const { return fSDEventClassVersion; }
  int GetFDEventClassVersion() const { return fFDEventClassVersion; }
  int GetShowerClassVersion() const { return fShowerClassVersion; }
  int GetRecShowerClassVersion() const { return fRecShowerClassVersion; }
  int GetFdRecShowerClassVersion() const { return fFdRecShowerClassVersion; }
  int GetSdRecShowerClassVersion() const { return fSdRecShowerClassVersion; }
  int GetUnivRecShowerClassVersion() const { return fUnivRecShowerClassVersion; }
  int GetSdRecStationClassVersion() const { return fSdRecStationClassVersion; }
  int GetGenShowerClassVersion() const { return fGenShowerClassVersion; }

  /// write Offline configuration to file or stdout
  void PrintOfflineConfiguration(const std::string& fileName = "") const;

  /// get a configuration value (searches occurence within all levels of topBranchName, no checks for multiple occurences)
  std::string GetOfflineConfigurationValue(const std::string& topBranchName,
                                           const std::string& branchName) const;

private:
  std::string fADSTVersion;

  // these variables are automatically set by RecEventFile::WriteFileInfo()
  mutable int fEventInfoClassVersion;
  mutable int fRecEventClassVersion;
  mutable int fSDEventClassVersion;
  mutable int fFDEventClassVersion;
  mutable int fShowerClassVersion;
  mutable int fRecShowerClassVersion;
  mutable int fFdRecShowerClassVersion;
  mutable int fSdRecShowerClassVersion;
  mutable int fUnivRecShowerClassVersion;
  mutable int fSdRecStationClassVersion;
  mutable int fGenShowerClassVersion;

  bool fHasMC;
  bool fHasFD;
  bool fHasSD;
  bool fHasFdTraces;
  bool fHasFdSpotRecTraces;

  bool fHasVEMTraces;
  bool fHasSdAllTraces;
  bool fHasRadioStation;
  bool fHasRadioChannel;
  ELDFType fRdLDFtype;
  mutable int fRdEventClassVersion;

  ELDFType fLDFType;

  std::string fOfflineVersion;
  std::string fHost;
  std::string fUser;

  std::string fOfflineConfiguration;

  SimInfo fSim;

  ClassDef(FileInfo, 13);

};


#endif
