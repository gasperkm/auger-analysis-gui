// $Id: GenStation.cc 28131 2015-11-15 20:06:17Z darko $
#include <GenStation.h>
#include <StationStatus.h> // for the enums

#include <iostream>
#include <vector>
#include <numeric>
#include <stdexcept>

using namespace std;


ClassImp(GenStation);
ClassImp(PETimeDistribution);
ClassImp(SDParticle);


PETimeDistribution::PETimeDistribution() :
  fComponent(eTotalTrace),
  fBinSize(0),
  fPMT(0)
{ }


SDParticle::SDParticle() :
  fType(0),
  fEnergy(0),
  fPartSecond(0),
  fPartNSecond(0)
{ }


GenStation::GenStation() :
  fInsideMinRadius(false),
  fSecond(0),
  fNSecond(0),
  fId(0),
  fNumberOfMuons(0),
  fTotalParticleCount(0)
{ }


const PETimeDistribution&
GenStation::GetPETimeDistribution(const unsigned int pmtId,
                                  const ETraceType component)
  const
{
  for (unsigned int i = 0, n = fPETimeDistr.size(); i < n; ++i) {
    if (fPETimeDistr[i].GetPMTId() == pmtId &&
        fPETimeDistr[i].GetComponent() == component)
      return fPETimeDistr[i];
  }
  static const PETimeDistribution empty;
  return empty;
}


template<class Container>
inline
const Container&
Switch(const int i, const Container& c1, const Container& c2, const Container& c3)
{
  switch (i) {
  case 1: return c1;
  case 2: return c2;
  case 3: return c3;
  default:
    throw std::out_of_range("unknown PMT id!");
  }
}


const vector<Float_t>&
GenStation::GetMuonTrace(const int pmtNo)
  const
{
  return Switch(pmtNo, fMuonTrace1, fMuonTrace2, fMuonTrace3);
}


const vector<Float_t>&
GenStation::GetElectronTrace(const int pmtNo)
  const
{
  return Switch(pmtNo, fElectronTrace1, fElectronTrace2, fElectronTrace3);
}


const vector<Float_t>&
GenStation::GetPhotonTrace(const int pmtNo)
  const
{
  return Switch(pmtNo, fPhotonTrace1, fPhotonTrace2, fPhotonTrace3);
}


template<class Container>
inline
double
Sum(const Container& c1, const Container& c2, const Container& c3)
{
  return
    accumulate(c1.begin(), c1.end(), 0.) +
    accumulate(c2.begin(), c2.end(), 0.) +
    accumulate(c3.begin(), c3.end(), 0.);
}


double
GenStation::GetMuonSignal()
  const
{
  return fMuonTrace1.empty() ?
    0 : Sum(fMuonTrace1, fMuonTrace2, fMuonTrace3) / 3;
}


double
GenStation::GetElectronSignal()
  const
{
  return fElectronTrace1.empty() ?
    0 : Sum(fElectronTrace1, fElectronTrace2, fElectronTrace3) / 3;
}


double
GenStation::GetPhotonSignal()
  const
{
  return fPhotonTrace1.empty() ?
    0 : Sum(fPhotonTrace1, fPhotonTrace2, fPhotonTrace3) / 3;
}
