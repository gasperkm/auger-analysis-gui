#ifndef _adst_GenStation_h_
#define _adst_GenStation_h_

#include <StationStatus.h> // for the enums
#include <Traces.h>

#include <TVector3.h>
#include <TObject.h>

#include <vector>
#include <map>


class PETimeDistribution : public TObject {
public:
  PETimeDistribution();
  virtual ~PETimeDistribution() { }

  void SetComponent(const ETraceType comp) { fComponent = comp; }
  ETraceType GetComponent() const { return fComponent; }

  void SetBinSize(const unsigned int binsize) { fBinSize = binsize; }
  unsigned int GetBinSize() const { return fBinSize; }

  void SetPMTId(const unsigned int id) { fPMT = id; }
  unsigned int GetPMTId() const { return fPMT; }

  void FillMap(const int time, const int value)
  { fTimeDistr.insert(std::make_pair(time, value)); }

  const std::map<int, unsigned int>& GetMap() const { return fTimeDistr; }

private:
  ETraceType fComponent;

  unsigned int fBinSize;
  unsigned int fPMT;

  std::map<int, unsigned int> fTimeDistr;

  ClassDef(PETimeDistribution, 2);
};


class SDParticle : public TObject {
public:
  SDParticle();
  virtual ~SDParticle() { }

  void SetType(const int comp) { fType = comp; }
  int GetType() const { return fType; }

  void SetEnergy(const double energy) { fEnergy = energy; }
  double GetEnergy() const { return fEnergy; }

  void SetMomentum(const TVector3& mom) { fMomentum = mom; }
  const TVector3& GetMomentum() const { return fMomentum; }

  void SetPosition(const TVector3& pos) { fPosition = pos; }
  const TVector3& GetPosition() const { return fPosition; }
  void SetTime(const Double_t second, const Double_t nsec)
  { fPartSecond = second; fPartNSecond = nsec; }
  double GetSecond() const { return fPartSecond; }
  double GetNSecond() const { return fPartNSecond; }

private:
  unsigned int fType;
  double fEnergy;
  double fPartSecond;
  double fPartNSecond;
  TVector3 fMomentum;
  TVector3 fPosition;
  ClassDef(SDParticle, 1);
};


//  Station data definition

class GenStation : public TObject {
public:
  GenStation();
  virtual ~GenStation() { }

  void SetInsideRMinFlag(const bool flag) { fInsideMinRadius = flag; }
  void SetPlaneFrontTime(const Double_t second, const Double_t nsec)
  { fSecond = second; fNSecond = nsec; }
  void SetId(const UInt_t id) { fId = id; }

  double GetPlaneFrontTimeSecond() const { return fSecond; }
  double GetPlaneFrontTimeNSecond() const { return fNSecond; }
  const std::vector<Float_t>& GetMuonTrace(const int pmtNo) const;
  const std::vector<Float_t>& GetElectronTrace(const int pmtNo) const;
  const std::vector<Float_t>& GetPhotonTrace(const int pmtNo) const;
  bool IsInsideRMin() const { return fInsideMinRadius; }
  UInt_t GetId() const { return fId; }

  void AddPETimeDistribution(const PETimeDistribution& timeDist)
  { fPETimeDistr.push_back(timeDist); }

  const std::vector<PETimeDistribution>& GetPETimeDistributions() const
  { return fPETimeDistr; }

  bool HasPETimeDistributions() const { return !fPETimeDistr.empty(); }

  const PETimeDistribution& GetPETimeDistribution(const unsigned int pmtId,
                                                  const ETraceType component) const;

  void AddParticle(const SDParticle particle) { fParticles.push_back(particle); }
  const std::vector<SDParticle>& GetParticles() const { return fParticles; }
  bool HasParticles() const { return !fParticles.empty(); }

  double GetMuonSignal() const;
  double GetElectronSignal() const;
  double GetPhotonSignal() const;

  UInt_t GetNumberOfMuons() const { return fNumberOfMuons; }
  void SetNumberOfMuons(const UInt_t mus) { fNumberOfMuons = mus; }
  UInt_t GetTotalParticleCount() const { return fTotalParticleCount; }
  void SetTotalParticleCount(const UInt_t n) { fTotalParticleCount = n; }
  UInt_t GetMaxNParticles() const { return fMaxNParticles; }
  void SetMaxNParticles(const UInt_t n) { fMaxNParticles = n; }
  Double_t GetThinning() const { return fThinning; }
  void SetThinning(const Double_t th) { fThinning = th; }
  Double_t GetUsedWeight() const { return fUsedWeight; }
  void SetUsedWeight(const Double_t w) { fUsedWeight = w; }
  UInt_t GetThinParticleCount() const { return fThinParticleCount; }
  void SetThinParticleCount(const UInt_t n) { fThinParticleCount = n; }

protected:
  // these should disapear in the near future
  std::vector<Float_t> fMuonTrace1;
  std::vector<Float_t> fElectronTrace1;
  std::vector<Float_t> fPhotonTrace1;

  std::vector<Float_t> fMuonTrace2;
  std::vector<Float_t> fElectronTrace2;
  std::vector<Float_t> fPhotonTrace2;

  std::vector<Float_t> fMuonTrace3;
  std::vector<Float_t> fElectronTrace3;
  std::vector<Float_t> fPhotonTrace3;

  std::vector<PETimeDistribution> fPETimeDistr;
  std::vector<SDParticle> fParticles;

  bool fInsideMinRadius;
  Double_t fSecond;
  Double_t fNSecond;
  UInt_t fId;
  UInt_t fNumberOfMuons;
  UInt_t fTotalParticleCount;
  UInt_t fMaxNParticles;
  Double_t fThinning;
  Double_t fUsedWeight;
  UInt_t fThinParticleCount;

  ClassDef(GenStation, 11);
};


#endif
