#include "MdRecChannel.h"
/*

   Martin Maur
   17 Apr 2012

*/


using namespace std;

ClassImp(MdRecChannel);

MdRecChannel::MdRecChannel():
  fId(0),
  fScintillatorId(0),
  fPixelId(0),
  //fNumberOfPatternMatchs(0),
  fNumberOfTraceBins(0),
  fTraceBinning(0),
  fTraceStartSecond(0),
  fTraceStartNano(0)
{
}

