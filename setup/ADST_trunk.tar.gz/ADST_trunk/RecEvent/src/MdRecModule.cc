
#include "MdRecModule.h"

ClassImp(MdRecModule);

MdRecModule::MdRecModule():
  fId(0),
  fActiveArea(0),
  fPosition(0,0,0),
  fSegmentation(0),
  fRecStatus(eUndefined),
  fChannelsOnBinning(0),
  fChannelsOnStartSecond(0),
  fChannelsOnStartNano(0),
  fNumberOfEstimatedMuons(0),
  fNumberOfMuonsErrorHigh(0),
  fNumberOfMuonsErrorLow(0),
  fNumberOfMuonsLowLimit(0),
  fMuonDensity(0),
  fMuonDensityErrorHigh(0),
  fMuonDensityErrorLow(0),
  fLDFResidual(0),
  fNumberOfSamples(0),
  fSampleTime(0),
  fSPDistance(0),
  fSPDistanceError(0),
  fSPDelta(0),
  fSPDeltaError(0),
  fSPAzimuth(0),
  fSPAzimuthError(0)  
{
}

unsigned int 
MdRecModule::GetNumberOfChannelsOn() 
const 
{
  unsigned int nChannelsOn = 0;
  std::vector<unsigned int>::const_iterator bin, endBin;
  for (bin=fChannelsOn.begin(), endBin=fChannelsOn.end(); bin!=endBin; ++bin) {
    nChannelsOn += *bin;
  }
  return nChannelsOn;  
}

unsigned int 
MdRecModule::GetMaxChannelsOn() 
const 
{
  unsigned int nMaxChannelsOn = 0;
  std::vector<unsigned int>::const_iterator bin, endBin;
  for (bin=fChannelsOn.begin(), endBin=fChannelsOn.end(); bin!=endBin; ++bin) {
    nMaxChannelsOn = std::max(nMaxChannelsOn,*bin);
  }
  return nMaxChannelsOn;  
}

// Channel access methods

bool 
MdRecModule::HasChannel(unsigned int id) 
const
{
  for (ChannelList::const_iterator it = fChannels.begin(); it != fChannels.end(); ++it) {
    if ( it->GetId() == id ) {
      return true;
    }
  } 
  return false; // the id is not found
}

bool 
MdRecModule::HasRecChannelByScintillator(unsigned int id) 
const
{
  for (ChannelList::const_iterator it = fChannels.begin(); it != fChannels.end(); ++it) {
    if ( it->GetScintillatorId() == id ) {
      return true;
    }
  } 
  return false; // the id is not found
}

bool 
MdRecModule::HasRecChannelByPixel(unsigned int id) 
const
{
  for (ChannelList::const_iterator it = fChannels.begin(); it != fChannels.end(); ++it) {
    if ( it->GetPixelId() == id ) {
      return true;
    }
  } 
  return false; // the id is not found
}

MdRecChannel* 
MdRecModule::GetChannel(unsigned int id) 
{
  for (ChannelIterator it = fChannels.begin(); it != fChannels.end(); ++it) {
    if ( it->GetId() == id ) {
      return &(*it);
    }
  } 
  return NULL; // the id is not found
}

MdRecChannel* 
MdRecModule::GetRecChannelByScintillatorId(unsigned int id) 
{
  for (ChannelIterator it = fChannels.begin(); it != fChannels.end(); ++it) {
    if ( it->GetScintillatorId() == id ) {
      return &(*it);
    }
  } 
  return NULL; // the id is not found
}

MdRecChannel* 
MdRecModule::GetChannelByPixelId(unsigned int id) 
{
  for (ChannelIterator it = fChannels.begin(); it != fChannels.end(); ++it) {
    if ( it->GetPixelId() == id ) {
      return &(*it);
    }
  } 
  return NULL; // the id is not found
}

double 
MdRecModule::GetLeadingMuonTime() 
{
  //Null pointer if there are no muons... better return null or 0.

  //return value
  double leadingMuonTime(0);

  if(HasPatternMatches()){
	  double firstMatchTime = *std::min_element(fPatternMatchTimes.begin(),fPatternMatchTimes.end());
	  const double binning = ChannelsBegin()->GetBinning();
	  // assume the muon time is half bin before the FADC sample
	  leadingMuonTime = firstMatchTime-0.5*binning;
  }
  return leadingMuonTime;

}
