
#ifndef __MdRecModule_h_
#define __MdRecModule_h_

#include <MdRecChannel.h>

#include <TObject.h>
#include <TVector3.h>
#include <vector>
#include <algorithm>

class MdRecModule: public TObject {

public:

  typedef std::vector<MdRecChannel> ChannelList;
  typedef ChannelList::iterator ChannelIterator;

  MdRecModule();
  virtual ~MdRecModule(){}

  // Master data methods

  void SetId(const unsigned int id){fId=id;}
  unsigned int GetId() const {return fId;}

  void SetActiveArea(const double area) {fActiveArea = area;}
  double GetActiveArea() const {return fActiveArea;}

  TVector3 GetPosition() const { return fPosition; }
  void SetPosition(const TVector3 position) { fPosition=position; }

  // position in shower coordinate system
  // errors not filled, so the corresponding getters are commented out
  void SetSPDistance(const double c, const double e) {
    fSPDistance=c;fSPDistanceError=e;}
  double GetSPDistance() const {return fSPDistance;}
//  double GetSPDistanceError() const {return fSPDistanceError;}

  void SetSPAzimuth(const double c, const double e) {fSPAzimuth = c; fSPAzimuthError = e;}
  double GetSPAzimuth() const {return fSPAzimuth;}
//  double GetSPAzimuthError() const {return fSPAzimuthError;}

  void SetSPDelta(const double c, const double e) {fSPDelta=c;fSPDeltaError=e;}
  double GetSPDelta() const {return fSPDelta;}
//  double GetSPDeltaError() const {return fSPDeltaError;}

  void SetSegmentation( unsigned int nm ) { fSegmentation = nm; }
  unsigned int GetSegmentation() const { return fSegmentation; }

  // Time between samples of the digital trace in nanoseconds
  void SetSampleTime(const double time) {fSampleTime=time;}
  double GetSampleTime() const {return fSampleTime;}

  // Number of samples of the digital trace
  void SetNumberOfSamples(const unsigned int n) {fNumberOfSamples=n;}
  unsigned int GetNumberOfSamples() {return fNumberOfSamples;}

  // Module status
  void SetCandidate() { fRecStatus = eCandidate; }
  bool IsCandidate() const { return fRecStatus == eCandidate; }
  void SetSilent() { fRecStatus = eSilent; }
  bool IsSilent() const { return fRecStatus == eSilent; }
  void SetRejected() { fRecStatus = eRejected; }
  bool IsRejected() const { return fRecStatus == eRejected; }

  // Module reconstructed data status, make sense for candidate modules only
  bool IsEmpty() const {return IsCandidate() && GetMaxChannelsOn()==0;}
  bool IsGood() const {return IsCandidate() && 0<GetMaxChannelsOn() && GetMaxChannelsOn()<fSegmentation;}
  bool IsSaturated() const {return IsCandidate() && GetMaxChannelsOn()==fSegmentation;} 
  
//  void SetSaturationFlag(const bool satFlag) {fSaturationFlag = satFlag;}
//  bool SaturationFlag() const {return fSaturationFlag;}

  // channelsOn methods
  std::vector<unsigned int>& GetChannelsOn() {return fChannelsOn;}
  const std::vector<unsigned int>& GetChannelsOn() const {return fChannelsOn;}
  bool HasChannelsOn() const {return fChannelsOn.size()==0;}

  void SetChannelsOnBinning(double b) { fChannelsOnBinning=b; }
  double GetChannelsOnBinning() const { return fChannelsOnBinning; }
  
  void SetChannelsOnStartTime(unsigned long second, double nano) 
  {fChannelsOnStartSecond = second; fChannelsOnStartNano = nano; }
  unsigned long GetChannelsOnStartSecond() const { return fChannelsOnStartSecond; }
  double GetChannelsOnStartNano() const { return fChannelsOnStartNano; } 

  unsigned int GetNumberOfChannelsOn() const;
  unsigned int GetMaxChannelsOn() const;

  // Counting methods
  void SetNumberOfEstimatedMuons(const double m) { fNumberOfEstimatedMuons=m; }
  double GetNumberOfEstimatedMuons() const { return fNumberOfEstimatedMuons; }

  void SetNumberOfMuonsErrorHigh(const double e) { fNumberOfMuonsErrorHigh=e; }
  double GetNumberOfMuonsErrorHigh() const { return fNumberOfMuonsErrorHigh; }    

  void SetNumberOfMuonsErrorLow(const double e) { fNumberOfMuonsErrorLow=e; }
  double GetNumberOfMuonsErrorLow() const { return fNumberOfMuonsErrorLow; }   

  void SetNumberOfMuonsLowLimit(const double e) { fNumberOfMuonsLowLimit=e; }
  double GetNumberOfMuonsLowLimit() const { return fNumberOfMuonsLowLimit; }

  void SetMuonDensity(double density) {fMuonDensity = density;}
  double GetMuonDensity() const {return fMuonDensity;} 

  void SetMuonDensityErrorHigh(double e) {fMuonDensityErrorHigh = e;}
  double GetMuonDensityErrorHigh() const {return fMuonDensityErrorHigh;} 

  void SetMuonDensityErrorLow(double e) {fMuonDensityErrorLow = e;}
  double GetMuonDensityErrorLow() const {return fMuonDensityErrorLow;} 

  void SetLDFResidual(const double LDFresidual) { fLDFResidual = LDFresidual; }    
  double GetLDFResidual() const { return fLDFResidual; }

  // Pattern match methods
  const std::vector<double>& GetPatternMatchTimes() const {return fPatternMatchTimes;}
  std::vector<double>& GetPatternMatchTimes() {return fPatternMatchTimes;}
  bool HasPatternMatches() const {return fPatternMatchTimes.size()>0;}
  double GetLeadingMuonTime();

  // Channel access methods
  void AddChannel(const MdRecChannel& m) {fChannels.push_back(m);}
  unsigned int GetNumberOfChannels() const {return fChannels.size();}
  bool HasChannels() const { return !fChannels.empty(); }
  bool HasChannel(unsigned int id) const;
  bool HasRecChannelByScintillator(unsigned int id) const;
  bool HasRecChannelByPixel(unsigned int id) const;
  ChannelIterator ChannelsBegin() {return fChannels.begin();}
  ChannelIterator ChannelsEnd() { return fChannels.end();}
  MdRecChannel* GetChannel(unsigned int id);
  MdRecChannel* GetRecChannelByScintillatorId(unsigned int id);
  MdRecChannel* GetChannelByPixelId(unsigned int id);

private:

  // Master data
  unsigned int fId;
  double fActiveArea;
  TVector3 fPosition;
  unsigned int fSegmentation;
//  bool fSaturationFlag;
 
  // Status data
  enum Status {
    eUndefined = 0,
    eCandidate,
    eSilent,
    eRejected
  };
  Status fRecStatus;

  // Counting data
  std::vector<unsigned int> fChannelsOn;
  double fChannelsOnBinning;
  unsigned long fChannelsOnStartSecond;
  double fChannelsOnStartNano;

  double fNumberOfEstimatedMuons;
  double fNumberOfMuonsErrorHigh;
  double fNumberOfMuonsErrorLow;
  double fNumberOfMuonsLowLimit;
  double fMuonDensity;
  double fMuonDensityErrorHigh;
  double fMuonDensityErrorLow;
  double fLDFResidual;

  // FADC trace data
  unsigned int fNumberOfSamples;
  double fSampleTime;

  std::vector<double> fPatternMatchTimes;  // see definition in ModuleRecData
  
  double fSPDistance;
  double fSPDistanceError;
  double fSPDelta;
  double fSPDeltaError;
  double fSPAzimuth;
  double fSPAzimuthError;

  // Channel data

  ChannelList fChannels;

  ClassDef(MdRecModule, 4);
};

#endif // __MdRecModule_h_
