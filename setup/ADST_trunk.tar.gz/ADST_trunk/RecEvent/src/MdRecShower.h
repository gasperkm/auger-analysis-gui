//#include <config.h>
/*
   Martin Maur
   27 Jun 2012
*/

#ifndef _adst_MdRecShower_h_
#define _adst_MdRecShower_h_

#include <RecShower.h>

#include <TVector3.h>

#include <vector>
#include <iostream>


class MdRecShower : public RecShower {

public:
  MdRecShower();
  virtual ~MdRecShower() { }

  void SetTabulatedValues(const std::vector<double>& x, const std::vector<double>& y)
  { fRhos = x; fValues = y; }

  double TabulatedFunction(const double r) const;

  double TabulatedFunction(const double* const x, const double*) const { return TabulatedFunction(x[0]); }

  // overloaded operator () is required to construct ROOT TF1s
  double operator()(const double* const x, const double* const /*p*/) const { return TabulatedFunction(x[0]); }

  double GetMLDFChi2() const { return fMLDFChi2; }

  double GetMLDFNdof() const { return fMLDFNdof; }

  double GetMLDFLikelihood() const { return fMLDFLikelihood; }

  double GetMLDFRecStage() const { return fMLDFRecStage; }

  //double GetAlpha() const { return fAlpha; }

  //double GetAlphaError() const { return fAlphaError; }

  double GetBeta() const { return fBeta; }

  double GetBetaError() const { return fBetaError; }

  double GetBetaSystematics() const { return fBetaSystematics; }

  //double GetGamma() const { return fGamma; }

  //double GetGammaError() const { return fGammaError; }

  //double GetR0() const { return fR0; }

  //double GetR0Error() const { return fR0Error; }

  double GetNMuRef() const { return fNMuRef; }

  double GetNMuRefError() const { return fNMuRefError; }

  double GetNMuRefSystematics() const { return fNMuRefSystematics; }

  double GetReferenceDistance() const { return fReferenceDistance; }

  const TVector3& GetBarycenter() const { return fBarycenter; }

  TVector3& GetBarycenter() { return fBarycenter; }

  void SetMLDFLikelihood(const double likelihood) { fMLDFLikelihood = likelihood; }

  void SetMLDFChi2(const double chi2) { fMLDFChi2 = chi2; }

  void SetMLDFNdof(const double ndof) { fMLDFNdof = ndof; }

  void SetMLDFRecStage(const double stage) { fMLDFRecStage = stage; }

  //void SetAlpha(const double alpha, const double error) { fAlpha = alpha; fAlphaError = error; }

  void SetBeta(const double beta, const double error) { fBeta = beta; fBetaError = error; }

  void SetBetaSystematics(const double BetaSys) { fBetaSystematics = BetaSys; }

  /*void SetGamma(const double gamma, const double error) { fGamma = gamma; fGammaError = error; }

  void SetR0(const double r0, const double error) { fR0 = r0; fR0Error = error; }*/

  void SetNMuRef(const double NMuRef, const double error) { fNMuRef = NMuRef; fNMuRefError = error; }

  void SetNMuRefSystematics(const double NMuRefSys) { fNMuRefSystematics = NMuRefSys; }

  void SetReferenceDistance(const double reference) { fReferenceDistance = reference; }

  void SetBarycenter(const TVector3& p) { fBarycenter = p; }

  bool IsReconstructed() const { return GetNMuRef() > 0.00001; }

private:
  std::vector<double> fRhos;
  std::vector<double> fValues;

  //double fAlpha;
  //double fAlphaError;
  double fBeta;
  double fBetaError;
  double fBetaSystematics;
  //double fGamma;
  //double fGammaError;
  //double fR0;
  //double fR0Error;
  double fNMuRef;
  double fNMuRefError;
  double fNMuRefSystematics;
  double fMLDFChi2;
  double fMLDFNdof;
  double fMLDFLikelihood;
  double fReferenceDistance;

  TVector3 fBarycenter;
  double fMLDFRecStage;

  ClassDef(MdRecShower, 1);

};


#endif
