#include "MdSimCounter.h"
/*
   Martin Maur
   14 Apr 2012
*/


using namespace std;


ClassImp(MdSimCounter);


MdSimCounter::MdSimCounter() :
  fId(0),
  fSdPartnerId(0),
  fInsideMinRadius(false),
  fSPDelta(0),
  fSPDistance(0),
  fSPAzimuth(0)
{ }


const MdSimScintillator*
MdSimCounter::GetSimScintillator(const unsigned int i)
  const
{
  if (i >= fScintillators.size())
    return NULL;
  return &fScintillators[i];
}


const MdSimScintillator*
MdSimCounter::GetSimScintillatorById(const unsigned int mId, const unsigned int scId)
  const
{
  for (unsigned int i = 0; i != fScintillators.size(); ++i) {
    if ((fScintillators[i].GetModuleId() == mId) && (fScintillators[i].GetId() == scId))
      return &fScintillators[i];
  }
  return NULL;
}


const MdSimScintillator*
MdSimCounter::GetSimScintillatorByChannelId(const unsigned int mId, const unsigned int cId)
  const
{
  for (unsigned int i = 0; i != fScintillators.size(); ++i) {
    if ((fScintillators[i].GetModuleId() == mId) && (fScintillators[i].GetChannelId() == cId))
      return &fScintillators[i];
  }
  return NULL;
}


const MdSimScintillator*
MdSimCounter::GetSimScintillatorByPixelId(const unsigned int mId, const unsigned int pxId)
  const
{
  for (unsigned int i = 0; i != fScintillators.size(); ++i) {
    if ((fScintillators[i].GetModuleId() == mId) && (fScintillators[i].GetPixelId() == pxId))
      return &fScintillators[i];
  }
  return NULL;
}


bool
MdSimCounter::HasSimScintillator(const unsigned int mId, const unsigned int scId)
  const
{
  for (unsigned int i = 0; i != fScintillators.size(); ++i) {
    if ((fScintillators[i].GetModuleId() == mId) && (fScintillators[i].GetId() == scId))
      return true;
  }
  return false;
}


bool
MdSimCounter::HasSimScintillatorByChannel(const unsigned int mId, const unsigned int cId)
  const
{
  for (unsigned int i = 0; i != fScintillators.size(); ++i) {
    if ((fScintillators[i].GetModuleId() == mId) && (fScintillators[i].GetChannelId() == cId))
      return true;
  }
  return false;
}


bool
MdSimCounter::HasSimScintillatorByPixel(const unsigned int mId, const unsigned int pxId)
  const
{
  for (unsigned int i = 0; i != fScintillators.size(); ++i) {
    if ((fScintillators[i].GetModuleId() == mId) && (fScintillators[i].GetPixelId() == pxId))
      return true;
  }
  return false;
}


void
MdSimCounter::AddSimScintillator(const MdSimScintillator& s)
{
  fScintillators.push_back(s);
}


double
MdSimCounter::GetAreaByModule(const unsigned int moduleId)
  const
{
  return fAreaByModule.find(moduleId)->second;
}


bool
MdSimCounter::HasModule(const unsigned int moduleId)
  const
{
  return fAreaByModule.find(moduleId) != fAreaByModule.end();
}


double
MdSimCounter::GetArea()
  const
{
  double area = 0;
  for (map<unsigned int, double>::const_iterator moduleIt = fAreaByModule.begin();
       moduleIt != fAreaByModule.end(); ++moduleIt) {
    area += moduleIt->second;
  }
  return area;
}


unsigned int
MdSimCounter::GetNumberOfInjectedMuons()
  const
{
  unsigned int nmuons = 0;
  for (unsigned int i = 0; i != fScintillators.size(); ++i) {
    nmuons += fScintillators[i].GetNumberOfInjectedMuons();
  }
  return nmuons;
}


double
MdSimCounter::GetEnergyDeposit()
  const
{
  double deposit = 0;
  for (unsigned int i = 0; i != fScintillators.size(); ++i) {
    deposit += fScintillators[i].GetEnergyDeposit();
  }
  return deposit;
}


double
MdSimCounter::GetMuonEnergyDeposit()
  const
{
  double deposit = 0;
  for (unsigned int i = 0; i != fScintillators.size(); ++i) {
    deposit += fScintillators[i].GetMuonEnergyDeposit();
  }
  return deposit;
}
