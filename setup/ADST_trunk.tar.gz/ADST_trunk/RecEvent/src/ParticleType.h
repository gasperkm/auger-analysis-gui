#ifndef __ParticleType_H 
#define __ParticleType_H

enum ParticleType {
  eUndefined = 0,
  eElectron = 11, 
  ePositron = -11,
  eNuElectron = 12,
  eAntiNuElectron = -12,
  eMuon = 13, 
  eAntiMuon = -13,
  eNuMuon = 14, 
  eAntiNuMuon = -14,
  eTau = 15, 
  eAntiTau = -15,
  eNuTau = 16, 
  eAntiNuTau = -16,
  ePhoton = 22,
  ePiZero = 111,
  ePiPlus = 211, 
  ePiMinus = -211,
  eEta = 221,
  eKaon0L = 130, 
  eKaon0S = 310,
  eKaonPlus = 321,
  eKaonMinus = -321, 
  eLambda = 3122, 
  eAntiLambda = -3122,
  eNeutron = 2112, 
  eAntiNeutron = -2112,
  eProton = 2212, 
  eAntiProton = -2212,
  // Selected nuclei.
  eIron = 1000026056,
  eCarbon= 1000006012, 
  eHelium= 1000002004, 
  eSilicon=  1000014028,
  eNitrogen = 1000007014, 
  eOxygen = 1000008016,
};

#endif
