#ifndef __RdBeamQuants_H
#define __RdBeamQuants_H

#include <TObject.h>
#include <RdBeamPeak.h>

class RdBeamQuants : public TObject {
 public:
  RdBeamQuants();
  
  Double_t GetZenith() const { return fZenith; }
  Double_t GetAzimuth() const { return fAzimuth; }
  Double_t GetCurvature() const { return fCurvature; }
  Double_t GetCone() const { return fCone; }
  
  const RdBeamPeak &GetCCPeak() const { return fCCPeak; }
  const RdBeamPeak &GetPowerPeak() const { return fPowerPeak; }
  const RdBeamPeak &GetXPeak() const { return fXPeak; }

  
  void SetZenith(Double_t zen)  { fZenith = zen; }
  void SetAzimuth(Double_t azi)  { fAzimuth = azi; }
  void SetCurvature(Double_t cur)  { fCurvature = cur; }
  void SetCone(Double_t con)  { fCone = con; }
  
  void SetCCPeak(const RdBeamPeak &cc) { fCCPeak = cc; }
  void SetPowerPeak(const RdBeamPeak &pw) { fPowerPeak = pw; }
  void SetXPeak(const RdBeamPeak &x) { fXPeak = x; }

 protected:
  Double_t fZenith;
  Double_t fAzimuth;
  Double_t fCurvature;
  Double_t fCone;
  
  RdBeamPeak fCCPeak;
  RdBeamPeak fPowerPeak;
  RdBeamPeak fXPeak;
  
  ClassDef(RdBeamQuants,1);
};

#endif
