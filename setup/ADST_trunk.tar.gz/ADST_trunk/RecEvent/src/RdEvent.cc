#include <RdEvent.h>

#include <RdRecStation.h>
#include <SimRdPulse.h>

#include <TClonesArray.h>

#include <iostream>
#include <TF1.h>

using namespace std;


ClassImp (RdEvent);


//=============================================================================
/*!
  \class   RdEvent
  \brief   General RD Event

  \version 1.0
  \date    May  2010
  \author  M. Melissas
*/
//=============================================================================

RdEvent::RdEvent() :
  fRdEventId(0),
  fRdRunNumber(0),
  fRRecLevel(eNoRd),
  fRGPSSecond(0),
  fRGPSNanoSecond(0),
  fHasShower(false),
  fRejectionStatus(0)
{
#ifdef DEBUGKG
  cout << " RdEvent::RdEvent()   begin" << endl;
#endif

#ifdef DEBUGKG
  cout << " RdEvent::RdEvent()   end" << endl;
#endif
}


RdEvent::~RdEvent()
{
#ifdef DEBUGKG
  cout << "  RdEvent::~RdEvent()  begin" << endl;
#endif

#ifdef DEBUGKG
  cout << "  RdEvent::~RdEvent()  end" << endl;
#endif
}


RdRecShower&
RdEvent::GetRdRecShower()
{
  return fRdRecShower;
}


const RdRecShower&
RdEvent::GetRdRecShower()
  const
{
  return fRdRecShower;
}


void
RdEvent::AddRdStation(const RdRecStation& station)
{
  fRStations.push_back(station);
}


void
RdEvent::AddRdStationWithId(const UInt_t id)
{
  RdRecStation station;
  station.SetId(id);
  fRStations.push_back(station);
}


void
RdEvent::AddSimRdPulse(const SimRdPulse& station)
{
  fSimRdPulses.push_back(station);
}


void
RdEvent::AddSimRdPulseWithId(const UInt_t id)
{
  SimRdPulse spulse;
  spulse.SetId(id);
  fSimRdPulses.push_back(spulse);
}


bool
RdEvent::HasRdStation(const unsigned int id)
  const
{
  for (unsigned int i = 0, n = fRStations.size(); i < n; ++i)
    if (fRStations[i].GetId() == id)
       return true;
  return false;
}


bool
RdEvent::HasSimRdPulse(const unsigned int id)
  const
{
  for (unsigned int i = 0, n = fSimRdPulses.size(); i < n; ++i)
    if (fSimRdPulses[i].GetId() == id)
      return true;
  return false;
}


//======================================================================
RdRecStation&
RdEvent::GetRdStation(const UInt_t i)
{
  return fRStations.at(i);
}



RdRecStation&
RdEvent::GetRdStationById(const UInt_t id)
{
  for (unsigned int i = 0, n = fRStations.size(); i < n; ++i)
    if (fRStations[i].GetId() == id)
      return fRStations[i];

  throw out_of_range("Station does not exist ");
}


const RdRecStation&
RdEvent::GetRdStation(const UInt_t i)
const
{
  if (i < fRStations.size())
    return fRStations[i];

  throw out_of_range("Station does not exist");
}


const RdRecStation&
RdEvent::GetRdStationById(const UInt_t id)
  const
{
  for (unsigned int i = 0, n = fRStations.size(); i < n; ++i)
    if (fRStations[i].GetId() == id)
      return fRStations[i];

  throw out_of_range("Station does not exist ");
}


SimRdPulse&
RdEvent::GetSimRdPulse(const UInt_t i)
{
  if (i < fSimRdPulses.size())
    return fSimRdPulses[i];

  throw out_of_range("Station does not exist");
}


SimRdPulse&
RdEvent::GetSimRdPulseById(const UInt_t id)
{
  for (unsigned int i = 0, n = fSimRdPulses.size(); i < n; ++i)
    if (fSimRdPulses[i].GetId() == id)
      return fSimRdPulses[i];

  throw out_of_range("Station does not exist");
}


const SimRdPulse&
RdEvent::GetSimRdPulse(const UInt_t i)
  const
{
  if (i < fSimRdPulses.size())
    return fSimRdPulses[i];

  throw out_of_range("Station does not exist");
}


const SimRdPulse&
RdEvent::GetSimRdPulseById(const UInt_t id)
  const
{
  for (unsigned int i = 0, n = fSimRdPulses.size(); i < n; ++i)
    if (fSimRdPulses[i].GetId() == id)
      return fSimRdPulses[i];

  throw out_of_range("Station does not exist");
}


bool
RdEvent::HasRdSignalTraces()
  const
{
  for (unsigned int i = 0, n = fRStations.size(); i < n; ++i)
    if (!fRStations[i].GetRdTimeTrace(1).empty())
      return true;

   return false;
}


bool
RdEvent::HasRdSignalAbsSpectra()
  const
{
  for (unsigned int i = 0, n = fRStations.size(); i < n; ++i)
    if (!fRStations[i].GetRdAbsSpectrum(1).empty())
      return true;

  return false;
}


void
RdEvent::DumpASCII(std::ostream& o)
  const
{
  if (!fRdEventId)
    return;

  o << "\n"
       "  Radio Id           " << fRdEventId << "\n"
       "  Run Id             " << fRdRunNumber << std::endl;

  fRdRecShower.DumpASCII(o);
}


