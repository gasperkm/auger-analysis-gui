#ifndef _adst_RdEvent_h_
#define _adst_RdEvent_h_

#include <RdRecShower.h>
#include <RdRecStation.h>
#include <RdRecLevel.h>
#include <SimRdPulse.h>

#include <TObject.h>
#include <TF1.h>

#include <vector>
#include <iostream>


class TClonesArray;


//  class to hold Radio event

class RdEvent : public TObject {

public:
  RdEvent();
  ~RdEvent();

  RdRecShower& GetRdRecShower();
  const RdRecShower& GetRdRecShower() const;
  /// get station with index "i"
  RdRecStation& GetRdStation(const UInt_t i);
  SimRdPulse& GetSimRdPulse(const UInt_t i);
  SimRdPulse& GetSimRdPulseById(const UInt_t id);
  RdRecStation& GetRdStationById(const UInt_t id);
  const RdRecStation& GetRdStation(const UInt_t i) const;
  const RdRecStation& GetRdStationById(const UInt_t id) const;
  const SimRdPulse& GetSimRdPulse(const UInt_t i) const;
  const SimRdPulse& GetSimRdPulseById(const UInt_t id) const;
  const std::vector<RdRecStation>& GetRdStationVector() const { return fRStations; }
  const std::vector<SimRdPulse>& GetSimRdPulseVector() const { return fSimRdPulses; }

  /// ask for presence of station with ID "id"
  bool HasRdStation(const unsigned int id) const;
  bool HasSimRdPulse(const unsigned int id) const;

  bool HasRdStations() const { return !fRStations.empty(); }

  void AddRdStation(const RdRecStation& s);
  void AddRdStationWithId(const UInt_t id);
  void AddSimRdPulse(const SimRdPulse& s);
  void AddSimRdPulseWithId(const UInt_t id); //< Create a new SimRdPulse with id =id

  Int_t GetRdEventId() const { return fRdEventId; }
  Int_t GetRdRunNumber() const { return fRdRunNumber; }
  ERdRecLevel GetRdRecLevel() const { return fRRecLevel; }
  Int_t GetGPSSecond() const { return fRGPSSecond; }
  Int_t GetGPSNanoSecond() const { return fRGPSNanoSecond; }

  void SetRejectionStatus(const int statRejected) { fRejectionStatus = statRejected; }
  Int_t GetRejectionStatus() const { return fRejectionStatus; }
  bool IsRejected() const { return fRejectionStatus; }

  void SetRdEventId(const Int_t event) { fRdEventId = event; }
  void SetRdRunNumber(const Int_t run) { fRdRunNumber = run; }
  void SetRdRecLevel(const ERdRecLevel l) { fRRecLevel = l; }
  void SetRdEventTime(const Int_t gPSSec, const Int_t gPSNSec) { fRGPSSecond = gPSSec; fRGPSNanoSecond = gPSNSec; }

  //void SetBadPeriodId(const Int_t badId){fRBadPeriodId= badId; } ///< set the bad period id
  bool HasRdShower() { return fHasShower; }
  void SetHasRdShower() { fHasShower = true; fRRecLevel = eHasRdShower; }
  bool HasRdSignalTraces() const;
  bool HasRdSignalAbsSpectra() const;
  bool HasRdLDF() const { return fRRecLevel >= eHasRdLDF; }
  //int GetBadPeriodId() const { return fRBadPeriodId; }

  void DumpASCII(std::ostream& o = std::cout) const;

private:
  Int_t fRdEventId;
  Int_t fRdRunNumber;
  //Int_t fRBadPeriodId;
  ERdRecLevel fRRecLevel;
  Int_t fRGPSSecond;
  Int_t fRGPSNanoSecond;
  bool fHasShower;
  std::string fRCDASSender;
  std::string fRCDASAlgo;

  Int_t fRejectionStatus;

  RdRecShower fRdRecShower;
  std::vector<RdRecStation> fRStations;
  std::vector<SimRdPulse> fSimRdPulses;

  ClassDef(RdEvent, 7);
};


#endif
