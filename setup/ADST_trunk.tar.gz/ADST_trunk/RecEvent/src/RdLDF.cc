#include <RdLDF.h> 
#include <TF1.h>
using namespace std; 
ClassImp(RdLDF); 

RdLDF::RdLDF() : 
frefcore(eFit) { 
  }

RdLDF::~RdLDF() { 
  }

