#ifndef __RdRecChannel_h_
#define __RdRecChannel_h_

#include <RdTrace.h>

#include <TObject.h>

#include "ChannelRRecDataQuantities.h"
#include "RdRecChannelParameterStorageMap.h"

#include <vector>
#include <map>
#include <stdexcept>


//  Channel data definition

class RdRecChannel : public TObject {

  // MM TOADD         : Antenna description ( LPDA/SALLA/Dipole/etc..)

public:
  RdRecChannel();
  ~RdRecChannel();

  void SetParameter(const revt::ChannelRRecDataQuantities eIndex, const double value)
  { fChannelQuantities.SetParameter(eIndex, value); }
  void SetParameterError(const revt::ChannelRRecDataQuantities eIndex, const double value)
  { fChannelQuantities.SetParameterError(eIndex, value); }
  void SetParameterCovariance(const revt::ChannelRRecDataQuantities eIndex1,
                              const revt::ChannelRRecDataQuantities eIndex2,
                              const double value)
  { fChannelQuantities.SetParameterCovariance(eIndex1, eIndex2 ,value); }
  
  double GetParameter(const revt::ChannelRRecDataQuantities eIndex) const
  { return fChannelQuantities.GetParameter(eIndex); }
  
  double GetParameterError(const revt::ChannelRRecDataQuantities eIndex) const
  { return fChannelQuantities.GetParameterError(eIndex); }
  
  double GetParameterCovariance(const revt::ChannelRRecDataQuantities eIndex1,
                                const revt::ChannelRRecDataQuantities eIndex2) const
  { return fChannelQuantities.GetParameterCovariance(eIndex1, eIndex2); }
  
  bool HasParameter(const revt::ChannelRRecDataQuantities eIndex) const
  { return fChannelQuantities.HasParameter(eIndex); }

  bool HasParameterError(const revt::ChannelRRecDataQuantities eIndex) const
  { return fChannelQuantities.HasParameterCovariance(eIndex, eIndex); }
  
  bool HasParameterCovariance(const revt::ChannelRRecDataQuantities eIndex1,
                              const revt::ChannelRRecDataQuantities eIndex2) const
  { return fChannelQuantities.HasParameterCovariance(eIndex1, eIndex2); }
  
  // ------------------ setters and getters ----------------------------------------------

  /** Get traces as vectors of floats or as RdTrace objects (equivalent to FFTDataContainer in Offline) **/

  void SetRdTimeTrace(const std::vector<Float_t>& timeTrace);
  const std::vector<Float_t>& GetRdTimeTrace() const;

  void SetRdAbsSpectrum(const std::vector<Float_t>& freqTrace);
  const std::vector<Float_t>& GetRdAbsSpectrum() const;

  const RdTrace& GetRdTrace() const;
  RdTrace& GetRdTrace();
  void SetRdTrace(const RdTrace& trace);

  /* Channel id */

  UInt_t GetId() const;
  void SetId(const UInt_t id);

  /* other information */

  UInt_t GetADCSignalThreshold() const;
  void SetADCSignalThreshold(const UInt_t tresh);
  UInt_t GetADCNoiseThreshold() const;
  void SetADCNoiseThreshold(const UInt_t tresh);
  void SetSaturated(const bool chanSaturated = true);
  bool IsSaturated() const;
  void SetScintillatorTop(const bool chanScintillatorTop = true);
  bool IsScintillatorTop() const;
  void SetScintillatorBottom(const bool chanScintillatorBottom = true);
  bool IsScintillatorBottom() const;


private:
  RdRecChannelParameterStorageMap fChannelQuantities;
    
  RdTrace fTrace;
  UInt_t fId;
  UInt_t fADCSignalThreshold;
  UInt_t fADCNoiseThreshold;
  Bool_t fIsSaturated;
  Bool_t fIsScintillatorTop;
  Bool_t fIsScintillatorBottom;

  ClassDef(RdRecChannel, 1);

};

#endif
