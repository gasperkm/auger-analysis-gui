#ifndef __RdRecShower_H
#define __RdRecShower_H
#include "TF1.h"
#include "TVector3.h"
#include "TFitResult.h"
#include "TMath.h"
#include <RdRecLevel.h>
#include <RecShower.h>
#include <RdBeamQuants.h>
#include "ShowerRRecDataQuantities.h"
#include "RdRecShowerParameterStorageMap.h"

#include <iostream>
#include <stdexcept>

#include <string>

//
//  Shower data definition
//


class RdRecShower : public RecShower {

public:

  RdRecShower();
  virtual ~RdRecShower() { }


  void SetParameter(const revt::ShowerRRecDataQuantities eIndex,const double value) {
    fShowerQuantities.SetParameter(eIndex,value);
  }
  void SetParameterError(const revt::ShowerRRecDataQuantities eIndex,const double value) {
    fShowerQuantities.SetParameterError(eIndex,value);
  }
  void SetParameterCovariance(const revt::ShowerRRecDataQuantities eIndex1, const revt::ShowerRRecDataQuantities eIndex2 ,const double value) {
    fShowerQuantities.SetParameterCovariance(eIndex1, eIndex2 ,value);
  }

  double GetParameter(const revt::ShowerRRecDataQuantities eIndex) const {
    return fShowerQuantities.GetParameter(eIndex);
  }

  double GetParameterError(const revt::ShowerRRecDataQuantities eIndex) const {
    return fShowerQuantities.GetParameterError(eIndex);
  }

  double GetParameterCovariance(const revt::ShowerRRecDataQuantities eIndex1, const  revt::ShowerRRecDataQuantities eIndex2) const {
    return fShowerQuantities.GetParameterCovariance(eIndex1,eIndex2);
  }

  bool HasParameter(const revt::ShowerRRecDataQuantities eIndex) const  {
    return fShowerQuantities.HasParameter(eIndex);
  }

  bool HasParameterCovariance(const revt::ShowerRRecDataQuantities eIndex1, const  revt::ShowerRRecDataQuantities eIndex2) const  {
    return fShowerQuantities.HasParameterCovariance( eIndex1, eIndex2);
  }



  /// return the radius (from the spherical wave fit) radius (in AugerUnits = m), return NaN if radius is not defined
  double GetRadius() const;
  double GetAERAScintRadius() const;
  /// return the error on the radius (in AugerUnits = m), return NaN if radius error is not defined. ATTENTION: This error is not correct, because covariances are not considered.
  double GetRadiusError() const { return fRadiusError; }
  void SetRadiusError(const double error) { fRadiusError = error; }

  /// return the Azimuth given by the prefit (in AugerUnits = radian) or NaN if the variable is not defined
  double GetAzimuthPreFit()  const;

  double GetAzimuthPreFitError() const { return fAzimuthPreFitError; }
  void SetAzimuthPreFitError(const double error) { fAzimuthPreFitError = error; }

  /// return the Azimuth given by the fit (in AugerUnits = radian) or NaN if the variable is not defined
  double GetAzimuth() const ;
  double GetAERAScintAzimuth() const;

  double GetAzimuthError() const { return fAzimuthError; }
  void SetAzimuthError(const double error) { fAzimuthError = error; }

  /// return the Zenith given by the prefit (in AugerUnits = radian) or NaN if the variable is not defined
  double GetZenithPreFit()  const;

  double GetZenithPreFitError()  const { return fZenithPreFitError; }
  void SetZenithPreFitError(const double error) { fZenithPreFitError = error; }

  /// return the Zenith given by the fit (in AugerUnits = radian) or NaN if the variable is not defined
  double GetZenith()  const;
  double GetZenithError() const { return fZenithError; }
  void SetZenithError(const double error) { fZenithError = error; }

  double GetAERAScintZenith() const;

  void SetRdLDF(const std::vector<TF1> ldf) { fRdLDF = ldf; }
  void SetRdLDFFitResult(const std::vector<TFitResult> fitresult) { fRdLDFFitResult = fitresult; }

  const std::vector<TF1>& GetRdLDF() const { return fRdLDF; }
  const std::vector<TFitResult>& GetRdLDFFitResult() const { return fRdLDFFitResult; }

  void SetMagneticField(const TVector3 mf) { fMagneticField = mf; }
  const TVector3& GetMagneticField() const { return fMagneticField; }

  void Set2dLDFFitResult(const TFitResult ldf) { f2dLDFFitResult = ldf; }
  const TFitResult Get2dLDFFitResult() const { return f2dLDFFitResult; }

  void SetScintLDF(const TF1 ldf) { fScintLDF = ldf; }
  const TF1& GetScintLDF() const { return fScintLDF; }


  /// get the magnetic field vector in the local coordinate system, if not get fall-back default value
  TVector3 GetMagneticFieldVector() const
  {
    if ( HasParameter(revt::eMagneticFieldVectorX)
      && HasParameter(revt::eMagneticFieldVectorY)
      && HasParameter(revt::eMagneticFieldVectorZ) )
      return TVector3(GetParameter(revt::eMagneticFieldVectorX), GetParameter(revt::eMagneticFieldVectorY), GetParameter(revt::eMagneticFieldVectorZ));
    else {
      // fall back to Auger magnetic field values used previously in RD simulation sets
      TVector3 bfield = TVector3(24300.,0,0); // strength 24300 nanoTesla
      double zenithGeo = 54.4 * TMath::DegToRad(); // inclination -36.6 degrees
      double azimuthGeo = 87.3 * TMath::DegToRad(); // declination 2.7 degrees
      bfield.SetTheta(zenithGeo);
      bfield.SetPhi(azimuthGeo);
      return bfield;
    }
  }

/////////////////////////////////////////////////////////
/// old getter functions /////////////////////
/////////////////////////////////////////////////////////


  /// get the chi2 from the wave fit, return nan if not defined
  Double_t GetRdPlaneFitChi2() const;

  /// get the no of degrees of freedom from the wave fit, return nan if not defined
  Double_t GetRdPlaneFitNDoF() const;


  /** Get the reconstruction stage of the wave fit (defined in ShowerRRecData.cc)
  *   kBary                    = 0.5;
  *   kPreWaveFit              = 1;
  *   kPlaneFitLinear2         = 1.1;
  *   kPlaneFit3d              = 1.2;
  *   kSphericalWaveFit        = 1.5;
  *   kSphericalWaveFitVarC    = 1.6;
  *   kConicalWaveFit          = 1.7;
  *   kHyperbolicWaveFit       = 1.9;
  **/
  double GetRdRecStage() const ;

  double GetRdFitConvergenceStatus() const ;
  double GetRdFitSuccess() const;


  const RdBeamQuants &GetRdBeamResult () {return fRdBeamResult; }
  void SetRdBeamResult (const RdBeamQuants &result)  { fRdBeamResult = result; }

  void DumpASCII(std::ostream &o=std::cout) const;

private:

  Double_t fRadiusError;
  Double_t fAzimuthError;
  Double_t fZenithError;

  Double_t fZenithPreFitError;
  Double_t fAzimuthPreFitError;

  RdRecShowerParameterStorageMap fShowerQuantities;

  RdBeamQuants fRdBeamResult;

  std::vector<TF1> fRdLDF;
  std::vector<TFitResult> fRdLDFFitResult;
  TFitResult f2dLDFFitResult;
  TVector3 fMagneticField;
  TF1 fScintLDF;

  ClassDef(RdRecShower, 18);
};

#endif
