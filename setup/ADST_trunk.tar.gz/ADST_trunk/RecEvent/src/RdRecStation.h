#ifndef __RdRecStation_h_
#define __RdRecStation_h_


#include <RecStation.h> // for the enums
#include <RdTrace.h>
#include <RdRecChannel.h>

#include <TObject.h>

#include "StationRRecDataQuantities.h"
#include "RdRecStationParameterStorageMap.h"

#include <vector>
#include <map>
#include <stdexcept>


//  Station data definition

typedef std::vector<RdRecChannel> RdRecChannels;


class RdRecStation : public TObject {

public:
  RdRecStation();
  ~RdRecStation();

  void SetId(const UInt_t id) { fId = id; }               ///< set  id of station
  UInt_t GetId() const { return fId; }                    ///< get  id of station

  void SetParameter(const revt::StationRRecDataQuantities eIndex, const double value)
  { fStationQuantities.SetParameter(eIndex, value); }
  void SetParameterError(const revt::StationRRecDataQuantities eIndex, const double value)
  { fStationQuantities.SetParameterError(eIndex, value); }
  void SetParameterCovariance(const revt::StationRRecDataQuantities eIndex1,
                              const revt::StationRRecDataQuantities eIndex2,
                              const double value)
  { fStationQuantities.SetParameterCovariance(eIndex1, eIndex2, value); }
  
  double GetParameter(const revt::StationRRecDataQuantities eIndex) const
  { return fStationQuantities.GetParameter(eIndex); }
  
  double GetParameterError(const revt::StationRRecDataQuantities eIndex) const
  { return fStationQuantities.GetParameterError(eIndex); }
  
  double GetParameterCovariance(const revt::StationRRecDataQuantities eIndex1,
                                const revt::StationRRecDataQuantities eIndex2) const
  { return fStationQuantities.GetParameterCovariance(eIndex1, eIndex2); }
  
  bool HasParameter(const revt::StationRRecDataQuantities eIndex) const
  { return fStationQuantities.HasParameter(eIndex); }

  bool HasParameterError(const revt::StationRRecDataQuantities eIndex) const
  { return fStationQuantities.HasParameterCovariance(eIndex, eIndex); }
  
  bool HasParameterCovariance(const revt::StationRRecDataQuantities eIndex1,
                              const revt::StationRRecDataQuantities eIndex2) const
  { return fStationQuantities.HasParameterCovariance(eIndex1, eIndex2); }
  
  // ------------------ setters and getters ----------------------------------------------

  /// directly access the map of channels stored in this station
  const RdRecChannels& GetRdChannelVector() const { return fChannels; }
  RdRecChannels& GetRdChannelVector() { return fChannels; }

  void SetHasPulse(const bool pulsefound = true) { fPulsefound = pulsefound; }
  bool HasPulse() const { return fPulsefound; }
  
  void SetSaturated(const bool statSaturated = true) { fSaturated = statSaturated; }
  bool IsSaturated() const { return fSaturated; }

  void SetRejectionStatus(const ULong64_t statRejected = 1) { fRejectionStatus = statRejected; }
  ULong64_t GetRejectionStatus() const { return fRejectionStatus; }
  bool IsRejected() const { return fRejectionStatus != 0; }

  /** Get traces as vectors of floats or as RdTrace objects (equivalent to FFTDataContainer in Offline)
   *  polNb corresponds to 0/1/2 for East, North, Vertical **/

  void SetRdTimeTrace(const std::vector<Float_t>& timeTrace, const int polNb);
  const std::vector<Float_t>& GetRdTimeTrace(const int polNb) const;
  const std::vector<Float_t>& GetRdTimeTraceShowerPlane(const int polNb) const;
  const std::vector<Float_t>& GetRdTimeTraceAnalyticSignal(const int polNb) const;
  void SetRdAbsSpectrum(const std::vector<Float_t>& freqTrace, const int polNb);
  const std::vector<Float_t>& GetRdAbsSpectrum(const int polNb) const;
  const RdTrace& GetRdTrace(const int polNb) const;
  const RdTrace& GetRdTraceShowerPlane(const int polNb) const;
  RdTrace& GetRdTrace(const int polNb);
  RdTrace& GetRdTraceShowerPlane(const int polNb);
  bool HasRdTraceShowerPlane(const int polNb) const
  { return fTracesShowerPlane.find(polNb) != fTracesShowerPlane.end(); }
  bool HasRdTimeTraceAnalyticSignal(const int polNb) const
  { return fTracesAnalyticSignal.find(polNb) != fTracesAnalyticSignal.end(); }
  void SetRdTrace(const RdTrace& trace, const int polNb);
  void SetRdTraceShowerPlane(const RdTrace& trace, const int polNb);
  void SetRdTraceAnalyticSignal(const RdTrace& trace, const int polNb);

  // sorting criterion: sort by signal stations, then non-signal stations, and within those by station id
  static bool SignalStationsFirst(const RdRecStation& lhs, const RdRecStation& rhs);

private:
  RdRecStationParameterStorageMap fStationQuantities;
    
  //ESaturationStatus fSaturationStatus;

  /// Radio signal variables

  UInt_t fId;
  Bool_t fPulsefound;
  Bool_t fSaturated;
  ULong64_t fRejectionStatus;
  std::map<int, RdTrace> fTraces;
  std::map<int, RdTrace> fTracesShowerPlane;
  std::map<int, RdTrace> fTracesAnalyticSignal;
  RdRecChannels fChannels;

  ClassDef(RdRecStation, 18);

};

#endif
