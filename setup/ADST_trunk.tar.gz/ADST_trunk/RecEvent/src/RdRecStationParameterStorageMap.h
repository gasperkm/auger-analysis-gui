#ifndef __RdRecStationParameterStorageMap_H
#define __RdRecStationParameterStorageMap_H
#include <TObject.h>
#include <map>
#include <utility>
#include <stdexcept>
#include <sstream>
#include <cmath>
#include "StationRRecDataQuantities.h"

class RdRecStationParameterStorageMap : public TObject {
  public:
    typedef revt::StationRRecDataQuantities ParameterKey;
    typedef std::pair<revt::StationRRecDataQuantities, revt::StationRRecDataQuantities> CovarianceKey;

    typedef std::map<ParameterKey, double> ParameterMap;
    typedef std::map<CovarianceKey, double> CovarianceMap;

//     RdRecStationParameterStorageMap();
//     virtual ~RdRecStationParameterStorageMap();

    void
    SetParameter(const ParameterKey index, const double value)
    {
      fParameterMap[index] = value;
    }

    void
    SetParameterCovariance(const ParameterKey index1, const ParameterKey index2, const double value)
    {
      fCovarianceMap[GenCovarianceKey(index1, index2)] = value;
    }

    void
    SetParameterError(const ParameterKey index, const double value)
    {
      SetParameterCovariance(index, index, value * value);
    }

    double
    GetParameter(const ParameterKey index)
      const
    {
      const ParameterMap::const_iterator it = fParameterMap.find(index);
      if (it != fParameterMap.end()) {
        return it->second;
      }
      else {
        std::stringstream sstr;
        sstr << "Station Parameter " << index << " not set";
        throw std::out_of_range(sstr.str().c_str());
      }
    }

    double
    GetParameterCovariance(const ParameterKey index1,
                           const ParameterKey index2)
      const
    {
      const CovarianceMap::const_iterator it =
        fCovarianceMap.find(GenCovarianceKey(index1, index2));

      if (it != fCovarianceMap.end()) {
        return it->second;
      }
      else {
        std::stringstream sstr;
        sstr << "Station ParameterCovariance " << index1 << ", " << index2 << " not set";
        throw std::out_of_range(sstr.str().c_str());
      }
    }

    double
    GetParameterError(const ParameterKey index)
      const
    {
      return std::sqrt(GetParameterCovariance(index, index));
    }

    bool
    HasParameter(const ParameterKey index)
      const
    {
      return fParameterMap.find(index) != fParameterMap.end();
    }

    bool
    HasParameterCovariance(const ParameterKey index1,
                           const ParameterKey index2)
      const
    {
      return fCovarianceMap.find(GenCovarianceKey(index1, index2))
        != fCovarianceMap.end();
    }

  private:

    ParameterMap fParameterMap;
    CovarianceMap fCovarianceMap;

    /// helper function to create the key for the covariance map from the parameters using sorting
    inline
    CovarianceKey
    GenCovarianceKey(const ParameterKey param1,
                     const ParameterKey param2)
    const
    {
      if (long(param1) < long(param2))
        return std::make_pair(param1, param2);
      else
        return std::make_pair(param2, param1);
    }

  ClassDef(RdRecStationParameterStorageMap, 5);
};

#endif
