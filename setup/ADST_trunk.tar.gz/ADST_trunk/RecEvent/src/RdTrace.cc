#include <RdTrace.h>

#include <iostream>
using namespace std;

 //=============================================================================
 /*!
   \class   RdTrace
   \brief   Contains the Trace from a radio station
   \brief   A trace includes the time trace and the frequency trace

   \version 1.0
   \date    January 2011
   \author  Maximilien Melissas

 */
 //=============================================================================

//ClassImp(RdTrace);

RdTrace::RdTrace() : 
fFreqMin(0),
fFreqMax(0),
fSamplingRate(0) {
        }
        
RdTrace::~RdTrace() { 
        fTimeTrace.clear();
        fAbsoluteFreqSpectrum.clear();                
        } 

Float_t RdTrace::Bin2Freq(Int_t bin) const  {
  Float_t slope=(fFreqMax-fFreqMin)/(fAbsoluteFreqSpectrum.size());
  Float_t rval=fFreqMin+slope*float(bin) ;
  //          return Float_t(fFreqMin+slope*float(bin));        
  return rval;
}
Float_t RdTrace::Bin2Time(Int_t bin) const
{
  return Float_t(bin) * fSamplingRate;
}
Int_t RdTrace::Time2Bin(Double_t time) const
{
  return Int_t(time / fSamplingRate);
}
void RdTrace::operator=(RdTrace rtr2) { 
  fFreqMin=rtr2.GetMinFreq();
  fFreqMax=rtr2.GetMaxFreq();
  fSamplingRate=rtr2.GetSamplingRate();
  fTimeTrace=rtr2.GetTimeTrace();
  fAbsoluteFreqSpectrum=rtr2.GetAbsoluteFreqSpectrum();                
}
