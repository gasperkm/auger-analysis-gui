#include <RecEventFile.h>
#include <FileInfo.h>
#include <DetectorGeometry.h>
#include <RecEvent.h>
#include <EventInfo.h>
#include <SdTriggerType.h>

#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <memory>

#include <TObject.h>
#include <TFile.h>
#include <TTree.h>
#include <TBranch.h>
#include <TChain.h>
#include <TDirectory.h>
#include <TChainElement.h>
#include <TObjArray.h>

using namespace std;


//=============================================================================
/*!
  \class RecEventFile
  \brief Class to handle saving/reading of FdRecEvent data.

  This class is able to create/write a ROOT file containing
  Offline reconstruction data:

  @li FdRecShower
  @li FdRecApertureLight
  @li FdRecPixel
  @li SdRecShower
  @li UnivRecShower
  @li SdRecStation
  @li FdRecStation
  @li GenStation
  @li GenShower
  @li FdGenGeometry


  \version 2.0
  \date    Dec 15 2005
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger

*/
//=============================================================================

const char* const RecEventFile::kDetectorGeometryName = "detectorGeometry";
const char* const RecEventFile::kFileInfoName = "fileInfo";

const char* const RecEventFile::kDataTreeName = "recData";
const char* const RecEventFile::kEventInfoTreeName = "eventInfo";

const char* const RecEventFile::kDataBranchName = "event.";
const char* const RecEventFile::kEventInfoBranchName = "info.";

// FD event & sub-objects
const char* const RecEventFile::kFDEventsBranchName = "fFDEvents";
const char* const RecEventFile::kFdRecShowerBranchName = "fFdRecShower";
const char* const RecEventFile::kFdRecApertureLightBranchName = "fFdRecApertureLight";
const char* const RecEventFile::kFdRecGeometryBranchName = "fFdRecGeometry";
const char* const RecEventFile::kSdRecGeometryBranchName = "fSdRecGeometry";
const char* const RecEventFile::kFdRecPixelBranchName = "fFdRecPixel";
const char* const RecEventFile::kFdGenGeometryBranchName = "fFdGenGeometry";
const char* const RecEventFile::kFdGenApertureLightBranchName = "fFdGenApertureLight";

// SDEvent &  sub-objects
const char* const RecEventFile::kSDEventBranchName = "fSDEvent";
const char* const RecEventFile::kSdRecShowerBranchName = "fSdRecShower";

const char* const RecEventFile::kUnivRecShowerBranchName = "fUnivRecShower";

//Radio
const char* const RecEventFile::kRdEventBranchName = "fRdEvent";
const char* const RecEventFile::kRStationVectorBranchName = "fRStations";

// GenShower
const char* const RecEventFile::kGenShowerBranchName = "fGenShower";

// vector branches
const char* const RecEventFile::kDepthVectorBranchName = "fDepth*";
const char* const RecEventFile::kHeightVectorBranchName = "fHeight*";
const char* const RecEventFile::kElectronVectorBranchName = "fElectrons*";
const char* const RecEventFile::kEnergyDepositVectorBranchName = "fEnergyDeposit*";
const char* const RecEventFile::kStationVectorBranchName = "fStations";
const char* const RecEventFile::kGenStationVectorBranchName = "fGenStations";


/*RecEventFile::RecEventFile(const char* const fname, const Mode mode,
			   const Int_t zipLevel, const int saveSelf) :
  fFile(0),
  fMode(mode),
  fSaveSelf(saveSelf),
  fHasMC(false),
  fNEvents(0),
  fRecEventPtr(0),
  fEventTree(0),
  fCurrentEvent(-1)
{
  AddFile(fname, fMode, zipLevel);
}*/


/// constructor to read or write events (depending on option)
RecEventFile::RecEventFile(const string& fname, const Mode mode,
			   const Int_t zipLevel, const int saveSelf) :
  fFile(0),
  fMode(mode),
  fSaveSelf(saveSelf),
  fHasMC(false),
  fNEvents(0),
  fRecEventPtr(0),
  fEventTree(0),
  fCurrentEvent(-1)
{
  AddFile(fname, fMode, zipLevel);
}


/// constructor to read a list of files
RecEventFile::RecEventFile(const vector<string>& fname) :
  fFile(0),
  fMode(eRead),
  fSaveSelf(-1),
  fHasMC(false),
  fNEvents(0),
  fRecEventPtr(0),
  fEventTree(0),
  fCurrentEvent(-1)
{
  for (vector<string>::const_iterator iFile = fname.begin();
       iFile != fname.end(); ++iFile) {
    cerr << "  input file " << *iFile << endl;
    AddFile(*iFile, eRead);
  }
}


/// constructor to read a list of files
RecEventFile::RecEventFile(const char* const * fileNamePointer) :
  fFile(0),
  fMode(eRead),
  fSaveSelf(-1),
  fHasMC(false),
  fNEvents(0),
  fRecEventPtr(0),
  fEventTree(0),
  fCurrentEvent(-1)
{
  while (*fileNamePointer) {
    cout << "  input file " << *fileNamePointer << endl;
    AddFile(*fileNamePointer, eRead);
    ++fileNamePointer;
  }
}


RecEventFile::~RecEventFile()
{
  Close();

  if (fMode == eRead) {
    delete fEventTree;
    delete fEventInfoTree;
  }
}


void
RecEventFile::AddFile(const string& fname, const Mode mode, const Int_t zipLevel)
{
  TDirectory* const save = gDirectory;

  if (mode != eRead && !fFileList.empty()) {
    cerr << " RecEventFile: in write mode only one file can be loaded!! "
            " ListSize: " << fFileList.size() << "\n"
            "               skipping: " << fname << endl;
    return;
  }

  // prepare access to files by using TChains
  if (mode == eRead) {

    if (!fEventTree) {
      fEventInfoTree = new TChain(kEventInfoTreeName);
      fEventTree = new TChain(kDataTreeName);
    }

    ((TChain*)fEventInfoTree)->Add(fname.c_str());
    const int nEventChain = ((TChain*)fEventTree)->Add(fname.c_str());

    if (!nEventChain) {
      cerr << " RecEventFile::RecEventFile - Error: no tree "
           << kDataTreeName
           << " found in file " << fname << "\n exit ..." << endl;
      return;
    } else {
      const int nInfo = int(fEventInfoTree->GetEntries());
      fNEvents = int(fEventTree->GetEntries());
      if (nInfo != fNEvents)
        cerr << " RecEventFile::RecEventFile - inconsistent entries: "
             << nInfo << " " << fNEvents << endl;

      FileInfo theFileInfo;
      ReadFileInfo(theFileInfo);
      if (theFileInfo.HasMC())
        fHasMC = true;
    }
  } else { // Write mode
    string option;
    switch (mode) {
    case eRead:
      option = "read";
      break;
    case eAppend:
      option = "update";
      break;
    case eWrite:
      option = "recreate";
      break;
    }

    fFile = new TFile(fname.c_str(), option.c_str(), "", zipLevel);

    if (!fFile || fFile->IsZombie()) {
      cerr << " RecEventFile::RecEventFile - Error opening file "
           << fname << "\n"
           << " skip ..." << endl;
      save->cd();
      delete fFile;
      fFile = 0;
      return;
    }

    // Append mode
    if (mode == eAppend) {
      fEventTree = (TTree*)fFile->Get(kDataTreeName);
      fEventInfoTree = (TTree*)fFile->Get(kEventInfoTreeName);

      // Event tree exists
      if (fEventTree) {
        fNEvents = int(fEventTree->GetEntries());

        if (fEventInfoTree)
          fNEvents = int(fEventInfoTree->GetEntries());
      } else {
        // Event tree does not exist, e.g., file is empty
        cerr << " RecEventFile::RecEventFile - APPEND Warning: no tree "
             << kDataTreeName << " found in file " << fname
             << "\n Switching to WRITE mode ..." << endl;

        fMode = eWrite;
        fNEvents = 0;
      }
    } else {
      // Write mode
      fNEvents = 0;
    }
  }

  fFileList.push_back(fname);
  fSDEventIndex.clear();
  fAugerEventIndex.clear();

  save->cd();
}


/// pass pointers to the objects (needed before the first reading/writing)
RecEventFile::Status
RecEventFile::SetBuffers(RecEvent** rec)
{
  if (fRecEventPtr) {
    cerr << " RecEventFile::SetBuffers"
	    " - Error: Addresses can only be set once!" << endl;
    return eFailure;
  }

  //fRecFile->cd();
  TDirectory* const save = gDirectory;

  fRecEventPtr = rec;

  if (fMode == eWrite && fFile) {
    fFile->cd();
    if (*rec) {
      fEventTree = new TTree(kDataTreeName, "Offline reconstruction Tree");
      fEventTree->Branch(kDataBranchName, "RecEvent", fRecEventPtr, 16000, 99);
      fEventInfoTree = new TTree(kEventInfoTreeName, "Event Info Tree");
      fEventInfo = new EventInfo();
      fEventInfoTree->Branch(kEventInfoBranchName, "EventInfo", &fEventInfo, 16000, 99);
    }
  } else if (rec && fEventTree) {
    if (!fHasMC) {
      // switch-off reading of MC related variables
      const string fd = string(kDataBranchName) + kFDEventsBranchName;
      fEventTree->SetBranchStatus((fd + ".fFdGen*").c_str(), 0);
      const string sd = string(kDataBranchName) + kSDEventBranchName;
      fEventTree->SetBranchStatus((sd + ".fGen*").c_str(), 0);
      fEventTree->SetBranchStatus((string(kDataBranchName) + kGenShowerBranchName + "*").c_str(), 0);
    }

    /*
      const string rd = string(kDataBranchName) + kRdEventBranchName;
      fEventTree->SetBranchStatus((rd + "." + kRStationVectorBranchName).c_str(), 1);
    */
    fEventTree->SetBranchAddress(kDataBranchName, fRecEventPtr);
    fEventInfoTree->SetBranchAddress(kEventInfoBranchName, &fEventInfo);
  }

  save->cd();
  return eSuccess;
}


/// close everything
void
RecEventFile::Close(const bool writeEventInfo)
{
  // nothing to do in read mode
  if (fMode == eRead || !fFile)
    return;

  fFile->cd();
  if (fEventTree)
    fEventTree->Write();
  if (fEventInfoTree && writeEventInfo)
    fEventInfoTree->Write();

  fFile->Close();
  delete fFile;
  fFile = NULL;
}


RecEventFile::Status
RecEventFile::ReadDetectorGeometry(DetectorGeometry& theGeo)
  const
{
  if (&theGeo == 0)
    return eFailure;

  if (!fEventTree)
    return eFailure;

  TDirectory* const save = gDirectory;

  bool firstFile = true;
  // stolen from TChain::AddFile docs
  TObjArray* const fileElements = ((TChain*)fEventTree)->GetListOfFiles();
  TIter next(fileElements);
  TChainElement* chEl = 0;
  while ((chEl = (TChainElement*)next())) {
    TFile file(chEl->GetTitle());
    file.cd();
    DetectorGeometry* const thisGeo = (DetectorGeometry*)file.Get(kDetectorGeometryName);
    if (firstFile) {
      theGeo = *thisGeo;
      firstFile = false;
    } else {
      theGeo.MergeFDFrom(*thisGeo);
      theGeo.MergeStationsFrom(*thisGeo);
    }
    delete thisGeo; // Dear ROOT object ownership, I hate you! Sincerely yours, Steffen
  }

  save->cd();
  return eSuccess;
}


RecEventFile::Status
RecEventFile::WriteDetectorGeometry(const DetectorGeometry& geom)
{
  if (!fFile)
    return eFailure;

  TDirectory* const save = gDirectory;
  fFile->cd();
  geom.Write(kDetectorGeometryName, TFile::kOverwrite);
  save->cd();
  return eSuccess;
}


RecEventFile::Status
RecEventFile::WriteFileInfo(const FileInfo& info)
{
  if (!fFile)
    return eFailure;

  info.fEventInfoClassVersion = EventInfo::Class_Version();
  info.fRecEventClassVersion = RecEvent::Class_Version();
  info.fSDEventClassVersion = SDEvent::Class_Version();
  info.fFDEventClassVersion = FDEvent::Class_Version();
  info.fShowerClassVersion = Shower::Class_Version();
  info.fRecShowerClassVersion = RecShower::Class_Version();
  info.fFdRecShowerClassVersion = FdRecShower::Class_Version();
  info.fSdRecShowerClassVersion = SdRecShower::Class_Version();
  info.fUnivRecShowerClassVersion = UnivRecShower::Class_Version();
  info.fSdRecStationClassVersion = SdRecStation::Class_Version();
  info.fGenShowerClassVersion = GenShower::Class_Version();
  info.fRdEventClassVersion = RdEvent::Class_Version();
  TDirectory* const save = gDirectory;
  fFile->cd();
  info.Write(kFileInfoName, TFile::kOverwrite);
  save->cd();
  return eSuccess;
}


RecEventFile::Status
RecEventFile::ReadFileInfo(FileInfo& fileInfo)
  const
{
  if (&fileInfo == 0)
    return eFailure;

  if (!fEventTree)
    return eFailure;

  TDirectory* const save = gDirectory;
  TFile* const file = fEventTree->GetCurrentFile();

  if (!file)
    return eFailure;

  FileInfo* const info = (FileInfo*)file->Get(kFileInfoName);
  if (!info)
    return eFailure;

  fileInfo = *info;
  delete info;

  save->cd();
  return eSuccess;
}


RecEventFile::Status
RecEventFile::SetSelection(TEventList &selection)
{
  fEventTree->SetEventList(&selection);
  return eSuccess;
}


RecEventFile::Status
RecEventFile::WriteEvent()
{
  if (!fEventTree)
    return eFailure;

  fEventTree->Fill();
  ++fCurrentEvent;
  ++fNEvents;
  FillEventInfo();

  if (fSaveSelf >= 0 && !(fNEvents % fSaveSelf)) {
    fEventTree->AutoSave("SaveSelf");
    fEventInfoTree->AutoSave("SaveSelf");
  }

  return eSuccess;
}


void
RecEventFile::FillEventInfo()
{
  RecEvent* const theEvent = *fRecEventPtr;

  auto_ptr<EventInfo> eInfo(new EventInfo(theEvent->GetNEyes()));
  fEventInfo = eInfo.get();

  SDEvent& theSdEvent = theEvent->GetSDEvent();
  SdRecShower& theSdShower = theSdEvent.GetSdRecShower();

  GenShower& theGenShower = theEvent->GetGenShower();
  if (theGenShower.GetEnergy() > 0) {
    fEventInfo->SetMCEnergy(theGenShower.GetEnergy());
    fEventInfo->SetMCZenith(theGenShower.GetZenith());
  }

  fEventInfo->SetYYMMDD(theEvent->GetYYMMDD());
  fEventInfo->SetHHMMSS(theEvent->GetHHMMSS());
  fEventInfo->SetAugerId(theEvent->GetAugerIdNumber());
  if (theSdEvent.GetEventId() > 0) {
    fEventInfo->SetSDId(theSdEvent.GetEventId());
    fEventInfo->SetSDRecLevel(theSdEvent.GetRecLevel());
    fEventInfo->SetSDEnergy(theSdShower.GetEnergy());
    fEventInfo->SetSDZenith(theSdShower.GetZenith());
    fEventInfo->SetSDAngChi2Probability(
      theSdShower.GetAngleNDoF() > 0 ?
      TMath::Prob(theSdShower.GetAngleChi2(),theSdShower.GetAngleNDoF()) : 1);
    fEventInfo->SetSDLDFChi2Probability(
      theSdShower.GetLDFNdof() > 0 ?
      TMath::Prob(theSdShower.GetLDFChi2(),theSdShower.GetLDFNdof()) : 1);
    fEventInfo->SetNumberOfStations(theSdEvent.GetNumberOfCandidates());

    if (theSdEvent.GetT4Trigger() > 1)
      fEventInfo->SetIsT4();
    if (theSdEvent.GetT5Trigger() & eT5_6T5)
      fEventInfo->SetIsT5();
    if (theSdEvent.GetT5Trigger() & eT5_5T5)
      fEventInfo->SetIsT5ICRC();
    if (theSdEvent.GetT5Trigger() & eT5_Has)
      fEventInfo->SetIsT5Has();
    if (theSdEvent.IsSaturated())
      fEventInfo->SetIsSaturated();
  }

  const std::vector<FDEvent>& theFDEvents = theEvent->GetFDEvents();
  for (std::size_t i = 0; i < theFDEvents.size(); ++i) {
    const FdRecShower& theFdShower = theFDEvents[i].GetFdRecShower();
    const FdRecPixel&  theFdPixels = theFDEvents[i].GetFdRecPixel();
    fEventInfo->SetEyeId(i, theFDEvents[i].GetEyeId());
    fEventInfo->SetRunId(i, theFDEvents[i].GetRunId());
    fEventInfo->SetEventId(i, theFDEvents[i].GetEventId());
    fEventInfo->SetFDRecLevel(i, theFDEvents[i].GetRecLevel());
    fEventInfo->SetFDEnergy(i, theFdShower.GetEnergy());
    fEventInfo->SetFDZenith(i, theFdShower.GetZenith());
    fEventInfo->SetNumberOfTriggeredPixels(i, theFdPixels.GetNumberOfTriggeredPixels());
    if (theFDEvents[i].IsHybridEvent())
      fEventInfo->SetHybrid(i);
    if (theFdShower.IsXmaxInFOV(0.))
      fEventInfo->SetXmaxInFOV(i);
    if (theFDEvents[i].GetRecLevel() >= eHasGHParameters)
      fEventInfo->SetXmax(i,theFdShower.GetXmax());
  }
  const RdEvent& theRev = theEvent->GetRdEvent();
  fEventInfo->SetRdZenith(theRev.GetRdRecShower().GetZenith());
  fEventInfo->SetRdAzimuth(theRev.GetRdRecShower().GetAzimuth());
  if(theRev.GetRdRecShower().HasParameter(revt::eRecStage)) {
    fEventInfo->SetRdRecStage(theRev.GetRdRecShower().GetParameter(revt::eRecStage));
  } else {
    fEventInfo->SetRdRecStage(std::numeric_limits<double>::quiet_NaN());
  }
  fEventInfo->SetRdEventId(theRev.GetRdEventId());
  fEventInfo->SetRdRunNumber(theRev.GetRdRunNumber());
  if (theRev.GetRdRecShower().HasParameter(revt::eNumberOfStationsWithPulseFound)) {
    fEventInfo->SetRdNumberOfStations(theRev.GetRdRecShower().GetParameter(revt::eNumberOfStationsWithPulseFound));
  } else {
    fEventInfo->SetRdNumberOfStations(std::numeric_limits<double>::quiet_NaN()); // remove when parameters active
  }
  fEventInfoTree->Fill();
}


bool
RecEventFile::GetEventInfo(const int i, EventInfo* theInfo)
{
  if (i >= 0 && i < fNEvents) {
    fEventInfoTree->SetBranchAddress(kEventInfoBranchName, &theInfo);
    fEventInfoTree->GetEntry(i);
    return true;
  } else {
    cerr << " RecEventFile::GetEventInfo - Error accessing event "
         << i << " (file has " << fNEvents << " event)" << endl;
    return false;
  }
}


bool
RecEventFile::GetEventInfos(const int iFirst,
                            const int nEntries,
                            vector<EventInfo>& eventInfoData)
{
  eventInfoData.resize(min(iFirst+nEntries, fNEvents));

  EventInfo theInfo;
  EventInfo* theInfoPtr = &theInfo;
  fEventInfoTree->SetBranchAddress(kEventInfoBranchName, &theInfoPtr);

  const int i1 = max(0, iFirst);
  const int i2 = min(iFirst+nEntries, fNEvents);

  for (int i = i1; i < i2; ++i) {
    fEventInfoTree->GetEntry(i);
    eventInfoData[i] = theInfo;
  }

  if (i2 > fNEvents - 1)
    return false;

  return true;
}


RecEventFile::Status
RecEventFile::ReadNextEvent()
{
  if (fMode != eRead) {
    cerr << "Trying to read from write only file!" << endl;
    return eFailure;
  }

  if (fCurrentEvent < fNEvents - 1) {
    ++fCurrentEvent;
    fEventTree->GetEntry(fCurrentEvent);
    return eSuccess;
  }
  return eFailure;
}


RecEventFile::Status
RecEventFile::ReadEvent(const int iEvent)
{
  if (fMode != eRead) {
    cerr << "Trying to read from write only file!" << endl;
    return eFailure;
  }

  if (SeekEvent(iEvent) == eSuccess) {
    fEventTree->GetEntry(fCurrentEvent);
    return eSuccess;
  }

  return eFailure;
}


RecEventFile::Status
RecEventFile::SeekEvent(const int iEvent)
{
  if (iEvent < fNEvents && iEvent > -1) {
    fCurrentEvent = iEvent;
    return eSuccess;
  }

  return eFailure;
}


RecEventFile::Status
RecEventFile::SearchForSDEvent(const UInt_t sdEventID)
{
  if (fMode != eRead) {
    cerr << " RecEventFile::ReadSDEvent()- "
	 << "Trying to read from write only file!" << endl;
    return eFailure;
  }

  if (fSDEventIndex.empty())
    CreateSDEventMap();

  std::map<unsigned int, unsigned int>::const_iterator sdIter =
    fSDEventIndex.find(sdEventID);

  if (sdIter != fSDEventIndex.end())
    return ReadEvent(sdIter->second);

  return eFailure;
}


RecEventFile::Status
RecEventFile::SearchForAugerEvent(const ULong_t augerEventID)
{
  if (fMode != eRead) {
    cerr << " RecEventFile::ReadSDEvent()- "
	       << "Trying to read from write only file!" << endl;
    return eFailure;
  }

  if (fAugerEventIndex.empty())
    CreateAugerEventMap();

  std::map<ULong_t, UInt_t>::const_iterator iter =
    fAugerEventIndex.find(augerEventID);

  if (iter != fAugerEventIndex.end())
    return ReadEvent(iter->second);

  return eFailure;
}


void
RecEventFile::CreateSDEventMap()
{
  EventInfo theInfo;
  EventInfo* theInfoPtr = &theInfo;

  fSDEventIndex.clear();

  fEventInfoTree->SetBranchAddress(kEventInfoBranchName, &theInfoPtr);
  for (int i = 0; i < fNEvents; ++i) {
    fEventInfoTree->GetEntry(i);
    fSDEventIndex[theInfo.GetSDId()] = i;
  }
}


void
RecEventFile::CreateAugerEventMap()
{
  EventInfo theInfo;
  EventInfo* theInfoPtr = &theInfo;

  fAugerEventIndex.clear();

  fEventInfoTree->SetBranchAddress(kEventInfoBranchName, &theInfoPtr);
  for (int i = 0; i < fNEvents; ++i) {
    fEventInfoTree->GetEntry(i);
    fAugerEventIndex[theInfo.GetAugerId()] = i;
  }
}


TBranch*
RecEventFile::GetBranch(const std::string& branchname, void* const address)
{
  TBranch* const branch = fEventTree->FindBranch(branchname.c_str());
  if (branch)
    branch->SetAddress(address);

  return branch;
}


bool
RecEventFile::IsMicroADST()
{
  const string fd = string(kDataBranchName) + kFDEventsBranchName;
  const string fdRecShower = fd + "." + kFdRecShowerBranchName;
  return fEventTree->GetBranchStatus((fdRecShower + "." + kElectronVectorBranchName + "*").c_str());
}


void
RecEventFile::SetMicroADST()
{
  if (!fEventTree) {
    cerr << " RecEventFile::SetMicroADST() - no TTree initialized! Ignoring" << endl;
    return;
  }

  if (fRecEventPtr) {
    cerr << " ###################################################\n"
            " RecEventFile::SetBranchStatus() - Error: \n"
            " cannot set Branch status after RecEventFile::SetBuffers()!!\n"
            " Ignoring!\n"
            " ###################################################\n" << endl;
  }

  // FD stuff

  const string fd = string(kDataBranchName) + kFDEventsBranchName;
  const string fdRecShower = fd + "." + kFdRecShowerBranchName;

  fEventTree->SetBranchStatus((fd + "." + kFdRecPixelBranchName + "*").c_str(), 0);
  fEventTree->SetBranchStatus((fd + "." + kFdRecPixelBranchName + ".fnPixel").c_str(), 1);
  fEventTree->SetBranchStatus((fd + "." + kFdRecPixelBranchName + ".fnTrigPixel").c_str(), 1);
  fEventTree->SetBranchStatus((fd + "." + kFdRecPixelBranchName + ".fnRecPixel").c_str(), 1);
  //fEventTree->SetBranchStatus((fdRecShower + "." + kDepthVectorBranchName + "*").c_str(), 0);
  fEventTree->SetBranchStatus((fdRecShower + "." + kElectronVectorBranchName + "*").c_str(), 0);
  fEventTree->SetBranchStatus((fdRecShower + "." + kEnergyDepositVectorBranchName + "*").c_str(), 0);
  fEventTree->SetBranchStatus((fdRecShower + "." + kHeightVectorBranchName).c_str(), 0);
  fEventTree->SetBranchStatus((fd + "." + kStationVectorBranchName + "*").c_str(), 0);
  fEventTree->SetBranchStatus((fd + "." + kFdRecApertureLightBranchName + "*").c_str(), 0);

  fEventTree->SetBranchStatus((fd + ".fFdGen*").c_str(), 0);

  // SD stations
  const string sd = string(kDataBranchName) + kSDEventBranchName;

  fEventTree->SetBranchStatus((sd + "." + kStationVectorBranchName + "*").c_str(), 0);
  fEventTree->SetBranchStatus((sd + "." + kGenStationVectorBranchName + "*").c_str(), 0);

// Radio Station
  const string rd = string(kDataBranchName) + kRdEventBranchName;
  fEventTree->SetBranchStatus((rd + "." + kRStationVectorBranchName).c_str(), 0);

  // simulation
  fEventTree->SetBranchStatus((fd + "." + kFdGenApertureLightBranchName + "*").c_str(), 0);
  fEventTree->SetBranchStatus((string(kDataBranchName) +
                               kGenShowerBranchName + "." + kDepthVectorBranchName).c_str(), 0);
  fEventTree->SetBranchStatus((string(kDataBranchName) +
                               kGenShowerBranchName + "." + kEnergyDepositVectorBranchName).c_str(), 0);
  fEventTree->SetBranchStatus((string(kDataBranchName) +
                               kGenShowerBranchName + "." + kElectronVectorBranchName).c_str(), 0);

  // detector: switch off everything ...
  fEventTree->SetBranchStatus((string(kDataBranchName) + "fDetector*").c_str(), 0);
  // ... then recover some frequently used variables
  fEventTree->SetBranchStatus((string(kDataBranchName) + "fDetector.fQDB*").c_str(), 1);
  fEventTree->SetBranchStatus((string(kDataBranchName) + "fDetector.fHas*").c_str(), 1);
  fEventTree->SetBranchStatus((string(kDataBranchName) + "fDetector.fTemp*").c_str(), 1);
  fEventTree->SetBranchStatus((string(kDataBranchName) + "fDetector.fPres*").c_str(), 1);
  fEventTree->SetBranchStatus((string(kDataBranchName) + "fDetector.fMeteo").c_str(), 1);
}


bool
RecEventFile::IsMiniADST()
{
  const string sd = string(kDataBranchName) + kSDEventBranchName;
  return fEventTree->GetBranchStatus((sd + "." + kStationVectorBranchName + ".fTraces").c_str());
}


void
RecEventFile::SetMiniADST()
{
  if (!fEventTree) {
    cerr << " RecEventFile::SetMiniADST() - no TTree initialized! Ignoring" << endl;
    return;
  }

  // FD stuff
  const string fd = string(kDataBranchName) + kFDEventsBranchName;
  const string fdRecShower = fd + "." + kFdRecShowerBranchName;

  fEventTree->SetBranchStatus((fd + "." + kFdRecPixelBranchName + ".fDataTrace").c_str(), 0);
  fEventTree->SetBranchStatus((fd + "." + kFdRecPixelBranchName + ".fSpotRecTrace").c_str(), 0);
  fEventTree->SetBranchStatus((fd + "." + kFdRecPixelBranchName + ".fSimTraceComponents").c_str(), 0);
  // SD stations
  const string sd = string(kDataBranchName) + kSDEventBranchName;
  fEventTree->SetBranchStatus((sd + "." + kStationVectorBranchName + ".fTraces").c_str(), 0);
  fEventTree->SetBranchStatus((sd + "." + kGenStationVectorBranchName + ".fPETimeDistr").c_str(), 0);
  fEventTree->SetBranchStatus((sd + "." + kGenStationVectorBranchName + ".fParticles").c_str(), 0);

}


void
RecEventFile::SetBranchStatus(const char* const branchname, const bool status)
{
  if (!fEventTree) {
    cerr << " RecEventFile::SetBranchStatus() - no TTree initialized! Ignoring" << endl;
    return;
  }

  if (fRecEventPtr) {
    cerr << " ###################################################\n"
            " RecEventFile::SetBranchStatus() - Error: \n"
            " cannot set Branch status after RecEventFile::SetBuffers()!!\n"
            " Ignoring!\n"
            " ###################################################\n" << endl;
  }

  fEventTree->SetBranchStatus(branchname, status);
}


void
RecEventFile::cd()
{
  if (!fEventTree)
    return;

  if (fMode == eWrite && fFile)
    fFile->cd();
}


// for joe
string
RecEventFile::GetActiveFileName()
  const
{
  TChain* const chain = dynamic_cast<TChain*>(fEventTree);
  if (chain) {
    TFile* const file = chain->GetFile();
    if (file) {
      if (file->IsZombie())
        return string(chain->GetFile()->GetName()) + "(ZOMBIE)";
      else
        return chain->GetFile()->GetName();
    } else
      return "no file loaded";
  }

  if (fFile) {
    if (fFile->IsZombie())
      return string(fFile->GetName()) + "(ZOMBIE)";
    else
      return fFile->GetName();
  } else
    return "no file loaded";
}


RecEventFile*
RecEventFile::OpenFromASCIIList(const char* const flist)
{
  ifstream fileList(flist);
  if (!fileList.is_open()) {
    cerr << " RecEventFile::OpenFromASCIIList(): - Error could not read file list "
         << flist << endl;
    return NULL;
  }

  vector<string> fileNames;
  string filename;
  while (fileList >> filename)
    fileNames.push_back(filename);

  return new RecEventFile(fileNames);
}


RecEventFile*
RecEventFile::SmartOpen(const string& fileName)
{
  RecEventFile* dataFile = NULL;

  const std::size_t len = fileName.length();
  if (len > 5 && fileName.substr(len-5) == ".root")
    dataFile = new RecEventFile(fileName.c_str());

  if (!dataFile)
    dataFile = RecEventFile::OpenFromASCIIList(fileName.c_str());

  return dataFile;
}


std::string
RecEventFile::GetCurrentEventString()
  const
{
  if (fRecEventPtr) {
    ostringstream eventInfo;
    eventInfo << showpoint << setiosflags(ios::fixed) << setprecision(1)
              << "   event #"
              << setw(10) << GetCurrentEvent()
              << " ID= " << (*fRecEventPtr)->GetEventId() << " ("
              << setw(4) << double(GetCurrentEvent()) / GetNEvents() * 100
              << "%)";
    return eventInfo.str();
  }

  return "";
}
