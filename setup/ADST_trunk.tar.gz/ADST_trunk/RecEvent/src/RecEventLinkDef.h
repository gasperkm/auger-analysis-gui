#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class DetectorGeometry+;
#pragma link C++ class EyeGeometry+;
#pragma link C++ class TelescopeGeometry+;

#pragma link C++ class RecEventFile+;
#pragma link C++ class FileInfo+;
#pragma link C++ class SimInfo+;
#pragma link C++ class EventInfo+;

#pragma link C++ class RecEvent+;
#pragma link C++ class Detector+;
#pragma link C++ class FDEvent+;
#pragma link C++ class std::vector<FDEvent>+;
#pragma link C++ class std::vector<FDEvent*>+;
#pragma link C++ class SDEvent+;
#pragma link C++ class MeteoData+;

#pragma link C++ class Shower+;
#pragma link C++ class RecShower+;
#pragma link C++ class GenShower+;
#pragma link C++ class SdRecShower+;

#pragma link C++ class UnivRecShower+;

#pragma link C++ class FdRecShower+;

#pragma link C++ class RecStation+;
#pragma link C++ class GenStation+;
#pragma link C++ class std::vector<GenStation>+;
#pragma link C++ class PETimeDistribution+;
#pragma link C++ class std::vector<PETimeDistribution>+;
#pragma link C++ class SDParticle+;
#pragma link C++ class std::vector<SDParticle>+;
#pragma link C++ class Traces+;
#pragma link C++ class std::vector<Traces>+;
#pragma link C++ class CalibHistogram+;

#pragma link C++ class FdRecStation+;
#pragma link C++ class std::vector<FdRecStation>+;
#pragma link C++ class SdRecStation+;
#pragma link C++ class std::vector<SdRecStation>+;
#pragma link C++ class SdBadStation+;
#pragma link C++ class std::vector<SdBadStation>+;

#pragma link C++ class FdApertureLight+;
#pragma link C++ class FdRecApertureLight+;
#pragma link C++ class FdGenApertureLight+;
#pragma link C++ class FdGenShower+;

#pragma link C++ class FdRecPixel+;
#pragma link C++ class FdTrace+;
#pragma link C++ class FdMultiTrace+;

#pragma link C++ class FdGeometry+;
#pragma link C++ class FdGenGeometry+;
#pragma link C++ class FdRecGeometry+;
#pragma link C++ class SdRecGeometry+;

#pragma link C++ class FdTelescopeData+;
#pragma link C++ class std::map<int, FdTelescopeData>+;
#pragma link C++ class std::pair<int, FdTelescopeData>+;
#pragma link C++ class std::vector<EPixelStatus>+;

#pragma link C++ class LDF+;

#pragma link C++ class SdRiseTime+;
#pragma link C++ class SdFootprintData+;
#pragma link C++ class MuonMap+;
#pragma link C++ class MuonMapContour+;
#pragma link C++ class MuonMapPoint+;

#pragma link C++ class FdLidarData+;
#pragma link C++ class FdCloudCameraData+;
#pragma link C++ class FdAerosols+;

#pragma link C++ enum EFdRecLevel;
#pragma link C++ enum ESdRecLevel;
#pragma link C++ enum EStationStatus;
#pragma link C++ enum EStationTrigger;
#pragma link C++ enum ERejectionStatus;
#pragma link C++ enum ESaturationStatus;
#pragma link C++ enum ETraceType;
#pragma link C++ enum ET5Trigger;
#pragma link C++ enum ET4Trigger;
#pragma link C++ enum EGridFlag;
#pragma link C++ enum ParticleType;
// ... there are more ADST enums not listed here,
// if you want them, please extend this list

#include "MdRecEventLinkDef.h"

#include "RadioRecEventLinkDef.h"

#endif
