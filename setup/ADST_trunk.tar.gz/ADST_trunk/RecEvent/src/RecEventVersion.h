/* --- Automatic generated code - Do not edit !!! --- */

#ifndef __CINT__

#ifndef __RECEVENTVERSION_H__
#define __RECEVENTVERSION_H__

#include <RecEvent.h>

#ifndef ModuleVersionCode
#define ModuleVersionCode(v,p,s) (((v)<<16)+((p)<<8)+(s))
#endif /* ModuleVersionCode */

#ifndef ADST_VERSION_CODE
#define ADST_VERSION_CODE RecEvent::GetVersion()
#endif /* ADST_VERSION_CODE */

#endif

#endif /* __CINT__ */
