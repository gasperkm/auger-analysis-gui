#include <RecShower.h>
#include <cmath>


ClassImp(RecShower);


RecShower::RecShower() :
  fEnergyError(0.),
  fCoreNorthError(0.),
  fCoreEastError(0.),
  fCoreNorthEastCorrelation(0.),
  fZenithError(0.),
  fAzimuthError(0.),
  fZenithAzimuthCorrelation(0.),
  fRightAscensionError(0.),
  fDeclinationError(0.),
  fRDCorrelation(0.),
  fGalacticLongError(0.),
  fGalacticLatError(0.),
  fLongLatCorrelation(0.)
{
}


Double_t
RecShower::GetCosZenithError()
  const
{
  return std::sin(GetZenith()) * fZenithError;
}
