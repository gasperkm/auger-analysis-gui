// $Id: RecStation.cc 28131 2015-11-15 20:06:17Z darko $
#include <RecStation.h>
#include <StationStatus.h> // for the enums

#include <cmath>

using namespace std;


ClassImp(RecStation);


RecStation::RecStation():
  fStatus(eUnknown),
  fTrigger(eNone),
  fRejectionStatus(eNoRejection),
  fTriggerBits(-1),
  fId(0),
  fIsHybrid(false),
  fTotalSignal(0),
  fTotalSignalError(0),
  fCalibVersion(0),
  fPLDVersion(""),
  fPLDTimeOffset(0),
  fT3ErrorCode(0),
  fT3Window(0)
{
}


bool
RecStation::IsTrigger(EStationTrigger type)
  const
{
  if (fTriggerBits < 0)
    return fTrigger == type;
  else
    return fTriggerBits & (1 << type);
}


void
RecStation::SetTrigger(EStationTrigger type)
{
  if (fTriggerBits < 0)
    fTriggerBits = 0;
  fTriggerBits |= (1 << type);
}


string
RecStation::GetStationTriggerName(const int version)
  const
{
  //version is the sdrecstation version
  if (version > 18) {
    if (IsToT())
      return "ToT";
    else if (IsToTd()) {
      string result = "ToTd";
      if (IsMoPS())
        result += ", MoPS";
      if (IsT2Threshold())
        result += ", Thr2";
      else if (IsT1Threshold())
        result += ", Thr1";
      return result;
    } else if (IsMoPS()) {
      string result = "MoPS";
      if (IsT2Threshold())
        result += ", Thr2";
      else if (IsT1Threshold())
        result += ", Thr1";
      return result;
    } else if (IsT2Threshold())
      return "Thr2";
    else if (IsT1Threshold())
      return "Thr1";
    else if (IsRandom())
      return "Random";
    else
      return "unknown";
  } else {
    if (IsT1Threshold())
      return "Thr";
    else if (IsThreshold())
      return "TOT";
    else if (IsTOT())
      return "Random";
    else if (IsRandom())
      return "part of CT"; // or bsh
    else
      return "unknown";
  }
}


void
RecStation::SetRejectStatus(const int stat)
{
  fRejectionStatus = ERejectionStatus(stat);
}


string
RecStation::GetRemovalReason()
  const
{
  string result;

  if (fRejectionStatus & eLightning)
    result = "lightning";
  if (fRejectionStatus & eBadCompress)
    result += result.empty() ? "bad compress." : ", bad compress.";
  if (fRejectionStatus & eOutOfTime)
    result += result.empty() ? "out of time" : ", out of time";
  if (fRejectionStatus & eOffGrid)
    result += result.empty() ? "off grid" : ", off grid";
  if (fRejectionStatus & eDenseArray)
    result += result.empty() ? "dense" : ", dense";
  if (fRejectionStatus & eRandomR)
    result += result.empty() ? "random" : ", random";
  if (fRejectionStatus & eEngineeringArray)
    result += result.empty() ? "eng. array" : ", eng. array";
  if (fRejectionStatus & eMCInnerRadiusCut)
    result += result.empty() ? "MC rad. cut" : ", MC rad. cut";
  if (fRejectionStatus & eNoRecData)
    result += result.empty() ? "no rec. data" : ", no rec. data";
  if (fRejectionStatus & eLonely)
    result += result.empty() ? "lonely" : ", lonely";
  if (fRejectionStatus & eNoTrigger)
    result += result.empty() ? "no trigger" : ", no trigger";
  if (fRejectionStatus & eErrorCode)
    result += result.empty() ? "error code" : ", error code";
  if (fRejectionStatus & eNoCalibData)
    result += result.empty() ? "no calib." : ", no calib.";
  if (fRejectionStatus & eNoGPSData)
    result += result.empty() ? "no GPS" : ", no GPS";
  if (fRejectionStatus & eBadCalib)
    result += result.empty() ? "bad calib." : ", bad calib.";
  if (fRejectionStatus & eRegularMC)
    result += result.empty() ? "reg. array" : ", reg. array";
  if (fRejectionStatus & eTOTdRejected)
    result += result.empty() ? "TOTd" : ", TOTd";
  if (fRejectionStatus & eMoPSRejected)
    result += result.empty() ? "MoPS" : ", MoPS";

  return result;
}


// the following two functions need to be changed in the future to non-hardcoded versions!
bool
RecStation::IsDoublet()
  const
{
  static unsigned int doublets[] = {
    49, 64, 72, 73, 77, 78, 80, 82, 83, 87, 89, 90, 91, 92,
    139, 140, 185, 186,
    635, 643, 651, 657, 663, 669, 688, 695,
    707, 734, 736,
    824
  };
  for (unsigned int i = 0, n = sizeof(doublets)/sizeof(doublets[0]); i < n; ++i)
    if (fId == doublets[i])
      return true;
  return false;
}


bool
RecStation::IsTriplet()
  const
{
  static unsigned int triplets[] = {
    71, 74, 75, 76, 79, 81, 84, 85, 86, 88, 93, 94, 95, 96,
    660, 664, 698,
    710, 713,
    819,
    918
  };
  for (unsigned int i = 0, n = sizeof(triplets)/sizeof(triplets[0]); i < n; ++i)
    if (fId == triplets[i])
      return true;
  return false;
}
