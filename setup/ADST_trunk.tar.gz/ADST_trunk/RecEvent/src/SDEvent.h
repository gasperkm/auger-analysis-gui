#ifndef __SDEvent_H
#define __SDEvent_H

#include <SdRecShower.h>

#include <UnivRecShower.h>

#include <SdRecStation.h>
#include <SdBadStation.h>
#include <GenStation.h>
#include <MuonMap.h>

#include <TObject.h>

#include <vector>
#include <iostream>


class TClonesArray;


//
//  class to hold SD event
//

class SDEvent : public TObject {

public:
  SDEvent();
  ~SDEvent();

  SdRecShower& GetSdRecShower();
  const SdRecShower& GetSdRecShower() const;

  UnivRecShower& GetUnivRecShower();
  const UnivRecShower& GetUnivRecShower() const;

  MuonMap& GetMuonMap();
  const MuonMap& GetMuonMap() const;
  /// get station with index "i"
  const SdRecStation* GetStation(const unsigned int i) const;
  const GenStation* GetSimStation(const unsigned int i) const;
  const GenStation* GetSimStationById(const unsigned int id) const;
  const SdRecStation* GetStationById(const unsigned int id) const;
  const std::vector<SdRecStation>& GetStationVector() const { return fStations; }
  const std::vector<GenStation>& GetSimStationVector() const { return fGenStations; }

  const SdBadStation* GetBadStationById(const unsigned int id) const;
  const std::vector<SdBadStation>& GetBadStationVector() const { return fBadStations; }

  /// ask for presence of station with ID "id"
  bool HasStation(const int id) const;
  bool HasSimStation(const int id) const;
  bool HasBadStation(const int id) const;
  bool HasTriggeredStations() const
  { return fSdRecLevel >= eHasTriggeredStations; }

  bool HasAxis() const { return fSdRecLevel >= eHasSdAxis; }
  bool HasLDF() const { return fSdRecLevel >= eHasLDF; }
  bool HasCurvature() const { return fSdRecLevel == eHasCurvature; }
  bool IsT5() const; ///>deprecated function: returns 6T5

  bool Is5T5() const;
  bool Is6T5() const;
  bool IsT5Has() const;

  bool HasStations() const { return !fStations.empty(); }
  bool IsSaturated() const;
  bool HasSaturatedCandidates() const;

  void AddStation(const SdRecStation &s);
  void AddSimStation(const GenStation &s);
  void AddBadStation(const SdBadStation& s);

  int GetEventId() const { return fSdEventId; }
  ESdRecLevel GetRecLevel() const { return fSdRecLevel; }
  int GetGPSSecond() const { return fSdGPSSecond; }
  int GetGPSNanoSecond() const { return fSdGPSNanoSecond; }
  int GetHHMMSS() const { return fHHMMSS; }
  int GetYYMMDD() const { return fYYMMDD; }

  /// set average station age in event in GPS seconds
  void SetAverageStationAge(double age) { fAverageStationAge = age; }
  /// get average station age in event in GPS seconds
  double GetAverageStationAge() const { return fAverageStationAge; }

  int GetNumberOfAccidentalStations() const; //< deprecated function

  /// returns the number of lonely and out of time stations
  int GetNoOfAccidentalStations() const;
  int GetNoOfRemovedStations() const { return fNumberOfAccidentalStations; }

  int GetNumberOfCandidates(const bool loop = false) const;

  int GetT4Trigger() const { return fT4Trigger; }
  int GetT5Trigger() const { return fT5Trigger; }

  std::string GetTriggerSender() const { return fCDASSender; }
  std::string GetTriggerAlgorithm() const { return fCDASAlgo; }

  void SetId(const int event) { fSdEventId = event; }
  void SetRecLevel(const ESdRecLevel l) { fSdRecLevel = l; }
  void SetEventTime(const int gPSSec, const int gPSNSec)
  { fSdGPSSecond = gPSSec; fSdGPSNanoSecond = gPSNSec; }
  void SetYYMMDD(const int yymmdd) { fYYMMDD = yymmdd; }
  void SetHHMMSS(const int hhmmss) { fHHMMSS = hhmmss; }

  /// set the number of removed stations
  void SetNumberOfAccidentalStations(const int nstations)
  { fNumberOfAccidentalStations = nstations; }

  /// set the number of candidate stations
  void SetNumberOfCandidates(const int candidates)
  { fNoOfCandidateStations = candidates; }

  /// set the bad period id
  void SetBadPeriodId(const int badId) { fBadPeriodId = badId; }
  void SetT4Trigger(const int t4Trigger) { fT4Trigger = t4Trigger; }
  void SetT5Trigger(const int t5Trigger) { fT5Trigger = t5Trigger; }

  /// set the CDAS trigger sender
  void SetCDASSender(const std::string& sender) { fCDASSender = sender; }
  /// set the CDAS trigger algorithm
  void SetCDASAlgorithm(const std::string& algo) { fCDASAlgo = algo; }

  void SetLightning() { fIsLightning = true; } /// set lightning flag
  bool IsLightning() const { return fIsLightning; }

  std::string ReturnT4Name() const;
  std::string ReturnT5Name() const;

  bool HasVEMTraces() const;
  bool HasFADCTraces() const;
  bool HasAllTraces() const;

  bool HasGenStations() const { return !fGenStations.empty(); }

  bool HasParticles() const;
  bool HasPEDistributions() const;

  int  GetBadPeriodId() const { return fBadPeriodId; }
  void DumpASCII(std::ostream& o = std::cout) const;

private:
  int fSdEventId;
  int fBadPeriodId;
  ESdRecLevel fSdRecLevel;
  int fSdGPSSecond;
  int fSdGPSNanoSecond;
  int fYYMMDD;
  int fHHMMSS;
  double fAverageStationAge;
  int fNumberOfAccidentalStations;
  int fNoOfCandidateStations;
  int fT4Trigger;
  int fT5Trigger;

  bool fIsLightning;

  std::string fCDASSender;
  std::string fCDASAlgo;

  SdRecShower fSdRecShower;

  UnivRecShower fUnivRecShower;

  MuonMap fMuonMap;
  std::vector<SdRecStation> fStations;
  std::vector<GenStation> fGenStations;
  std::vector<SdBadStation> fBadStations;

  ClassDef(SDEvent, 16);

};


#endif
