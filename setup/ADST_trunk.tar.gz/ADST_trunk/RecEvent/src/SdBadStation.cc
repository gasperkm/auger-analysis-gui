
#include <SdBadStation.h>

ClassImp (SdBadStation);
