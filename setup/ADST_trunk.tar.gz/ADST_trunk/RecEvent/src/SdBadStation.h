#ifndef _SdBadStation_h_
#define _SdBadStation_h_

#include <StationStatus.h>
#include <TObject.h>

class SdBadStation : public TObject {

public:

  SdBadStation()
    : fId(0), fReason(eNoRejection)
  {}

  SdBadStation(const unsigned int id, const int reason)
    : fId(id), fReason(ERejectionStatus(reason))
  {}

  unsigned int GetId() const { return fId; }
  ERejectionStatus GetReason() const { return fReason; }

  void SetId(const unsigned int id) { fId = id; }
  void SetReason(const int reason) { fReason = ERejectionStatus(reason); }

private:
  unsigned int fId;
  ERejectionStatus fReason;

  ClassDef(SdBadStation,1);
};

#endif
