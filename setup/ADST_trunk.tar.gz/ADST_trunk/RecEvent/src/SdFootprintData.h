/**
   \file

   \author Javier Gonzalez
   \version $Id: SdFootprintData.h 22862 2013-03-01 23:18:55Z darko $
   \date 20 Apr 2012
*/

#ifndef __SdFootprintData_h_
#define __SdFootprintData_h_

#include <map>
#include <TObject.h>
#include <SdFootprintEnumerations.h>


/**
   \class SdFootprintData SdFootprintData.h "sevt/SdFootprintData.h"

   \brief Class to hold simple parameters describing the footprint of an SD event.

   This class is intended for simple parameters related to the
   footprint of the event like the ones used in the neutrino
   analyses. Since the set of parameters used in the analyses
   changes with time, this class provides getters and setter for the
   most standard ones and leaves the user the choice to add his or
   her own. The allowed parameters are indexed by the
   SdFootprintEnumerations::Parameter enumeration, which includes
   some values for user-defined parameters.

   \author Javier Gonzalez
   \version $Id: SdFootprintData.h 22862 2013-03-01 23:18:55Z darko $
   \date 19 Apr 2012
*/

class SdFootprintData: public TObject {
  public:
    typedef SdFootprintEnumerations::Alignment Alignment;

    SdFootprintData() :
      fLength(0),
      fWidth(0),
      fSpeed(0),
      fSpeedStandardDeviation(0),
      fTOTFraction(0),
      fAreaOverPeakAsymmetry(0),
      fAlignment(SdFootprintEnumerations::eNotAligned)
    { }

    ~SdFootprintData() { }

    //! \name Standard Parameters
    //@{
    double GetLength() const { return fLength; }
    double GetWidth() const { return fWidth; }
    /// The mean 'apparent speed' of the signals as they sweep over the array.
    double GetSpeed() const { return fSpeed; }
    /// The standard deviation of apparent speed histogram. All possible pairs of stations correspond to an entry in the histogram.
    double GetSpeedStandardDeviation() const { return fSpeedStandardDeviation; }
    /// Fraction of stations with a TOT trigger
    double GetTOTFraction() const { return fTOTFraction; }
    double GetAreaOverPeakAsymmetry() const { return fAreaOverPeakAsymmetry; }
    /// Flag describing how 'aligned' an event is.
    int GetAlignment() const { return fAlignment; }

    void SetLength(const double l) { fLength = l; }
    void SetWidth(const double w) { fWidth = w; }
    void SetSpeed(const double s, const double ds) { fSpeed = s; fSpeedStandardDeviation = ds; }
    void SetTOTFraction(const double f) { fTOTFraction = f; }
    void SetAreaOverPeakAsymmetry(const double a) { fAreaOverPeakAsymmetry = a; }
    void SetAlignment(const Alignment alignment) { fAlignment = alignment; }
    //@}

    //! \name Not-so-standard Parameters
    //@{
    typedef SdFootprintEnumerations::Parameter Parameter;

    void SetParameter(const Parameter p, const double v) { fParameters[p] = v; }
    bool HasParameter(const Parameter p) const { return fParameters.find(p) != fParameters.end(); }
    double GetParameter(const Parameter p) const { return fParameters.find(p)->second; }
    const std::map<int, double>& GetParameters() const { return fParameters; }
    //@}

  private:
    double fLength;
    double fWidth;
    double fSpeed;
    double fSpeedStandardDeviation;
    double fTOTFraction;
    double fAreaOverPeakAsymmetry;
    int fAlignment;

    std::map<int, double> fParameters;

    ClassDef(SdFootprintData, 1);
};


#endif
