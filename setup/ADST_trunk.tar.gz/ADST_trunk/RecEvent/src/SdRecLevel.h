#ifndef __SdRecLevel_H
#define __SdRecLevel_H

enum ESdRecLevel {

  /// no Sd event found
  eNoSdEvent = 0,

  /// Sd has triggered stations
  eHasTriggeredStations = 1,

  /// axis reconstructed
  eHasSdAxis = 2,

  /// LDF fit
  eHasLDF = 3,

  /// curvature
  eHasCurvature = 4

};


#endif
