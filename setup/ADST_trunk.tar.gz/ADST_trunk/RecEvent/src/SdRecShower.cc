#include <SdRecShower.h>
#include <SdRecLevel.h>

#include <iostream>
using namespace std;


ClassImp(SdRecShower);


//=============================================================================
/*!
  \class   SdRecShower
  \brief   Reconstructed shower parameters

  \version 1.0
  \date    Jun 10 2005
  \author  I. Mari&#351;, F. Sch&uuml;ssler, R. Ulrich, M. Unger

*/
//=============================================================================

SdRecShower::SdRecShower() :
  //fSeedStations,
  fSeedAxis(0,0,0),
  fPlaneFrontAxis(0,0,0),
  fCurvature(0),
  fCurvatureError(0),
  fCt0(0),
  fCt0Error(0),
  fAngleChi2(0),
  fAngleNdof(0),
  fTimeResidualMean(0),
  fTimeResidualSpread(0),
  fRopt(0),
  fRoptError(0),
  fEnergyLDFSys(0),
  fLdf(),
  fR1000(),
  fMPDMin(0),
  fMPDMax(0)
{ }


TH1D
SdRecShower::GetMPDHistogram()
  const
{
  TH1D mpdHist("MPD", ";X[g/cm^{2}];N [a.u.]", fMPDData.size(), fMPDMin, fMPDMax);

  for (unsigned int i = 0; i < fMPDData.size(); ++i)
    mpdHist.SetBinContent(i+1, fMPDData[i]);

  return mpdHist;
}


void
SdRecShower::DumpASCII(std::ostream& o)
  const
{
  Shower::DumpASCII(o);
  fLdf.DumpASCII(o);
}
