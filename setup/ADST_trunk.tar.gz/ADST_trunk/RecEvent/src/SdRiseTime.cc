
#include <SdRiseTime.h>
#include <RecStation.h>

#include <TGraphErrors.h>
#include <TMath.h>

#include <vector>
#include <iostream>
#include <cmath>
using namespace std;

ClassImp(SdRiseTime);

SdRiseTime::SdRiseTime():
  fRiseTime1000(0),     
  fRiseTime1000Error(0), 
  fRiseTimeChi2(0),  
  fRiseTimeNDF(0),   
  fXmax(0),          
  fXmaxErrorUp(0),   
  fXmaxErrorDown(0),
  fAlpha(0),
  fBeta(0){ 
}


TF1 SdRiseTime::GetFitResults(const double zenith, const double energy) 
  const{
   

  const  double maxDistanceForRiseTimeFit  = 1200.0; 
  const  double minDistanceForRiseTimeFit  = 600.0;  
  
  TF1 risetimeFit("risetimeFit", "40+[0]*x+[1]*x*x",
		  minDistanceForRiseTimeFit, maxDistanceForRiseTimeFit);
  
  
  //Karen Mora paremeterisation:
    
  const double secTheta= 1./cos(zenith); 
  
  const double a_par1= -0.141152; 
  //const double aerr_par1=0.0211922; 
  const double a_par2=0.0141074;   
  // const double aerr_par2=0.00112648; 
  const double a_par3=1.25107;  
  // const double aerr_par3=0.00564702;
  const double a_par4=-0.405333;   
  //const double aerr_par4=0.00292129;
  
  const double b_par1=0.000904323;   
  //const double berr_par1=0.000205126;
  const double b_par2=6.4291e-06; 
  //const double berr_par2=1.07674e-05; 
  const double b_par3=-1.09992; 
  //const double berr_par3=0.00313012;
  const double b_par4=0.30987;  
  //const double berr_par4=0.00147789;
  
  double alpha=(a_par1+a_par2*log10(energy))*
    exp(-0.5*pow((secTheta-a_par3)/a_par4,2));
  double beta=(b_par1+b_par2*log10(energy))*
    (1+b_par3* secTheta+b_par4*pow(secTheta, 2));
  
  risetimeFit.SetParameter(0,alpha);
  risetimeFit.SetParameter(1,beta);
  
  return risetimeFit;
}




TF1 SdRiseTime::GetFitResults() 
  const{
  const  double maxDistanceForRiseTimeFit  = 1200.0; 
  const  double minDistanceForRiseTimeFit  = 600.0;  
  
  TF1 risetimeFit("risetimeFit", "40+[0]*x+[1]*x*x", 
		  minDistanceForRiseTimeFit, maxDistanceForRiseTimeFit);
  
  risetimeFit.SetParameter(0, fAlpha);
  risetimeFit.SetParameter(1, fBeta);
  return risetimeFit;
}





double SdRiseTime::GetRiseTime1000(const double zenith, const double energy) const{
  return GetFitResults(zenith,energy).Eval(1000.);
}


double SdRiseTime::GetRiseTime1000Error(const double zenith, const double s1000) 
  const{
  
//   const float pJA_0 = 969.111;
//   const float pJA_1 = -491.919;
//   const float pJB_0 = -0.000872009;
//   const float pJB_1 = 0.000527853;
//   const float pJC_0 = 8.17938e-07;
//   const float pJC_1 = -4.45007e-07;
//   const float pK1_0 = -36.1416;
//   const float pK1_1 = 16.5374;
//   const float pK2_0 = 0.0810758;
//   const float pK2_1 = -0.0349458;


//Parameters Jun 2012 Karen Mora (current baseline)
  const float pJA_0=-313.724;
  const float pJA_1=166.872;
  
  const float pJB_0=0.00125723;
  const float pJB_1=-0.000584173;
  
  const float pJC_0=-2.58177e-07;
  const float pJC_1=1.2744e-07;
  
  const float pK1_0=-19.8047;
  const float pK1_1=9.3843;
  
  const float pK2_0=0.0790256;
  const float pK2_1=-0.0343573;


//Parameters Jun 2012 Karen Mora (Baseline corrected by R.Bruijn's algorithm)

//   const float pJA_0 = -189.884;
//   const float pJA_1 = 101.83;
//   const float pJB_0 = 0.00119306;
//   const float pJB_1 = -0.000554442;
//   const float pJC_0 = -1.96462e-07;
//   const float pJC_1 = 9.70452e-08;
//   const float pK1_0 = -23.4863;
//   const float pK1_1 = 11.0905;
//   const float pK2_0 = 0.0750989;
//   const float pK2_1 = -0.031979;

  
  const double secTheta = 1./cos(zenith); 
  const double k = pK1_0+pK1_1*secTheta + (pK2_0+pK2_1*secTheta)*1000.; 
  const double j = pJA_0+pJA_1*secTheta + (pJB_0+pJB_1*secTheta)*pow(1000.,2) 
    + (pJC_0+pJC_1*secTheta)* pow(1000.,3);
  //This error represents ~14% of the RT1000 value
  return abs(j/s1000+k);;
}



 
