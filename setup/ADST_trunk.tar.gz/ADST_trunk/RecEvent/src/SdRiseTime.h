#ifndef __SdRiseTime_H
#define __SdRiseTime_H

#include <TObject.h>
#include <TF1.h>

class SdRiseTime : public TObject {

 friend class SdRecShower;

 public:

  SdRiseTime();
  virtual ~SdRiseTime(){;}
  
  TF1 GetFitResults() const; ///> returns the rise time fit function
  void SetRiseTime1000(const double riseTime, const double riseTimeError)
  { fRiseTime1000 = riseTime; fRiseTime1000Error = riseTimeError; }
  double GetRiseTime1000()const {return fRiseTime1000;} ///> returns the rise time at 1000 m
  double GetRiseTime1000Error()const {return fRiseTime1000Error;} ///> returns the error of rise time at 1000m

  
  void SetRiseTimeNDF(const double inRiseTimeNDF) { fRiseTimeNDF = inRiseTimeNDF;} ///> set rise time fit deg. of freedom
  double GetRiseTimeNDF() const {return fRiseTimeNDF;}///> returns  rise time fit deg of freedom
   
  void SetRiseTimeChi2(const double inRiseTimeChi2) { fRiseTimeChi2 = inRiseTimeChi2;}///> set rise time fit chi2
  double GetRiseTimeChi2() const {return fRiseTimeChi2;}///> returns rise time fit chi2

    
  void SetAlpha(const double inFitPar0) {fAlpha = inFitPar0;} ///> set rise time fit parameter alpha
  double GetAlpha() const {return fAlpha;} ///> returns rise time fit parameter alpha
  void SetBeta(const double inFitPar1)  {fBeta = inFitPar1;} ///> set rise time fit parameter beta
  double GetBeta() const {return fBeta;} ///> returns rise time fit parameter beta
  
  
  double GetXmax() const  {return fXmax;} 
  void SetXmax(const double inXmax) { fXmax = inXmax;}
  
  void SetXmaxErrorUp(const double inXmaxErrorUp) { fXmaxErrorUp = inXmaxErrorUp;}
  double GetXmaxErrorUp() const {return fXmaxErrorUp;}
  
  void SetXmaxErrorDown(const double inXmaxErrorDown) { fXmaxErrorDown = inXmaxErrorDown;}
  double GetXmaxErrorDown() const {return fXmaxErrorDown;} 
 
 
  TF1 GetFitResults(const double zenith,
		    const double energy) const; ///> returns the rise time function (Karlsruhe parametrisation)
  double GetRiseTime1000(const double zenith,
			 const double energy) const; ///> returns the rise time at 1000 m (Karen Mora parametrisation)
  double GetRiseTime1000Error(const double zenith,
			      const double s1000) const; ///> returns the rise time at 1000 m error (Karen Mora parametrisation)       
 
 private:

 
  double fRiseTime1000;
  double fRiseTime1000Error;
  double fRiseTimeChi2;
  double fRiseTimeNDF;
  double fXmax;
  double fXmaxErrorUp;
  double fXmaxErrorDown;
  double fAlpha;
  double fBeta;

  ClassDef(SdRiseTime,4);


};


#endif

