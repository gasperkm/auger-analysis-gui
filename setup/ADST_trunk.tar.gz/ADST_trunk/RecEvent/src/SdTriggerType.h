#ifndef _adst_SdTriggerType_h_
#define _adst_SdTriggerType_h_

// Keep this synchronized with Offline/Framework/Shower/ShowerSRecData.h


enum ET4Trigger {
  eT4_None    = 0,
  eT4_FD      = 1 << 0,  //< any of TOT or Threshold configurations that were triggered by FD
  eT4_3TOT    = 1 << 1,  //< 3 not-aligned tanks with TOT trigger (3TOT)
  eT4_4C1     = 1 << 2,  //< 4 tanks with T2 in 4C1 configuration (4C1)
  eT4_3TOTd   = 1 << 3,  //< 3 not-aligned tanks with TOTd trigger (3TOTd)
  eT4_3TOTMix = 1 << 4,  //< 3 not-aligned tanks with TOTd or TOT trigger (3TOTMix)
  eT4_3MoPS   = 1 << 5   //< 3 not-aligned tanks with TOTd or TOT trigger (3TOTMix)
};


enum ET5Trigger {
  eT5_None = 0,
  eT5_6T5  = 1 << 0,  //< Prior T5
  eT5_5T5  = 1 << 1,  //< Posterior T5 for vertical events
  eT5_Has  = 1 << 2,  //< Posterior T5 for inclined events
};


#endif
