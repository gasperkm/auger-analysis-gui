// $Id: Shower.h 26589 2014-09-17 20:32:55Z darko $
#ifndef __Shower_H
#define __Shower_H

#include <TObject.h>
#include <TVector3.h>

#include <iostream>


//  Shower data definition

class Shower : public TObject {

public:
  Shower();
  virtual ~Shower() { }

  /// get total energy [eV]
  double GetEnergy() const { return fEnergy; }
  /// translate the core at altitude
  TVector3 GetCoreAtAltitudeUTMCS(double altitude) const;
  /// get shower core in UTM system [m] (East, North, alt.)
  const TVector3& GetCoreUTMCS() const { return fCoreUTMCS; }
  /// get the core GPS second
  UInt_t GetCoreTimeSecond() const { return fCoreTimeSecond; }
  /// get the core GPS nanosecond
  virtual UInt_t GetCoreTimeNanoSecond() const { return fCoreTimeNanoSecond; }
  /// get shower core in site system [m]
  const TVector3& GetCoreSiteCS() const { return fCoreSiteCS; }
  /// get shower axis in local core system
  const TVector3& GetAxisCoreCS() const { return fAxisCoreCS; }
   /// get shower axis in site system
  const TVector3& GetAxisSiteCS() const { return fAxisSiteCS; }
  /// translate the core at altitude
  TVector3 GetCoreAtAltitudeSiteCS(double altitude) const;

  /// get zenith angle in local core system [rad]
  double GetZenith() const;
  /// get cos(zenith angle) in local core system [rad]
  double GetCosZenith() const;
  /// get azimuth angle in local core system [rad]
  double GetAzimuth() const;
  /// get galactic longitude [rad]
  double GetGalacticLongitude() const { return fGalacticLong; }
  /// get galactic latitude [rad]
  double GetGalacticLatitude() const { return fGalacticLat; }
  /// get declination angle [rad]
  double GetDeclination() const { return fDeclination; }
  /// get right ascension angle [rad]
  double GetRightAscension() const { return fRightAscension; }
  /// get local sideral time
  Double_t GetLocalSiderealTime() const { return fLocalSiderealTime; }

  /// set total energy [eV]
  void SetEnergy(const double e) { fEnergy = e; }
  /// set shower core in UTM system [m] (East, North, alt.)
  void SetCoreUTMCS(const TVector3& core) { fCoreUTMCS = core; }
  /// set shower core in site system [m]
  void SetCoreSiteCS(const TVector3& core) { fCoreSiteCS = core; }
  // set time at shower core
  void SetCoreTime(const int sec, const int nsec)
  { fCoreTimeSecond = sec; fCoreTimeNanoSecond = nsec; }
  /// set shower axis in local core system
  void SetAxisCoreCS(const TVector3& axis) { fAxisCoreCS = axis; }
  /// set shower axis in local core system
  void SetAxisSiteCS(const TVector3& axis) { fAxisSiteCS = axis; }
  /// set galactic longitude [rad]
  void SetGalacticLongitude(const double arg) { fGalacticLong = arg; }
  /// set galactic latitude [rad]
  void SetGalacticLatitude(const double arg) { fGalacticLat = arg; }
  /// set declination angle [rad]
  void SetDeclination(const double arg) { fDeclination = arg; }
  /// set right ascension angle [rad]
  void SetRightAscension(const double arg) { fRightAscension = arg; }
  /// set local sideral time
  void SetLocalSiderealTime(const Double_t arg) { fLocalSiderealTime = arg; }

  void DumpASCII(std::ostream& o = std::cout) const;

private:
  Double_t fEnergy;

  UInt_t fCoreTimeSecond;
  UInt_t fCoreTimeNanoSecond;
  TVector3 fCoreSiteCS; //||
  TVector3 fCoreUTMCS;  //||
  TVector3 fAxisCoreCS; //||
  TVector3 fAxisSiteCS; //||

  Double_t fGalacticLong;
  Double_t fGalacticLat;
  Double_t fDeclination;
  Double_t fRightAscension;
  Double_t fLocalSiderealTime;

  ClassDef(Shower, 3);

};


#endif
