// $Id: TelescopeGeometry.cc 23300 2013-04-08 20:42:31Z munger $
#include <TelescopeGeometry.h>

#include <iostream>
#include <TMath.h>
#include <cmath>

using namespace std;


// THIS IS THE ONLY REALLY HARDCODED NUMBER OF THE
// F-DETECTOR
// (Not any more, nowadays, this is just hardcoded in ADST --Steffen)
const UInt_t TelescopeGeometry::fgNumberOfPixels = 440;


TelescopeGeometry::TelescopeGeometry() :
  //fDefaultFOVId
  fNBinsFADC(0),
  fBinningFADC(0),
  fElevation(0),
  fAzimuth(0),
  fCurrentFOVId("INVALID"),
  fMinPhi(0),
  fMinOmega(0),
  fMaxPhi(0),
  fMaxOmega(0)
{ }


TelescopeGeometry::TelescopeGeometry(const map<TString, Double_t>& telElevations,
                                     const map<TString, Double_t>& telAzimuths,
                                     const UInt_t nFADC, const Double_t bFADC,
                                     const map<TString, TelescopeGeometry::PixelList_t>& telPixPhis,
                                     const map<TString, TelescopeGeometry::PixelList_t>& telPixOmegas)
{
  for (map<TString, PixelList_t>::const_iterator it = telPixPhis.begin();
       it != telPixPhis.end(); ++it) {
    const TString& pointingId = it->first;
    const PixelList_t& pixPhi = it->second;
    if (telPixOmegas.find(pointingId) == telPixOmegas.end()) {
      cerr << "\n"
              " ******************************************************************************\n"
              " ****   Found telescope pointing with id " << pointingId << " for phi but not for elevation ****\n"
              " ******************************************************************************\n"
           << endl;
      continue;
    }

    const PixelList_t& pixOmega = telPixOmegas.find(pointingId)->second;
    if (pixPhi.size() != fgNumberOfPixels || pixOmega.size() != fgNumberOfPixels) {
      cerr << "\n"
              " *************************************************************\n"
              " *************************************************************\n"
              " ****                                                     ****\n"
              " ****                                                     ****\n"
              " ****   EACH TELESCOPE HAS TO HAVE "<< fgNumberOfPixels
           << " PIXELS !!!!       ****\n"
              " ****                                                     ****\n"
              " ****                                                     ****\n"
              " *************************************************************\n"
              " *************************************************************\n"
           << endl;
    }
  }

  fTelPointingElevation  = telElevations;
  fTelPointingAzimuth    = telAzimuths;

  fTelPointingPixelPhi   = telPixPhis;
  fTelPointingPixelOmega = telPixOmegas;

  fElevation = 0;
  fAzimuth   = 0;

  fNBinsFADC = nFADC;
  fBinningFADC = bFADC;

  fCurrentFOVId = "";
  fMinPhi = 0;
  fMaxPhi = 0;
  fMinOmega = 0;
  fMaxOmega = 0;

  GuessDefaultPointing(); // refresh default FOV id
}


Double_t
TelescopeGeometry::GetPixelPhi(const UInt_t iPix, TString pointingId)
  const
{
  if (pointingId == "")
    pointingId = fDefaultFOVId;
  const map<TString, PixelList_t>::const_iterator it = fTelPointingPixelPhi.find(pointingId);
  if (it == fTelPointingPixelPhi.end()) {
    if (!HasPixel(iPix)) {
      cerr << "ERROR: Pixel id=" << iPix << " not available. nPix="
           << fPixelPhi.size() << endl;
      return 0;
    }
    return fPixelPhi[iPix];
  }

  const PixelList_t& pixList = it->second;
  return pixList[iPix];
}


Double_t
TelescopeGeometry::GetPixelOmega(const UInt_t iPix, TString pointingId)
  const
{
  if (pointingId == "")
    pointingId = fDefaultFOVId;
  const map<TString, PixelList_t>::const_iterator it = fTelPointingPixelOmega.find(pointingId);
  if (it == fTelPointingPixelOmega.end()) {
    if (!HasPixel(iPix)) {
      cerr << "ERROR: Pixel id=" << iPix << " not available. nPix="
           << fPixelOmega.size() << endl;
      return 0;
    }
    return fPixelOmega[iPix];
  }

  const PixelList_t& pixList = it->second;
  return pixList[iPix];
}


const TelescopeGeometry::PixelList_t&
TelescopeGeometry::GetPixelsPhi(TString pointingId)
  const
{
  if (pointingId == "")
    pointingId = fDefaultFOVId;

  const map<TString, PixelList_t>::const_iterator it = fTelPointingPixelPhi.find(pointingId);

  if (it == fTelPointingPixelPhi.end())
    return fPixelPhi;

  return it->second;
}


const TelescopeGeometry::PixelList_t&
TelescopeGeometry::GetPixelsOmega(TString pointingId)
  const
{
  if (pointingId == "")
    pointingId = fDefaultFOVId;

  const map<TString, PixelList_t>::const_iterator it = fTelPointingPixelOmega.find(pointingId);

  if (it == fTelPointingPixelOmega.end())
    return fPixelOmega;

  return it->second;
}


Double_t
TelescopeGeometry::GetPixelMinPhi(const TString& pointingId)
  const
{
  if (fCurrentFOVId != pointingId)
    CalculateMinMaxFOV(pointingId);
  return fMinPhi;
}


Double_t
TelescopeGeometry::GetPixelMaxPhi(const TString& pointingId)
  const
{
  if (fCurrentFOVId != pointingId)
    CalculateMinMaxFOV(pointingId);
  return fMaxPhi;
}


Double_t
TelescopeGeometry::GetPixelMinOmega(const TString& pointingId)
  const
{
  if (fCurrentFOVId != pointingId)
    CalculateMinMaxFOV(pointingId);
  return fMinOmega;
}


Double_t
TelescopeGeometry::GetPixelMaxOmega(const TString& pointingId)
  const
{
  if (fCurrentFOVId != pointingId)
    CalculateMinMaxFOV(pointingId);
  return fMaxOmega;
}


void
TelescopeGeometry::CalculateMinMaxFOV(TString pointingId)
  const
{
  if (pointingId == "")
    pointingId = fDefaultFOVId;

  fCurrentFOVId = pointingId;

  const map<TString, PixelList_t>::const_iterator phiIt =
    fTelPointingPixelPhi.find(pointingId);
  const map<TString, PixelList_t>::const_iterator omegaIt =
    fTelPointingPixelOmega.find(pointingId);

  const PixelList_t& phiList =
    (phiIt != fTelPointingPixelPhi.end() ? phiIt->second : fPixelPhi);
  const PixelList_t& omegaList =
    (omegaIt != fTelPointingPixelOmega.end() ? omegaIt->second : fPixelOmega);

  if (phiList.empty() || omegaList.empty()) {
    cerr << "ERROR: CalculateMinMaxFOV: Could not find pixel pointing "
            " for telescope pointing id '" << pointingId << "'" << endl;
    fCurrentFOVId = "";
    return;
  }

  // --------- calculate FOV ---------
  bool first = true;
  for (UInt_t iPix = 0, nPix = phiList.size(); iPix < nPix; ++iPix) {

    const double phi = phiList[iPix];
    const double omega = omegaList[iPix];

    // equivalent radius if pixel was circular
    const double solidAngle = GetSolidAngle(iPix);

    const double delta =
      acos(1 - solidAngle/TMath::TwoPi()) * TMath::RadToDeg();

    if (first) {
      first = false;
      fMinPhi = phi - delta;
      fMaxPhi = phi + delta;
      fMinOmega = omega - delta;
      fMaxOmega = omega + delta;
    } else {
      if (phi - delta < fMinPhi)
        fMinPhi = phi - delta;
      if (phi + delta > fMaxPhi)
        fMaxPhi = phi + delta;
      if (omega - delta < fMinOmega)
        fMinOmega = omega - delta;
      if (omega + delta > fMaxOmega)
        fMaxOmega = omega + delta;
    }
  }
}


bool
TelescopeGeometry::HasPointing(const TString& pointingId)
  const
{
  return fTelPointingPixelPhi.find(pointingId) != fTelPointingPixelPhi.end();
}


void
TelescopeGeometry::AddPointing(const TString& pointingId,
                               const Double_t phi, const Double_t elevation,
                               const TelescopeGeometry::PixelList_t& pixPhis,
                               const TelescopeGeometry::PixelList_t& pixOmegas)
{
  // check whether it exists already
  if (fTelPointingElevation.find(pointingId) != fTelPointingElevation.end()) {
    cerr << "ERROR: Trying to overwrite telescope pointing '"
         << pointingId << "'" << endl;
    return;
  }

  fTelPointingAzimuth[pointingId]    = phi;
  fTelPointingElevation[pointingId]  = elevation;
  fTelPointingPixelPhi[pointingId]   = pixPhis;
  fTelPointingPixelOmega[pointingId] = pixOmegas;

  GuessDefaultPointing(); // refresh
}


Double_t
TelescopeGeometry::GetElevation(TString pointingId)
  const
{
  if (pointingId == "")
    pointingId = fDefaultFOVId;
  const map<TString, Double_t>::const_iterator it = fTelPointingElevation.find(pointingId);
  if (it == fTelPointingElevation.end())
    return fElevation;
  return it->second;
}


Double_t
TelescopeGeometry::GetAzimuth(TString pointingId)
  const
{
  if (pointingId == "")
    pointingId = fDefaultFOVId;
  const map<TString, Double_t>::const_iterator it = fTelPointingAzimuth.find(pointingId);
  if (it == fTelPointingAzimuth.end())
    return fAzimuth;
  return it->second;
}


UShort_t
TelescopeGeometry::GetNumberOfPixels()
  const
{
  for (map<TString, Double_t>::const_iterator it = fTelPointingElevation.begin();
       it != fTelPointingElevation.end(); ++it) {
    const UShort_t nPix = fTelPointingPixelPhi.find(it->first)->second.size();
    if (nPix)
      return nPix;
  }
  // if reached here, we are dealing with veeery old ADSTs
  // --> return constant
  return fgNumberOfPixels;
}


unsigned int
TelescopeGeometry::GetRow(const unsigned int pixelId)
{
  return (pixelId - fgFirstPixel) % fgLastRow + fgFirstRow;
}


unsigned int
TelescopeGeometry::GetColumn(const unsigned int pixelId)
{
  return (pixelId - fgFirstPixel) / fgLastRow + fgFirstColumn;
}


vector<TString>
TelescopeGeometry::GetPointingIds()
  const
{
  vector<TString> pointingIds;

  for (map<TString, Double_t>::const_iterator pIt = fTelPointingElevation.begin();
       pIt != fTelPointingElevation.end(); ++pIt)
    pointingIds.push_back(pIt->first);

  return pointingIds;
}


bool
TelescopeGeometry::MergeTelescopeFrom(const TelescopeGeometry& source)
{
  bool retval = false;

  const vector<TString> srcPIds = source.GetPointingIds();
  for (vector<TString>::const_iterator pIt = srcPIds.begin();
       pIt != srcPIds.end(); ++pIt) {
    const TString& pId = *pIt;
    if (!HasPointing(pId)) {
      AddPointing(pId, source.GetAzimuth(pId), source.GetElevation(pId),
                  source.GetPixelsPhi(pId), source.GetPixelsOmega(pId));
      retval = true;
    }
  }

  GuessDefaultPointing(); // refresh

  return retval;
}


void
TelescopeGeometry::GuessDefaultPointing()
{
  // Infer the 'default' pointing by using the one that looks the
  // closest to the ground. While this is a hack, it's a guaranteed way
  // to stay backwards compatible with old data and conversely for old
  // EventBrowsers dealing with new data.
  const TString oldDefaultId = fDefaultFOVId;
  fDefaultFOVId = "";
  bool first = true;
  Double_t minElevation = 1.e99;
  for (map<TString, Double_t>::const_iterator it = fTelPointingElevation.begin();
       it != fTelPointingElevation.end(); ++it) {
    const TString& pointingId = it->first;
    const Double_t elevation = it->second;
    if (first || elevation < minElevation) {
      first = false;
      minElevation = elevation;
      fDefaultFOVId = pointingId;
    }
  }

  // Now, based on the potentially new default id, fill the old-style members.
  if (oldDefaultId == fDefaultFOVId)
    return;

  fPixelPhi   = fTelPointingPixelPhi[fDefaultFOVId];
  fPixelOmega = fTelPointingPixelOmega[fDefaultFOVId];
  fElevation  = fTelPointingElevation[fDefaultFOVId];
  fAzimuth    = fTelPointingAzimuth[fDefaultFOVId];
}

double
TelescopeGeometry::GetSolidAngle(const UInt_t iPix)
  const
{

  if (fSolidAngles.empty()) {
    const double standardSolidAngle = 580e-6; // fallback for old ADSTs
    return standardSolidAngle;
  }
  else {
    if (fSolidAngles.size() <= iPix) {
      cerr << "ERROR: Pixel id=" << iPix << " not available. nPix="
           << fSolidAngles.size() << endl;
      return 0;
    }
    else {
      return  fSolidAngles[iPix];
    }
  }
}
