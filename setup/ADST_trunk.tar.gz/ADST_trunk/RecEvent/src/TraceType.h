// $Id: TraceType.h 28131 2015-11-15 20:06:17Z darko $
#ifndef _adst_TraceType_h_
#define _adst_TraceType_h_


enum ESaturationStatus {
  eLowGainSaturated,
  eHighGainSaturated,
  eNoSaturation
};


enum ETraceType {
  eTotalTrace = 0,
  ePhotonTrace = 1,
  eElectronTrace = 2,
  eMuonTrace = 3,
  ePhotonFromMuonTrace = 4,
  eElectronFromMuonTrace = 5,
  eHadronTrace = 6,
  eTotalUnsaturatedTrace = 7,
  eUnknownTrace = 10,
  
  // components for universality parametrization
  eShowerLocalHadronPhotonTrace = 11,
  eShowerLocalHadronElectronTrace = 12,
};


#endif
