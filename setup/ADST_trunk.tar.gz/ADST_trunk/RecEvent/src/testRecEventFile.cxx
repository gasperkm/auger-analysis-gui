#include "RecEventFile.h"
#include "DetectorGeometry.h"
#include "RecEvent.h"
#include "FDEvent.h"
#include "SDEvent.h"

#include <TTree.h>
#include <TClass.h>

#include <vector>
#include <string>
#include <iostream>

using namespace std;


void CreateFile(const char* fname, RecEvent* recEvent);

void ReadFiles(const vector<string>& files);
void ReadFile(const string& files);
void FastBranchAccess(const vector<string>& files);
void CreateDetector(DetectorGeometry& det);
void TestMany();


int
main(int argc, char** argv)
{
  cout << " RecEvent-Release: " << RecEvent::fgRecEventRelease << "\n"
          " RecEvent-Version: " << RecEvent::GetVersion() << "\n"
          " RecEvent-CVSname: " << RecEvent::fgRecEventCVSname << "\n"
          " RecEvent-CVSid:   " << RecEvent::fgRecEventCVSid << "\n"
          " Test Many event " << endl;
  TestMany();
  cout << " - done -" << endl;

  // create test event
  RecEvent* recEvent = new RecEvent();
  recEvent->GetDetector();
  FDEvent eye1;
  FDEvent eye2;

  eye1.SetEyeId(1);
  eye2.SetEyeId(2);
  recEvent->AddEye(eye1);
  recEvent->AddEye(eye2);
  recEvent->GetSDEvent().SetId(9);
  cout << " create first RecEventFile " << endl;
  CreateFile("testing1.root", recEvent);
  cout << " - done -" << endl;

  // test reading
  cout << " read RecEventFile" << endl;
  ReadFile("testing1.root");
  cout << " - done -" << endl;

  // modify rec event
  recEvent->GetSDEvent().SetId(8);

  cout << " create second RecEventFile " << endl;
  CreateFile("testing2.root", recEvent);

  vector<string> files;
  files.push_back("testing1.root");
  files.push_back("testing2.root");

  cout << " read list of RecEventFile " << endl;
  ReadFiles(files);

  // test fast access of FD/SD header
  //    cout << " test access of FD/SD events " << endl;
  // FastBranchAccess (files);

  return 0;
}


void
CreateFile(const char* fname, RecEvent* recEvent)
{
  RecEventFile file(fname, RecEventFile::eWrite);
  file.SetBuffers(&recEvent);
  file.WriteEvent();
  recEvent->GetSDEvent().SetId(10);
  file.WriteEvent();
  recEvent->GetSDEvent().SetId(11);
  file.WriteEvent();
  DetectorGeometry g;
  CreateDetector(g);
  file.WriteDetectorGeometry(g);
  file.Close();
}


void
ReadFile(const string& file)
{
  RecEventFile recFile(file);
  DetectorGeometry* geom = new DetectorGeometry();
  RecEvent* rec = new RecEvent();
  recFile.SetBuffers(&rec);
  if (!recFile.ReadDetectorGeometry(*geom) == RecEventFile::eSuccess)
    cerr << " error reading DetectorGeometry " << endl;

  while (recFile.ReadNextEvent() == RecEventFile::eSuccess) {

    cout << " sd-id: " << rec->GetSDEvent().GetEventId() << endl;

      for (RecEvent::ConstEyeIterator iEye = rec->EyesBegin();
           iEye != rec->EyesEnd(); ++iEye) {
        cout << " eye no. " << iEye->GetEyeId()
             << "(" << geom->GetEye(iEye->GetEyeId()).GetName()
             << ")" << endl;
      }
      cout << endl;

  }
}


void
ReadFiles(const vector<string>& files)
{
  RecEventFile file(files);
  RecEvent* rec = new RecEvent();
  file.SetBuffers(&rec);
  int nFiles = file.GetNFiles();
  int nEntries = file.GetNEvents();

  cout << "  files: " << nFiles
       << "  entries: " << nEntries
       << endl;

  const vector<string>& file_list = file.GetFileList();
  for (vector<string>::const_iterator iFile = file_list.begin();
       iFile != file_list.end(); ++iFile) {
      cout << "  input-file: " << *iFile << endl;
  }

  TTree* eventTree = file.GetEventTree();
  cout << "  eventTree is of type: \"" << eventTree->Class()->GetName() << "\""
       << " and has: TTree::GetEntries() : " << eventTree->GetEntries()
       << endl;
  //eventTree->Print();
}


/*
void
FastBranchAccess(const vector<string>& files)
{
  FDHeader* fd = new FDHeader();

  RecEventFile file(files);

  TBranch* bfd = file.GetBranch("event.fFDEvents.fFdHeader.fTriggerNanoSec", fd);
  if (bfd) {
    int nFD = bfd->GetEntries();
    cout << "  nFDHeader: " << nFD << endl
  } else {
    cout << "  branch not found! " << endl;
  }
}*/


void
CreateDetector(DetectorGeometry& det)
{
  cout << " CreateDetector " << endl;

  int nx = 10;
  int ny = 10;

  for (int ix = 0; ix < nx; ++ix)
    for (int iy = 0; iy < ny; ++iy)
      det.SetStation(ix+iy*nx+1, 1.5*ix - 5., 1.5*iy - 5., 1.);

  det.AddEye(0, EyeGeometry(0., -6., 1., 10.*M_PI/180., 0, 0, std::string("eye1"), std::string("one")));
  det.AddEye(1, EyeGeometry(12., 0., 1., 90.*M_PI/180.,0,0, std::string("eye2"), std::string("two")));
  det.AddEye(2, EyeGeometry(0.,  12., 1., 180.*M_PI/180.,0,0, std::string("eye3"), std::string("three")));
  det.AddEye(3, EyeGeometry(-6., 0., 1., 270.*M_PI/180.,0,0, std::string("eye4"), std::string("four")));
}


void
TestMany()
{
  cout << "   TestMany() new " << endl;
  RecEvent* recEvent = new RecEvent();
  cout << "   done TestMany() new " << endl;
  RecEventFile file("testing1.root", RecEventFile::eWrite);

  cout << "   TestMany() SetBuffers " << endl;
  file.SetBuffers(&recEvent);
  cout << "   TestMany() done SetBuffers " << endl;

  for (int i = 0; i < 1000; ++i) {
    if (!(i%100))
      cout << " ===> " << i << endl;

    recEvent = new RecEvent();
    file.WriteEvent();
    delete recEvent;
  }
  file.Close();
}
