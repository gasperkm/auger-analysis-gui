#include "RecEvent.h"
#include "RecEventFile.h"
#include "DetectorGeometry.h"
#include "FileInfo.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

/*========================================================

   print some usage hints

==========================================================*/
void usage() {

  cout <<  "  Usage: RecSelectAndMerge <filelistName> <outputfileName> \n" 
       <<  "         where <filelistName> is the name of an ASCII file \n" 
       <<  "         containing the list of files to process (one file \n" 
       <<  "         per line)" << endl;

}  

/*========================================================

  AcceptEvent()

  dummy function for Event selection

  return value determines if event is stored (return true)
  or not (return false)

==========================================================*/
bool AcceptEvent(const RecEvent * theRecEvent) {

  // insert your selection here ...

  bool selected;

  // example: FD hybrids with Xmax in FOV

  if ( theRecEvent->GetInFoVHybrids(10.).size() <= 0 )
    selected = false;
  else
    selected = true;

  return selected;
}


/******************************************************************/
int main(int argc, char **argv) {

  if ( argc < 3 ) {
    usage();
    exit(1);
  }

  RecEvent * theRecEvent = new RecEvent();

  // open output file
  RecEventFile * mergedFile = new RecEventFile(argv[2],RecEventFile::eWrite); 
  mergedFile->SetBuffers(&theRecEvent);

  int nsel=0;
  int ntot=0;

  ifstream fileList; 	
  fileList.open(argv[1]);
  if ( !fileList.is_open() ) {
    cerr << " RecSelectAndMerge: - Error could not read file list " 
	 << argv[1] << "\n"
	 << "             exit ..." << endl;
    exit(1);
  }

  DetectorGeometry theGeometry;
  FileInfo theInfo;

  while (true) {

    string thisFile;

    if (fileList.good() ) {
      fileList >> thisFile;
      if ( fileList.eof() ) 
	break;
    }
    else
      break;

    cout << "==[RecSelectAndMerge]==> processing file " << thisFile <<endl; 

    RecEventFile dataFile(thisFile.c_str()); 
    dataFile.SetBuffers(&theRecEvent);

    if(dataFile.GetNEvents()<=0 ||
       !dataFile.ReadFileInfo(theInfo)==RecEventFile::eSuccess) 
      continue;

    // loop over events  
    ntot += dataFile.GetNEvents();

    while (dataFile.ReadNextEvent()==RecEventFile::eSuccess )
      if(AcceptEvent(theRecEvent)) {  
	nsel++;
	mergedFile->WriteEvent();
      }

    DetectorGeometry thisGeometry;
    
    if (dataFile.ReadDetectorGeometry(thisGeometry) == RecEventFile::eSuccess)
      if ( thisGeometry.GetNStations() > theGeometry.GetNStations() )
	theGeometry = thisGeometry;
  }    

  mergedFile->WriteDetectorGeometry(theGeometry);
  mergedFile->WriteFileInfo(theInfo);
  mergedFile->Close();

  cout << " total number of events:" << ntot << "\n"
       << " selected events:       " << nsel 
       << " (eps=" << 100.*(double)nsel/ (double) ntot << " %)" 
       << endl;
}

