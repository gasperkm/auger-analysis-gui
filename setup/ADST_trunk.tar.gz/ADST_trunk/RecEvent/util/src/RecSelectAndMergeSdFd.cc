#include "RecEvent.h"
#include "RecEventFile.h"
#include "DetectorGeometry.h"
#include "FileInfo.h"

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <cstdlib>
#include <assert.h>
using namespace std;

typedef vector<string>  StringVector;
typedef map<long,long>  TreeMap;

/*========================================================

   print some usage hints

==========================================================*/
void usage() {

  cout <<  "  Usage: RecSelectAndMergeFdSd <filelistName of FD files> <filelistName of SD files> <outputfileName> \n"
       <<  "         where <filelistName> is the name of an ASCII file \n"
       <<  "         containing the list of files to process (one file \n"
       <<  "         per line)" << endl;

}

/*========================================================

  ASCII progress bar

==========================================================*/
void ShowProgress(unsigned int currEvent, unsigned int nEvent) {

  const int nProgWidth=50;

  cout << flush;
  if ( currEvent != 0 ) {
    for ( int i=0;i<nProgWidth+8;i++)
      cout << "\b";
  }

  double percent = (double) currEvent/ (double) nEvent;
  int nBars = (int) ( percent*nProgWidth );

  cout << " |";
  for ( int i=0;i<nBars-1;i++)
    cout << "=";
  if ( nBars>0 )
    cout << ">";
  for ( int i=nBars;i<nProgWidth;i++)
    cout << " ";
  cout << "| " << setw(3) << (int) (percent*100.) << "%";
  cout << flush;

}

/*========================================================

  FilterEventFd()

  Removes eyes which do not have a trusted absolution
  calibration and no reconstructed energy

==========================================================*/
bool FilterEventFd(RecEvent * theRecEvent) {

  bool selected;

  // insert your selection here ...

  /* loose example cut:
    1 FD hybrids with Xmax in FOV
    2 At least one eye with reconstructed energy
    3 That eye should have an energy error smaller than 100 %
  */

  // ------- calbration constants --------
  // info from Jeff Brack (LL,CO,LM) and Rossella Caruso (LA)
  // HEAT still not calibrated...
  const unsigned int firstValidCalibrationDate[5]={41201,50602,70501,41201,999999};

  const unsigned int yymmdd = theRecEvent->GetYYMMDD();

  typedef vector<FDEvent> EyeVector;
  const EyeVector eyes = theRecEvent->GetFDEvents();

  EyeVector selectedEyes;
  for (EyeVector::const_iterator it=eyes.begin();it!=eyes.end();++it)
  {
    const FDEvent& fe = *it;
    int ieye = fe.GetEyeId()-1;
    if (fe.GetRecLevel()>=eHasEnergy && firstValidCalibrationDate[ieye] <= yymmdd)
      selectedEyes.push_back(fe);
  }

  selected = false;
  if (selectedEyes.size() > 0) {
    selected = true;
    theRecEvent->GetFDEvents() = selectedEyes;
  }

  return selected;
}


bool AcceptEventFd(const RecEvent * theRecEvent) {

  // insert your selection here ...

  bool selected;

  // example selection: at least one eye has reconstructed energy

  typedef vector<FDEvent> EyeVector;
  const EyeVector& eyes = theRecEvent->GetFDEvents();

  selected = false;
  for (EyeVector::const_iterator it=eyes.begin();it!=eyes.end();++it)
  {
    if (it->GetRecLevel()>= eHasEnergy)
      selected = true;
  }

  return selected;
}



bool AcceptEventSd(const RecEvent * theRecEvent) {

  // insert your selection here ...

  bool selected;

  selected = true;

  return selected;
}


/******************************************************************/
int main(int argc, char **argv) {

  if ( argc < 4 ) {
    usage();
    exit(1);
  }

  RecEvent * theRecEventFd = new RecEvent();
  RecEvent * theRecEventSd = new RecEvent();

  ifstream fileListSd, fileListFd;

  fileListFd.open(argv[1]);
  if ( !fileListFd.is_open() ) {
    cerr << " RecSelectAndMerge: - Error could not read file list "
         << argv[1] << "\n"
         << "             exit ..." << endl;
    exit(1);
  }
  fileListSd.open(argv[2]);
  if ( !fileListSd.is_open() ) {
    cerr << " RecSelectAndMerge: - Error could not read file list "
         << argv[2] << "\n"
         << "             exit ..." << endl;
    exit(1);
  }

  StringVector filesFd;
  while (true) {
    string thisFile;

    if (fileListFd.good() ) {
      fileListFd >> thisFile;
      if ( fileListFd.eof() ) break;
      filesFd.push_back(thisFile);
    }
    else
      break;
  }

  StringVector filesSd;
  while (true) {
    string thisFile;

    if (fileListSd.good() ) {
      fileListSd >> thisFile;
      if ( fileListSd.eof() ) break;
      filesSd.push_back(thisFile);
    }
    else
      break;
  }

  // FD
  cout << "==[RecSelectAndMergeFdSd]==> selection phase 1 - FD" << endl;

  TreeMap fdMap;
  RecEventFile fdInput(filesFd);
  fdInput.SetBuffers(&theRecEventFd);

  cout << "==[RecSelectAndMergeFdSd]==> selection phase 1: " << fdInput.GetNEvents() << " events"<<endl;

  // loop over events
  while (fdInput.ReadNextEvent()==RecEventFile::eSuccess ) {
    if(AcceptEventFd(theRecEventFd)) {
      long treeId = fdInput.GetCurrentEvent();
      long sdId   = theRecEventFd->GetSDEvent().GetEventId();
      fdMap[sdId] = treeId;
    }
    if (fdInput.GetCurrentEvent() % 100 == 0)
      ShowProgress(fdInput.GetCurrentEvent(),fdInput.GetNEvents());
  }
  ShowProgress(1,1); cout << endl;

  // SD
  cout << "==[RecSelectAndMergeFdSd]==> selection phase 2 - SD" << endl;

  TreeMap sdMap;
  RecEventFile sdInput(filesSd);
  sdInput.SetBuffers(&theRecEventSd);

  cout << "==[RecSelectAndMergeFdSd]==> selection phase 2: " << sdInput.GetNEvents() << " events"<<endl;

  // loop over events
  while (sdInput.ReadNextEvent()==RecEventFile::eSuccess ) {
    // only even care about SD events, if they are also in the FD set, then do selection
    if(fdMap.find(theRecEventSd->GetSDEvent().GetEventId())!=fdMap.end()
        && AcceptEventSd(theRecEventSd))
    {
      long treeId  = sdInput.GetCurrentEvent();
      long sdId    = theRecEventSd->GetSDEvent().GetEventId();
      sdMap[sdId] = treeId;
    }
    if (sdInput.GetCurrentEvent() % 100 == 0)
      ShowProgress(sdInput.GetCurrentEvent(),sdInput.GetNEvents());
  }
  ShowProgress(1,1); cout << endl;

  cout << "==[RecSelectAndMergeFdSd]==> writing phase: " << fdMap.size() << " events before eye filter" <<endl;
  // open output file
  RecEventFile mergedFile(argv[3],RecEventFile::eWrite);
  mergedFile.SetBuffers(&theRecEventFd); // we merge the SD event into the FD event

  long count = 0;
  for (TreeMap::iterator it=fdMap.begin();it!=fdMap.end();++it)
  {
    long sdId = it->first;
    long fdTreeId = it->second;

    fdInput.ReadEvent(fdTreeId);

    TreeMap::const_iterator sIt = sdMap.find(sdId);
    if (sIt!=sdMap.end()){
      long sdTreeId = sIt->second;
      sdInput.ReadEvent(sdTreeId);
      theRecEventFd->GetSDEvent() = theRecEventSd->GetSDEvent();
    }

    bool keepFilteredEvent = FilterEventFd(theRecEventFd);

    if (keepFilteredEvent)
      assert(mergedFile.WriteEvent()==RecEventFile::eSuccess);

    if (mergedFile.GetCurrentEvent() % 100 == 0)
      ShowProgress(count,fdMap.size());
    ++count;
  }
  ShowProgress(1,1); cout << endl;
  cout << "==[RecSelectAndMergeFdSd]==> writing phase: " << mergedFile.GetNEvents() << " events after eye filter" <<endl;

  // find most recent detector geometry in the input files
  cout << "==[RecSelectAndMergeFdSd]==> update detector geometry"<<endl;

  DetectorGeometry theGeometry;
  FileInfo theInfo;
  for (StringVector::const_iterator it=filesFd.begin();it!=filesFd.end();++it)
  {
    DetectorGeometry thisGeometry;
    RecEventFile dataFile(it->c_str());
    if (dataFile.ReadDetectorGeometry(thisGeometry) == RecEventFile::eSuccess)
      if ( thisGeometry.GetNStations() > theGeometry.GetNStations() )
        theGeometry = thisGeometry;
  }
  for (StringVector::const_iterator it=filesSd.begin();it!=filesSd.end();++it)
  {
    DetectorGeometry thisGeometry;
    RecEventFile dataFile(it->c_str());
    if (dataFile.ReadDetectorGeometry(thisGeometry) == RecEventFile::eSuccess)
      if ( thisGeometry.GetNStations() > theGeometry.GetNStations() )
        theGeometry = thisGeometry;
  }

  mergedFile.WriteDetectorGeometry(theGeometry);
  mergedFile.WriteFileInfo(theInfo);
  mergedFile.Close();

  cout << "merging to output file " << argv[3] << " complete" << endl;
}
