#include "RecEvent.h"
#include "RecEventFile.h"
#include "DetectorGeometry.h"
#include "FileInfo.h"
#include "EventInfo.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

/*========================================================

   print some usage hints

==========================================================*/
void usage() {

  cout <<  "\n  Usage:   compareADSTs reco1.root reco2.root\n" 
       <<  "           compareADSTs \"reco1*.root\" \"reco2*.root\" \n "
       <<  "          (tip: if N2<<N1, program runs faster with  \n "
       <<  "                compareADSTs reco2.root reco1.root)  \n "
       << endl;

}  

/*========================================================

   dummy analysis function

   called for each matching event

==========================================================*/
bool AnalyzeEvent(const RecEvent * recEvent1,const RecEvent * recEvent2) {

  return true;

}

/*========================================================

  ASCII progress bar

==========================================================*/
void ShowProgress(unsigned int currEvent, unsigned int nEvent) {
  
  const int nProgWidth=50;

  if ( currEvent != 0 ) {
    for ( int i=0;i<nProgWidth+8;i++)
      cout << "\b";
  }

  double percent = (double) currEvent/ (double) nEvent;
  int nBars = (int) ( percent*nProgWidth );

  cout << " |";
  for ( int i=0;i<nBars-1;i++)
    cout << "=";
  if ( nBars>0 )
    cout << ">";
  for ( int i=nBars;i<nProgWidth;i++)
    cout << " ";
  cout << "| " << setw(3) << (int) (percent*100.) << "%";
  cout << flush;

}


/*========================================================

   compareADSTs main()

==========================================================*/
int main(int argc, char **argv) {

  if ( argc != 3 ) {
    usage();
    exit(1);
  }

  EventInfo eventInfo;
  RecEventFile * dataFile[2];
  RecEvent * recEvent[2];

  for ( unsigned int i=0;i<2;i++) {
    dataFile[i] = new RecEventFile(argv[i+1]); 
    recEvent[i] = new RecEvent();
    dataFile[i]->SetBuffers(&(recEvent[i]));
    dataFile[i]->SetMicroADST(); 
    cout << " reading file " << argv[i+1] 
	 << " in MicroADST mode (Nev=" << dataFile[i]->GetNEvents() 
	 << ")" << endl;
  }

  int nMatch=0;
  int nAna=0;

  unsigned int nEv0=dataFile[0]->GetNEvents();

  for ( unsigned int i=0;i<nEv0;i++) {
    dataFile[0]->GetEventInfo(i,&eventInfo);
    UInt_t sdEventId = eventInfo.GetSDId();
    if ( dataFile[1]->SearchForSDEvent(sdEventId)==RecEventFile::eSuccess  ) {
      nMatch++;
      dataFile[0]->ReadEvent(i);
      if(AnalyzeEvent(recEvent[0],recEvent[1]))
      	nAna++;
    }
    if ( i%100 == 0 )
      ShowProgress(i,nEv0);
  }

  ShowProgress(nEv0,nEv0);

  cout << "\n " << nMatch << " matching event" 
       << (nMatch>1?"s":"") 
       << " out of " << dataFile[0]->GetNEvents() 
       << endl;
  cout << " " << nAna << " event" 
       << (nAna>1?"s":"") << " analyzed" << endl; 

}
